import FormalConjectures.ErdosProblems.«128»
import FormalConjectures.ErdosProblems.«263»
import FormalConjectures.ErdosProblems.«386»
import FormalConjectures.ErdosProblems.«828»
import TaskSupport

set_option maxHeartbeats 20000
namespace AttackBattery

-- ATTACK fc-8432eac9-erdos128-erdos-128-f573848738-counterexample-v1 simp
theorem probe_3_0 : ¬ (fcTypeOfName% "Erdos128.erdos_128") := by
  simp
#print axioms probe_3_0

-- ATTACK fc-8432eac9-erdos128-erdos-128-f573848738-counterexample-v1 simpa
theorem probe_3_1 : ¬ (fcTypeOfName% "Erdos128.erdos_128") := by
  simpa
#print axioms probe_3_1

-- ATTACK fc-8432eac9-erdos128-erdos-128-f573848738-counterexample-v1 simp_all
theorem probe_3_2 : ¬ (fcTypeOfName% "Erdos128.erdos_128") := by
  simp_all
#print axioms probe_3_2

-- ATTACK fc-8432eac9-erdos128-erdos-128-f573848738-counterexample-v1 aesop
theorem probe_3_3 : ¬ (fcTypeOfName% "Erdos128.erdos_128") := by
  aesop
#print axioms probe_3_3

-- ATTACK fc-8432eac9-erdos128-erdos-128-f573848738-counterexample-v1 omega
theorem probe_3_4 : ¬ (fcTypeOfName% "Erdos128.erdos_128") := by
  omega
#print axioms probe_3_4

-- ATTACK fc-8432eac9-erdos128-erdos-128-f573848738-counterexample-v1 norm_num
theorem probe_3_5 : ¬ (fcTypeOfName% "Erdos128.erdos_128") := by
  norm_num
#print axioms probe_3_5

-- ATTACK fc-8432eac9-erdos128-erdos-128-f573848738-counterexample-v1 decide
theorem probe_3_6 : ¬ (fcTypeOfName% "Erdos128.erdos_128") := by
  decide
#print axioms probe_3_6

-- ATTACK fc-8432eac9-erdos128-erdos-128-f573848738-counterexample-v1 native_decide
theorem probe_3_7 : ¬ (fcTypeOfName% "Erdos128.erdos_128") := by
  native_decide
#print axioms probe_3_7

-- ATTACK fc-8432eac9-erdos128-erdos-128-f573848738-counterexample-v1 true_intro
theorem probe_3_8 : ¬ (fcTypeOfName% "Erdos128.erdos_128") := by
  exact True.intro
#print axioms probe_3_8

-- ATTACK fc-8432eac9-erdos128-erdos-128-f573848738-counterexample-v1 false_elim_simp
theorem probe_3_9 : ¬ (fcTypeOfName% "Erdos128.erdos_128") := by
  apply False.elim
  simp_all
#print axioms probe_3_9

-- ATTACK fc-8432eac9-erdos128-erdos-128-f573848738-counterexample-v1 constructor
theorem probe_3_10 : ¬ (fcTypeOfName% "Erdos128.erdos_128") := by
  constructor
#print axioms probe_3_10

-- ATTACK fc-8432eac9-erdos128-erdos-128-f573848738-counterexample-v1 constructor_simp
theorem probe_3_11 : ¬ (fcTypeOfName% "Erdos128.erdos_128") := by
  constructor <;> simp
#print axioms probe_3_11

-- ATTACK fc-8432eac9-erdos128-erdos-128-f573848738-counterexample-v1 constructor_aesop
theorem probe_3_12 : ¬ (fcTypeOfName% "Erdos128.erdos_128") := by
  constructor <;> aesop
#print axioms probe_3_12

-- ATTACK fc-8432eac9-erdos128-erdos-128-f573848738-counterexample-v1 rfl
theorem probe_3_13 : ¬ (fcTypeOfName% "Erdos128.erdos_128") := by
  rfl
#print axioms probe_3_13

-- ATTACK fc-8432eac9-erdos128-erdos-128-f573848738-counterexample-v1 trivial
theorem probe_3_14 : ¬ (fcTypeOfName% "Erdos128.erdos_128") := by
  trivial
#print axioms probe_3_14

-- ATTACK fc-8432eac9-erdos128-erdos-128-f573848738-counterexample-v1 tauto
theorem probe_3_15 : ¬ (fcTypeOfName% "Erdos128.erdos_128") := by
  tauto
#print axioms probe_3_15

-- ATTACK fc-8432eac9-erdos128-erdos-128-f573848738-counterexample-v1 positivity
theorem probe_3_16 : ¬ (fcTypeOfName% "Erdos128.erdos_128") := by
  positivity
#print axioms probe_3_16

-- ATTACK fc-8432eac9-erdos128-erdos-128-f573848738-counterexample-v1 linarith
theorem probe_3_17 : ¬ (fcTypeOfName% "Erdos128.erdos_128") := by
  linarith
#print axioms probe_3_17

-- ATTACK fc-8432eac9-erdos128-erdos-128-f573848738-counterexample-v1 nlinarith
theorem probe_3_18 : ¬ (fcTypeOfName% "Erdos128.erdos_128") := by
  nlinarith
#print axioms probe_3_18

-- ATTACK fc-8432eac9-erdos128-erdos-128-f573848738-counterexample-v1 intros_simp_all
theorem probe_3_19 : ¬ (fcTypeOfName% "Erdos128.erdos_128") := by
  intros
  simp_all
#print axioms probe_3_19

-- ATTACK fc-8432eac9-erdos128-erdos-128-f573848738-counterexample-v1 intros_omega
theorem probe_3_20 : ¬ (fcTypeOfName% "Erdos128.erdos_128") := by
  intros
  omega
#print axioms probe_3_20

-- ATTACK fc-8432eac9-erdos128-erdos-128-f573848738-counterexample-v1 intros_norm_num
theorem probe_3_21 : ¬ (fcTypeOfName% "Erdos128.erdos_128") := by
  intros
  norm_num at *
#print axioms probe_3_21

-- ATTACK fc-8432eac9-erdos128-erdos-128-f573848738-counterexample-v1 intros_aesop
theorem probe_3_22 : ¬ (fcTypeOfName% "Erdos128.erdos_128") := by
  intros
  aesop
#print axioms probe_3_22

-- ATTACK fc-8432eac9-erdos128-erdos-128-f573848738-counterexample-v1 by_contra_simp_all
theorem probe_3_23 : ¬ (fcTypeOfName% "Erdos128.erdos_128") := by
  by_contra h
  simp_all
#print axioms probe_3_23

-- ATTACK fc-8432eac9-erdos128-erdos-128-f573848738-counterexample-v1 classical_simp_all
theorem probe_3_24 : ¬ (fcTypeOfName% "Erdos128.erdos_128") := by
  classical
  simp_all
#print axioms probe_3_24

-- ATTACK fc-8432eac9-erdos128-erdos-128-f573848738-counterexample-v1 classical_aesop
theorem probe_3_25 : ¬ (fcTypeOfName% "Erdos128.erdos_128") := by
  classical
  aesop
#print axioms probe_3_25

-- ATTACK fc-8432eac9-erdos128-erdos-128-f573848738-counterexample-v1 refine_pair_simp
theorem probe_3_26 : ¬ (fcTypeOfName% "Erdos128.erdos_128") := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_3_26

-- ATTACK fc-8432eac9-erdos128-erdos-128-f573848738-counterexample-v1 refine_pair_aesop
theorem probe_3_27 : ¬ (fcTypeOfName% "Erdos128.erdos_128") := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_3_27

-- ATTACK fc-8432eac9-erdos128-erdos-128-f573848738-counterexample-v1 use_zero_simp
theorem probe_3_28 : ¬ (fcTypeOfName% "Erdos128.erdos_128") := by
  use 0 <;> simp
#print axioms probe_3_28

-- ATTACK fc-8432eac9-erdos128-erdos-128-f573848738-counterexample-v1 use_one_simp
theorem probe_3_29 : ¬ (fcTypeOfName% "Erdos128.erdos_128") := by
  use 1 <;> simp
#print axioms probe_3_29

-- ATTACK fc-8432eac9-erdos128-erdos-128-f573848738-counterexample-v1 use_empty_simp
theorem probe_3_30 : ¬ (fcTypeOfName% "Erdos128.erdos_128") := by
  use ∅ <;> simp
#print axioms probe_3_30

-- ATTACK fc-8432eac9-erdos128-erdos-128-f573848738-counterexample-v1 assumption
theorem probe_3_31 : ¬ (fcTypeOfName% "Erdos128.erdos_128") := by
  assumption
#print axioms probe_3_31

-- ATTACK fc-8432eac9-erdos128-erdos-128-f573848738-counterexample-v1 infer_instance
theorem probe_3_32 : ¬ (fcTypeOfName% "Erdos128.erdos_128") := by
  infer_instance
#print axioms probe_3_32

-- ATTACK fc-8432eac9-erdos128-erdos-128-f573848738-counterexample-v1 contradiction
theorem probe_3_33 : ¬ (fcTypeOfName% "Erdos128.erdos_128") := by
  contradiction
#print axioms probe_3_33

-- ATTACK fc-8432eac9-erdos128-erdos-128-f573848738-counterexample-v1 solve_by_elim
theorem probe_3_34 : ¬ (fcTypeOfName% "Erdos128.erdos_128") := by
  solve_by_elim
#print axioms probe_3_34

-- ATTACK fc-8432eac9-erdos128-erdos-128-f573848738-counterexample-v1 first_order
theorem probe_3_35 : ¬ (fcTypeOfName% "Erdos128.erdos_128") := by
  first_order
#print axioms probe_3_35

-- ATTACK fc-8432eac9-erdos128-erdos-128-f573848738-counterexample-v1 grind
theorem probe_3_36 : ¬ (fcTypeOfName% "Erdos128.erdos_128") := by
  grind
#print axioms probe_3_36

-- ATTACK fc-8432eac9-erdos128-erdos-128-f573848738-counterexample-v1 exact_search
theorem probe_3_37 : ¬ (fcTypeOfName% "Erdos128.erdos_128") := by
  exact?
#print axioms probe_3_37

-- ATTACK fc-8432eac9-erdos128-erdos-128-f573848738-counterexample-v1 apply_search
theorem probe_3_38 : ¬ (fcTypeOfName% "Erdos128.erdos_128") := by
  apply?
#print axioms probe_3_38

-- ATTACK fc-8432eac9-erdos128-erdos-128-f573848738-counterexample-v1 library_search
theorem probe_3_39 : ¬ (fcTypeOfName% "Erdos128.erdos_128") := by
  library_search
#print axioms probe_3_39

-- ATTACK fc-8432eac9-erdos128-erdos-128-f573848738-counterexample-v1 aesop_search
theorem probe_3_40 : ¬ (fcTypeOfName% "Erdos128.erdos_128") := by
  aesop?
#print axioms probe_3_40

-- ATTACK fc-8432eac9-erdos128-erdos-128-f573848738-counterexample-v1 simp_search
theorem probe_3_41 : ¬ (fcTypeOfName% "Erdos128.erdos_128") := by
  simp?
#print axioms probe_3_41

-- ATTACK fc-8432eac9-parts-i-a5c90ee305-counterexample-v1 simp
theorem probe_3_42 : ¬ (fcTypeOfName% "Erdos263.erdos_263.parts.i") := by
  simp
#print axioms probe_3_42

-- ATTACK fc-8432eac9-parts-i-a5c90ee305-counterexample-v1 simpa
theorem probe_3_43 : ¬ (fcTypeOfName% "Erdos263.erdos_263.parts.i") := by
  simpa
#print axioms probe_3_43

-- ATTACK fc-8432eac9-parts-i-a5c90ee305-counterexample-v1 simp_all
theorem probe_3_44 : ¬ (fcTypeOfName% "Erdos263.erdos_263.parts.i") := by
  simp_all
#print axioms probe_3_44

-- ATTACK fc-8432eac9-parts-i-a5c90ee305-counterexample-v1 aesop
theorem probe_3_45 : ¬ (fcTypeOfName% "Erdos263.erdos_263.parts.i") := by
  aesop
#print axioms probe_3_45

-- ATTACK fc-8432eac9-parts-i-a5c90ee305-counterexample-v1 omega
theorem probe_3_46 : ¬ (fcTypeOfName% "Erdos263.erdos_263.parts.i") := by
  omega
#print axioms probe_3_46

-- ATTACK fc-8432eac9-parts-i-a5c90ee305-counterexample-v1 norm_num
theorem probe_3_47 : ¬ (fcTypeOfName% "Erdos263.erdos_263.parts.i") := by
  norm_num
#print axioms probe_3_47

-- ATTACK fc-8432eac9-parts-i-a5c90ee305-counterexample-v1 decide
theorem probe_3_48 : ¬ (fcTypeOfName% "Erdos263.erdos_263.parts.i") := by
  decide
#print axioms probe_3_48

-- ATTACK fc-8432eac9-parts-i-a5c90ee305-counterexample-v1 native_decide
theorem probe_3_49 : ¬ (fcTypeOfName% "Erdos263.erdos_263.parts.i") := by
  native_decide
#print axioms probe_3_49

-- ATTACK fc-8432eac9-parts-i-a5c90ee305-counterexample-v1 true_intro
theorem probe_3_50 : ¬ (fcTypeOfName% "Erdos263.erdos_263.parts.i") := by
  exact True.intro
#print axioms probe_3_50

-- ATTACK fc-8432eac9-parts-i-a5c90ee305-counterexample-v1 false_elim_simp
theorem probe_3_51 : ¬ (fcTypeOfName% "Erdos263.erdos_263.parts.i") := by
  apply False.elim
  simp_all
#print axioms probe_3_51

-- ATTACK fc-8432eac9-parts-i-a5c90ee305-counterexample-v1 constructor
theorem probe_3_52 : ¬ (fcTypeOfName% "Erdos263.erdos_263.parts.i") := by
  constructor
#print axioms probe_3_52

-- ATTACK fc-8432eac9-parts-i-a5c90ee305-counterexample-v1 constructor_simp
theorem probe_3_53 : ¬ (fcTypeOfName% "Erdos263.erdos_263.parts.i") := by
  constructor <;> simp
#print axioms probe_3_53

-- ATTACK fc-8432eac9-parts-i-a5c90ee305-counterexample-v1 constructor_aesop
theorem probe_3_54 : ¬ (fcTypeOfName% "Erdos263.erdos_263.parts.i") := by
  constructor <;> aesop
#print axioms probe_3_54

-- ATTACK fc-8432eac9-parts-i-a5c90ee305-counterexample-v1 rfl
theorem probe_3_55 : ¬ (fcTypeOfName% "Erdos263.erdos_263.parts.i") := by
  rfl
#print axioms probe_3_55

-- ATTACK fc-8432eac9-parts-i-a5c90ee305-counterexample-v1 trivial
theorem probe_3_56 : ¬ (fcTypeOfName% "Erdos263.erdos_263.parts.i") := by
  trivial
#print axioms probe_3_56

-- ATTACK fc-8432eac9-parts-i-a5c90ee305-counterexample-v1 tauto
theorem probe_3_57 : ¬ (fcTypeOfName% "Erdos263.erdos_263.parts.i") := by
  tauto
#print axioms probe_3_57

-- ATTACK fc-8432eac9-parts-i-a5c90ee305-counterexample-v1 positivity
theorem probe_3_58 : ¬ (fcTypeOfName% "Erdos263.erdos_263.parts.i") := by
  positivity
#print axioms probe_3_58

-- ATTACK fc-8432eac9-parts-i-a5c90ee305-counterexample-v1 linarith
theorem probe_3_59 : ¬ (fcTypeOfName% "Erdos263.erdos_263.parts.i") := by
  linarith
#print axioms probe_3_59

-- ATTACK fc-8432eac9-parts-i-a5c90ee305-counterexample-v1 nlinarith
theorem probe_3_60 : ¬ (fcTypeOfName% "Erdos263.erdos_263.parts.i") := by
  nlinarith
#print axioms probe_3_60

-- ATTACK fc-8432eac9-parts-i-a5c90ee305-counterexample-v1 intros_simp_all
theorem probe_3_61 : ¬ (fcTypeOfName% "Erdos263.erdos_263.parts.i") := by
  intros
  simp_all
#print axioms probe_3_61

-- ATTACK fc-8432eac9-parts-i-a5c90ee305-counterexample-v1 intros_omega
theorem probe_3_62 : ¬ (fcTypeOfName% "Erdos263.erdos_263.parts.i") := by
  intros
  omega
#print axioms probe_3_62

-- ATTACK fc-8432eac9-parts-i-a5c90ee305-counterexample-v1 intros_norm_num
theorem probe_3_63 : ¬ (fcTypeOfName% "Erdos263.erdos_263.parts.i") := by
  intros
  norm_num at *
#print axioms probe_3_63

-- ATTACK fc-8432eac9-parts-i-a5c90ee305-counterexample-v1 intros_aesop
theorem probe_3_64 : ¬ (fcTypeOfName% "Erdos263.erdos_263.parts.i") := by
  intros
  aesop
#print axioms probe_3_64

-- ATTACK fc-8432eac9-parts-i-a5c90ee305-counterexample-v1 by_contra_simp_all
theorem probe_3_65 : ¬ (fcTypeOfName% "Erdos263.erdos_263.parts.i") := by
  by_contra h
  simp_all
#print axioms probe_3_65

-- ATTACK fc-8432eac9-parts-i-a5c90ee305-counterexample-v1 classical_simp_all
theorem probe_3_66 : ¬ (fcTypeOfName% "Erdos263.erdos_263.parts.i") := by
  classical
  simp_all
#print axioms probe_3_66

-- ATTACK fc-8432eac9-parts-i-a5c90ee305-counterexample-v1 classical_aesop
theorem probe_3_67 : ¬ (fcTypeOfName% "Erdos263.erdos_263.parts.i") := by
  classical
  aesop
#print axioms probe_3_67

-- ATTACK fc-8432eac9-parts-i-a5c90ee305-counterexample-v1 refine_pair_simp
theorem probe_3_68 : ¬ (fcTypeOfName% "Erdos263.erdos_263.parts.i") := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_3_68

-- ATTACK fc-8432eac9-parts-i-a5c90ee305-counterexample-v1 refine_pair_aesop
theorem probe_3_69 : ¬ (fcTypeOfName% "Erdos263.erdos_263.parts.i") := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_3_69

-- ATTACK fc-8432eac9-parts-i-a5c90ee305-counterexample-v1 use_zero_simp
theorem probe_3_70 : ¬ (fcTypeOfName% "Erdos263.erdos_263.parts.i") := by
  use 0 <;> simp
#print axioms probe_3_70

-- ATTACK fc-8432eac9-parts-i-a5c90ee305-counterexample-v1 use_one_simp
theorem probe_3_71 : ¬ (fcTypeOfName% "Erdos263.erdos_263.parts.i") := by
  use 1 <;> simp
#print axioms probe_3_71

-- ATTACK fc-8432eac9-parts-i-a5c90ee305-counterexample-v1 use_empty_simp
theorem probe_3_72 : ¬ (fcTypeOfName% "Erdos263.erdos_263.parts.i") := by
  use ∅ <;> simp
#print axioms probe_3_72

-- ATTACK fc-8432eac9-parts-i-a5c90ee305-counterexample-v1 assumption
theorem probe_3_73 : ¬ (fcTypeOfName% "Erdos263.erdos_263.parts.i") := by
  assumption
#print axioms probe_3_73

-- ATTACK fc-8432eac9-parts-i-a5c90ee305-counterexample-v1 infer_instance
theorem probe_3_74 : ¬ (fcTypeOfName% "Erdos263.erdos_263.parts.i") := by
  infer_instance
#print axioms probe_3_74

-- ATTACK fc-8432eac9-parts-i-a5c90ee305-counterexample-v1 contradiction
theorem probe_3_75 : ¬ (fcTypeOfName% "Erdos263.erdos_263.parts.i") := by
  contradiction
#print axioms probe_3_75

-- ATTACK fc-8432eac9-parts-i-a5c90ee305-counterexample-v1 solve_by_elim
theorem probe_3_76 : ¬ (fcTypeOfName% "Erdos263.erdos_263.parts.i") := by
  solve_by_elim
#print axioms probe_3_76

-- ATTACK fc-8432eac9-parts-i-a5c90ee305-counterexample-v1 first_order
theorem probe_3_77 : ¬ (fcTypeOfName% "Erdos263.erdos_263.parts.i") := by
  first_order
#print axioms probe_3_77

-- ATTACK fc-8432eac9-parts-i-a5c90ee305-counterexample-v1 grind
theorem probe_3_78 : ¬ (fcTypeOfName% "Erdos263.erdos_263.parts.i") := by
  grind
#print axioms probe_3_78

-- ATTACK fc-8432eac9-parts-i-a5c90ee305-counterexample-v1 exact_search
theorem probe_3_79 : ¬ (fcTypeOfName% "Erdos263.erdos_263.parts.i") := by
  exact?
#print axioms probe_3_79

-- ATTACK fc-8432eac9-parts-i-a5c90ee305-counterexample-v1 apply_search
theorem probe_3_80 : ¬ (fcTypeOfName% "Erdos263.erdos_263.parts.i") := by
  apply?
#print axioms probe_3_80

-- ATTACK fc-8432eac9-parts-i-a5c90ee305-counterexample-v1 library_search
theorem probe_3_81 : ¬ (fcTypeOfName% "Erdos263.erdos_263.parts.i") := by
  library_search
#print axioms probe_3_81

-- ATTACK fc-8432eac9-parts-i-a5c90ee305-counterexample-v1 aesop_search
theorem probe_3_82 : ¬ (fcTypeOfName% "Erdos263.erdos_263.parts.i") := by
  aesop?
#print axioms probe_3_82

-- ATTACK fc-8432eac9-parts-i-a5c90ee305-counterexample-v1 simp_search
theorem probe_3_83 : ¬ (fcTypeOfName% "Erdos263.erdos_263.parts.i") := by
  simp?
#print axioms probe_3_83

-- ATTACK fc-8432eac9-variants-two-b6c2515417-counterexample-v1 simp
theorem probe_3_84 : ¬ (fcTypeOfName% "Erdos386.erdos_386.variants.two") := by
  simp
#print axioms probe_3_84

-- ATTACK fc-8432eac9-variants-two-b6c2515417-counterexample-v1 simpa
theorem probe_3_85 : ¬ (fcTypeOfName% "Erdos386.erdos_386.variants.two") := by
  simpa
#print axioms probe_3_85

-- ATTACK fc-8432eac9-variants-two-b6c2515417-counterexample-v1 simp_all
theorem probe_3_86 : ¬ (fcTypeOfName% "Erdos386.erdos_386.variants.two") := by
  simp_all
#print axioms probe_3_86

-- ATTACK fc-8432eac9-variants-two-b6c2515417-counterexample-v1 aesop
theorem probe_3_87 : ¬ (fcTypeOfName% "Erdos386.erdos_386.variants.two") := by
  aesop
#print axioms probe_3_87

-- ATTACK fc-8432eac9-variants-two-b6c2515417-counterexample-v1 omega
theorem probe_3_88 : ¬ (fcTypeOfName% "Erdos386.erdos_386.variants.two") := by
  omega
#print axioms probe_3_88

-- ATTACK fc-8432eac9-variants-two-b6c2515417-counterexample-v1 norm_num
theorem probe_3_89 : ¬ (fcTypeOfName% "Erdos386.erdos_386.variants.two") := by
  norm_num
#print axioms probe_3_89

-- ATTACK fc-8432eac9-variants-two-b6c2515417-counterexample-v1 decide
theorem probe_3_90 : ¬ (fcTypeOfName% "Erdos386.erdos_386.variants.two") := by
  decide
#print axioms probe_3_90

-- ATTACK fc-8432eac9-variants-two-b6c2515417-counterexample-v1 native_decide
theorem probe_3_91 : ¬ (fcTypeOfName% "Erdos386.erdos_386.variants.two") := by
  native_decide
#print axioms probe_3_91

-- ATTACK fc-8432eac9-variants-two-b6c2515417-counterexample-v1 true_intro
theorem probe_3_92 : ¬ (fcTypeOfName% "Erdos386.erdos_386.variants.two") := by
  exact True.intro
#print axioms probe_3_92

-- ATTACK fc-8432eac9-variants-two-b6c2515417-counterexample-v1 false_elim_simp
theorem probe_3_93 : ¬ (fcTypeOfName% "Erdos386.erdos_386.variants.two") := by
  apply False.elim
  simp_all
#print axioms probe_3_93

-- ATTACK fc-8432eac9-variants-two-b6c2515417-counterexample-v1 constructor
theorem probe_3_94 : ¬ (fcTypeOfName% "Erdos386.erdos_386.variants.two") := by
  constructor
#print axioms probe_3_94

-- ATTACK fc-8432eac9-variants-two-b6c2515417-counterexample-v1 constructor_simp
theorem probe_3_95 : ¬ (fcTypeOfName% "Erdos386.erdos_386.variants.two") := by
  constructor <;> simp
#print axioms probe_3_95

-- ATTACK fc-8432eac9-variants-two-b6c2515417-counterexample-v1 constructor_aesop
theorem probe_3_96 : ¬ (fcTypeOfName% "Erdos386.erdos_386.variants.two") := by
  constructor <;> aesop
#print axioms probe_3_96

-- ATTACK fc-8432eac9-variants-two-b6c2515417-counterexample-v1 rfl
theorem probe_3_97 : ¬ (fcTypeOfName% "Erdos386.erdos_386.variants.two") := by
  rfl
#print axioms probe_3_97

-- ATTACK fc-8432eac9-variants-two-b6c2515417-counterexample-v1 trivial
theorem probe_3_98 : ¬ (fcTypeOfName% "Erdos386.erdos_386.variants.two") := by
  trivial
#print axioms probe_3_98

-- ATTACK fc-8432eac9-variants-two-b6c2515417-counterexample-v1 tauto
theorem probe_3_99 : ¬ (fcTypeOfName% "Erdos386.erdos_386.variants.two") := by
  tauto
#print axioms probe_3_99

-- ATTACK fc-8432eac9-variants-two-b6c2515417-counterexample-v1 positivity
theorem probe_3_100 : ¬ (fcTypeOfName% "Erdos386.erdos_386.variants.two") := by
  positivity
#print axioms probe_3_100

-- ATTACK fc-8432eac9-variants-two-b6c2515417-counterexample-v1 linarith
theorem probe_3_101 : ¬ (fcTypeOfName% "Erdos386.erdos_386.variants.two") := by
  linarith
#print axioms probe_3_101

-- ATTACK fc-8432eac9-variants-two-b6c2515417-counterexample-v1 nlinarith
theorem probe_3_102 : ¬ (fcTypeOfName% "Erdos386.erdos_386.variants.two") := by
  nlinarith
#print axioms probe_3_102

-- ATTACK fc-8432eac9-variants-two-b6c2515417-counterexample-v1 intros_simp_all
theorem probe_3_103 : ¬ (fcTypeOfName% "Erdos386.erdos_386.variants.two") := by
  intros
  simp_all
#print axioms probe_3_103

-- ATTACK fc-8432eac9-variants-two-b6c2515417-counterexample-v1 intros_omega
theorem probe_3_104 : ¬ (fcTypeOfName% "Erdos386.erdos_386.variants.two") := by
  intros
  omega
#print axioms probe_3_104

-- ATTACK fc-8432eac9-variants-two-b6c2515417-counterexample-v1 intros_norm_num
theorem probe_3_105 : ¬ (fcTypeOfName% "Erdos386.erdos_386.variants.two") := by
  intros
  norm_num at *
#print axioms probe_3_105

-- ATTACK fc-8432eac9-variants-two-b6c2515417-counterexample-v1 intros_aesop
theorem probe_3_106 : ¬ (fcTypeOfName% "Erdos386.erdos_386.variants.two") := by
  intros
  aesop
#print axioms probe_3_106

-- ATTACK fc-8432eac9-variants-two-b6c2515417-counterexample-v1 by_contra_simp_all
theorem probe_3_107 : ¬ (fcTypeOfName% "Erdos386.erdos_386.variants.two") := by
  by_contra h
  simp_all
#print axioms probe_3_107

-- ATTACK fc-8432eac9-variants-two-b6c2515417-counterexample-v1 classical_simp_all
theorem probe_3_108 : ¬ (fcTypeOfName% "Erdos386.erdos_386.variants.two") := by
  classical
  simp_all
#print axioms probe_3_108

-- ATTACK fc-8432eac9-variants-two-b6c2515417-counterexample-v1 classical_aesop
theorem probe_3_109 : ¬ (fcTypeOfName% "Erdos386.erdos_386.variants.two") := by
  classical
  aesop
#print axioms probe_3_109

-- ATTACK fc-8432eac9-variants-two-b6c2515417-counterexample-v1 refine_pair_simp
theorem probe_3_110 : ¬ (fcTypeOfName% "Erdos386.erdos_386.variants.two") := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_3_110

-- ATTACK fc-8432eac9-variants-two-b6c2515417-counterexample-v1 refine_pair_aesop
theorem probe_3_111 : ¬ (fcTypeOfName% "Erdos386.erdos_386.variants.two") := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_3_111

-- ATTACK fc-8432eac9-variants-two-b6c2515417-counterexample-v1 use_zero_simp
theorem probe_3_112 : ¬ (fcTypeOfName% "Erdos386.erdos_386.variants.two") := by
  use 0 <;> simp
#print axioms probe_3_112

-- ATTACK fc-8432eac9-variants-two-b6c2515417-counterexample-v1 use_one_simp
theorem probe_3_113 : ¬ (fcTypeOfName% "Erdos386.erdos_386.variants.two") := by
  use 1 <;> simp
#print axioms probe_3_113

-- ATTACK fc-8432eac9-variants-two-b6c2515417-counterexample-v1 use_empty_simp
theorem probe_3_114 : ¬ (fcTypeOfName% "Erdos386.erdos_386.variants.two") := by
  use ∅ <;> simp
#print axioms probe_3_114

-- ATTACK fc-8432eac9-variants-two-b6c2515417-counterexample-v1 assumption
theorem probe_3_115 : ¬ (fcTypeOfName% "Erdos386.erdos_386.variants.two") := by
  assumption
#print axioms probe_3_115

-- ATTACK fc-8432eac9-variants-two-b6c2515417-counterexample-v1 infer_instance
theorem probe_3_116 : ¬ (fcTypeOfName% "Erdos386.erdos_386.variants.two") := by
  infer_instance
#print axioms probe_3_116

-- ATTACK fc-8432eac9-variants-two-b6c2515417-counterexample-v1 contradiction
theorem probe_3_117 : ¬ (fcTypeOfName% "Erdos386.erdos_386.variants.two") := by
  contradiction
#print axioms probe_3_117

-- ATTACK fc-8432eac9-variants-two-b6c2515417-counterexample-v1 solve_by_elim
theorem probe_3_118 : ¬ (fcTypeOfName% "Erdos386.erdos_386.variants.two") := by
  solve_by_elim
#print axioms probe_3_118

-- ATTACK fc-8432eac9-variants-two-b6c2515417-counterexample-v1 first_order
theorem probe_3_119 : ¬ (fcTypeOfName% "Erdos386.erdos_386.variants.two") := by
  first_order
#print axioms probe_3_119

-- ATTACK fc-8432eac9-variants-two-b6c2515417-counterexample-v1 grind
theorem probe_3_120 : ¬ (fcTypeOfName% "Erdos386.erdos_386.variants.two") := by
  grind
#print axioms probe_3_120

-- ATTACK fc-8432eac9-variants-two-b6c2515417-counterexample-v1 exact_search
theorem probe_3_121 : ¬ (fcTypeOfName% "Erdos386.erdos_386.variants.two") := by
  exact?
#print axioms probe_3_121

-- ATTACK fc-8432eac9-variants-two-b6c2515417-counterexample-v1 apply_search
theorem probe_3_122 : ¬ (fcTypeOfName% "Erdos386.erdos_386.variants.two") := by
  apply?
#print axioms probe_3_122

-- ATTACK fc-8432eac9-variants-two-b6c2515417-counterexample-v1 library_search
theorem probe_3_123 : ¬ (fcTypeOfName% "Erdos386.erdos_386.variants.two") := by
  library_search
#print axioms probe_3_123

-- ATTACK fc-8432eac9-variants-two-b6c2515417-counterexample-v1 aesop_search
theorem probe_3_124 : ¬ (fcTypeOfName% "Erdos386.erdos_386.variants.two") := by
  aesop?
#print axioms probe_3_124

-- ATTACK fc-8432eac9-variants-two-b6c2515417-counterexample-v1 simp_search
theorem probe_3_125 : ¬ (fcTypeOfName% "Erdos386.erdos_386.variants.two") := by
  simp?
#print axioms probe_3_125

-- ATTACK fc-8432eac9-erdos828-erdos-828-18f44de46a-counterexample-v1 simp
theorem probe_3_126 : ¬ (fcTypeOfName% "Erdos828.erdos_828") := by
  simp
#print axioms probe_3_126

-- ATTACK fc-8432eac9-erdos828-erdos-828-18f44de46a-counterexample-v1 simpa
theorem probe_3_127 : ¬ (fcTypeOfName% "Erdos828.erdos_828") := by
  simpa
#print axioms probe_3_127

-- ATTACK fc-8432eac9-erdos828-erdos-828-18f44de46a-counterexample-v1 simp_all
theorem probe_3_128 : ¬ (fcTypeOfName% "Erdos828.erdos_828") := by
  simp_all
#print axioms probe_3_128

-- ATTACK fc-8432eac9-erdos828-erdos-828-18f44de46a-counterexample-v1 aesop
theorem probe_3_129 : ¬ (fcTypeOfName% "Erdos828.erdos_828") := by
  aesop
#print axioms probe_3_129

-- ATTACK fc-8432eac9-erdos828-erdos-828-18f44de46a-counterexample-v1 omega
theorem probe_3_130 : ¬ (fcTypeOfName% "Erdos828.erdos_828") := by
  omega
#print axioms probe_3_130

-- ATTACK fc-8432eac9-erdos828-erdos-828-18f44de46a-counterexample-v1 norm_num
theorem probe_3_131 : ¬ (fcTypeOfName% "Erdos828.erdos_828") := by
  norm_num
#print axioms probe_3_131

-- ATTACK fc-8432eac9-erdos828-erdos-828-18f44de46a-counterexample-v1 decide
theorem probe_3_132 : ¬ (fcTypeOfName% "Erdos828.erdos_828") := by
  decide
#print axioms probe_3_132

-- ATTACK fc-8432eac9-erdos828-erdos-828-18f44de46a-counterexample-v1 native_decide
theorem probe_3_133 : ¬ (fcTypeOfName% "Erdos828.erdos_828") := by
  native_decide
#print axioms probe_3_133

-- ATTACK fc-8432eac9-erdos828-erdos-828-18f44de46a-counterexample-v1 true_intro
theorem probe_3_134 : ¬ (fcTypeOfName% "Erdos828.erdos_828") := by
  exact True.intro
#print axioms probe_3_134

-- ATTACK fc-8432eac9-erdos828-erdos-828-18f44de46a-counterexample-v1 false_elim_simp
theorem probe_3_135 : ¬ (fcTypeOfName% "Erdos828.erdos_828") := by
  apply False.elim
  simp_all
#print axioms probe_3_135

-- ATTACK fc-8432eac9-erdos828-erdos-828-18f44de46a-counterexample-v1 constructor
theorem probe_3_136 : ¬ (fcTypeOfName% "Erdos828.erdos_828") := by
  constructor
#print axioms probe_3_136

-- ATTACK fc-8432eac9-erdos828-erdos-828-18f44de46a-counterexample-v1 constructor_simp
theorem probe_3_137 : ¬ (fcTypeOfName% "Erdos828.erdos_828") := by
  constructor <;> simp
#print axioms probe_3_137

-- ATTACK fc-8432eac9-erdos828-erdos-828-18f44de46a-counterexample-v1 constructor_aesop
theorem probe_3_138 : ¬ (fcTypeOfName% "Erdos828.erdos_828") := by
  constructor <;> aesop
#print axioms probe_3_138

-- ATTACK fc-8432eac9-erdos828-erdos-828-18f44de46a-counterexample-v1 rfl
theorem probe_3_139 : ¬ (fcTypeOfName% "Erdos828.erdos_828") := by
  rfl
#print axioms probe_3_139

-- ATTACK fc-8432eac9-erdos828-erdos-828-18f44de46a-counterexample-v1 trivial
theorem probe_3_140 : ¬ (fcTypeOfName% "Erdos828.erdos_828") := by
  trivial
#print axioms probe_3_140

-- ATTACK fc-8432eac9-erdos828-erdos-828-18f44de46a-counterexample-v1 tauto
theorem probe_3_141 : ¬ (fcTypeOfName% "Erdos828.erdos_828") := by
  tauto
#print axioms probe_3_141

-- ATTACK fc-8432eac9-erdos828-erdos-828-18f44de46a-counterexample-v1 positivity
theorem probe_3_142 : ¬ (fcTypeOfName% "Erdos828.erdos_828") := by
  positivity
#print axioms probe_3_142

-- ATTACK fc-8432eac9-erdos828-erdos-828-18f44de46a-counterexample-v1 linarith
theorem probe_3_143 : ¬ (fcTypeOfName% "Erdos828.erdos_828") := by
  linarith
#print axioms probe_3_143

-- ATTACK fc-8432eac9-erdos828-erdos-828-18f44de46a-counterexample-v1 nlinarith
theorem probe_3_144 : ¬ (fcTypeOfName% "Erdos828.erdos_828") := by
  nlinarith
#print axioms probe_3_144

-- ATTACK fc-8432eac9-erdos828-erdos-828-18f44de46a-counterexample-v1 intros_simp_all
theorem probe_3_145 : ¬ (fcTypeOfName% "Erdos828.erdos_828") := by
  intros
  simp_all
#print axioms probe_3_145

-- ATTACK fc-8432eac9-erdos828-erdos-828-18f44de46a-counterexample-v1 intros_omega
theorem probe_3_146 : ¬ (fcTypeOfName% "Erdos828.erdos_828") := by
  intros
  omega
#print axioms probe_3_146

-- ATTACK fc-8432eac9-erdos828-erdos-828-18f44de46a-counterexample-v1 intros_norm_num
theorem probe_3_147 : ¬ (fcTypeOfName% "Erdos828.erdos_828") := by
  intros
  norm_num at *
#print axioms probe_3_147

-- ATTACK fc-8432eac9-erdos828-erdos-828-18f44de46a-counterexample-v1 intros_aesop
theorem probe_3_148 : ¬ (fcTypeOfName% "Erdos828.erdos_828") := by
  intros
  aesop
#print axioms probe_3_148

-- ATTACK fc-8432eac9-erdos828-erdos-828-18f44de46a-counterexample-v1 by_contra_simp_all
theorem probe_3_149 : ¬ (fcTypeOfName% "Erdos828.erdos_828") := by
  by_contra h
  simp_all
#print axioms probe_3_149

-- ATTACK fc-8432eac9-erdos828-erdos-828-18f44de46a-counterexample-v1 classical_simp_all
theorem probe_3_150 : ¬ (fcTypeOfName% "Erdos828.erdos_828") := by
  classical
  simp_all
#print axioms probe_3_150

-- ATTACK fc-8432eac9-erdos828-erdos-828-18f44de46a-counterexample-v1 classical_aesop
theorem probe_3_151 : ¬ (fcTypeOfName% "Erdos828.erdos_828") := by
  classical
  aesop
#print axioms probe_3_151

-- ATTACK fc-8432eac9-erdos828-erdos-828-18f44de46a-counterexample-v1 refine_pair_simp
theorem probe_3_152 : ¬ (fcTypeOfName% "Erdos828.erdos_828") := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_3_152

-- ATTACK fc-8432eac9-erdos828-erdos-828-18f44de46a-counterexample-v1 refine_pair_aesop
theorem probe_3_153 : ¬ (fcTypeOfName% "Erdos828.erdos_828") := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_3_153

-- ATTACK fc-8432eac9-erdos828-erdos-828-18f44de46a-counterexample-v1 use_zero_simp
theorem probe_3_154 : ¬ (fcTypeOfName% "Erdos828.erdos_828") := by
  use 0 <;> simp
#print axioms probe_3_154

-- ATTACK fc-8432eac9-erdos828-erdos-828-18f44de46a-counterexample-v1 use_one_simp
theorem probe_3_155 : ¬ (fcTypeOfName% "Erdos828.erdos_828") := by
  use 1 <;> simp
#print axioms probe_3_155

-- ATTACK fc-8432eac9-erdos828-erdos-828-18f44de46a-counterexample-v1 use_empty_simp
theorem probe_3_156 : ¬ (fcTypeOfName% "Erdos828.erdos_828") := by
  use ∅ <;> simp
#print axioms probe_3_156

-- ATTACK fc-8432eac9-erdos828-erdos-828-18f44de46a-counterexample-v1 assumption
theorem probe_3_157 : ¬ (fcTypeOfName% "Erdos828.erdos_828") := by
  assumption
#print axioms probe_3_157

-- ATTACK fc-8432eac9-erdos828-erdos-828-18f44de46a-counterexample-v1 infer_instance
theorem probe_3_158 : ¬ (fcTypeOfName% "Erdos828.erdos_828") := by
  infer_instance
#print axioms probe_3_158

-- ATTACK fc-8432eac9-erdos828-erdos-828-18f44de46a-counterexample-v1 contradiction
theorem probe_3_159 : ¬ (fcTypeOfName% "Erdos828.erdos_828") := by
  contradiction
#print axioms probe_3_159

-- ATTACK fc-8432eac9-erdos828-erdos-828-18f44de46a-counterexample-v1 solve_by_elim
theorem probe_3_160 : ¬ (fcTypeOfName% "Erdos828.erdos_828") := by
  solve_by_elim
#print axioms probe_3_160

-- ATTACK fc-8432eac9-erdos828-erdos-828-18f44de46a-counterexample-v1 first_order
theorem probe_3_161 : ¬ (fcTypeOfName% "Erdos828.erdos_828") := by
  first_order
#print axioms probe_3_161

-- ATTACK fc-8432eac9-erdos828-erdos-828-18f44de46a-counterexample-v1 grind
theorem probe_3_162 : ¬ (fcTypeOfName% "Erdos828.erdos_828") := by
  grind
#print axioms probe_3_162

-- ATTACK fc-8432eac9-erdos828-erdos-828-18f44de46a-counterexample-v1 exact_search
theorem probe_3_163 : ¬ (fcTypeOfName% "Erdos828.erdos_828") := by
  exact?
#print axioms probe_3_163

-- ATTACK fc-8432eac9-erdos828-erdos-828-18f44de46a-counterexample-v1 apply_search
theorem probe_3_164 : ¬ (fcTypeOfName% "Erdos828.erdos_828") := by
  apply?
#print axioms probe_3_164

-- ATTACK fc-8432eac9-erdos828-erdos-828-18f44de46a-counterexample-v1 library_search
theorem probe_3_165 : ¬ (fcTypeOfName% "Erdos828.erdos_828") := by
  library_search
#print axioms probe_3_165

-- ATTACK fc-8432eac9-erdos828-erdos-828-18f44de46a-counterexample-v1 aesop_search
theorem probe_3_166 : ¬ (fcTypeOfName% "Erdos828.erdos_828") := by
  aesop?
#print axioms probe_3_166

-- ATTACK fc-8432eac9-erdos828-erdos-828-18f44de46a-counterexample-v1 simp_search
theorem probe_3_167 : ¬ (fcTypeOfName% "Erdos828.erdos_828") := by
  simp?
#print axioms probe_3_167

end AttackBattery
