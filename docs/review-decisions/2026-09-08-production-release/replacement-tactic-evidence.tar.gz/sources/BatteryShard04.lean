import FormalConjectures.ErdosProblems.«128»
import FormalConjectures.ErdosProblems.«263»
import FormalConjectures.ErdosProblems.«386»
import FormalConjectures.ErdosProblems.«828»
import TaskSupport

set_option maxHeartbeats 20000
namespace AttackBattery

-- ATTACK fc-8432eac9-erdos128-erdos-128-a89f80bc76-formalized-v1 simp
theorem probe_4_0 : fcTypeOfName% "Erdos128.erdos_128" := by
  simp
#print axioms probe_4_0

-- ATTACK fc-8432eac9-erdos128-erdos-128-a89f80bc76-formalized-v1 simpa
theorem probe_4_1 : fcTypeOfName% "Erdos128.erdos_128" := by
  simpa
#print axioms probe_4_1

-- ATTACK fc-8432eac9-erdos128-erdos-128-a89f80bc76-formalized-v1 simp_all
theorem probe_4_2 : fcTypeOfName% "Erdos128.erdos_128" := by
  simp_all
#print axioms probe_4_2

-- ATTACK fc-8432eac9-erdos128-erdos-128-a89f80bc76-formalized-v1 aesop
theorem probe_4_3 : fcTypeOfName% "Erdos128.erdos_128" := by
  aesop
#print axioms probe_4_3

-- ATTACK fc-8432eac9-erdos128-erdos-128-a89f80bc76-formalized-v1 omega
theorem probe_4_4 : fcTypeOfName% "Erdos128.erdos_128" := by
  omega
#print axioms probe_4_4

-- ATTACK fc-8432eac9-erdos128-erdos-128-a89f80bc76-formalized-v1 norm_num
theorem probe_4_5 : fcTypeOfName% "Erdos128.erdos_128" := by
  norm_num
#print axioms probe_4_5

-- ATTACK fc-8432eac9-erdos128-erdos-128-a89f80bc76-formalized-v1 decide
theorem probe_4_6 : fcTypeOfName% "Erdos128.erdos_128" := by
  decide
#print axioms probe_4_6

-- ATTACK fc-8432eac9-erdos128-erdos-128-a89f80bc76-formalized-v1 native_decide
theorem probe_4_7 : fcTypeOfName% "Erdos128.erdos_128" := by
  native_decide
#print axioms probe_4_7

-- ATTACK fc-8432eac9-erdos128-erdos-128-a89f80bc76-formalized-v1 true_intro
theorem probe_4_8 : fcTypeOfName% "Erdos128.erdos_128" := by
  exact True.intro
#print axioms probe_4_8

-- ATTACK fc-8432eac9-erdos128-erdos-128-a89f80bc76-formalized-v1 false_elim_simp
theorem probe_4_9 : fcTypeOfName% "Erdos128.erdos_128" := by
  apply False.elim
  simp_all
#print axioms probe_4_9

-- ATTACK fc-8432eac9-erdos128-erdos-128-a89f80bc76-formalized-v1 constructor
theorem probe_4_10 : fcTypeOfName% "Erdos128.erdos_128" := by
  constructor
#print axioms probe_4_10

-- ATTACK fc-8432eac9-erdos128-erdos-128-a89f80bc76-formalized-v1 constructor_simp
theorem probe_4_11 : fcTypeOfName% "Erdos128.erdos_128" := by
  constructor <;> simp
#print axioms probe_4_11

-- ATTACK fc-8432eac9-erdos128-erdos-128-a89f80bc76-formalized-v1 constructor_aesop
theorem probe_4_12 : fcTypeOfName% "Erdos128.erdos_128" := by
  constructor <;> aesop
#print axioms probe_4_12

-- ATTACK fc-8432eac9-erdos128-erdos-128-a89f80bc76-formalized-v1 rfl
theorem probe_4_13 : fcTypeOfName% "Erdos128.erdos_128" := by
  rfl
#print axioms probe_4_13

-- ATTACK fc-8432eac9-erdos128-erdos-128-a89f80bc76-formalized-v1 trivial
theorem probe_4_14 : fcTypeOfName% "Erdos128.erdos_128" := by
  trivial
#print axioms probe_4_14

-- ATTACK fc-8432eac9-erdos128-erdos-128-a89f80bc76-formalized-v1 tauto
theorem probe_4_15 : fcTypeOfName% "Erdos128.erdos_128" := by
  tauto
#print axioms probe_4_15

-- ATTACK fc-8432eac9-erdos128-erdos-128-a89f80bc76-formalized-v1 positivity
theorem probe_4_16 : fcTypeOfName% "Erdos128.erdos_128" := by
  positivity
#print axioms probe_4_16

-- ATTACK fc-8432eac9-erdos128-erdos-128-a89f80bc76-formalized-v1 linarith
theorem probe_4_17 : fcTypeOfName% "Erdos128.erdos_128" := by
  linarith
#print axioms probe_4_17

-- ATTACK fc-8432eac9-erdos128-erdos-128-a89f80bc76-formalized-v1 nlinarith
theorem probe_4_18 : fcTypeOfName% "Erdos128.erdos_128" := by
  nlinarith
#print axioms probe_4_18

-- ATTACK fc-8432eac9-erdos128-erdos-128-a89f80bc76-formalized-v1 intros_simp_all
theorem probe_4_19 : fcTypeOfName% "Erdos128.erdos_128" := by
  intros
  simp_all
#print axioms probe_4_19

-- ATTACK fc-8432eac9-erdos128-erdos-128-a89f80bc76-formalized-v1 intros_omega
theorem probe_4_20 : fcTypeOfName% "Erdos128.erdos_128" := by
  intros
  omega
#print axioms probe_4_20

-- ATTACK fc-8432eac9-erdos128-erdos-128-a89f80bc76-formalized-v1 intros_norm_num
theorem probe_4_21 : fcTypeOfName% "Erdos128.erdos_128" := by
  intros
  norm_num at *
#print axioms probe_4_21

-- ATTACK fc-8432eac9-erdos128-erdos-128-a89f80bc76-formalized-v1 intros_aesop
theorem probe_4_22 : fcTypeOfName% "Erdos128.erdos_128" := by
  intros
  aesop
#print axioms probe_4_22

-- ATTACK fc-8432eac9-erdos128-erdos-128-a89f80bc76-formalized-v1 by_contra_simp_all
theorem probe_4_23 : fcTypeOfName% "Erdos128.erdos_128" := by
  by_contra h
  simp_all
#print axioms probe_4_23

-- ATTACK fc-8432eac9-erdos128-erdos-128-a89f80bc76-formalized-v1 classical_simp_all
theorem probe_4_24 : fcTypeOfName% "Erdos128.erdos_128" := by
  classical
  simp_all
#print axioms probe_4_24

-- ATTACK fc-8432eac9-erdos128-erdos-128-a89f80bc76-formalized-v1 classical_aesop
theorem probe_4_25 : fcTypeOfName% "Erdos128.erdos_128" := by
  classical
  aesop
#print axioms probe_4_25

-- ATTACK fc-8432eac9-erdos128-erdos-128-a89f80bc76-formalized-v1 refine_pair_simp
theorem probe_4_26 : fcTypeOfName% "Erdos128.erdos_128" := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_4_26

-- ATTACK fc-8432eac9-erdos128-erdos-128-a89f80bc76-formalized-v1 refine_pair_aesop
theorem probe_4_27 : fcTypeOfName% "Erdos128.erdos_128" := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_4_27

-- ATTACK fc-8432eac9-erdos128-erdos-128-a89f80bc76-formalized-v1 use_zero_simp
theorem probe_4_28 : fcTypeOfName% "Erdos128.erdos_128" := by
  use 0 <;> simp
#print axioms probe_4_28

-- ATTACK fc-8432eac9-erdos128-erdos-128-a89f80bc76-formalized-v1 use_one_simp
theorem probe_4_29 : fcTypeOfName% "Erdos128.erdos_128" := by
  use 1 <;> simp
#print axioms probe_4_29

-- ATTACK fc-8432eac9-erdos128-erdos-128-a89f80bc76-formalized-v1 use_empty_simp
theorem probe_4_30 : fcTypeOfName% "Erdos128.erdos_128" := by
  use ∅ <;> simp
#print axioms probe_4_30

-- ATTACK fc-8432eac9-erdos128-erdos-128-a89f80bc76-formalized-v1 assumption
theorem probe_4_31 : fcTypeOfName% "Erdos128.erdos_128" := by
  assumption
#print axioms probe_4_31

-- ATTACK fc-8432eac9-erdos128-erdos-128-a89f80bc76-formalized-v1 infer_instance
theorem probe_4_32 : fcTypeOfName% "Erdos128.erdos_128" := by
  infer_instance
#print axioms probe_4_32

-- ATTACK fc-8432eac9-erdos128-erdos-128-a89f80bc76-formalized-v1 contradiction
theorem probe_4_33 : fcTypeOfName% "Erdos128.erdos_128" := by
  contradiction
#print axioms probe_4_33

-- ATTACK fc-8432eac9-erdos128-erdos-128-a89f80bc76-formalized-v1 solve_by_elim
theorem probe_4_34 : fcTypeOfName% "Erdos128.erdos_128" := by
  solve_by_elim
#print axioms probe_4_34

-- ATTACK fc-8432eac9-erdos128-erdos-128-a89f80bc76-formalized-v1 first_order
theorem probe_4_35 : fcTypeOfName% "Erdos128.erdos_128" := by
  first_order
#print axioms probe_4_35

-- ATTACK fc-8432eac9-erdos128-erdos-128-a89f80bc76-formalized-v1 grind
theorem probe_4_36 : fcTypeOfName% "Erdos128.erdos_128" := by
  grind
#print axioms probe_4_36

-- ATTACK fc-8432eac9-erdos128-erdos-128-a89f80bc76-formalized-v1 exact_search
theorem probe_4_37 : fcTypeOfName% "Erdos128.erdos_128" := by
  exact?
#print axioms probe_4_37

-- ATTACK fc-8432eac9-erdos128-erdos-128-a89f80bc76-formalized-v1 apply_search
theorem probe_4_38 : fcTypeOfName% "Erdos128.erdos_128" := by
  apply?
#print axioms probe_4_38

-- ATTACK fc-8432eac9-erdos128-erdos-128-a89f80bc76-formalized-v1 library_search
theorem probe_4_39 : fcTypeOfName% "Erdos128.erdos_128" := by
  library_search
#print axioms probe_4_39

-- ATTACK fc-8432eac9-erdos128-erdos-128-a89f80bc76-formalized-v1 aesop_search
theorem probe_4_40 : fcTypeOfName% "Erdos128.erdos_128" := by
  aesop?
#print axioms probe_4_40

-- ATTACK fc-8432eac9-erdos128-erdos-128-a89f80bc76-formalized-v1 simp_search
theorem probe_4_41 : fcTypeOfName% "Erdos128.erdos_128" := by
  simp?
#print axioms probe_4_41

-- ATTACK fc-8432eac9-parts-i-93d641bef3-formalized-v1 simp
theorem probe_4_42 : fcTypeOfName% "Erdos263.erdos_263.parts.i" := by
  simp
#print axioms probe_4_42

-- ATTACK fc-8432eac9-parts-i-93d641bef3-formalized-v1 simpa
theorem probe_4_43 : fcTypeOfName% "Erdos263.erdos_263.parts.i" := by
  simpa
#print axioms probe_4_43

-- ATTACK fc-8432eac9-parts-i-93d641bef3-formalized-v1 simp_all
theorem probe_4_44 : fcTypeOfName% "Erdos263.erdos_263.parts.i" := by
  simp_all
#print axioms probe_4_44

-- ATTACK fc-8432eac9-parts-i-93d641bef3-formalized-v1 aesop
theorem probe_4_45 : fcTypeOfName% "Erdos263.erdos_263.parts.i" := by
  aesop
#print axioms probe_4_45

-- ATTACK fc-8432eac9-parts-i-93d641bef3-formalized-v1 omega
theorem probe_4_46 : fcTypeOfName% "Erdos263.erdos_263.parts.i" := by
  omega
#print axioms probe_4_46

-- ATTACK fc-8432eac9-parts-i-93d641bef3-formalized-v1 norm_num
theorem probe_4_47 : fcTypeOfName% "Erdos263.erdos_263.parts.i" := by
  norm_num
#print axioms probe_4_47

-- ATTACK fc-8432eac9-parts-i-93d641bef3-formalized-v1 decide
theorem probe_4_48 : fcTypeOfName% "Erdos263.erdos_263.parts.i" := by
  decide
#print axioms probe_4_48

-- ATTACK fc-8432eac9-parts-i-93d641bef3-formalized-v1 native_decide
theorem probe_4_49 : fcTypeOfName% "Erdos263.erdos_263.parts.i" := by
  native_decide
#print axioms probe_4_49

-- ATTACK fc-8432eac9-parts-i-93d641bef3-formalized-v1 true_intro
theorem probe_4_50 : fcTypeOfName% "Erdos263.erdos_263.parts.i" := by
  exact True.intro
#print axioms probe_4_50

-- ATTACK fc-8432eac9-parts-i-93d641bef3-formalized-v1 false_elim_simp
theorem probe_4_51 : fcTypeOfName% "Erdos263.erdos_263.parts.i" := by
  apply False.elim
  simp_all
#print axioms probe_4_51

-- ATTACK fc-8432eac9-parts-i-93d641bef3-formalized-v1 constructor
theorem probe_4_52 : fcTypeOfName% "Erdos263.erdos_263.parts.i" := by
  constructor
#print axioms probe_4_52

-- ATTACK fc-8432eac9-parts-i-93d641bef3-formalized-v1 constructor_simp
theorem probe_4_53 : fcTypeOfName% "Erdos263.erdos_263.parts.i" := by
  constructor <;> simp
#print axioms probe_4_53

-- ATTACK fc-8432eac9-parts-i-93d641bef3-formalized-v1 constructor_aesop
theorem probe_4_54 : fcTypeOfName% "Erdos263.erdos_263.parts.i" := by
  constructor <;> aesop
#print axioms probe_4_54

-- ATTACK fc-8432eac9-parts-i-93d641bef3-formalized-v1 rfl
theorem probe_4_55 : fcTypeOfName% "Erdos263.erdos_263.parts.i" := by
  rfl
#print axioms probe_4_55

-- ATTACK fc-8432eac9-parts-i-93d641bef3-formalized-v1 trivial
theorem probe_4_56 : fcTypeOfName% "Erdos263.erdos_263.parts.i" := by
  trivial
#print axioms probe_4_56

-- ATTACK fc-8432eac9-parts-i-93d641bef3-formalized-v1 tauto
theorem probe_4_57 : fcTypeOfName% "Erdos263.erdos_263.parts.i" := by
  tauto
#print axioms probe_4_57

-- ATTACK fc-8432eac9-parts-i-93d641bef3-formalized-v1 positivity
theorem probe_4_58 : fcTypeOfName% "Erdos263.erdos_263.parts.i" := by
  positivity
#print axioms probe_4_58

-- ATTACK fc-8432eac9-parts-i-93d641bef3-formalized-v1 linarith
theorem probe_4_59 : fcTypeOfName% "Erdos263.erdos_263.parts.i" := by
  linarith
#print axioms probe_4_59

-- ATTACK fc-8432eac9-parts-i-93d641bef3-formalized-v1 nlinarith
theorem probe_4_60 : fcTypeOfName% "Erdos263.erdos_263.parts.i" := by
  nlinarith
#print axioms probe_4_60

-- ATTACK fc-8432eac9-parts-i-93d641bef3-formalized-v1 intros_simp_all
theorem probe_4_61 : fcTypeOfName% "Erdos263.erdos_263.parts.i" := by
  intros
  simp_all
#print axioms probe_4_61

-- ATTACK fc-8432eac9-parts-i-93d641bef3-formalized-v1 intros_omega
theorem probe_4_62 : fcTypeOfName% "Erdos263.erdos_263.parts.i" := by
  intros
  omega
#print axioms probe_4_62

-- ATTACK fc-8432eac9-parts-i-93d641bef3-formalized-v1 intros_norm_num
theorem probe_4_63 : fcTypeOfName% "Erdos263.erdos_263.parts.i" := by
  intros
  norm_num at *
#print axioms probe_4_63

-- ATTACK fc-8432eac9-parts-i-93d641bef3-formalized-v1 intros_aesop
theorem probe_4_64 : fcTypeOfName% "Erdos263.erdos_263.parts.i" := by
  intros
  aesop
#print axioms probe_4_64

-- ATTACK fc-8432eac9-parts-i-93d641bef3-formalized-v1 by_contra_simp_all
theorem probe_4_65 : fcTypeOfName% "Erdos263.erdos_263.parts.i" := by
  by_contra h
  simp_all
#print axioms probe_4_65

-- ATTACK fc-8432eac9-parts-i-93d641bef3-formalized-v1 classical_simp_all
theorem probe_4_66 : fcTypeOfName% "Erdos263.erdos_263.parts.i" := by
  classical
  simp_all
#print axioms probe_4_66

-- ATTACK fc-8432eac9-parts-i-93d641bef3-formalized-v1 classical_aesop
theorem probe_4_67 : fcTypeOfName% "Erdos263.erdos_263.parts.i" := by
  classical
  aesop
#print axioms probe_4_67

-- ATTACK fc-8432eac9-parts-i-93d641bef3-formalized-v1 refine_pair_simp
theorem probe_4_68 : fcTypeOfName% "Erdos263.erdos_263.parts.i" := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_4_68

-- ATTACK fc-8432eac9-parts-i-93d641bef3-formalized-v1 refine_pair_aesop
theorem probe_4_69 : fcTypeOfName% "Erdos263.erdos_263.parts.i" := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_4_69

-- ATTACK fc-8432eac9-parts-i-93d641bef3-formalized-v1 use_zero_simp
theorem probe_4_70 : fcTypeOfName% "Erdos263.erdos_263.parts.i" := by
  use 0 <;> simp
#print axioms probe_4_70

-- ATTACK fc-8432eac9-parts-i-93d641bef3-formalized-v1 use_one_simp
theorem probe_4_71 : fcTypeOfName% "Erdos263.erdos_263.parts.i" := by
  use 1 <;> simp
#print axioms probe_4_71

-- ATTACK fc-8432eac9-parts-i-93d641bef3-formalized-v1 use_empty_simp
theorem probe_4_72 : fcTypeOfName% "Erdos263.erdos_263.parts.i" := by
  use ∅ <;> simp
#print axioms probe_4_72

-- ATTACK fc-8432eac9-parts-i-93d641bef3-formalized-v1 assumption
theorem probe_4_73 : fcTypeOfName% "Erdos263.erdos_263.parts.i" := by
  assumption
#print axioms probe_4_73

-- ATTACK fc-8432eac9-parts-i-93d641bef3-formalized-v1 infer_instance
theorem probe_4_74 : fcTypeOfName% "Erdos263.erdos_263.parts.i" := by
  infer_instance
#print axioms probe_4_74

-- ATTACK fc-8432eac9-parts-i-93d641bef3-formalized-v1 contradiction
theorem probe_4_75 : fcTypeOfName% "Erdos263.erdos_263.parts.i" := by
  contradiction
#print axioms probe_4_75

-- ATTACK fc-8432eac9-parts-i-93d641bef3-formalized-v1 solve_by_elim
theorem probe_4_76 : fcTypeOfName% "Erdos263.erdos_263.parts.i" := by
  solve_by_elim
#print axioms probe_4_76

-- ATTACK fc-8432eac9-parts-i-93d641bef3-formalized-v1 first_order
theorem probe_4_77 : fcTypeOfName% "Erdos263.erdos_263.parts.i" := by
  first_order
#print axioms probe_4_77

-- ATTACK fc-8432eac9-parts-i-93d641bef3-formalized-v1 grind
theorem probe_4_78 : fcTypeOfName% "Erdos263.erdos_263.parts.i" := by
  grind
#print axioms probe_4_78

-- ATTACK fc-8432eac9-parts-i-93d641bef3-formalized-v1 exact_search
theorem probe_4_79 : fcTypeOfName% "Erdos263.erdos_263.parts.i" := by
  exact?
#print axioms probe_4_79

-- ATTACK fc-8432eac9-parts-i-93d641bef3-formalized-v1 apply_search
theorem probe_4_80 : fcTypeOfName% "Erdos263.erdos_263.parts.i" := by
  apply?
#print axioms probe_4_80

-- ATTACK fc-8432eac9-parts-i-93d641bef3-formalized-v1 library_search
theorem probe_4_81 : fcTypeOfName% "Erdos263.erdos_263.parts.i" := by
  library_search
#print axioms probe_4_81

-- ATTACK fc-8432eac9-parts-i-93d641bef3-formalized-v1 aesop_search
theorem probe_4_82 : fcTypeOfName% "Erdos263.erdos_263.parts.i" := by
  aesop?
#print axioms probe_4_82

-- ATTACK fc-8432eac9-parts-i-93d641bef3-formalized-v1 simp_search
theorem probe_4_83 : fcTypeOfName% "Erdos263.erdos_263.parts.i" := by
  simp?
#print axioms probe_4_83

-- ATTACK fc-8432eac9-variants-two-95f97acfa5-formalized-v1 simp
theorem probe_4_84 : fcTypeOfName% "Erdos386.erdos_386.variants.two" := by
  simp
#print axioms probe_4_84

-- ATTACK fc-8432eac9-variants-two-95f97acfa5-formalized-v1 simpa
theorem probe_4_85 : fcTypeOfName% "Erdos386.erdos_386.variants.two" := by
  simpa
#print axioms probe_4_85

-- ATTACK fc-8432eac9-variants-two-95f97acfa5-formalized-v1 simp_all
theorem probe_4_86 : fcTypeOfName% "Erdos386.erdos_386.variants.two" := by
  simp_all
#print axioms probe_4_86

-- ATTACK fc-8432eac9-variants-two-95f97acfa5-formalized-v1 aesop
theorem probe_4_87 : fcTypeOfName% "Erdos386.erdos_386.variants.two" := by
  aesop
#print axioms probe_4_87

-- ATTACK fc-8432eac9-variants-two-95f97acfa5-formalized-v1 omega
theorem probe_4_88 : fcTypeOfName% "Erdos386.erdos_386.variants.two" := by
  omega
#print axioms probe_4_88

-- ATTACK fc-8432eac9-variants-two-95f97acfa5-formalized-v1 norm_num
theorem probe_4_89 : fcTypeOfName% "Erdos386.erdos_386.variants.two" := by
  norm_num
#print axioms probe_4_89

-- ATTACK fc-8432eac9-variants-two-95f97acfa5-formalized-v1 decide
theorem probe_4_90 : fcTypeOfName% "Erdos386.erdos_386.variants.two" := by
  decide
#print axioms probe_4_90

-- ATTACK fc-8432eac9-variants-two-95f97acfa5-formalized-v1 native_decide
theorem probe_4_91 : fcTypeOfName% "Erdos386.erdos_386.variants.two" := by
  native_decide
#print axioms probe_4_91

-- ATTACK fc-8432eac9-variants-two-95f97acfa5-formalized-v1 true_intro
theorem probe_4_92 : fcTypeOfName% "Erdos386.erdos_386.variants.two" := by
  exact True.intro
#print axioms probe_4_92

-- ATTACK fc-8432eac9-variants-two-95f97acfa5-formalized-v1 false_elim_simp
theorem probe_4_93 : fcTypeOfName% "Erdos386.erdos_386.variants.two" := by
  apply False.elim
  simp_all
#print axioms probe_4_93

-- ATTACK fc-8432eac9-variants-two-95f97acfa5-formalized-v1 constructor
theorem probe_4_94 : fcTypeOfName% "Erdos386.erdos_386.variants.two" := by
  constructor
#print axioms probe_4_94

-- ATTACK fc-8432eac9-variants-two-95f97acfa5-formalized-v1 constructor_simp
theorem probe_4_95 : fcTypeOfName% "Erdos386.erdos_386.variants.two" := by
  constructor <;> simp
#print axioms probe_4_95

-- ATTACK fc-8432eac9-variants-two-95f97acfa5-formalized-v1 constructor_aesop
theorem probe_4_96 : fcTypeOfName% "Erdos386.erdos_386.variants.two" := by
  constructor <;> aesop
#print axioms probe_4_96

-- ATTACK fc-8432eac9-variants-two-95f97acfa5-formalized-v1 rfl
theorem probe_4_97 : fcTypeOfName% "Erdos386.erdos_386.variants.two" := by
  rfl
#print axioms probe_4_97

-- ATTACK fc-8432eac9-variants-two-95f97acfa5-formalized-v1 trivial
theorem probe_4_98 : fcTypeOfName% "Erdos386.erdos_386.variants.two" := by
  trivial
#print axioms probe_4_98

-- ATTACK fc-8432eac9-variants-two-95f97acfa5-formalized-v1 tauto
theorem probe_4_99 : fcTypeOfName% "Erdos386.erdos_386.variants.two" := by
  tauto
#print axioms probe_4_99

-- ATTACK fc-8432eac9-variants-two-95f97acfa5-formalized-v1 positivity
theorem probe_4_100 : fcTypeOfName% "Erdos386.erdos_386.variants.two" := by
  positivity
#print axioms probe_4_100

-- ATTACK fc-8432eac9-variants-two-95f97acfa5-formalized-v1 linarith
theorem probe_4_101 : fcTypeOfName% "Erdos386.erdos_386.variants.two" := by
  linarith
#print axioms probe_4_101

-- ATTACK fc-8432eac9-variants-two-95f97acfa5-formalized-v1 nlinarith
theorem probe_4_102 : fcTypeOfName% "Erdos386.erdos_386.variants.two" := by
  nlinarith
#print axioms probe_4_102

-- ATTACK fc-8432eac9-variants-two-95f97acfa5-formalized-v1 intros_simp_all
theorem probe_4_103 : fcTypeOfName% "Erdos386.erdos_386.variants.two" := by
  intros
  simp_all
#print axioms probe_4_103

-- ATTACK fc-8432eac9-variants-two-95f97acfa5-formalized-v1 intros_omega
theorem probe_4_104 : fcTypeOfName% "Erdos386.erdos_386.variants.two" := by
  intros
  omega
#print axioms probe_4_104

-- ATTACK fc-8432eac9-variants-two-95f97acfa5-formalized-v1 intros_norm_num
theorem probe_4_105 : fcTypeOfName% "Erdos386.erdos_386.variants.two" := by
  intros
  norm_num at *
#print axioms probe_4_105

-- ATTACK fc-8432eac9-variants-two-95f97acfa5-formalized-v1 intros_aesop
theorem probe_4_106 : fcTypeOfName% "Erdos386.erdos_386.variants.two" := by
  intros
  aesop
#print axioms probe_4_106

-- ATTACK fc-8432eac9-variants-two-95f97acfa5-formalized-v1 by_contra_simp_all
theorem probe_4_107 : fcTypeOfName% "Erdos386.erdos_386.variants.two" := by
  by_contra h
  simp_all
#print axioms probe_4_107

-- ATTACK fc-8432eac9-variants-two-95f97acfa5-formalized-v1 classical_simp_all
theorem probe_4_108 : fcTypeOfName% "Erdos386.erdos_386.variants.two" := by
  classical
  simp_all
#print axioms probe_4_108

-- ATTACK fc-8432eac9-variants-two-95f97acfa5-formalized-v1 classical_aesop
theorem probe_4_109 : fcTypeOfName% "Erdos386.erdos_386.variants.two" := by
  classical
  aesop
#print axioms probe_4_109

-- ATTACK fc-8432eac9-variants-two-95f97acfa5-formalized-v1 refine_pair_simp
theorem probe_4_110 : fcTypeOfName% "Erdos386.erdos_386.variants.two" := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_4_110

-- ATTACK fc-8432eac9-variants-two-95f97acfa5-formalized-v1 refine_pair_aesop
theorem probe_4_111 : fcTypeOfName% "Erdos386.erdos_386.variants.two" := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_4_111

-- ATTACK fc-8432eac9-variants-two-95f97acfa5-formalized-v1 use_zero_simp
theorem probe_4_112 : fcTypeOfName% "Erdos386.erdos_386.variants.two" := by
  use 0 <;> simp
#print axioms probe_4_112

-- ATTACK fc-8432eac9-variants-two-95f97acfa5-formalized-v1 use_one_simp
theorem probe_4_113 : fcTypeOfName% "Erdos386.erdos_386.variants.two" := by
  use 1 <;> simp
#print axioms probe_4_113

-- ATTACK fc-8432eac9-variants-two-95f97acfa5-formalized-v1 use_empty_simp
theorem probe_4_114 : fcTypeOfName% "Erdos386.erdos_386.variants.two" := by
  use ∅ <;> simp
#print axioms probe_4_114

-- ATTACK fc-8432eac9-variants-two-95f97acfa5-formalized-v1 assumption
theorem probe_4_115 : fcTypeOfName% "Erdos386.erdos_386.variants.two" := by
  assumption
#print axioms probe_4_115

-- ATTACK fc-8432eac9-variants-two-95f97acfa5-formalized-v1 infer_instance
theorem probe_4_116 : fcTypeOfName% "Erdos386.erdos_386.variants.two" := by
  infer_instance
#print axioms probe_4_116

-- ATTACK fc-8432eac9-variants-two-95f97acfa5-formalized-v1 contradiction
theorem probe_4_117 : fcTypeOfName% "Erdos386.erdos_386.variants.two" := by
  contradiction
#print axioms probe_4_117

-- ATTACK fc-8432eac9-variants-two-95f97acfa5-formalized-v1 solve_by_elim
theorem probe_4_118 : fcTypeOfName% "Erdos386.erdos_386.variants.two" := by
  solve_by_elim
#print axioms probe_4_118

-- ATTACK fc-8432eac9-variants-two-95f97acfa5-formalized-v1 first_order
theorem probe_4_119 : fcTypeOfName% "Erdos386.erdos_386.variants.two" := by
  first_order
#print axioms probe_4_119

-- ATTACK fc-8432eac9-variants-two-95f97acfa5-formalized-v1 grind
theorem probe_4_120 : fcTypeOfName% "Erdos386.erdos_386.variants.two" := by
  grind
#print axioms probe_4_120

-- ATTACK fc-8432eac9-variants-two-95f97acfa5-formalized-v1 exact_search
theorem probe_4_121 : fcTypeOfName% "Erdos386.erdos_386.variants.two" := by
  exact?
#print axioms probe_4_121

-- ATTACK fc-8432eac9-variants-two-95f97acfa5-formalized-v1 apply_search
theorem probe_4_122 : fcTypeOfName% "Erdos386.erdos_386.variants.two" := by
  apply?
#print axioms probe_4_122

-- ATTACK fc-8432eac9-variants-two-95f97acfa5-formalized-v1 library_search
theorem probe_4_123 : fcTypeOfName% "Erdos386.erdos_386.variants.two" := by
  library_search
#print axioms probe_4_123

-- ATTACK fc-8432eac9-variants-two-95f97acfa5-formalized-v1 aesop_search
theorem probe_4_124 : fcTypeOfName% "Erdos386.erdos_386.variants.two" := by
  aesop?
#print axioms probe_4_124

-- ATTACK fc-8432eac9-variants-two-95f97acfa5-formalized-v1 simp_search
theorem probe_4_125 : fcTypeOfName% "Erdos386.erdos_386.variants.two" := by
  simp?
#print axioms probe_4_125

-- ATTACK fc-8432eac9-erdos828-erdos-828-cbbc2d3106-formalized-v1 simp
theorem probe_4_126 : fcTypeOfName% "Erdos828.erdos_828" := by
  simp
#print axioms probe_4_126

-- ATTACK fc-8432eac9-erdos828-erdos-828-cbbc2d3106-formalized-v1 simpa
theorem probe_4_127 : fcTypeOfName% "Erdos828.erdos_828" := by
  simpa
#print axioms probe_4_127

-- ATTACK fc-8432eac9-erdos828-erdos-828-cbbc2d3106-formalized-v1 simp_all
theorem probe_4_128 : fcTypeOfName% "Erdos828.erdos_828" := by
  simp_all
#print axioms probe_4_128

-- ATTACK fc-8432eac9-erdos828-erdos-828-cbbc2d3106-formalized-v1 aesop
theorem probe_4_129 : fcTypeOfName% "Erdos828.erdos_828" := by
  aesop
#print axioms probe_4_129

-- ATTACK fc-8432eac9-erdos828-erdos-828-cbbc2d3106-formalized-v1 omega
theorem probe_4_130 : fcTypeOfName% "Erdos828.erdos_828" := by
  omega
#print axioms probe_4_130

-- ATTACK fc-8432eac9-erdos828-erdos-828-cbbc2d3106-formalized-v1 norm_num
theorem probe_4_131 : fcTypeOfName% "Erdos828.erdos_828" := by
  norm_num
#print axioms probe_4_131

-- ATTACK fc-8432eac9-erdos828-erdos-828-cbbc2d3106-formalized-v1 decide
theorem probe_4_132 : fcTypeOfName% "Erdos828.erdos_828" := by
  decide
#print axioms probe_4_132

-- ATTACK fc-8432eac9-erdos828-erdos-828-cbbc2d3106-formalized-v1 native_decide
theorem probe_4_133 : fcTypeOfName% "Erdos828.erdos_828" := by
  native_decide
#print axioms probe_4_133

-- ATTACK fc-8432eac9-erdos828-erdos-828-cbbc2d3106-formalized-v1 true_intro
theorem probe_4_134 : fcTypeOfName% "Erdos828.erdos_828" := by
  exact True.intro
#print axioms probe_4_134

-- ATTACK fc-8432eac9-erdos828-erdos-828-cbbc2d3106-formalized-v1 false_elim_simp
theorem probe_4_135 : fcTypeOfName% "Erdos828.erdos_828" := by
  apply False.elim
  simp_all
#print axioms probe_4_135

-- ATTACK fc-8432eac9-erdos828-erdos-828-cbbc2d3106-formalized-v1 constructor
theorem probe_4_136 : fcTypeOfName% "Erdos828.erdos_828" := by
  constructor
#print axioms probe_4_136

-- ATTACK fc-8432eac9-erdos828-erdos-828-cbbc2d3106-formalized-v1 constructor_simp
theorem probe_4_137 : fcTypeOfName% "Erdos828.erdos_828" := by
  constructor <;> simp
#print axioms probe_4_137

-- ATTACK fc-8432eac9-erdos828-erdos-828-cbbc2d3106-formalized-v1 constructor_aesop
theorem probe_4_138 : fcTypeOfName% "Erdos828.erdos_828" := by
  constructor <;> aesop
#print axioms probe_4_138

-- ATTACK fc-8432eac9-erdos828-erdos-828-cbbc2d3106-formalized-v1 rfl
theorem probe_4_139 : fcTypeOfName% "Erdos828.erdos_828" := by
  rfl
#print axioms probe_4_139

-- ATTACK fc-8432eac9-erdos828-erdos-828-cbbc2d3106-formalized-v1 trivial
theorem probe_4_140 : fcTypeOfName% "Erdos828.erdos_828" := by
  trivial
#print axioms probe_4_140

-- ATTACK fc-8432eac9-erdos828-erdos-828-cbbc2d3106-formalized-v1 tauto
theorem probe_4_141 : fcTypeOfName% "Erdos828.erdos_828" := by
  tauto
#print axioms probe_4_141

-- ATTACK fc-8432eac9-erdos828-erdos-828-cbbc2d3106-formalized-v1 positivity
theorem probe_4_142 : fcTypeOfName% "Erdos828.erdos_828" := by
  positivity
#print axioms probe_4_142

-- ATTACK fc-8432eac9-erdos828-erdos-828-cbbc2d3106-formalized-v1 linarith
theorem probe_4_143 : fcTypeOfName% "Erdos828.erdos_828" := by
  linarith
#print axioms probe_4_143

-- ATTACK fc-8432eac9-erdos828-erdos-828-cbbc2d3106-formalized-v1 nlinarith
theorem probe_4_144 : fcTypeOfName% "Erdos828.erdos_828" := by
  nlinarith
#print axioms probe_4_144

-- ATTACK fc-8432eac9-erdos828-erdos-828-cbbc2d3106-formalized-v1 intros_simp_all
theorem probe_4_145 : fcTypeOfName% "Erdos828.erdos_828" := by
  intros
  simp_all
#print axioms probe_4_145

-- ATTACK fc-8432eac9-erdos828-erdos-828-cbbc2d3106-formalized-v1 intros_omega
theorem probe_4_146 : fcTypeOfName% "Erdos828.erdos_828" := by
  intros
  omega
#print axioms probe_4_146

-- ATTACK fc-8432eac9-erdos828-erdos-828-cbbc2d3106-formalized-v1 intros_norm_num
theorem probe_4_147 : fcTypeOfName% "Erdos828.erdos_828" := by
  intros
  norm_num at *
#print axioms probe_4_147

-- ATTACK fc-8432eac9-erdos828-erdos-828-cbbc2d3106-formalized-v1 intros_aesop
theorem probe_4_148 : fcTypeOfName% "Erdos828.erdos_828" := by
  intros
  aesop
#print axioms probe_4_148

-- ATTACK fc-8432eac9-erdos828-erdos-828-cbbc2d3106-formalized-v1 by_contra_simp_all
theorem probe_4_149 : fcTypeOfName% "Erdos828.erdos_828" := by
  by_contra h
  simp_all
#print axioms probe_4_149

-- ATTACK fc-8432eac9-erdos828-erdos-828-cbbc2d3106-formalized-v1 classical_simp_all
theorem probe_4_150 : fcTypeOfName% "Erdos828.erdos_828" := by
  classical
  simp_all
#print axioms probe_4_150

-- ATTACK fc-8432eac9-erdos828-erdos-828-cbbc2d3106-formalized-v1 classical_aesop
theorem probe_4_151 : fcTypeOfName% "Erdos828.erdos_828" := by
  classical
  aesop
#print axioms probe_4_151

-- ATTACK fc-8432eac9-erdos828-erdos-828-cbbc2d3106-formalized-v1 refine_pair_simp
theorem probe_4_152 : fcTypeOfName% "Erdos828.erdos_828" := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_4_152

-- ATTACK fc-8432eac9-erdos828-erdos-828-cbbc2d3106-formalized-v1 refine_pair_aesop
theorem probe_4_153 : fcTypeOfName% "Erdos828.erdos_828" := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_4_153

-- ATTACK fc-8432eac9-erdos828-erdos-828-cbbc2d3106-formalized-v1 use_zero_simp
theorem probe_4_154 : fcTypeOfName% "Erdos828.erdos_828" := by
  use 0 <;> simp
#print axioms probe_4_154

-- ATTACK fc-8432eac9-erdos828-erdos-828-cbbc2d3106-formalized-v1 use_one_simp
theorem probe_4_155 : fcTypeOfName% "Erdos828.erdos_828" := by
  use 1 <;> simp
#print axioms probe_4_155

-- ATTACK fc-8432eac9-erdos828-erdos-828-cbbc2d3106-formalized-v1 use_empty_simp
theorem probe_4_156 : fcTypeOfName% "Erdos828.erdos_828" := by
  use ∅ <;> simp
#print axioms probe_4_156

-- ATTACK fc-8432eac9-erdos828-erdos-828-cbbc2d3106-formalized-v1 assumption
theorem probe_4_157 : fcTypeOfName% "Erdos828.erdos_828" := by
  assumption
#print axioms probe_4_157

-- ATTACK fc-8432eac9-erdos828-erdos-828-cbbc2d3106-formalized-v1 infer_instance
theorem probe_4_158 : fcTypeOfName% "Erdos828.erdos_828" := by
  infer_instance
#print axioms probe_4_158

-- ATTACK fc-8432eac9-erdos828-erdos-828-cbbc2d3106-formalized-v1 contradiction
theorem probe_4_159 : fcTypeOfName% "Erdos828.erdos_828" := by
  contradiction
#print axioms probe_4_159

-- ATTACK fc-8432eac9-erdos828-erdos-828-cbbc2d3106-formalized-v1 solve_by_elim
theorem probe_4_160 : fcTypeOfName% "Erdos828.erdos_828" := by
  solve_by_elim
#print axioms probe_4_160

-- ATTACK fc-8432eac9-erdos828-erdos-828-cbbc2d3106-formalized-v1 first_order
theorem probe_4_161 : fcTypeOfName% "Erdos828.erdos_828" := by
  first_order
#print axioms probe_4_161

-- ATTACK fc-8432eac9-erdos828-erdos-828-cbbc2d3106-formalized-v1 grind
theorem probe_4_162 : fcTypeOfName% "Erdos828.erdos_828" := by
  grind
#print axioms probe_4_162

-- ATTACK fc-8432eac9-erdos828-erdos-828-cbbc2d3106-formalized-v1 exact_search
theorem probe_4_163 : fcTypeOfName% "Erdos828.erdos_828" := by
  exact?
#print axioms probe_4_163

-- ATTACK fc-8432eac9-erdos828-erdos-828-cbbc2d3106-formalized-v1 apply_search
theorem probe_4_164 : fcTypeOfName% "Erdos828.erdos_828" := by
  apply?
#print axioms probe_4_164

-- ATTACK fc-8432eac9-erdos828-erdos-828-cbbc2d3106-formalized-v1 library_search
theorem probe_4_165 : fcTypeOfName% "Erdos828.erdos_828" := by
  library_search
#print axioms probe_4_165

-- ATTACK fc-8432eac9-erdos828-erdos-828-cbbc2d3106-formalized-v1 aesop_search
theorem probe_4_166 : fcTypeOfName% "Erdos828.erdos_828" := by
  aesop?
#print axioms probe_4_166

-- ATTACK fc-8432eac9-erdos828-erdos-828-cbbc2d3106-formalized-v1 simp_search
theorem probe_4_167 : fcTypeOfName% "Erdos828.erdos_828" := by
  simp?
#print axioms probe_4_167

end AttackBattery
