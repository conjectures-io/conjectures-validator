import FormalConjectures.ErdosProblems.«10»
import FormalConjectures.ErdosProblems.«18»
import FormalConjectures.ErdosProblems.«366»
import FormalConjectures.ErdosProblems.«653»
import TaskSupport

set_option maxHeartbeats 20000
namespace AttackBattery

-- ATTACK fc-8432eac9-erdos10-erdos-10-9d98d946d0-counterexample-v1 simp
theorem probe_1_0 : ¬ (fcTypeOfName% "Erdos10.erdos_10") := by
  simp
#print axioms probe_1_0

-- ATTACK fc-8432eac9-erdos10-erdos-10-9d98d946d0-counterexample-v1 simpa
theorem probe_1_1 : ¬ (fcTypeOfName% "Erdos10.erdos_10") := by
  simpa
#print axioms probe_1_1

-- ATTACK fc-8432eac9-erdos10-erdos-10-9d98d946d0-counterexample-v1 simp_all
theorem probe_1_2 : ¬ (fcTypeOfName% "Erdos10.erdos_10") := by
  simp_all
#print axioms probe_1_2

-- ATTACK fc-8432eac9-erdos10-erdos-10-9d98d946d0-counterexample-v1 aesop
theorem probe_1_3 : ¬ (fcTypeOfName% "Erdos10.erdos_10") := by
  aesop
#print axioms probe_1_3

-- ATTACK fc-8432eac9-erdos10-erdos-10-9d98d946d0-counterexample-v1 omega
theorem probe_1_4 : ¬ (fcTypeOfName% "Erdos10.erdos_10") := by
  omega
#print axioms probe_1_4

-- ATTACK fc-8432eac9-erdos10-erdos-10-9d98d946d0-counterexample-v1 norm_num
theorem probe_1_5 : ¬ (fcTypeOfName% "Erdos10.erdos_10") := by
  norm_num
#print axioms probe_1_5

-- ATTACK fc-8432eac9-erdos10-erdos-10-9d98d946d0-counterexample-v1 decide
theorem probe_1_6 : ¬ (fcTypeOfName% "Erdos10.erdos_10") := by
  decide
#print axioms probe_1_6

-- ATTACK fc-8432eac9-erdos10-erdos-10-9d98d946d0-counterexample-v1 native_decide
theorem probe_1_7 : ¬ (fcTypeOfName% "Erdos10.erdos_10") := by
  native_decide
#print axioms probe_1_7

-- ATTACK fc-8432eac9-erdos10-erdos-10-9d98d946d0-counterexample-v1 true_intro
theorem probe_1_8 : ¬ (fcTypeOfName% "Erdos10.erdos_10") := by
  exact True.intro
#print axioms probe_1_8

-- ATTACK fc-8432eac9-erdos10-erdos-10-9d98d946d0-counterexample-v1 false_elim_simp
theorem probe_1_9 : ¬ (fcTypeOfName% "Erdos10.erdos_10") := by
  apply False.elim
  simp_all
#print axioms probe_1_9

-- ATTACK fc-8432eac9-erdos10-erdos-10-9d98d946d0-counterexample-v1 constructor
theorem probe_1_10 : ¬ (fcTypeOfName% "Erdos10.erdos_10") := by
  constructor
#print axioms probe_1_10

-- ATTACK fc-8432eac9-erdos10-erdos-10-9d98d946d0-counterexample-v1 constructor_simp
theorem probe_1_11 : ¬ (fcTypeOfName% "Erdos10.erdos_10") := by
  constructor <;> simp
#print axioms probe_1_11

-- ATTACK fc-8432eac9-erdos10-erdos-10-9d98d946d0-counterexample-v1 constructor_aesop
theorem probe_1_12 : ¬ (fcTypeOfName% "Erdos10.erdos_10") := by
  constructor <;> aesop
#print axioms probe_1_12

-- ATTACK fc-8432eac9-erdos10-erdos-10-9d98d946d0-counterexample-v1 rfl
theorem probe_1_13 : ¬ (fcTypeOfName% "Erdos10.erdos_10") := by
  rfl
#print axioms probe_1_13

-- ATTACK fc-8432eac9-erdos10-erdos-10-9d98d946d0-counterexample-v1 trivial
theorem probe_1_14 : ¬ (fcTypeOfName% "Erdos10.erdos_10") := by
  trivial
#print axioms probe_1_14

-- ATTACK fc-8432eac9-erdos10-erdos-10-9d98d946d0-counterexample-v1 tauto
theorem probe_1_15 : ¬ (fcTypeOfName% "Erdos10.erdos_10") := by
  tauto
#print axioms probe_1_15

-- ATTACK fc-8432eac9-erdos10-erdos-10-9d98d946d0-counterexample-v1 positivity
theorem probe_1_16 : ¬ (fcTypeOfName% "Erdos10.erdos_10") := by
  positivity
#print axioms probe_1_16

-- ATTACK fc-8432eac9-erdos10-erdos-10-9d98d946d0-counterexample-v1 linarith
theorem probe_1_17 : ¬ (fcTypeOfName% "Erdos10.erdos_10") := by
  linarith
#print axioms probe_1_17

-- ATTACK fc-8432eac9-erdos10-erdos-10-9d98d946d0-counterexample-v1 nlinarith
theorem probe_1_18 : ¬ (fcTypeOfName% "Erdos10.erdos_10") := by
  nlinarith
#print axioms probe_1_18

-- ATTACK fc-8432eac9-erdos10-erdos-10-9d98d946d0-counterexample-v1 intros_simp_all
theorem probe_1_19 : ¬ (fcTypeOfName% "Erdos10.erdos_10") := by
  intros
  simp_all
#print axioms probe_1_19

-- ATTACK fc-8432eac9-erdos10-erdos-10-9d98d946d0-counterexample-v1 intros_omega
theorem probe_1_20 : ¬ (fcTypeOfName% "Erdos10.erdos_10") := by
  intros
  omega
#print axioms probe_1_20

-- ATTACK fc-8432eac9-erdos10-erdos-10-9d98d946d0-counterexample-v1 intros_norm_num
theorem probe_1_21 : ¬ (fcTypeOfName% "Erdos10.erdos_10") := by
  intros
  norm_num at *
#print axioms probe_1_21

-- ATTACK fc-8432eac9-erdos10-erdos-10-9d98d946d0-counterexample-v1 intros_aesop
theorem probe_1_22 : ¬ (fcTypeOfName% "Erdos10.erdos_10") := by
  intros
  aesop
#print axioms probe_1_22

-- ATTACK fc-8432eac9-erdos10-erdos-10-9d98d946d0-counterexample-v1 by_contra_simp_all
theorem probe_1_23 : ¬ (fcTypeOfName% "Erdos10.erdos_10") := by
  by_contra h
  simp_all
#print axioms probe_1_23

-- ATTACK fc-8432eac9-erdos10-erdos-10-9d98d946d0-counterexample-v1 classical_simp_all
theorem probe_1_24 : ¬ (fcTypeOfName% "Erdos10.erdos_10") := by
  classical
  simp_all
#print axioms probe_1_24

-- ATTACK fc-8432eac9-erdos10-erdos-10-9d98d946d0-counterexample-v1 classical_aesop
theorem probe_1_25 : ¬ (fcTypeOfName% "Erdos10.erdos_10") := by
  classical
  aesop
#print axioms probe_1_25

-- ATTACK fc-8432eac9-erdos10-erdos-10-9d98d946d0-counterexample-v1 refine_pair_simp
theorem probe_1_26 : ¬ (fcTypeOfName% "Erdos10.erdos_10") := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_1_26

-- ATTACK fc-8432eac9-erdos10-erdos-10-9d98d946d0-counterexample-v1 refine_pair_aesop
theorem probe_1_27 : ¬ (fcTypeOfName% "Erdos10.erdos_10") := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_1_27

-- ATTACK fc-8432eac9-erdos10-erdos-10-9d98d946d0-counterexample-v1 use_zero_simp
theorem probe_1_28 : ¬ (fcTypeOfName% "Erdos10.erdos_10") := by
  use 0 <;> simp
#print axioms probe_1_28

-- ATTACK fc-8432eac9-erdos10-erdos-10-9d98d946d0-counterexample-v1 use_one_simp
theorem probe_1_29 : ¬ (fcTypeOfName% "Erdos10.erdos_10") := by
  use 1 <;> simp
#print axioms probe_1_29

-- ATTACK fc-8432eac9-erdos10-erdos-10-9d98d946d0-counterexample-v1 use_empty_simp
theorem probe_1_30 : ¬ (fcTypeOfName% "Erdos10.erdos_10") := by
  use ∅ <;> simp
#print axioms probe_1_30

-- ATTACK fc-8432eac9-erdos10-erdos-10-9d98d946d0-counterexample-v1 assumption
theorem probe_1_31 : ¬ (fcTypeOfName% "Erdos10.erdos_10") := by
  assumption
#print axioms probe_1_31

-- ATTACK fc-8432eac9-erdos10-erdos-10-9d98d946d0-counterexample-v1 infer_instance
theorem probe_1_32 : ¬ (fcTypeOfName% "Erdos10.erdos_10") := by
  infer_instance
#print axioms probe_1_32

-- ATTACK fc-8432eac9-erdos10-erdos-10-9d98d946d0-counterexample-v1 contradiction
theorem probe_1_33 : ¬ (fcTypeOfName% "Erdos10.erdos_10") := by
  contradiction
#print axioms probe_1_33

-- ATTACK fc-8432eac9-erdos10-erdos-10-9d98d946d0-counterexample-v1 solve_by_elim
theorem probe_1_34 : ¬ (fcTypeOfName% "Erdos10.erdos_10") := by
  solve_by_elim
#print axioms probe_1_34

-- ATTACK fc-8432eac9-erdos10-erdos-10-9d98d946d0-counterexample-v1 first_order
theorem probe_1_35 : ¬ (fcTypeOfName% "Erdos10.erdos_10") := by
  first_order
#print axioms probe_1_35

-- ATTACK fc-8432eac9-erdos10-erdos-10-9d98d946d0-counterexample-v1 grind
theorem probe_1_36 : ¬ (fcTypeOfName% "Erdos10.erdos_10") := by
  grind
#print axioms probe_1_36

-- ATTACK fc-8432eac9-erdos10-erdos-10-9d98d946d0-counterexample-v1 exact_search
theorem probe_1_37 : ¬ (fcTypeOfName% "Erdos10.erdos_10") := by
  exact?
#print axioms probe_1_37

-- ATTACK fc-8432eac9-erdos10-erdos-10-9d98d946d0-counterexample-v1 apply_search
theorem probe_1_38 : ¬ (fcTypeOfName% "Erdos10.erdos_10") := by
  apply?
#print axioms probe_1_38

-- ATTACK fc-8432eac9-erdos10-erdos-10-9d98d946d0-counterexample-v1 library_search
theorem probe_1_39 : ¬ (fcTypeOfName% "Erdos10.erdos_10") := by
  library_search
#print axioms probe_1_39

-- ATTACK fc-8432eac9-erdos10-erdos-10-9d98d946d0-counterexample-v1 aesop_search
theorem probe_1_40 : ¬ (fcTypeOfName% "Erdos10.erdos_10") := by
  aesop?
#print axioms probe_1_40

-- ATTACK fc-8432eac9-erdos10-erdos-10-9d98d946d0-counterexample-v1 simp_search
theorem probe_1_41 : ¬ (fcTypeOfName% "Erdos10.erdos_10") := by
  simp?
#print axioms probe_1_41

-- ATTACK fc-8432eac9-erdos18-erdos-18b-c45e6e4118-counterexample-v1 simp
theorem probe_1_42 : ¬ (fcTypeOfName% "Erdos18.erdos_18b") := by
  simp
#print axioms probe_1_42

-- ATTACK fc-8432eac9-erdos18-erdos-18b-c45e6e4118-counterexample-v1 simpa
theorem probe_1_43 : ¬ (fcTypeOfName% "Erdos18.erdos_18b") := by
  simpa
#print axioms probe_1_43

-- ATTACK fc-8432eac9-erdos18-erdos-18b-c45e6e4118-counterexample-v1 simp_all
theorem probe_1_44 : ¬ (fcTypeOfName% "Erdos18.erdos_18b") := by
  simp_all
#print axioms probe_1_44

-- ATTACK fc-8432eac9-erdos18-erdos-18b-c45e6e4118-counterexample-v1 aesop
theorem probe_1_45 : ¬ (fcTypeOfName% "Erdos18.erdos_18b") := by
  aesop
#print axioms probe_1_45

-- ATTACK fc-8432eac9-erdos18-erdos-18b-c45e6e4118-counterexample-v1 omega
theorem probe_1_46 : ¬ (fcTypeOfName% "Erdos18.erdos_18b") := by
  omega
#print axioms probe_1_46

-- ATTACK fc-8432eac9-erdos18-erdos-18b-c45e6e4118-counterexample-v1 norm_num
theorem probe_1_47 : ¬ (fcTypeOfName% "Erdos18.erdos_18b") := by
  norm_num
#print axioms probe_1_47

-- ATTACK fc-8432eac9-erdos18-erdos-18b-c45e6e4118-counterexample-v1 decide
theorem probe_1_48 : ¬ (fcTypeOfName% "Erdos18.erdos_18b") := by
  decide
#print axioms probe_1_48

-- ATTACK fc-8432eac9-erdos18-erdos-18b-c45e6e4118-counterexample-v1 native_decide
theorem probe_1_49 : ¬ (fcTypeOfName% "Erdos18.erdos_18b") := by
  native_decide
#print axioms probe_1_49

-- ATTACK fc-8432eac9-erdos18-erdos-18b-c45e6e4118-counterexample-v1 true_intro
theorem probe_1_50 : ¬ (fcTypeOfName% "Erdos18.erdos_18b") := by
  exact True.intro
#print axioms probe_1_50

-- ATTACK fc-8432eac9-erdos18-erdos-18b-c45e6e4118-counterexample-v1 false_elim_simp
theorem probe_1_51 : ¬ (fcTypeOfName% "Erdos18.erdos_18b") := by
  apply False.elim
  simp_all
#print axioms probe_1_51

-- ATTACK fc-8432eac9-erdos18-erdos-18b-c45e6e4118-counterexample-v1 constructor
theorem probe_1_52 : ¬ (fcTypeOfName% "Erdos18.erdos_18b") := by
  constructor
#print axioms probe_1_52

-- ATTACK fc-8432eac9-erdos18-erdos-18b-c45e6e4118-counterexample-v1 constructor_simp
theorem probe_1_53 : ¬ (fcTypeOfName% "Erdos18.erdos_18b") := by
  constructor <;> simp
#print axioms probe_1_53

-- ATTACK fc-8432eac9-erdos18-erdos-18b-c45e6e4118-counterexample-v1 constructor_aesop
theorem probe_1_54 : ¬ (fcTypeOfName% "Erdos18.erdos_18b") := by
  constructor <;> aesop
#print axioms probe_1_54

-- ATTACK fc-8432eac9-erdos18-erdos-18b-c45e6e4118-counterexample-v1 rfl
theorem probe_1_55 : ¬ (fcTypeOfName% "Erdos18.erdos_18b") := by
  rfl
#print axioms probe_1_55

-- ATTACK fc-8432eac9-erdos18-erdos-18b-c45e6e4118-counterexample-v1 trivial
theorem probe_1_56 : ¬ (fcTypeOfName% "Erdos18.erdos_18b") := by
  trivial
#print axioms probe_1_56

-- ATTACK fc-8432eac9-erdos18-erdos-18b-c45e6e4118-counterexample-v1 tauto
theorem probe_1_57 : ¬ (fcTypeOfName% "Erdos18.erdos_18b") := by
  tauto
#print axioms probe_1_57

-- ATTACK fc-8432eac9-erdos18-erdos-18b-c45e6e4118-counterexample-v1 positivity
theorem probe_1_58 : ¬ (fcTypeOfName% "Erdos18.erdos_18b") := by
  positivity
#print axioms probe_1_58

-- ATTACK fc-8432eac9-erdos18-erdos-18b-c45e6e4118-counterexample-v1 linarith
theorem probe_1_59 : ¬ (fcTypeOfName% "Erdos18.erdos_18b") := by
  linarith
#print axioms probe_1_59

-- ATTACK fc-8432eac9-erdos18-erdos-18b-c45e6e4118-counterexample-v1 nlinarith
theorem probe_1_60 : ¬ (fcTypeOfName% "Erdos18.erdos_18b") := by
  nlinarith
#print axioms probe_1_60

-- ATTACK fc-8432eac9-erdos18-erdos-18b-c45e6e4118-counterexample-v1 intros_simp_all
theorem probe_1_61 : ¬ (fcTypeOfName% "Erdos18.erdos_18b") := by
  intros
  simp_all
#print axioms probe_1_61

-- ATTACK fc-8432eac9-erdos18-erdos-18b-c45e6e4118-counterexample-v1 intros_omega
theorem probe_1_62 : ¬ (fcTypeOfName% "Erdos18.erdos_18b") := by
  intros
  omega
#print axioms probe_1_62

-- ATTACK fc-8432eac9-erdos18-erdos-18b-c45e6e4118-counterexample-v1 intros_norm_num
theorem probe_1_63 : ¬ (fcTypeOfName% "Erdos18.erdos_18b") := by
  intros
  norm_num at *
#print axioms probe_1_63

-- ATTACK fc-8432eac9-erdos18-erdos-18b-c45e6e4118-counterexample-v1 intros_aesop
theorem probe_1_64 : ¬ (fcTypeOfName% "Erdos18.erdos_18b") := by
  intros
  aesop
#print axioms probe_1_64

-- ATTACK fc-8432eac9-erdos18-erdos-18b-c45e6e4118-counterexample-v1 by_contra_simp_all
theorem probe_1_65 : ¬ (fcTypeOfName% "Erdos18.erdos_18b") := by
  by_contra h
  simp_all
#print axioms probe_1_65

-- ATTACK fc-8432eac9-erdos18-erdos-18b-c45e6e4118-counterexample-v1 classical_simp_all
theorem probe_1_66 : ¬ (fcTypeOfName% "Erdos18.erdos_18b") := by
  classical
  simp_all
#print axioms probe_1_66

-- ATTACK fc-8432eac9-erdos18-erdos-18b-c45e6e4118-counterexample-v1 classical_aesop
theorem probe_1_67 : ¬ (fcTypeOfName% "Erdos18.erdos_18b") := by
  classical
  aesop
#print axioms probe_1_67

-- ATTACK fc-8432eac9-erdos18-erdos-18b-c45e6e4118-counterexample-v1 refine_pair_simp
theorem probe_1_68 : ¬ (fcTypeOfName% "Erdos18.erdos_18b") := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_1_68

-- ATTACK fc-8432eac9-erdos18-erdos-18b-c45e6e4118-counterexample-v1 refine_pair_aesop
theorem probe_1_69 : ¬ (fcTypeOfName% "Erdos18.erdos_18b") := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_1_69

-- ATTACK fc-8432eac9-erdos18-erdos-18b-c45e6e4118-counterexample-v1 use_zero_simp
theorem probe_1_70 : ¬ (fcTypeOfName% "Erdos18.erdos_18b") := by
  use 0 <;> simp
#print axioms probe_1_70

-- ATTACK fc-8432eac9-erdos18-erdos-18b-c45e6e4118-counterexample-v1 use_one_simp
theorem probe_1_71 : ¬ (fcTypeOfName% "Erdos18.erdos_18b") := by
  use 1 <;> simp
#print axioms probe_1_71

-- ATTACK fc-8432eac9-erdos18-erdos-18b-c45e6e4118-counterexample-v1 use_empty_simp
theorem probe_1_72 : ¬ (fcTypeOfName% "Erdos18.erdos_18b") := by
  use ∅ <;> simp
#print axioms probe_1_72

-- ATTACK fc-8432eac9-erdos18-erdos-18b-c45e6e4118-counterexample-v1 assumption
theorem probe_1_73 : ¬ (fcTypeOfName% "Erdos18.erdos_18b") := by
  assumption
#print axioms probe_1_73

-- ATTACK fc-8432eac9-erdos18-erdos-18b-c45e6e4118-counterexample-v1 infer_instance
theorem probe_1_74 : ¬ (fcTypeOfName% "Erdos18.erdos_18b") := by
  infer_instance
#print axioms probe_1_74

-- ATTACK fc-8432eac9-erdos18-erdos-18b-c45e6e4118-counterexample-v1 contradiction
theorem probe_1_75 : ¬ (fcTypeOfName% "Erdos18.erdos_18b") := by
  contradiction
#print axioms probe_1_75

-- ATTACK fc-8432eac9-erdos18-erdos-18b-c45e6e4118-counterexample-v1 solve_by_elim
theorem probe_1_76 : ¬ (fcTypeOfName% "Erdos18.erdos_18b") := by
  solve_by_elim
#print axioms probe_1_76

-- ATTACK fc-8432eac9-erdos18-erdos-18b-c45e6e4118-counterexample-v1 first_order
theorem probe_1_77 : ¬ (fcTypeOfName% "Erdos18.erdos_18b") := by
  first_order
#print axioms probe_1_77

-- ATTACK fc-8432eac9-erdos18-erdos-18b-c45e6e4118-counterexample-v1 grind
theorem probe_1_78 : ¬ (fcTypeOfName% "Erdos18.erdos_18b") := by
  grind
#print axioms probe_1_78

-- ATTACK fc-8432eac9-erdos18-erdos-18b-c45e6e4118-counterexample-v1 exact_search
theorem probe_1_79 : ¬ (fcTypeOfName% "Erdos18.erdos_18b") := by
  exact?
#print axioms probe_1_79

-- ATTACK fc-8432eac9-erdos18-erdos-18b-c45e6e4118-counterexample-v1 apply_search
theorem probe_1_80 : ¬ (fcTypeOfName% "Erdos18.erdos_18b") := by
  apply?
#print axioms probe_1_80

-- ATTACK fc-8432eac9-erdos18-erdos-18b-c45e6e4118-counterexample-v1 library_search
theorem probe_1_81 : ¬ (fcTypeOfName% "Erdos18.erdos_18b") := by
  library_search
#print axioms probe_1_81

-- ATTACK fc-8432eac9-erdos18-erdos-18b-c45e6e4118-counterexample-v1 aesop_search
theorem probe_1_82 : ¬ (fcTypeOfName% "Erdos18.erdos_18b") := by
  aesop?
#print axioms probe_1_82

-- ATTACK fc-8432eac9-erdos18-erdos-18b-c45e6e4118-counterexample-v1 simp_search
theorem probe_1_83 : ¬ (fcTypeOfName% "Erdos18.erdos_18b") := by
  simp?
#print axioms probe_1_83

-- ATTACK fc-8432eac9-erdos366-erdos-366-8b8f947734-counterexample-v1 simp
theorem probe_1_84 : ¬ (fcTypeOfName% "Erdos366.erdos_366") := by
  simp
#print axioms probe_1_84

-- ATTACK fc-8432eac9-erdos366-erdos-366-8b8f947734-counterexample-v1 simpa
theorem probe_1_85 : ¬ (fcTypeOfName% "Erdos366.erdos_366") := by
  simpa
#print axioms probe_1_85

-- ATTACK fc-8432eac9-erdos366-erdos-366-8b8f947734-counterexample-v1 simp_all
theorem probe_1_86 : ¬ (fcTypeOfName% "Erdos366.erdos_366") := by
  simp_all
#print axioms probe_1_86

-- ATTACK fc-8432eac9-erdos366-erdos-366-8b8f947734-counterexample-v1 aesop
theorem probe_1_87 : ¬ (fcTypeOfName% "Erdos366.erdos_366") := by
  aesop
#print axioms probe_1_87

-- ATTACK fc-8432eac9-erdos366-erdos-366-8b8f947734-counterexample-v1 omega
theorem probe_1_88 : ¬ (fcTypeOfName% "Erdos366.erdos_366") := by
  omega
#print axioms probe_1_88

-- ATTACK fc-8432eac9-erdos366-erdos-366-8b8f947734-counterexample-v1 norm_num
theorem probe_1_89 : ¬ (fcTypeOfName% "Erdos366.erdos_366") := by
  norm_num
#print axioms probe_1_89

-- ATTACK fc-8432eac9-erdos366-erdos-366-8b8f947734-counterexample-v1 decide
theorem probe_1_90 : ¬ (fcTypeOfName% "Erdos366.erdos_366") := by
  decide
#print axioms probe_1_90

-- ATTACK fc-8432eac9-erdos366-erdos-366-8b8f947734-counterexample-v1 native_decide
theorem probe_1_91 : ¬ (fcTypeOfName% "Erdos366.erdos_366") := by
  native_decide
#print axioms probe_1_91

-- ATTACK fc-8432eac9-erdos366-erdos-366-8b8f947734-counterexample-v1 true_intro
theorem probe_1_92 : ¬ (fcTypeOfName% "Erdos366.erdos_366") := by
  exact True.intro
#print axioms probe_1_92

-- ATTACK fc-8432eac9-erdos366-erdos-366-8b8f947734-counterexample-v1 false_elim_simp
theorem probe_1_93 : ¬ (fcTypeOfName% "Erdos366.erdos_366") := by
  apply False.elim
  simp_all
#print axioms probe_1_93

-- ATTACK fc-8432eac9-erdos366-erdos-366-8b8f947734-counterexample-v1 constructor
theorem probe_1_94 : ¬ (fcTypeOfName% "Erdos366.erdos_366") := by
  constructor
#print axioms probe_1_94

-- ATTACK fc-8432eac9-erdos366-erdos-366-8b8f947734-counterexample-v1 constructor_simp
theorem probe_1_95 : ¬ (fcTypeOfName% "Erdos366.erdos_366") := by
  constructor <;> simp
#print axioms probe_1_95

-- ATTACK fc-8432eac9-erdos366-erdos-366-8b8f947734-counterexample-v1 constructor_aesop
theorem probe_1_96 : ¬ (fcTypeOfName% "Erdos366.erdos_366") := by
  constructor <;> aesop
#print axioms probe_1_96

-- ATTACK fc-8432eac9-erdos366-erdos-366-8b8f947734-counterexample-v1 rfl
theorem probe_1_97 : ¬ (fcTypeOfName% "Erdos366.erdos_366") := by
  rfl
#print axioms probe_1_97

-- ATTACK fc-8432eac9-erdos366-erdos-366-8b8f947734-counterexample-v1 trivial
theorem probe_1_98 : ¬ (fcTypeOfName% "Erdos366.erdos_366") := by
  trivial
#print axioms probe_1_98

-- ATTACK fc-8432eac9-erdos366-erdos-366-8b8f947734-counterexample-v1 tauto
theorem probe_1_99 : ¬ (fcTypeOfName% "Erdos366.erdos_366") := by
  tauto
#print axioms probe_1_99

-- ATTACK fc-8432eac9-erdos366-erdos-366-8b8f947734-counterexample-v1 positivity
theorem probe_1_100 : ¬ (fcTypeOfName% "Erdos366.erdos_366") := by
  positivity
#print axioms probe_1_100

-- ATTACK fc-8432eac9-erdos366-erdos-366-8b8f947734-counterexample-v1 linarith
theorem probe_1_101 : ¬ (fcTypeOfName% "Erdos366.erdos_366") := by
  linarith
#print axioms probe_1_101

-- ATTACK fc-8432eac9-erdos366-erdos-366-8b8f947734-counterexample-v1 nlinarith
theorem probe_1_102 : ¬ (fcTypeOfName% "Erdos366.erdos_366") := by
  nlinarith
#print axioms probe_1_102

-- ATTACK fc-8432eac9-erdos366-erdos-366-8b8f947734-counterexample-v1 intros_simp_all
theorem probe_1_103 : ¬ (fcTypeOfName% "Erdos366.erdos_366") := by
  intros
  simp_all
#print axioms probe_1_103

-- ATTACK fc-8432eac9-erdos366-erdos-366-8b8f947734-counterexample-v1 intros_omega
theorem probe_1_104 : ¬ (fcTypeOfName% "Erdos366.erdos_366") := by
  intros
  omega
#print axioms probe_1_104

-- ATTACK fc-8432eac9-erdos366-erdos-366-8b8f947734-counterexample-v1 intros_norm_num
theorem probe_1_105 : ¬ (fcTypeOfName% "Erdos366.erdos_366") := by
  intros
  norm_num at *
#print axioms probe_1_105

-- ATTACK fc-8432eac9-erdos366-erdos-366-8b8f947734-counterexample-v1 intros_aesop
theorem probe_1_106 : ¬ (fcTypeOfName% "Erdos366.erdos_366") := by
  intros
  aesop
#print axioms probe_1_106

-- ATTACK fc-8432eac9-erdos366-erdos-366-8b8f947734-counterexample-v1 by_contra_simp_all
theorem probe_1_107 : ¬ (fcTypeOfName% "Erdos366.erdos_366") := by
  by_contra h
  simp_all
#print axioms probe_1_107

-- ATTACK fc-8432eac9-erdos366-erdos-366-8b8f947734-counterexample-v1 classical_simp_all
theorem probe_1_108 : ¬ (fcTypeOfName% "Erdos366.erdos_366") := by
  classical
  simp_all
#print axioms probe_1_108

-- ATTACK fc-8432eac9-erdos366-erdos-366-8b8f947734-counterexample-v1 classical_aesop
theorem probe_1_109 : ¬ (fcTypeOfName% "Erdos366.erdos_366") := by
  classical
  aesop
#print axioms probe_1_109

-- ATTACK fc-8432eac9-erdos366-erdos-366-8b8f947734-counterexample-v1 refine_pair_simp
theorem probe_1_110 : ¬ (fcTypeOfName% "Erdos366.erdos_366") := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_1_110

-- ATTACK fc-8432eac9-erdos366-erdos-366-8b8f947734-counterexample-v1 refine_pair_aesop
theorem probe_1_111 : ¬ (fcTypeOfName% "Erdos366.erdos_366") := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_1_111

-- ATTACK fc-8432eac9-erdos366-erdos-366-8b8f947734-counterexample-v1 use_zero_simp
theorem probe_1_112 : ¬ (fcTypeOfName% "Erdos366.erdos_366") := by
  use 0 <;> simp
#print axioms probe_1_112

-- ATTACK fc-8432eac9-erdos366-erdos-366-8b8f947734-counterexample-v1 use_one_simp
theorem probe_1_113 : ¬ (fcTypeOfName% "Erdos366.erdos_366") := by
  use 1 <;> simp
#print axioms probe_1_113

-- ATTACK fc-8432eac9-erdos366-erdos-366-8b8f947734-counterexample-v1 use_empty_simp
theorem probe_1_114 : ¬ (fcTypeOfName% "Erdos366.erdos_366") := by
  use ∅ <;> simp
#print axioms probe_1_114

-- ATTACK fc-8432eac9-erdos366-erdos-366-8b8f947734-counterexample-v1 assumption
theorem probe_1_115 : ¬ (fcTypeOfName% "Erdos366.erdos_366") := by
  assumption
#print axioms probe_1_115

-- ATTACK fc-8432eac9-erdos366-erdos-366-8b8f947734-counterexample-v1 infer_instance
theorem probe_1_116 : ¬ (fcTypeOfName% "Erdos366.erdos_366") := by
  infer_instance
#print axioms probe_1_116

-- ATTACK fc-8432eac9-erdos366-erdos-366-8b8f947734-counterexample-v1 contradiction
theorem probe_1_117 : ¬ (fcTypeOfName% "Erdos366.erdos_366") := by
  contradiction
#print axioms probe_1_117

-- ATTACK fc-8432eac9-erdos366-erdos-366-8b8f947734-counterexample-v1 solve_by_elim
theorem probe_1_118 : ¬ (fcTypeOfName% "Erdos366.erdos_366") := by
  solve_by_elim
#print axioms probe_1_118

-- ATTACK fc-8432eac9-erdos366-erdos-366-8b8f947734-counterexample-v1 first_order
theorem probe_1_119 : ¬ (fcTypeOfName% "Erdos366.erdos_366") := by
  first_order
#print axioms probe_1_119

-- ATTACK fc-8432eac9-erdos366-erdos-366-8b8f947734-counterexample-v1 grind
theorem probe_1_120 : ¬ (fcTypeOfName% "Erdos366.erdos_366") := by
  grind
#print axioms probe_1_120

-- ATTACK fc-8432eac9-erdos366-erdos-366-8b8f947734-counterexample-v1 exact_search
theorem probe_1_121 : ¬ (fcTypeOfName% "Erdos366.erdos_366") := by
  exact?
#print axioms probe_1_121

-- ATTACK fc-8432eac9-erdos366-erdos-366-8b8f947734-counterexample-v1 apply_search
theorem probe_1_122 : ¬ (fcTypeOfName% "Erdos366.erdos_366") := by
  apply?
#print axioms probe_1_122

-- ATTACK fc-8432eac9-erdos366-erdos-366-8b8f947734-counterexample-v1 library_search
theorem probe_1_123 : ¬ (fcTypeOfName% "Erdos366.erdos_366") := by
  library_search
#print axioms probe_1_123

-- ATTACK fc-8432eac9-erdos366-erdos-366-8b8f947734-counterexample-v1 aesop_search
theorem probe_1_124 : ¬ (fcTypeOfName% "Erdos366.erdos_366") := by
  aesop?
#print axioms probe_1_124

-- ATTACK fc-8432eac9-erdos366-erdos-366-8b8f947734-counterexample-v1 simp_search
theorem probe_1_125 : ¬ (fcTypeOfName% "Erdos366.erdos_366") := by
  simp?
#print axioms probe_1_125

-- ATTACK fc-8432eac9-erdos653-erdos-653-42c9d5c2c1-counterexample-v1 simp
theorem probe_1_126 : ¬ (fcTypeOfName% "Erdos653.erdos_653") := by
  simp
#print axioms probe_1_126

-- ATTACK fc-8432eac9-erdos653-erdos-653-42c9d5c2c1-counterexample-v1 simpa
theorem probe_1_127 : ¬ (fcTypeOfName% "Erdos653.erdos_653") := by
  simpa
#print axioms probe_1_127

-- ATTACK fc-8432eac9-erdos653-erdos-653-42c9d5c2c1-counterexample-v1 simp_all
theorem probe_1_128 : ¬ (fcTypeOfName% "Erdos653.erdos_653") := by
  simp_all
#print axioms probe_1_128

-- ATTACK fc-8432eac9-erdos653-erdos-653-42c9d5c2c1-counterexample-v1 aesop
theorem probe_1_129 : ¬ (fcTypeOfName% "Erdos653.erdos_653") := by
  aesop
#print axioms probe_1_129

-- ATTACK fc-8432eac9-erdos653-erdos-653-42c9d5c2c1-counterexample-v1 omega
theorem probe_1_130 : ¬ (fcTypeOfName% "Erdos653.erdos_653") := by
  omega
#print axioms probe_1_130

-- ATTACK fc-8432eac9-erdos653-erdos-653-42c9d5c2c1-counterexample-v1 norm_num
theorem probe_1_131 : ¬ (fcTypeOfName% "Erdos653.erdos_653") := by
  norm_num
#print axioms probe_1_131

-- ATTACK fc-8432eac9-erdos653-erdos-653-42c9d5c2c1-counterexample-v1 decide
theorem probe_1_132 : ¬ (fcTypeOfName% "Erdos653.erdos_653") := by
  decide
#print axioms probe_1_132

-- ATTACK fc-8432eac9-erdos653-erdos-653-42c9d5c2c1-counterexample-v1 native_decide
theorem probe_1_133 : ¬ (fcTypeOfName% "Erdos653.erdos_653") := by
  native_decide
#print axioms probe_1_133

-- ATTACK fc-8432eac9-erdos653-erdos-653-42c9d5c2c1-counterexample-v1 true_intro
theorem probe_1_134 : ¬ (fcTypeOfName% "Erdos653.erdos_653") := by
  exact True.intro
#print axioms probe_1_134

-- ATTACK fc-8432eac9-erdos653-erdos-653-42c9d5c2c1-counterexample-v1 false_elim_simp
theorem probe_1_135 : ¬ (fcTypeOfName% "Erdos653.erdos_653") := by
  apply False.elim
  simp_all
#print axioms probe_1_135

-- ATTACK fc-8432eac9-erdos653-erdos-653-42c9d5c2c1-counterexample-v1 constructor
theorem probe_1_136 : ¬ (fcTypeOfName% "Erdos653.erdos_653") := by
  constructor
#print axioms probe_1_136

-- ATTACK fc-8432eac9-erdos653-erdos-653-42c9d5c2c1-counterexample-v1 constructor_simp
theorem probe_1_137 : ¬ (fcTypeOfName% "Erdos653.erdos_653") := by
  constructor <;> simp
#print axioms probe_1_137

-- ATTACK fc-8432eac9-erdos653-erdos-653-42c9d5c2c1-counterexample-v1 constructor_aesop
theorem probe_1_138 : ¬ (fcTypeOfName% "Erdos653.erdos_653") := by
  constructor <;> aesop
#print axioms probe_1_138

-- ATTACK fc-8432eac9-erdos653-erdos-653-42c9d5c2c1-counterexample-v1 rfl
theorem probe_1_139 : ¬ (fcTypeOfName% "Erdos653.erdos_653") := by
  rfl
#print axioms probe_1_139

-- ATTACK fc-8432eac9-erdos653-erdos-653-42c9d5c2c1-counterexample-v1 trivial
theorem probe_1_140 : ¬ (fcTypeOfName% "Erdos653.erdos_653") := by
  trivial
#print axioms probe_1_140

-- ATTACK fc-8432eac9-erdos653-erdos-653-42c9d5c2c1-counterexample-v1 tauto
theorem probe_1_141 : ¬ (fcTypeOfName% "Erdos653.erdos_653") := by
  tauto
#print axioms probe_1_141

-- ATTACK fc-8432eac9-erdos653-erdos-653-42c9d5c2c1-counterexample-v1 positivity
theorem probe_1_142 : ¬ (fcTypeOfName% "Erdos653.erdos_653") := by
  positivity
#print axioms probe_1_142

-- ATTACK fc-8432eac9-erdos653-erdos-653-42c9d5c2c1-counterexample-v1 linarith
theorem probe_1_143 : ¬ (fcTypeOfName% "Erdos653.erdos_653") := by
  linarith
#print axioms probe_1_143

-- ATTACK fc-8432eac9-erdos653-erdos-653-42c9d5c2c1-counterexample-v1 nlinarith
theorem probe_1_144 : ¬ (fcTypeOfName% "Erdos653.erdos_653") := by
  nlinarith
#print axioms probe_1_144

-- ATTACK fc-8432eac9-erdos653-erdos-653-42c9d5c2c1-counterexample-v1 intros_simp_all
theorem probe_1_145 : ¬ (fcTypeOfName% "Erdos653.erdos_653") := by
  intros
  simp_all
#print axioms probe_1_145

-- ATTACK fc-8432eac9-erdos653-erdos-653-42c9d5c2c1-counterexample-v1 intros_omega
theorem probe_1_146 : ¬ (fcTypeOfName% "Erdos653.erdos_653") := by
  intros
  omega
#print axioms probe_1_146

-- ATTACK fc-8432eac9-erdos653-erdos-653-42c9d5c2c1-counterexample-v1 intros_norm_num
theorem probe_1_147 : ¬ (fcTypeOfName% "Erdos653.erdos_653") := by
  intros
  norm_num at *
#print axioms probe_1_147

-- ATTACK fc-8432eac9-erdos653-erdos-653-42c9d5c2c1-counterexample-v1 intros_aesop
theorem probe_1_148 : ¬ (fcTypeOfName% "Erdos653.erdos_653") := by
  intros
  aesop
#print axioms probe_1_148

-- ATTACK fc-8432eac9-erdos653-erdos-653-42c9d5c2c1-counterexample-v1 by_contra_simp_all
theorem probe_1_149 : ¬ (fcTypeOfName% "Erdos653.erdos_653") := by
  by_contra h
  simp_all
#print axioms probe_1_149

-- ATTACK fc-8432eac9-erdos653-erdos-653-42c9d5c2c1-counterexample-v1 classical_simp_all
theorem probe_1_150 : ¬ (fcTypeOfName% "Erdos653.erdos_653") := by
  classical
  simp_all
#print axioms probe_1_150

-- ATTACK fc-8432eac9-erdos653-erdos-653-42c9d5c2c1-counterexample-v1 classical_aesop
theorem probe_1_151 : ¬ (fcTypeOfName% "Erdos653.erdos_653") := by
  classical
  aesop
#print axioms probe_1_151

-- ATTACK fc-8432eac9-erdos653-erdos-653-42c9d5c2c1-counterexample-v1 refine_pair_simp
theorem probe_1_152 : ¬ (fcTypeOfName% "Erdos653.erdos_653") := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_1_152

-- ATTACK fc-8432eac9-erdos653-erdos-653-42c9d5c2c1-counterexample-v1 refine_pair_aesop
theorem probe_1_153 : ¬ (fcTypeOfName% "Erdos653.erdos_653") := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_1_153

-- ATTACK fc-8432eac9-erdos653-erdos-653-42c9d5c2c1-counterexample-v1 use_zero_simp
theorem probe_1_154 : ¬ (fcTypeOfName% "Erdos653.erdos_653") := by
  use 0 <;> simp
#print axioms probe_1_154

-- ATTACK fc-8432eac9-erdos653-erdos-653-42c9d5c2c1-counterexample-v1 use_one_simp
theorem probe_1_155 : ¬ (fcTypeOfName% "Erdos653.erdos_653") := by
  use 1 <;> simp
#print axioms probe_1_155

-- ATTACK fc-8432eac9-erdos653-erdos-653-42c9d5c2c1-counterexample-v1 use_empty_simp
theorem probe_1_156 : ¬ (fcTypeOfName% "Erdos653.erdos_653") := by
  use ∅ <;> simp
#print axioms probe_1_156

-- ATTACK fc-8432eac9-erdos653-erdos-653-42c9d5c2c1-counterexample-v1 assumption
theorem probe_1_157 : ¬ (fcTypeOfName% "Erdos653.erdos_653") := by
  assumption
#print axioms probe_1_157

-- ATTACK fc-8432eac9-erdos653-erdos-653-42c9d5c2c1-counterexample-v1 infer_instance
theorem probe_1_158 : ¬ (fcTypeOfName% "Erdos653.erdos_653") := by
  infer_instance
#print axioms probe_1_158

-- ATTACK fc-8432eac9-erdos653-erdos-653-42c9d5c2c1-counterexample-v1 contradiction
theorem probe_1_159 : ¬ (fcTypeOfName% "Erdos653.erdos_653") := by
  contradiction
#print axioms probe_1_159

-- ATTACK fc-8432eac9-erdos653-erdos-653-42c9d5c2c1-counterexample-v1 solve_by_elim
theorem probe_1_160 : ¬ (fcTypeOfName% "Erdos653.erdos_653") := by
  solve_by_elim
#print axioms probe_1_160

-- ATTACK fc-8432eac9-erdos653-erdos-653-42c9d5c2c1-counterexample-v1 first_order
theorem probe_1_161 : ¬ (fcTypeOfName% "Erdos653.erdos_653") := by
  first_order
#print axioms probe_1_161

-- ATTACK fc-8432eac9-erdos653-erdos-653-42c9d5c2c1-counterexample-v1 grind
theorem probe_1_162 : ¬ (fcTypeOfName% "Erdos653.erdos_653") := by
  grind
#print axioms probe_1_162

-- ATTACK fc-8432eac9-erdos653-erdos-653-42c9d5c2c1-counterexample-v1 exact_search
theorem probe_1_163 : ¬ (fcTypeOfName% "Erdos653.erdos_653") := by
  exact?
#print axioms probe_1_163

-- ATTACK fc-8432eac9-erdos653-erdos-653-42c9d5c2c1-counterexample-v1 apply_search
theorem probe_1_164 : ¬ (fcTypeOfName% "Erdos653.erdos_653") := by
  apply?
#print axioms probe_1_164

-- ATTACK fc-8432eac9-erdos653-erdos-653-42c9d5c2c1-counterexample-v1 library_search
theorem probe_1_165 : ¬ (fcTypeOfName% "Erdos653.erdos_653") := by
  library_search
#print axioms probe_1_165

-- ATTACK fc-8432eac9-erdos653-erdos-653-42c9d5c2c1-counterexample-v1 aesop_search
theorem probe_1_166 : ¬ (fcTypeOfName% "Erdos653.erdos_653") := by
  aesop?
#print axioms probe_1_166

-- ATTACK fc-8432eac9-erdos653-erdos-653-42c9d5c2c1-counterexample-v1 simp_search
theorem probe_1_167 : ¬ (fcTypeOfName% "Erdos653.erdos_653") := by
  simp?
#print axioms probe_1_167

end AttackBattery
