import FormalConjectures.ErdosProblems.«10»
import FormalConjectures.ErdosProblems.«18»
import FormalConjectures.ErdosProblems.«366»
import FormalConjectures.ErdosProblems.«653»
import TaskSupport

set_option maxHeartbeats 20000
namespace AttackBattery

-- ATTACK fc-8432eac9-erdos10-erdos-10-d27c264dfa-formalized-v1 simp
theorem probe_2_0 : fcTypeOfName% "Erdos10.erdos_10" := by
  simp
#print axioms probe_2_0

-- ATTACK fc-8432eac9-erdos10-erdos-10-d27c264dfa-formalized-v1 simpa
theorem probe_2_1 : fcTypeOfName% "Erdos10.erdos_10" := by
  simpa
#print axioms probe_2_1

-- ATTACK fc-8432eac9-erdos10-erdos-10-d27c264dfa-formalized-v1 simp_all
theorem probe_2_2 : fcTypeOfName% "Erdos10.erdos_10" := by
  simp_all
#print axioms probe_2_2

-- ATTACK fc-8432eac9-erdos10-erdos-10-d27c264dfa-formalized-v1 aesop
theorem probe_2_3 : fcTypeOfName% "Erdos10.erdos_10" := by
  aesop
#print axioms probe_2_3

-- ATTACK fc-8432eac9-erdos10-erdos-10-d27c264dfa-formalized-v1 omega
theorem probe_2_4 : fcTypeOfName% "Erdos10.erdos_10" := by
  omega
#print axioms probe_2_4

-- ATTACK fc-8432eac9-erdos10-erdos-10-d27c264dfa-formalized-v1 norm_num
theorem probe_2_5 : fcTypeOfName% "Erdos10.erdos_10" := by
  norm_num
#print axioms probe_2_5

-- ATTACK fc-8432eac9-erdos10-erdos-10-d27c264dfa-formalized-v1 decide
theorem probe_2_6 : fcTypeOfName% "Erdos10.erdos_10" := by
  decide
#print axioms probe_2_6

-- ATTACK fc-8432eac9-erdos10-erdos-10-d27c264dfa-formalized-v1 native_decide
theorem probe_2_7 : fcTypeOfName% "Erdos10.erdos_10" := by
  native_decide
#print axioms probe_2_7

-- ATTACK fc-8432eac9-erdos10-erdos-10-d27c264dfa-formalized-v1 true_intro
theorem probe_2_8 : fcTypeOfName% "Erdos10.erdos_10" := by
  exact True.intro
#print axioms probe_2_8

-- ATTACK fc-8432eac9-erdos10-erdos-10-d27c264dfa-formalized-v1 false_elim_simp
theorem probe_2_9 : fcTypeOfName% "Erdos10.erdos_10" := by
  apply False.elim
  simp_all
#print axioms probe_2_9

-- ATTACK fc-8432eac9-erdos10-erdos-10-d27c264dfa-formalized-v1 constructor
theorem probe_2_10 : fcTypeOfName% "Erdos10.erdos_10" := by
  constructor
#print axioms probe_2_10

-- ATTACK fc-8432eac9-erdos10-erdos-10-d27c264dfa-formalized-v1 constructor_simp
theorem probe_2_11 : fcTypeOfName% "Erdos10.erdos_10" := by
  constructor <;> simp
#print axioms probe_2_11

-- ATTACK fc-8432eac9-erdos10-erdos-10-d27c264dfa-formalized-v1 constructor_aesop
theorem probe_2_12 : fcTypeOfName% "Erdos10.erdos_10" := by
  constructor <;> aesop
#print axioms probe_2_12

-- ATTACK fc-8432eac9-erdos10-erdos-10-d27c264dfa-formalized-v1 rfl
theorem probe_2_13 : fcTypeOfName% "Erdos10.erdos_10" := by
  rfl
#print axioms probe_2_13

-- ATTACK fc-8432eac9-erdos10-erdos-10-d27c264dfa-formalized-v1 trivial
theorem probe_2_14 : fcTypeOfName% "Erdos10.erdos_10" := by
  trivial
#print axioms probe_2_14

-- ATTACK fc-8432eac9-erdos10-erdos-10-d27c264dfa-formalized-v1 tauto
theorem probe_2_15 : fcTypeOfName% "Erdos10.erdos_10" := by
  tauto
#print axioms probe_2_15

-- ATTACK fc-8432eac9-erdos10-erdos-10-d27c264dfa-formalized-v1 positivity
theorem probe_2_16 : fcTypeOfName% "Erdos10.erdos_10" := by
  positivity
#print axioms probe_2_16

-- ATTACK fc-8432eac9-erdos10-erdos-10-d27c264dfa-formalized-v1 linarith
theorem probe_2_17 : fcTypeOfName% "Erdos10.erdos_10" := by
  linarith
#print axioms probe_2_17

-- ATTACK fc-8432eac9-erdos10-erdos-10-d27c264dfa-formalized-v1 nlinarith
theorem probe_2_18 : fcTypeOfName% "Erdos10.erdos_10" := by
  nlinarith
#print axioms probe_2_18

-- ATTACK fc-8432eac9-erdos10-erdos-10-d27c264dfa-formalized-v1 intros_simp_all
theorem probe_2_19 : fcTypeOfName% "Erdos10.erdos_10" := by
  intros
  simp_all
#print axioms probe_2_19

-- ATTACK fc-8432eac9-erdos10-erdos-10-d27c264dfa-formalized-v1 intros_omega
theorem probe_2_20 : fcTypeOfName% "Erdos10.erdos_10" := by
  intros
  omega
#print axioms probe_2_20

-- ATTACK fc-8432eac9-erdos10-erdos-10-d27c264dfa-formalized-v1 intros_norm_num
theorem probe_2_21 : fcTypeOfName% "Erdos10.erdos_10" := by
  intros
  norm_num at *
#print axioms probe_2_21

-- ATTACK fc-8432eac9-erdos10-erdos-10-d27c264dfa-formalized-v1 intros_aesop
theorem probe_2_22 : fcTypeOfName% "Erdos10.erdos_10" := by
  intros
  aesop
#print axioms probe_2_22

-- ATTACK fc-8432eac9-erdos10-erdos-10-d27c264dfa-formalized-v1 by_contra_simp_all
theorem probe_2_23 : fcTypeOfName% "Erdos10.erdos_10" := by
  by_contra h
  simp_all
#print axioms probe_2_23

-- ATTACK fc-8432eac9-erdos10-erdos-10-d27c264dfa-formalized-v1 classical_simp_all
theorem probe_2_24 : fcTypeOfName% "Erdos10.erdos_10" := by
  classical
  simp_all
#print axioms probe_2_24

-- ATTACK fc-8432eac9-erdos10-erdos-10-d27c264dfa-formalized-v1 classical_aesop
theorem probe_2_25 : fcTypeOfName% "Erdos10.erdos_10" := by
  classical
  aesop
#print axioms probe_2_25

-- ATTACK fc-8432eac9-erdos10-erdos-10-d27c264dfa-formalized-v1 refine_pair_simp
theorem probe_2_26 : fcTypeOfName% "Erdos10.erdos_10" := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_2_26

-- ATTACK fc-8432eac9-erdos10-erdos-10-d27c264dfa-formalized-v1 refine_pair_aesop
theorem probe_2_27 : fcTypeOfName% "Erdos10.erdos_10" := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_2_27

-- ATTACK fc-8432eac9-erdos10-erdos-10-d27c264dfa-formalized-v1 use_zero_simp
theorem probe_2_28 : fcTypeOfName% "Erdos10.erdos_10" := by
  use 0 <;> simp
#print axioms probe_2_28

-- ATTACK fc-8432eac9-erdos10-erdos-10-d27c264dfa-formalized-v1 use_one_simp
theorem probe_2_29 : fcTypeOfName% "Erdos10.erdos_10" := by
  use 1 <;> simp
#print axioms probe_2_29

-- ATTACK fc-8432eac9-erdos10-erdos-10-d27c264dfa-formalized-v1 use_empty_simp
theorem probe_2_30 : fcTypeOfName% "Erdos10.erdos_10" := by
  use ∅ <;> simp
#print axioms probe_2_30

-- ATTACK fc-8432eac9-erdos10-erdos-10-d27c264dfa-formalized-v1 assumption
theorem probe_2_31 : fcTypeOfName% "Erdos10.erdos_10" := by
  assumption
#print axioms probe_2_31

-- ATTACK fc-8432eac9-erdos10-erdos-10-d27c264dfa-formalized-v1 infer_instance
theorem probe_2_32 : fcTypeOfName% "Erdos10.erdos_10" := by
  infer_instance
#print axioms probe_2_32

-- ATTACK fc-8432eac9-erdos10-erdos-10-d27c264dfa-formalized-v1 contradiction
theorem probe_2_33 : fcTypeOfName% "Erdos10.erdos_10" := by
  contradiction
#print axioms probe_2_33

-- ATTACK fc-8432eac9-erdos10-erdos-10-d27c264dfa-formalized-v1 solve_by_elim
theorem probe_2_34 : fcTypeOfName% "Erdos10.erdos_10" := by
  solve_by_elim
#print axioms probe_2_34

-- ATTACK fc-8432eac9-erdos10-erdos-10-d27c264dfa-formalized-v1 first_order
theorem probe_2_35 : fcTypeOfName% "Erdos10.erdos_10" := by
  first_order
#print axioms probe_2_35

-- ATTACK fc-8432eac9-erdos10-erdos-10-d27c264dfa-formalized-v1 grind
theorem probe_2_36 : fcTypeOfName% "Erdos10.erdos_10" := by
  grind
#print axioms probe_2_36

-- ATTACK fc-8432eac9-erdos10-erdos-10-d27c264dfa-formalized-v1 exact_search
theorem probe_2_37 : fcTypeOfName% "Erdos10.erdos_10" := by
  exact?
#print axioms probe_2_37

-- ATTACK fc-8432eac9-erdos10-erdos-10-d27c264dfa-formalized-v1 apply_search
theorem probe_2_38 : fcTypeOfName% "Erdos10.erdos_10" := by
  apply?
#print axioms probe_2_38

-- ATTACK fc-8432eac9-erdos10-erdos-10-d27c264dfa-formalized-v1 library_search
theorem probe_2_39 : fcTypeOfName% "Erdos10.erdos_10" := by
  library_search
#print axioms probe_2_39

-- ATTACK fc-8432eac9-erdos10-erdos-10-d27c264dfa-formalized-v1 aesop_search
theorem probe_2_40 : fcTypeOfName% "Erdos10.erdos_10" := by
  aesop?
#print axioms probe_2_40

-- ATTACK fc-8432eac9-erdos10-erdos-10-d27c264dfa-formalized-v1 simp_search
theorem probe_2_41 : fcTypeOfName% "Erdos10.erdos_10" := by
  simp?
#print axioms probe_2_41

-- ATTACK fc-8432eac9-erdos18-erdos-18b-9bd94d8707-formalized-v1 simp
theorem probe_2_42 : fcTypeOfName% "Erdos18.erdos_18b" := by
  simp
#print axioms probe_2_42

-- ATTACK fc-8432eac9-erdos18-erdos-18b-9bd94d8707-formalized-v1 simpa
theorem probe_2_43 : fcTypeOfName% "Erdos18.erdos_18b" := by
  simpa
#print axioms probe_2_43

-- ATTACK fc-8432eac9-erdos18-erdos-18b-9bd94d8707-formalized-v1 simp_all
theorem probe_2_44 : fcTypeOfName% "Erdos18.erdos_18b" := by
  simp_all
#print axioms probe_2_44

-- ATTACK fc-8432eac9-erdos18-erdos-18b-9bd94d8707-formalized-v1 aesop
theorem probe_2_45 : fcTypeOfName% "Erdos18.erdos_18b" := by
  aesop
#print axioms probe_2_45

-- ATTACK fc-8432eac9-erdos18-erdos-18b-9bd94d8707-formalized-v1 omega
theorem probe_2_46 : fcTypeOfName% "Erdos18.erdos_18b" := by
  omega
#print axioms probe_2_46

-- ATTACK fc-8432eac9-erdos18-erdos-18b-9bd94d8707-formalized-v1 norm_num
theorem probe_2_47 : fcTypeOfName% "Erdos18.erdos_18b" := by
  norm_num
#print axioms probe_2_47

-- ATTACK fc-8432eac9-erdos18-erdos-18b-9bd94d8707-formalized-v1 decide
theorem probe_2_48 : fcTypeOfName% "Erdos18.erdos_18b" := by
  decide
#print axioms probe_2_48

-- ATTACK fc-8432eac9-erdos18-erdos-18b-9bd94d8707-formalized-v1 native_decide
theorem probe_2_49 : fcTypeOfName% "Erdos18.erdos_18b" := by
  native_decide
#print axioms probe_2_49

-- ATTACK fc-8432eac9-erdos18-erdos-18b-9bd94d8707-formalized-v1 true_intro
theorem probe_2_50 : fcTypeOfName% "Erdos18.erdos_18b" := by
  exact True.intro
#print axioms probe_2_50

-- ATTACK fc-8432eac9-erdos18-erdos-18b-9bd94d8707-formalized-v1 false_elim_simp
theorem probe_2_51 : fcTypeOfName% "Erdos18.erdos_18b" := by
  apply False.elim
  simp_all
#print axioms probe_2_51

-- ATTACK fc-8432eac9-erdos18-erdos-18b-9bd94d8707-formalized-v1 constructor
theorem probe_2_52 : fcTypeOfName% "Erdos18.erdos_18b" := by
  constructor
#print axioms probe_2_52

-- ATTACK fc-8432eac9-erdos18-erdos-18b-9bd94d8707-formalized-v1 constructor_simp
theorem probe_2_53 : fcTypeOfName% "Erdos18.erdos_18b" := by
  constructor <;> simp
#print axioms probe_2_53

-- ATTACK fc-8432eac9-erdos18-erdos-18b-9bd94d8707-formalized-v1 constructor_aesop
theorem probe_2_54 : fcTypeOfName% "Erdos18.erdos_18b" := by
  constructor <;> aesop
#print axioms probe_2_54

-- ATTACK fc-8432eac9-erdos18-erdos-18b-9bd94d8707-formalized-v1 rfl
theorem probe_2_55 : fcTypeOfName% "Erdos18.erdos_18b" := by
  rfl
#print axioms probe_2_55

-- ATTACK fc-8432eac9-erdos18-erdos-18b-9bd94d8707-formalized-v1 trivial
theorem probe_2_56 : fcTypeOfName% "Erdos18.erdos_18b" := by
  trivial
#print axioms probe_2_56

-- ATTACK fc-8432eac9-erdos18-erdos-18b-9bd94d8707-formalized-v1 tauto
theorem probe_2_57 : fcTypeOfName% "Erdos18.erdos_18b" := by
  tauto
#print axioms probe_2_57

-- ATTACK fc-8432eac9-erdos18-erdos-18b-9bd94d8707-formalized-v1 positivity
theorem probe_2_58 : fcTypeOfName% "Erdos18.erdos_18b" := by
  positivity
#print axioms probe_2_58

-- ATTACK fc-8432eac9-erdos18-erdos-18b-9bd94d8707-formalized-v1 linarith
theorem probe_2_59 : fcTypeOfName% "Erdos18.erdos_18b" := by
  linarith
#print axioms probe_2_59

-- ATTACK fc-8432eac9-erdos18-erdos-18b-9bd94d8707-formalized-v1 nlinarith
theorem probe_2_60 : fcTypeOfName% "Erdos18.erdos_18b" := by
  nlinarith
#print axioms probe_2_60

-- ATTACK fc-8432eac9-erdos18-erdos-18b-9bd94d8707-formalized-v1 intros_simp_all
theorem probe_2_61 : fcTypeOfName% "Erdos18.erdos_18b" := by
  intros
  simp_all
#print axioms probe_2_61

-- ATTACK fc-8432eac9-erdos18-erdos-18b-9bd94d8707-formalized-v1 intros_omega
theorem probe_2_62 : fcTypeOfName% "Erdos18.erdos_18b" := by
  intros
  omega
#print axioms probe_2_62

-- ATTACK fc-8432eac9-erdos18-erdos-18b-9bd94d8707-formalized-v1 intros_norm_num
theorem probe_2_63 : fcTypeOfName% "Erdos18.erdos_18b" := by
  intros
  norm_num at *
#print axioms probe_2_63

-- ATTACK fc-8432eac9-erdos18-erdos-18b-9bd94d8707-formalized-v1 intros_aesop
theorem probe_2_64 : fcTypeOfName% "Erdos18.erdos_18b" := by
  intros
  aesop
#print axioms probe_2_64

-- ATTACK fc-8432eac9-erdos18-erdos-18b-9bd94d8707-formalized-v1 by_contra_simp_all
theorem probe_2_65 : fcTypeOfName% "Erdos18.erdos_18b" := by
  by_contra h
  simp_all
#print axioms probe_2_65

-- ATTACK fc-8432eac9-erdos18-erdos-18b-9bd94d8707-formalized-v1 classical_simp_all
theorem probe_2_66 : fcTypeOfName% "Erdos18.erdos_18b" := by
  classical
  simp_all
#print axioms probe_2_66

-- ATTACK fc-8432eac9-erdos18-erdos-18b-9bd94d8707-formalized-v1 classical_aesop
theorem probe_2_67 : fcTypeOfName% "Erdos18.erdos_18b" := by
  classical
  aesop
#print axioms probe_2_67

-- ATTACK fc-8432eac9-erdos18-erdos-18b-9bd94d8707-formalized-v1 refine_pair_simp
theorem probe_2_68 : fcTypeOfName% "Erdos18.erdos_18b" := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_2_68

-- ATTACK fc-8432eac9-erdos18-erdos-18b-9bd94d8707-formalized-v1 refine_pair_aesop
theorem probe_2_69 : fcTypeOfName% "Erdos18.erdos_18b" := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_2_69

-- ATTACK fc-8432eac9-erdos18-erdos-18b-9bd94d8707-formalized-v1 use_zero_simp
theorem probe_2_70 : fcTypeOfName% "Erdos18.erdos_18b" := by
  use 0 <;> simp
#print axioms probe_2_70

-- ATTACK fc-8432eac9-erdos18-erdos-18b-9bd94d8707-formalized-v1 use_one_simp
theorem probe_2_71 : fcTypeOfName% "Erdos18.erdos_18b" := by
  use 1 <;> simp
#print axioms probe_2_71

-- ATTACK fc-8432eac9-erdos18-erdos-18b-9bd94d8707-formalized-v1 use_empty_simp
theorem probe_2_72 : fcTypeOfName% "Erdos18.erdos_18b" := by
  use ∅ <;> simp
#print axioms probe_2_72

-- ATTACK fc-8432eac9-erdos18-erdos-18b-9bd94d8707-formalized-v1 assumption
theorem probe_2_73 : fcTypeOfName% "Erdos18.erdos_18b" := by
  assumption
#print axioms probe_2_73

-- ATTACK fc-8432eac9-erdos18-erdos-18b-9bd94d8707-formalized-v1 infer_instance
theorem probe_2_74 : fcTypeOfName% "Erdos18.erdos_18b" := by
  infer_instance
#print axioms probe_2_74

-- ATTACK fc-8432eac9-erdos18-erdos-18b-9bd94d8707-formalized-v1 contradiction
theorem probe_2_75 : fcTypeOfName% "Erdos18.erdos_18b" := by
  contradiction
#print axioms probe_2_75

-- ATTACK fc-8432eac9-erdos18-erdos-18b-9bd94d8707-formalized-v1 solve_by_elim
theorem probe_2_76 : fcTypeOfName% "Erdos18.erdos_18b" := by
  solve_by_elim
#print axioms probe_2_76

-- ATTACK fc-8432eac9-erdos18-erdos-18b-9bd94d8707-formalized-v1 first_order
theorem probe_2_77 : fcTypeOfName% "Erdos18.erdos_18b" := by
  first_order
#print axioms probe_2_77

-- ATTACK fc-8432eac9-erdos18-erdos-18b-9bd94d8707-formalized-v1 grind
theorem probe_2_78 : fcTypeOfName% "Erdos18.erdos_18b" := by
  grind
#print axioms probe_2_78

-- ATTACK fc-8432eac9-erdos18-erdos-18b-9bd94d8707-formalized-v1 exact_search
theorem probe_2_79 : fcTypeOfName% "Erdos18.erdos_18b" := by
  exact?
#print axioms probe_2_79

-- ATTACK fc-8432eac9-erdos18-erdos-18b-9bd94d8707-formalized-v1 apply_search
theorem probe_2_80 : fcTypeOfName% "Erdos18.erdos_18b" := by
  apply?
#print axioms probe_2_80

-- ATTACK fc-8432eac9-erdos18-erdos-18b-9bd94d8707-formalized-v1 library_search
theorem probe_2_81 : fcTypeOfName% "Erdos18.erdos_18b" := by
  library_search
#print axioms probe_2_81

-- ATTACK fc-8432eac9-erdos18-erdos-18b-9bd94d8707-formalized-v1 aesop_search
theorem probe_2_82 : fcTypeOfName% "Erdos18.erdos_18b" := by
  aesop?
#print axioms probe_2_82

-- ATTACK fc-8432eac9-erdos18-erdos-18b-9bd94d8707-formalized-v1 simp_search
theorem probe_2_83 : fcTypeOfName% "Erdos18.erdos_18b" := by
  simp?
#print axioms probe_2_83

-- ATTACK fc-8432eac9-erdos366-erdos-366-e013583642-formalized-v1 simp
theorem probe_2_84 : fcTypeOfName% "Erdos366.erdos_366" := by
  simp
#print axioms probe_2_84

-- ATTACK fc-8432eac9-erdos366-erdos-366-e013583642-formalized-v1 simpa
theorem probe_2_85 : fcTypeOfName% "Erdos366.erdos_366" := by
  simpa
#print axioms probe_2_85

-- ATTACK fc-8432eac9-erdos366-erdos-366-e013583642-formalized-v1 simp_all
theorem probe_2_86 : fcTypeOfName% "Erdos366.erdos_366" := by
  simp_all
#print axioms probe_2_86

-- ATTACK fc-8432eac9-erdos366-erdos-366-e013583642-formalized-v1 aesop
theorem probe_2_87 : fcTypeOfName% "Erdos366.erdos_366" := by
  aesop
#print axioms probe_2_87

-- ATTACK fc-8432eac9-erdos366-erdos-366-e013583642-formalized-v1 omega
theorem probe_2_88 : fcTypeOfName% "Erdos366.erdos_366" := by
  omega
#print axioms probe_2_88

-- ATTACK fc-8432eac9-erdos366-erdos-366-e013583642-formalized-v1 norm_num
theorem probe_2_89 : fcTypeOfName% "Erdos366.erdos_366" := by
  norm_num
#print axioms probe_2_89

-- ATTACK fc-8432eac9-erdos366-erdos-366-e013583642-formalized-v1 decide
theorem probe_2_90 : fcTypeOfName% "Erdos366.erdos_366" := by
  decide
#print axioms probe_2_90

-- ATTACK fc-8432eac9-erdos366-erdos-366-e013583642-formalized-v1 native_decide
theorem probe_2_91 : fcTypeOfName% "Erdos366.erdos_366" := by
  native_decide
#print axioms probe_2_91

-- ATTACK fc-8432eac9-erdos366-erdos-366-e013583642-formalized-v1 true_intro
theorem probe_2_92 : fcTypeOfName% "Erdos366.erdos_366" := by
  exact True.intro
#print axioms probe_2_92

-- ATTACK fc-8432eac9-erdos366-erdos-366-e013583642-formalized-v1 false_elim_simp
theorem probe_2_93 : fcTypeOfName% "Erdos366.erdos_366" := by
  apply False.elim
  simp_all
#print axioms probe_2_93

-- ATTACK fc-8432eac9-erdos366-erdos-366-e013583642-formalized-v1 constructor
theorem probe_2_94 : fcTypeOfName% "Erdos366.erdos_366" := by
  constructor
#print axioms probe_2_94

-- ATTACK fc-8432eac9-erdos366-erdos-366-e013583642-formalized-v1 constructor_simp
theorem probe_2_95 : fcTypeOfName% "Erdos366.erdos_366" := by
  constructor <;> simp
#print axioms probe_2_95

-- ATTACK fc-8432eac9-erdos366-erdos-366-e013583642-formalized-v1 constructor_aesop
theorem probe_2_96 : fcTypeOfName% "Erdos366.erdos_366" := by
  constructor <;> aesop
#print axioms probe_2_96

-- ATTACK fc-8432eac9-erdos366-erdos-366-e013583642-formalized-v1 rfl
theorem probe_2_97 : fcTypeOfName% "Erdos366.erdos_366" := by
  rfl
#print axioms probe_2_97

-- ATTACK fc-8432eac9-erdos366-erdos-366-e013583642-formalized-v1 trivial
theorem probe_2_98 : fcTypeOfName% "Erdos366.erdos_366" := by
  trivial
#print axioms probe_2_98

-- ATTACK fc-8432eac9-erdos366-erdos-366-e013583642-formalized-v1 tauto
theorem probe_2_99 : fcTypeOfName% "Erdos366.erdos_366" := by
  tauto
#print axioms probe_2_99

-- ATTACK fc-8432eac9-erdos366-erdos-366-e013583642-formalized-v1 positivity
theorem probe_2_100 : fcTypeOfName% "Erdos366.erdos_366" := by
  positivity
#print axioms probe_2_100

-- ATTACK fc-8432eac9-erdos366-erdos-366-e013583642-formalized-v1 linarith
theorem probe_2_101 : fcTypeOfName% "Erdos366.erdos_366" := by
  linarith
#print axioms probe_2_101

-- ATTACK fc-8432eac9-erdos366-erdos-366-e013583642-formalized-v1 nlinarith
theorem probe_2_102 : fcTypeOfName% "Erdos366.erdos_366" := by
  nlinarith
#print axioms probe_2_102

-- ATTACK fc-8432eac9-erdos366-erdos-366-e013583642-formalized-v1 intros_simp_all
theorem probe_2_103 : fcTypeOfName% "Erdos366.erdos_366" := by
  intros
  simp_all
#print axioms probe_2_103

-- ATTACK fc-8432eac9-erdos366-erdos-366-e013583642-formalized-v1 intros_omega
theorem probe_2_104 : fcTypeOfName% "Erdos366.erdos_366" := by
  intros
  omega
#print axioms probe_2_104

-- ATTACK fc-8432eac9-erdos366-erdos-366-e013583642-formalized-v1 intros_norm_num
theorem probe_2_105 : fcTypeOfName% "Erdos366.erdos_366" := by
  intros
  norm_num at *
#print axioms probe_2_105

-- ATTACK fc-8432eac9-erdos366-erdos-366-e013583642-formalized-v1 intros_aesop
theorem probe_2_106 : fcTypeOfName% "Erdos366.erdos_366" := by
  intros
  aesop
#print axioms probe_2_106

-- ATTACK fc-8432eac9-erdos366-erdos-366-e013583642-formalized-v1 by_contra_simp_all
theorem probe_2_107 : fcTypeOfName% "Erdos366.erdos_366" := by
  by_contra h
  simp_all
#print axioms probe_2_107

-- ATTACK fc-8432eac9-erdos366-erdos-366-e013583642-formalized-v1 classical_simp_all
theorem probe_2_108 : fcTypeOfName% "Erdos366.erdos_366" := by
  classical
  simp_all
#print axioms probe_2_108

-- ATTACK fc-8432eac9-erdos366-erdos-366-e013583642-formalized-v1 classical_aesop
theorem probe_2_109 : fcTypeOfName% "Erdos366.erdos_366" := by
  classical
  aesop
#print axioms probe_2_109

-- ATTACK fc-8432eac9-erdos366-erdos-366-e013583642-formalized-v1 refine_pair_simp
theorem probe_2_110 : fcTypeOfName% "Erdos366.erdos_366" := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_2_110

-- ATTACK fc-8432eac9-erdos366-erdos-366-e013583642-formalized-v1 refine_pair_aesop
theorem probe_2_111 : fcTypeOfName% "Erdos366.erdos_366" := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_2_111

-- ATTACK fc-8432eac9-erdos366-erdos-366-e013583642-formalized-v1 use_zero_simp
theorem probe_2_112 : fcTypeOfName% "Erdos366.erdos_366" := by
  use 0 <;> simp
#print axioms probe_2_112

-- ATTACK fc-8432eac9-erdos366-erdos-366-e013583642-formalized-v1 use_one_simp
theorem probe_2_113 : fcTypeOfName% "Erdos366.erdos_366" := by
  use 1 <;> simp
#print axioms probe_2_113

-- ATTACK fc-8432eac9-erdos366-erdos-366-e013583642-formalized-v1 use_empty_simp
theorem probe_2_114 : fcTypeOfName% "Erdos366.erdos_366" := by
  use ∅ <;> simp
#print axioms probe_2_114

-- ATTACK fc-8432eac9-erdos366-erdos-366-e013583642-formalized-v1 assumption
theorem probe_2_115 : fcTypeOfName% "Erdos366.erdos_366" := by
  assumption
#print axioms probe_2_115

-- ATTACK fc-8432eac9-erdos366-erdos-366-e013583642-formalized-v1 infer_instance
theorem probe_2_116 : fcTypeOfName% "Erdos366.erdos_366" := by
  infer_instance
#print axioms probe_2_116

-- ATTACK fc-8432eac9-erdos366-erdos-366-e013583642-formalized-v1 contradiction
theorem probe_2_117 : fcTypeOfName% "Erdos366.erdos_366" := by
  contradiction
#print axioms probe_2_117

-- ATTACK fc-8432eac9-erdos366-erdos-366-e013583642-formalized-v1 solve_by_elim
theorem probe_2_118 : fcTypeOfName% "Erdos366.erdos_366" := by
  solve_by_elim
#print axioms probe_2_118

-- ATTACK fc-8432eac9-erdos366-erdos-366-e013583642-formalized-v1 first_order
theorem probe_2_119 : fcTypeOfName% "Erdos366.erdos_366" := by
  first_order
#print axioms probe_2_119

-- ATTACK fc-8432eac9-erdos366-erdos-366-e013583642-formalized-v1 grind
theorem probe_2_120 : fcTypeOfName% "Erdos366.erdos_366" := by
  grind
#print axioms probe_2_120

-- ATTACK fc-8432eac9-erdos366-erdos-366-e013583642-formalized-v1 exact_search
theorem probe_2_121 : fcTypeOfName% "Erdos366.erdos_366" := by
  exact?
#print axioms probe_2_121

-- ATTACK fc-8432eac9-erdos366-erdos-366-e013583642-formalized-v1 apply_search
theorem probe_2_122 : fcTypeOfName% "Erdos366.erdos_366" := by
  apply?
#print axioms probe_2_122

-- ATTACK fc-8432eac9-erdos366-erdos-366-e013583642-formalized-v1 library_search
theorem probe_2_123 : fcTypeOfName% "Erdos366.erdos_366" := by
  library_search
#print axioms probe_2_123

-- ATTACK fc-8432eac9-erdos366-erdos-366-e013583642-formalized-v1 aesop_search
theorem probe_2_124 : fcTypeOfName% "Erdos366.erdos_366" := by
  aesop?
#print axioms probe_2_124

-- ATTACK fc-8432eac9-erdos366-erdos-366-e013583642-formalized-v1 simp_search
theorem probe_2_125 : fcTypeOfName% "Erdos366.erdos_366" := by
  simp?
#print axioms probe_2_125

-- ATTACK fc-8432eac9-erdos653-erdos-653-15000f4d45-formalized-v1 simp
theorem probe_2_126 : fcTypeOfName% "Erdos653.erdos_653" := by
  simp
#print axioms probe_2_126

-- ATTACK fc-8432eac9-erdos653-erdos-653-15000f4d45-formalized-v1 simpa
theorem probe_2_127 : fcTypeOfName% "Erdos653.erdos_653" := by
  simpa
#print axioms probe_2_127

-- ATTACK fc-8432eac9-erdos653-erdos-653-15000f4d45-formalized-v1 simp_all
theorem probe_2_128 : fcTypeOfName% "Erdos653.erdos_653" := by
  simp_all
#print axioms probe_2_128

-- ATTACK fc-8432eac9-erdos653-erdos-653-15000f4d45-formalized-v1 aesop
theorem probe_2_129 : fcTypeOfName% "Erdos653.erdos_653" := by
  aesop
#print axioms probe_2_129

-- ATTACK fc-8432eac9-erdos653-erdos-653-15000f4d45-formalized-v1 omega
theorem probe_2_130 : fcTypeOfName% "Erdos653.erdos_653" := by
  omega
#print axioms probe_2_130

-- ATTACK fc-8432eac9-erdos653-erdos-653-15000f4d45-formalized-v1 norm_num
theorem probe_2_131 : fcTypeOfName% "Erdos653.erdos_653" := by
  norm_num
#print axioms probe_2_131

-- ATTACK fc-8432eac9-erdos653-erdos-653-15000f4d45-formalized-v1 decide
theorem probe_2_132 : fcTypeOfName% "Erdos653.erdos_653" := by
  decide
#print axioms probe_2_132

-- ATTACK fc-8432eac9-erdos653-erdos-653-15000f4d45-formalized-v1 native_decide
theorem probe_2_133 : fcTypeOfName% "Erdos653.erdos_653" := by
  native_decide
#print axioms probe_2_133

-- ATTACK fc-8432eac9-erdos653-erdos-653-15000f4d45-formalized-v1 true_intro
theorem probe_2_134 : fcTypeOfName% "Erdos653.erdos_653" := by
  exact True.intro
#print axioms probe_2_134

-- ATTACK fc-8432eac9-erdos653-erdos-653-15000f4d45-formalized-v1 false_elim_simp
theorem probe_2_135 : fcTypeOfName% "Erdos653.erdos_653" := by
  apply False.elim
  simp_all
#print axioms probe_2_135

-- ATTACK fc-8432eac9-erdos653-erdos-653-15000f4d45-formalized-v1 constructor
theorem probe_2_136 : fcTypeOfName% "Erdos653.erdos_653" := by
  constructor
#print axioms probe_2_136

-- ATTACK fc-8432eac9-erdos653-erdos-653-15000f4d45-formalized-v1 constructor_simp
theorem probe_2_137 : fcTypeOfName% "Erdos653.erdos_653" := by
  constructor <;> simp
#print axioms probe_2_137

-- ATTACK fc-8432eac9-erdos653-erdos-653-15000f4d45-formalized-v1 constructor_aesop
theorem probe_2_138 : fcTypeOfName% "Erdos653.erdos_653" := by
  constructor <;> aesop
#print axioms probe_2_138

-- ATTACK fc-8432eac9-erdos653-erdos-653-15000f4d45-formalized-v1 rfl
theorem probe_2_139 : fcTypeOfName% "Erdos653.erdos_653" := by
  rfl
#print axioms probe_2_139

-- ATTACK fc-8432eac9-erdos653-erdos-653-15000f4d45-formalized-v1 trivial
theorem probe_2_140 : fcTypeOfName% "Erdos653.erdos_653" := by
  trivial
#print axioms probe_2_140

-- ATTACK fc-8432eac9-erdos653-erdos-653-15000f4d45-formalized-v1 tauto
theorem probe_2_141 : fcTypeOfName% "Erdos653.erdos_653" := by
  tauto
#print axioms probe_2_141

-- ATTACK fc-8432eac9-erdos653-erdos-653-15000f4d45-formalized-v1 positivity
theorem probe_2_142 : fcTypeOfName% "Erdos653.erdos_653" := by
  positivity
#print axioms probe_2_142

-- ATTACK fc-8432eac9-erdos653-erdos-653-15000f4d45-formalized-v1 linarith
theorem probe_2_143 : fcTypeOfName% "Erdos653.erdos_653" := by
  linarith
#print axioms probe_2_143

-- ATTACK fc-8432eac9-erdos653-erdos-653-15000f4d45-formalized-v1 nlinarith
theorem probe_2_144 : fcTypeOfName% "Erdos653.erdos_653" := by
  nlinarith
#print axioms probe_2_144

-- ATTACK fc-8432eac9-erdos653-erdos-653-15000f4d45-formalized-v1 intros_simp_all
theorem probe_2_145 : fcTypeOfName% "Erdos653.erdos_653" := by
  intros
  simp_all
#print axioms probe_2_145

-- ATTACK fc-8432eac9-erdos653-erdos-653-15000f4d45-formalized-v1 intros_omega
theorem probe_2_146 : fcTypeOfName% "Erdos653.erdos_653" := by
  intros
  omega
#print axioms probe_2_146

-- ATTACK fc-8432eac9-erdos653-erdos-653-15000f4d45-formalized-v1 intros_norm_num
theorem probe_2_147 : fcTypeOfName% "Erdos653.erdos_653" := by
  intros
  norm_num at *
#print axioms probe_2_147

-- ATTACK fc-8432eac9-erdos653-erdos-653-15000f4d45-formalized-v1 intros_aesop
theorem probe_2_148 : fcTypeOfName% "Erdos653.erdos_653" := by
  intros
  aesop
#print axioms probe_2_148

-- ATTACK fc-8432eac9-erdos653-erdos-653-15000f4d45-formalized-v1 by_contra_simp_all
theorem probe_2_149 : fcTypeOfName% "Erdos653.erdos_653" := by
  by_contra h
  simp_all
#print axioms probe_2_149

-- ATTACK fc-8432eac9-erdos653-erdos-653-15000f4d45-formalized-v1 classical_simp_all
theorem probe_2_150 : fcTypeOfName% "Erdos653.erdos_653" := by
  classical
  simp_all
#print axioms probe_2_150

-- ATTACK fc-8432eac9-erdos653-erdos-653-15000f4d45-formalized-v1 classical_aesop
theorem probe_2_151 : fcTypeOfName% "Erdos653.erdos_653" := by
  classical
  aesop
#print axioms probe_2_151

-- ATTACK fc-8432eac9-erdos653-erdos-653-15000f4d45-formalized-v1 refine_pair_simp
theorem probe_2_152 : fcTypeOfName% "Erdos653.erdos_653" := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_2_152

-- ATTACK fc-8432eac9-erdos653-erdos-653-15000f4d45-formalized-v1 refine_pair_aesop
theorem probe_2_153 : fcTypeOfName% "Erdos653.erdos_653" := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_2_153

-- ATTACK fc-8432eac9-erdos653-erdos-653-15000f4d45-formalized-v1 use_zero_simp
theorem probe_2_154 : fcTypeOfName% "Erdos653.erdos_653" := by
  use 0 <;> simp
#print axioms probe_2_154

-- ATTACK fc-8432eac9-erdos653-erdos-653-15000f4d45-formalized-v1 use_one_simp
theorem probe_2_155 : fcTypeOfName% "Erdos653.erdos_653" := by
  use 1 <;> simp
#print axioms probe_2_155

-- ATTACK fc-8432eac9-erdos653-erdos-653-15000f4d45-formalized-v1 use_empty_simp
theorem probe_2_156 : fcTypeOfName% "Erdos653.erdos_653" := by
  use ∅ <;> simp
#print axioms probe_2_156

-- ATTACK fc-8432eac9-erdos653-erdos-653-15000f4d45-formalized-v1 assumption
theorem probe_2_157 : fcTypeOfName% "Erdos653.erdos_653" := by
  assumption
#print axioms probe_2_157

-- ATTACK fc-8432eac9-erdos653-erdos-653-15000f4d45-formalized-v1 infer_instance
theorem probe_2_158 : fcTypeOfName% "Erdos653.erdos_653" := by
  infer_instance
#print axioms probe_2_158

-- ATTACK fc-8432eac9-erdos653-erdos-653-15000f4d45-formalized-v1 contradiction
theorem probe_2_159 : fcTypeOfName% "Erdos653.erdos_653" := by
  contradiction
#print axioms probe_2_159

-- ATTACK fc-8432eac9-erdos653-erdos-653-15000f4d45-formalized-v1 solve_by_elim
theorem probe_2_160 : fcTypeOfName% "Erdos653.erdos_653" := by
  solve_by_elim
#print axioms probe_2_160

-- ATTACK fc-8432eac9-erdos653-erdos-653-15000f4d45-formalized-v1 first_order
theorem probe_2_161 : fcTypeOfName% "Erdos653.erdos_653" := by
  first_order
#print axioms probe_2_161

-- ATTACK fc-8432eac9-erdos653-erdos-653-15000f4d45-formalized-v1 grind
theorem probe_2_162 : fcTypeOfName% "Erdos653.erdos_653" := by
  grind
#print axioms probe_2_162

-- ATTACK fc-8432eac9-erdos653-erdos-653-15000f4d45-formalized-v1 exact_search
theorem probe_2_163 : fcTypeOfName% "Erdos653.erdos_653" := by
  exact?
#print axioms probe_2_163

-- ATTACK fc-8432eac9-erdos653-erdos-653-15000f4d45-formalized-v1 apply_search
theorem probe_2_164 : fcTypeOfName% "Erdos653.erdos_653" := by
  apply?
#print axioms probe_2_164

-- ATTACK fc-8432eac9-erdos653-erdos-653-15000f4d45-formalized-v1 library_search
theorem probe_2_165 : fcTypeOfName% "Erdos653.erdos_653" := by
  library_search
#print axioms probe_2_165

-- ATTACK fc-8432eac9-erdos653-erdos-653-15000f4d45-formalized-v1 aesop_search
theorem probe_2_166 : fcTypeOfName% "Erdos653.erdos_653" := by
  aesop?
#print axioms probe_2_166

-- ATTACK fc-8432eac9-erdos653-erdos-653-15000f4d45-formalized-v1 simp_search
theorem probe_2_167 : fcTypeOfName% "Erdos653.erdos_653" := by
  simp?
#print axioms probe_2_167

end AttackBattery
