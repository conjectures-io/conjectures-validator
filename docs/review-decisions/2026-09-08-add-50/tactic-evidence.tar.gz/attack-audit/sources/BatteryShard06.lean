import FormalConjectures.ErdosProblems.«1082»
import FormalConjectures.ErdosProblems.«124»
import FormalConjectures.ErdosProblems.«234»
import FormalConjectures.ErdosProblems.«30»
import FormalConjectures.ErdosProblems.«323»
import FormalConjectures.ErdosProblems.«413»
import FormalConjectures.ErdosProblems.«647»
import FormalConjectures.ErdosProblems.«770»
import FormalConjectures.ErdosProblems.«930»
import FormalConjectures.ErdosProblems.«944»
import FormalConjectures.ErdosProblems.«979»
import FormalConjectures.GreensOpenProblems.«44»
import TaskSupport

set_option maxHeartbeats 20000
namespace AttackBattery

-- ATTACK fc-379fc029-parts-i-475be06ddd-formalized-v1 simp
theorem probe_6_0 : fcTypeOfName% "Erdos1082.erdos_1082.parts.i" := by
  simp
#print axioms probe_6_0

-- ATTACK fc-379fc029-parts-i-475be06ddd-formalized-v1 simpa
theorem probe_6_1 : fcTypeOfName% "Erdos1082.erdos_1082.parts.i" := by
  simpa
#print axioms probe_6_1

-- ATTACK fc-379fc029-parts-i-475be06ddd-formalized-v1 simp_all
theorem probe_6_2 : fcTypeOfName% "Erdos1082.erdos_1082.parts.i" := by
  simp_all
#print axioms probe_6_2

-- ATTACK fc-379fc029-parts-i-475be06ddd-formalized-v1 aesop
theorem probe_6_3 : fcTypeOfName% "Erdos1082.erdos_1082.parts.i" := by
  aesop
#print axioms probe_6_3

-- ATTACK fc-379fc029-parts-i-475be06ddd-formalized-v1 omega
theorem probe_6_4 : fcTypeOfName% "Erdos1082.erdos_1082.parts.i" := by
  omega
#print axioms probe_6_4

-- ATTACK fc-379fc029-parts-i-475be06ddd-formalized-v1 norm_num
theorem probe_6_5 : fcTypeOfName% "Erdos1082.erdos_1082.parts.i" := by
  norm_num
#print axioms probe_6_5

-- ATTACK fc-379fc029-parts-i-475be06ddd-formalized-v1 decide
theorem probe_6_6 : fcTypeOfName% "Erdos1082.erdos_1082.parts.i" := by
  decide
#print axioms probe_6_6

-- ATTACK fc-379fc029-parts-i-475be06ddd-formalized-v1 native_decide
theorem probe_6_7 : fcTypeOfName% "Erdos1082.erdos_1082.parts.i" := by
  native_decide
#print axioms probe_6_7

-- ATTACK fc-379fc029-parts-i-475be06ddd-formalized-v1 true_intro
theorem probe_6_8 : fcTypeOfName% "Erdos1082.erdos_1082.parts.i" := by
  exact True.intro
#print axioms probe_6_8

-- ATTACK fc-379fc029-parts-i-475be06ddd-formalized-v1 false_elim_simp
theorem probe_6_9 : fcTypeOfName% "Erdos1082.erdos_1082.parts.i" := by
  apply False.elim
  simp_all
#print axioms probe_6_9

-- ATTACK fc-379fc029-parts-i-475be06ddd-formalized-v1 constructor
theorem probe_6_10 : fcTypeOfName% "Erdos1082.erdos_1082.parts.i" := by
  constructor
#print axioms probe_6_10

-- ATTACK fc-379fc029-parts-i-475be06ddd-formalized-v1 constructor_simp
theorem probe_6_11 : fcTypeOfName% "Erdos1082.erdos_1082.parts.i" := by
  constructor <;> simp
#print axioms probe_6_11

-- ATTACK fc-379fc029-parts-i-475be06ddd-formalized-v1 constructor_aesop
theorem probe_6_12 : fcTypeOfName% "Erdos1082.erdos_1082.parts.i" := by
  constructor <;> aesop
#print axioms probe_6_12

-- ATTACK fc-379fc029-parts-i-475be06ddd-formalized-v1 rfl
theorem probe_6_13 : fcTypeOfName% "Erdos1082.erdos_1082.parts.i" := by
  rfl
#print axioms probe_6_13

-- ATTACK fc-379fc029-parts-i-475be06ddd-formalized-v1 trivial
theorem probe_6_14 : fcTypeOfName% "Erdos1082.erdos_1082.parts.i" := by
  trivial
#print axioms probe_6_14

-- ATTACK fc-379fc029-parts-i-475be06ddd-formalized-v1 tauto
theorem probe_6_15 : fcTypeOfName% "Erdos1082.erdos_1082.parts.i" := by
  tauto
#print axioms probe_6_15

-- ATTACK fc-379fc029-parts-i-475be06ddd-formalized-v1 positivity
theorem probe_6_16 : fcTypeOfName% "Erdos1082.erdos_1082.parts.i" := by
  positivity
#print axioms probe_6_16

-- ATTACK fc-379fc029-parts-i-475be06ddd-formalized-v1 linarith
theorem probe_6_17 : fcTypeOfName% "Erdos1082.erdos_1082.parts.i" := by
  linarith
#print axioms probe_6_17

-- ATTACK fc-379fc029-parts-i-475be06ddd-formalized-v1 nlinarith
theorem probe_6_18 : fcTypeOfName% "Erdos1082.erdos_1082.parts.i" := by
  nlinarith
#print axioms probe_6_18

-- ATTACK fc-379fc029-parts-i-475be06ddd-formalized-v1 intros_simp_all
theorem probe_6_19 : fcTypeOfName% "Erdos1082.erdos_1082.parts.i" := by
  intros
  simp_all
#print axioms probe_6_19

-- ATTACK fc-379fc029-parts-i-475be06ddd-formalized-v1 intros_omega
theorem probe_6_20 : fcTypeOfName% "Erdos1082.erdos_1082.parts.i" := by
  intros
  omega
#print axioms probe_6_20

-- ATTACK fc-379fc029-parts-i-475be06ddd-formalized-v1 intros_norm_num
theorem probe_6_21 : fcTypeOfName% "Erdos1082.erdos_1082.parts.i" := by
  intros
  norm_num at *
#print axioms probe_6_21

-- ATTACK fc-379fc029-parts-i-475be06ddd-formalized-v1 intros_aesop
theorem probe_6_22 : fcTypeOfName% "Erdos1082.erdos_1082.parts.i" := by
  intros
  aesop
#print axioms probe_6_22

-- ATTACK fc-379fc029-parts-i-475be06ddd-formalized-v1 by_contra_simp_all
theorem probe_6_23 : fcTypeOfName% "Erdos1082.erdos_1082.parts.i" := by
  by_contra h
  simp_all
#print axioms probe_6_23

-- ATTACK fc-379fc029-parts-i-475be06ddd-formalized-v1 classical_simp_all
theorem probe_6_24 : fcTypeOfName% "Erdos1082.erdos_1082.parts.i" := by
  classical
  simp_all
#print axioms probe_6_24

-- ATTACK fc-379fc029-parts-i-475be06ddd-formalized-v1 classical_aesop
theorem probe_6_25 : fcTypeOfName% "Erdos1082.erdos_1082.parts.i" := by
  classical
  aesop
#print axioms probe_6_25

-- ATTACK fc-379fc029-parts-i-475be06ddd-formalized-v1 refine_pair_simp
theorem probe_6_26 : fcTypeOfName% "Erdos1082.erdos_1082.parts.i" := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_6_26

-- ATTACK fc-379fc029-parts-i-475be06ddd-formalized-v1 refine_pair_aesop
theorem probe_6_27 : fcTypeOfName% "Erdos1082.erdos_1082.parts.i" := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_6_27

-- ATTACK fc-379fc029-parts-i-475be06ddd-formalized-v1 use_zero_simp
theorem probe_6_28 : fcTypeOfName% "Erdos1082.erdos_1082.parts.i" := by
  use 0 <;> simp
#print axioms probe_6_28

-- ATTACK fc-379fc029-parts-i-475be06ddd-formalized-v1 use_one_simp
theorem probe_6_29 : fcTypeOfName% "Erdos1082.erdos_1082.parts.i" := by
  use 1 <;> simp
#print axioms probe_6_29

-- ATTACK fc-379fc029-parts-i-475be06ddd-formalized-v1 use_empty_simp
theorem probe_6_30 : fcTypeOfName% "Erdos1082.erdos_1082.parts.i" := by
  use ∅ <;> simp
#print axioms probe_6_30

-- ATTACK fc-379fc029-parts-i-475be06ddd-formalized-v1 assumption
theorem probe_6_31 : fcTypeOfName% "Erdos1082.erdos_1082.parts.i" := by
  assumption
#print axioms probe_6_31

-- ATTACK fc-379fc029-parts-i-475be06ddd-formalized-v1 infer_instance
theorem probe_6_32 : fcTypeOfName% "Erdos1082.erdos_1082.parts.i" := by
  infer_instance
#print axioms probe_6_32

-- ATTACK fc-379fc029-parts-i-475be06ddd-formalized-v1 contradiction
theorem probe_6_33 : fcTypeOfName% "Erdos1082.erdos_1082.parts.i" := by
  contradiction
#print axioms probe_6_33

-- ATTACK fc-379fc029-parts-i-475be06ddd-formalized-v1 solve_by_elim
theorem probe_6_34 : fcTypeOfName% "Erdos1082.erdos_1082.parts.i" := by
  solve_by_elim
#print axioms probe_6_34

-- ATTACK fc-379fc029-parts-i-475be06ddd-formalized-v1 first_order
theorem probe_6_35 : fcTypeOfName% "Erdos1082.erdos_1082.parts.i" := by
  first_order
#print axioms probe_6_35

-- ATTACK fc-379fc029-parts-i-475be06ddd-formalized-v1 grind
theorem probe_6_36 : fcTypeOfName% "Erdos1082.erdos_1082.parts.i" := by
  grind
#print axioms probe_6_36

-- ATTACK fc-379fc029-parts-i-475be06ddd-formalized-v1 exact_search
theorem probe_6_37 : fcTypeOfName% "Erdos1082.erdos_1082.parts.i" := by
  exact?
#print axioms probe_6_37

-- ATTACK fc-379fc029-parts-i-475be06ddd-formalized-v1 apply_search
theorem probe_6_38 : fcTypeOfName% "Erdos1082.erdos_1082.parts.i" := by
  apply?
#print axioms probe_6_38

-- ATTACK fc-379fc029-parts-i-475be06ddd-formalized-v1 library_search
theorem probe_6_39 : fcTypeOfName% "Erdos1082.erdos_1082.parts.i" := by
  library_search
#print axioms probe_6_39

-- ATTACK fc-379fc029-parts-i-475be06ddd-formalized-v1 aesop_search
theorem probe_6_40 : fcTypeOfName% "Erdos1082.erdos_1082.parts.i" := by
  aesop?
#print axioms probe_6_40

-- ATTACK fc-379fc029-parts-i-475be06ddd-formalized-v1 simp_search
theorem probe_6_41 : fcTypeOfName% "Erdos1082.erdos_1082.parts.i" := by
  simp?
#print axioms probe_6_41

-- ATTACK fc-379fc029-erdos124-ne-zero-2f8a958348-formalized-v1 simp
theorem probe_6_42 : fcTypeOfName% "Erdos124.erdos124.ne_zero" := by
  simp
#print axioms probe_6_42

-- ATTACK fc-379fc029-erdos124-ne-zero-2f8a958348-formalized-v1 simpa
theorem probe_6_43 : fcTypeOfName% "Erdos124.erdos124.ne_zero" := by
  simpa
#print axioms probe_6_43

-- ATTACK fc-379fc029-erdos124-ne-zero-2f8a958348-formalized-v1 simp_all
theorem probe_6_44 : fcTypeOfName% "Erdos124.erdos124.ne_zero" := by
  simp_all
#print axioms probe_6_44

-- ATTACK fc-379fc029-erdos124-ne-zero-2f8a958348-formalized-v1 aesop
theorem probe_6_45 : fcTypeOfName% "Erdos124.erdos124.ne_zero" := by
  aesop
#print axioms probe_6_45

-- ATTACK fc-379fc029-erdos124-ne-zero-2f8a958348-formalized-v1 omega
theorem probe_6_46 : fcTypeOfName% "Erdos124.erdos124.ne_zero" := by
  omega
#print axioms probe_6_46

-- ATTACK fc-379fc029-erdos124-ne-zero-2f8a958348-formalized-v1 norm_num
theorem probe_6_47 : fcTypeOfName% "Erdos124.erdos124.ne_zero" := by
  norm_num
#print axioms probe_6_47

-- ATTACK fc-379fc029-erdos124-ne-zero-2f8a958348-formalized-v1 decide
theorem probe_6_48 : fcTypeOfName% "Erdos124.erdos124.ne_zero" := by
  decide
#print axioms probe_6_48

-- ATTACK fc-379fc029-erdos124-ne-zero-2f8a958348-formalized-v1 native_decide
theorem probe_6_49 : fcTypeOfName% "Erdos124.erdos124.ne_zero" := by
  native_decide
#print axioms probe_6_49

-- ATTACK fc-379fc029-erdos124-ne-zero-2f8a958348-formalized-v1 true_intro
theorem probe_6_50 : fcTypeOfName% "Erdos124.erdos124.ne_zero" := by
  exact True.intro
#print axioms probe_6_50

-- ATTACK fc-379fc029-erdos124-ne-zero-2f8a958348-formalized-v1 false_elim_simp
theorem probe_6_51 : fcTypeOfName% "Erdos124.erdos124.ne_zero" := by
  apply False.elim
  simp_all
#print axioms probe_6_51

-- ATTACK fc-379fc029-erdos124-ne-zero-2f8a958348-formalized-v1 constructor
theorem probe_6_52 : fcTypeOfName% "Erdos124.erdos124.ne_zero" := by
  constructor
#print axioms probe_6_52

-- ATTACK fc-379fc029-erdos124-ne-zero-2f8a958348-formalized-v1 constructor_simp
theorem probe_6_53 : fcTypeOfName% "Erdos124.erdos124.ne_zero" := by
  constructor <;> simp
#print axioms probe_6_53

-- ATTACK fc-379fc029-erdos124-ne-zero-2f8a958348-formalized-v1 constructor_aesop
theorem probe_6_54 : fcTypeOfName% "Erdos124.erdos124.ne_zero" := by
  constructor <;> aesop
#print axioms probe_6_54

-- ATTACK fc-379fc029-erdos124-ne-zero-2f8a958348-formalized-v1 rfl
theorem probe_6_55 : fcTypeOfName% "Erdos124.erdos124.ne_zero" := by
  rfl
#print axioms probe_6_55

-- ATTACK fc-379fc029-erdos124-ne-zero-2f8a958348-formalized-v1 trivial
theorem probe_6_56 : fcTypeOfName% "Erdos124.erdos124.ne_zero" := by
  trivial
#print axioms probe_6_56

-- ATTACK fc-379fc029-erdos124-ne-zero-2f8a958348-formalized-v1 tauto
theorem probe_6_57 : fcTypeOfName% "Erdos124.erdos124.ne_zero" := by
  tauto
#print axioms probe_6_57

-- ATTACK fc-379fc029-erdos124-ne-zero-2f8a958348-formalized-v1 positivity
theorem probe_6_58 : fcTypeOfName% "Erdos124.erdos124.ne_zero" := by
  positivity
#print axioms probe_6_58

-- ATTACK fc-379fc029-erdos124-ne-zero-2f8a958348-formalized-v1 linarith
theorem probe_6_59 : fcTypeOfName% "Erdos124.erdos124.ne_zero" := by
  linarith
#print axioms probe_6_59

-- ATTACK fc-379fc029-erdos124-ne-zero-2f8a958348-formalized-v1 nlinarith
theorem probe_6_60 : fcTypeOfName% "Erdos124.erdos124.ne_zero" := by
  nlinarith
#print axioms probe_6_60

-- ATTACK fc-379fc029-erdos124-ne-zero-2f8a958348-formalized-v1 intros_simp_all
theorem probe_6_61 : fcTypeOfName% "Erdos124.erdos124.ne_zero" := by
  intros
  simp_all
#print axioms probe_6_61

-- ATTACK fc-379fc029-erdos124-ne-zero-2f8a958348-formalized-v1 intros_omega
theorem probe_6_62 : fcTypeOfName% "Erdos124.erdos124.ne_zero" := by
  intros
  omega
#print axioms probe_6_62

-- ATTACK fc-379fc029-erdos124-ne-zero-2f8a958348-formalized-v1 intros_norm_num
theorem probe_6_63 : fcTypeOfName% "Erdos124.erdos124.ne_zero" := by
  intros
  norm_num at *
#print axioms probe_6_63

-- ATTACK fc-379fc029-erdos124-ne-zero-2f8a958348-formalized-v1 intros_aesop
theorem probe_6_64 : fcTypeOfName% "Erdos124.erdos124.ne_zero" := by
  intros
  aesop
#print axioms probe_6_64

-- ATTACK fc-379fc029-erdos124-ne-zero-2f8a958348-formalized-v1 by_contra_simp_all
theorem probe_6_65 : fcTypeOfName% "Erdos124.erdos124.ne_zero" := by
  by_contra h
  simp_all
#print axioms probe_6_65

-- ATTACK fc-379fc029-erdos124-ne-zero-2f8a958348-formalized-v1 classical_simp_all
theorem probe_6_66 : fcTypeOfName% "Erdos124.erdos124.ne_zero" := by
  classical
  simp_all
#print axioms probe_6_66

-- ATTACK fc-379fc029-erdos124-ne-zero-2f8a958348-formalized-v1 classical_aesop
theorem probe_6_67 : fcTypeOfName% "Erdos124.erdos124.ne_zero" := by
  classical
  aesop
#print axioms probe_6_67

-- ATTACK fc-379fc029-erdos124-ne-zero-2f8a958348-formalized-v1 refine_pair_simp
theorem probe_6_68 : fcTypeOfName% "Erdos124.erdos124.ne_zero" := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_6_68

-- ATTACK fc-379fc029-erdos124-ne-zero-2f8a958348-formalized-v1 refine_pair_aesop
theorem probe_6_69 : fcTypeOfName% "Erdos124.erdos124.ne_zero" := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_6_69

-- ATTACK fc-379fc029-erdos124-ne-zero-2f8a958348-formalized-v1 use_zero_simp
theorem probe_6_70 : fcTypeOfName% "Erdos124.erdos124.ne_zero" := by
  use 0 <;> simp
#print axioms probe_6_70

-- ATTACK fc-379fc029-erdos124-ne-zero-2f8a958348-formalized-v1 use_one_simp
theorem probe_6_71 : fcTypeOfName% "Erdos124.erdos124.ne_zero" := by
  use 1 <;> simp
#print axioms probe_6_71

-- ATTACK fc-379fc029-erdos124-ne-zero-2f8a958348-formalized-v1 use_empty_simp
theorem probe_6_72 : fcTypeOfName% "Erdos124.erdos124.ne_zero" := by
  use ∅ <;> simp
#print axioms probe_6_72

-- ATTACK fc-379fc029-erdos124-ne-zero-2f8a958348-formalized-v1 assumption
theorem probe_6_73 : fcTypeOfName% "Erdos124.erdos124.ne_zero" := by
  assumption
#print axioms probe_6_73

-- ATTACK fc-379fc029-erdos124-ne-zero-2f8a958348-formalized-v1 infer_instance
theorem probe_6_74 : fcTypeOfName% "Erdos124.erdos124.ne_zero" := by
  infer_instance
#print axioms probe_6_74

-- ATTACK fc-379fc029-erdos124-ne-zero-2f8a958348-formalized-v1 contradiction
theorem probe_6_75 : fcTypeOfName% "Erdos124.erdos124.ne_zero" := by
  contradiction
#print axioms probe_6_75

-- ATTACK fc-379fc029-erdos124-ne-zero-2f8a958348-formalized-v1 solve_by_elim
theorem probe_6_76 : fcTypeOfName% "Erdos124.erdos124.ne_zero" := by
  solve_by_elim
#print axioms probe_6_76

-- ATTACK fc-379fc029-erdos124-ne-zero-2f8a958348-formalized-v1 first_order
theorem probe_6_77 : fcTypeOfName% "Erdos124.erdos124.ne_zero" := by
  first_order
#print axioms probe_6_77

-- ATTACK fc-379fc029-erdos124-ne-zero-2f8a958348-formalized-v1 grind
theorem probe_6_78 : fcTypeOfName% "Erdos124.erdos124.ne_zero" := by
  grind
#print axioms probe_6_78

-- ATTACK fc-379fc029-erdos124-ne-zero-2f8a958348-formalized-v1 exact_search
theorem probe_6_79 : fcTypeOfName% "Erdos124.erdos124.ne_zero" := by
  exact?
#print axioms probe_6_79

-- ATTACK fc-379fc029-erdos124-ne-zero-2f8a958348-formalized-v1 apply_search
theorem probe_6_80 : fcTypeOfName% "Erdos124.erdos124.ne_zero" := by
  apply?
#print axioms probe_6_80

-- ATTACK fc-379fc029-erdos124-ne-zero-2f8a958348-formalized-v1 library_search
theorem probe_6_81 : fcTypeOfName% "Erdos124.erdos124.ne_zero" := by
  library_search
#print axioms probe_6_81

-- ATTACK fc-379fc029-erdos124-ne-zero-2f8a958348-formalized-v1 aesop_search
theorem probe_6_82 : fcTypeOfName% "Erdos124.erdos124.ne_zero" := by
  aesop?
#print axioms probe_6_82

-- ATTACK fc-379fc029-erdos124-ne-zero-2f8a958348-formalized-v1 simp_search
theorem probe_6_83 : fcTypeOfName% "Erdos124.erdos124.ne_zero" := by
  simp?
#print axioms probe_6_83

-- ATTACK fc-379fc029-erdos234-erdos-234-f69d94bdbc-formalized-v1 simp
theorem probe_6_84 : fcTypeOfName% "Erdos234.erdos_234" := by
  simp
#print axioms probe_6_84

-- ATTACK fc-379fc029-erdos234-erdos-234-f69d94bdbc-formalized-v1 simpa
theorem probe_6_85 : fcTypeOfName% "Erdos234.erdos_234" := by
  simpa
#print axioms probe_6_85

-- ATTACK fc-379fc029-erdos234-erdos-234-f69d94bdbc-formalized-v1 simp_all
theorem probe_6_86 : fcTypeOfName% "Erdos234.erdos_234" := by
  simp_all
#print axioms probe_6_86

-- ATTACK fc-379fc029-erdos234-erdos-234-f69d94bdbc-formalized-v1 aesop
theorem probe_6_87 : fcTypeOfName% "Erdos234.erdos_234" := by
  aesop
#print axioms probe_6_87

-- ATTACK fc-379fc029-erdos234-erdos-234-f69d94bdbc-formalized-v1 omega
theorem probe_6_88 : fcTypeOfName% "Erdos234.erdos_234" := by
  omega
#print axioms probe_6_88

-- ATTACK fc-379fc029-erdos234-erdos-234-f69d94bdbc-formalized-v1 norm_num
theorem probe_6_89 : fcTypeOfName% "Erdos234.erdos_234" := by
  norm_num
#print axioms probe_6_89

-- ATTACK fc-379fc029-erdos234-erdos-234-f69d94bdbc-formalized-v1 decide
theorem probe_6_90 : fcTypeOfName% "Erdos234.erdos_234" := by
  decide
#print axioms probe_6_90

-- ATTACK fc-379fc029-erdos234-erdos-234-f69d94bdbc-formalized-v1 native_decide
theorem probe_6_91 : fcTypeOfName% "Erdos234.erdos_234" := by
  native_decide
#print axioms probe_6_91

-- ATTACK fc-379fc029-erdos234-erdos-234-f69d94bdbc-formalized-v1 true_intro
theorem probe_6_92 : fcTypeOfName% "Erdos234.erdos_234" := by
  exact True.intro
#print axioms probe_6_92

-- ATTACK fc-379fc029-erdos234-erdos-234-f69d94bdbc-formalized-v1 false_elim_simp
theorem probe_6_93 : fcTypeOfName% "Erdos234.erdos_234" := by
  apply False.elim
  simp_all
#print axioms probe_6_93

-- ATTACK fc-379fc029-erdos234-erdos-234-f69d94bdbc-formalized-v1 constructor
theorem probe_6_94 : fcTypeOfName% "Erdos234.erdos_234" := by
  constructor
#print axioms probe_6_94

-- ATTACK fc-379fc029-erdos234-erdos-234-f69d94bdbc-formalized-v1 constructor_simp
theorem probe_6_95 : fcTypeOfName% "Erdos234.erdos_234" := by
  constructor <;> simp
#print axioms probe_6_95

-- ATTACK fc-379fc029-erdos234-erdos-234-f69d94bdbc-formalized-v1 constructor_aesop
theorem probe_6_96 : fcTypeOfName% "Erdos234.erdos_234" := by
  constructor <;> aesop
#print axioms probe_6_96

-- ATTACK fc-379fc029-erdos234-erdos-234-f69d94bdbc-formalized-v1 rfl
theorem probe_6_97 : fcTypeOfName% "Erdos234.erdos_234" := by
  rfl
#print axioms probe_6_97

-- ATTACK fc-379fc029-erdos234-erdos-234-f69d94bdbc-formalized-v1 trivial
theorem probe_6_98 : fcTypeOfName% "Erdos234.erdos_234" := by
  trivial
#print axioms probe_6_98

-- ATTACK fc-379fc029-erdos234-erdos-234-f69d94bdbc-formalized-v1 tauto
theorem probe_6_99 : fcTypeOfName% "Erdos234.erdos_234" := by
  tauto
#print axioms probe_6_99

-- ATTACK fc-379fc029-erdos234-erdos-234-f69d94bdbc-formalized-v1 positivity
theorem probe_6_100 : fcTypeOfName% "Erdos234.erdos_234" := by
  positivity
#print axioms probe_6_100

-- ATTACK fc-379fc029-erdos234-erdos-234-f69d94bdbc-formalized-v1 linarith
theorem probe_6_101 : fcTypeOfName% "Erdos234.erdos_234" := by
  linarith
#print axioms probe_6_101

-- ATTACK fc-379fc029-erdos234-erdos-234-f69d94bdbc-formalized-v1 nlinarith
theorem probe_6_102 : fcTypeOfName% "Erdos234.erdos_234" := by
  nlinarith
#print axioms probe_6_102

-- ATTACK fc-379fc029-erdos234-erdos-234-f69d94bdbc-formalized-v1 intros_simp_all
theorem probe_6_103 : fcTypeOfName% "Erdos234.erdos_234" := by
  intros
  simp_all
#print axioms probe_6_103

-- ATTACK fc-379fc029-erdos234-erdos-234-f69d94bdbc-formalized-v1 intros_omega
theorem probe_6_104 : fcTypeOfName% "Erdos234.erdos_234" := by
  intros
  omega
#print axioms probe_6_104

-- ATTACK fc-379fc029-erdos234-erdos-234-f69d94bdbc-formalized-v1 intros_norm_num
theorem probe_6_105 : fcTypeOfName% "Erdos234.erdos_234" := by
  intros
  norm_num at *
#print axioms probe_6_105

-- ATTACK fc-379fc029-erdos234-erdos-234-f69d94bdbc-formalized-v1 intros_aesop
theorem probe_6_106 : fcTypeOfName% "Erdos234.erdos_234" := by
  intros
  aesop
#print axioms probe_6_106

-- ATTACK fc-379fc029-erdos234-erdos-234-f69d94bdbc-formalized-v1 by_contra_simp_all
theorem probe_6_107 : fcTypeOfName% "Erdos234.erdos_234" := by
  by_contra h
  simp_all
#print axioms probe_6_107

-- ATTACK fc-379fc029-erdos234-erdos-234-f69d94bdbc-formalized-v1 classical_simp_all
theorem probe_6_108 : fcTypeOfName% "Erdos234.erdos_234" := by
  classical
  simp_all
#print axioms probe_6_108

-- ATTACK fc-379fc029-erdos234-erdos-234-f69d94bdbc-formalized-v1 classical_aesop
theorem probe_6_109 : fcTypeOfName% "Erdos234.erdos_234" := by
  classical
  aesop
#print axioms probe_6_109

-- ATTACK fc-379fc029-erdos234-erdos-234-f69d94bdbc-formalized-v1 refine_pair_simp
theorem probe_6_110 : fcTypeOfName% "Erdos234.erdos_234" := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_6_110

-- ATTACK fc-379fc029-erdos234-erdos-234-f69d94bdbc-formalized-v1 refine_pair_aesop
theorem probe_6_111 : fcTypeOfName% "Erdos234.erdos_234" := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_6_111

-- ATTACK fc-379fc029-erdos234-erdos-234-f69d94bdbc-formalized-v1 use_zero_simp
theorem probe_6_112 : fcTypeOfName% "Erdos234.erdos_234" := by
  use 0 <;> simp
#print axioms probe_6_112

-- ATTACK fc-379fc029-erdos234-erdos-234-f69d94bdbc-formalized-v1 use_one_simp
theorem probe_6_113 : fcTypeOfName% "Erdos234.erdos_234" := by
  use 1 <;> simp
#print axioms probe_6_113

-- ATTACK fc-379fc029-erdos234-erdos-234-f69d94bdbc-formalized-v1 use_empty_simp
theorem probe_6_114 : fcTypeOfName% "Erdos234.erdos_234" := by
  use ∅ <;> simp
#print axioms probe_6_114

-- ATTACK fc-379fc029-erdos234-erdos-234-f69d94bdbc-formalized-v1 assumption
theorem probe_6_115 : fcTypeOfName% "Erdos234.erdos_234" := by
  assumption
#print axioms probe_6_115

-- ATTACK fc-379fc029-erdos234-erdos-234-f69d94bdbc-formalized-v1 infer_instance
theorem probe_6_116 : fcTypeOfName% "Erdos234.erdos_234" := by
  infer_instance
#print axioms probe_6_116

-- ATTACK fc-379fc029-erdos234-erdos-234-f69d94bdbc-formalized-v1 contradiction
theorem probe_6_117 : fcTypeOfName% "Erdos234.erdos_234" := by
  contradiction
#print axioms probe_6_117

-- ATTACK fc-379fc029-erdos234-erdos-234-f69d94bdbc-formalized-v1 solve_by_elim
theorem probe_6_118 : fcTypeOfName% "Erdos234.erdos_234" := by
  solve_by_elim
#print axioms probe_6_118

-- ATTACK fc-379fc029-erdos234-erdos-234-f69d94bdbc-formalized-v1 first_order
theorem probe_6_119 : fcTypeOfName% "Erdos234.erdos_234" := by
  first_order
#print axioms probe_6_119

-- ATTACK fc-379fc029-erdos234-erdos-234-f69d94bdbc-formalized-v1 grind
theorem probe_6_120 : fcTypeOfName% "Erdos234.erdos_234" := by
  grind
#print axioms probe_6_120

-- ATTACK fc-379fc029-erdos234-erdos-234-f69d94bdbc-formalized-v1 exact_search
theorem probe_6_121 : fcTypeOfName% "Erdos234.erdos_234" := by
  exact?
#print axioms probe_6_121

-- ATTACK fc-379fc029-erdos234-erdos-234-f69d94bdbc-formalized-v1 apply_search
theorem probe_6_122 : fcTypeOfName% "Erdos234.erdos_234" := by
  apply?
#print axioms probe_6_122

-- ATTACK fc-379fc029-erdos234-erdos-234-f69d94bdbc-formalized-v1 library_search
theorem probe_6_123 : fcTypeOfName% "Erdos234.erdos_234" := by
  library_search
#print axioms probe_6_123

-- ATTACK fc-379fc029-erdos234-erdos-234-f69d94bdbc-formalized-v1 aesop_search
theorem probe_6_124 : fcTypeOfName% "Erdos234.erdos_234" := by
  aesop?
#print axioms probe_6_124

-- ATTACK fc-379fc029-erdos234-erdos-234-f69d94bdbc-formalized-v1 simp_search
theorem probe_6_125 : fcTypeOfName% "Erdos234.erdos_234" := by
  simp?
#print axioms probe_6_125

-- ATTACK fc-379fc029-erdos30-erdos-30-c75cce8ff6-formalized-v1 simp
theorem probe_6_126 : fcTypeOfName% "Erdos30.erdos_30" := by
  simp
#print axioms probe_6_126

-- ATTACK fc-379fc029-erdos30-erdos-30-c75cce8ff6-formalized-v1 simpa
theorem probe_6_127 : fcTypeOfName% "Erdos30.erdos_30" := by
  simpa
#print axioms probe_6_127

-- ATTACK fc-379fc029-erdos30-erdos-30-c75cce8ff6-formalized-v1 simp_all
theorem probe_6_128 : fcTypeOfName% "Erdos30.erdos_30" := by
  simp_all
#print axioms probe_6_128

-- ATTACK fc-379fc029-erdos30-erdos-30-c75cce8ff6-formalized-v1 aesop
theorem probe_6_129 : fcTypeOfName% "Erdos30.erdos_30" := by
  aesop
#print axioms probe_6_129

-- ATTACK fc-379fc029-erdos30-erdos-30-c75cce8ff6-formalized-v1 omega
theorem probe_6_130 : fcTypeOfName% "Erdos30.erdos_30" := by
  omega
#print axioms probe_6_130

-- ATTACK fc-379fc029-erdos30-erdos-30-c75cce8ff6-formalized-v1 norm_num
theorem probe_6_131 : fcTypeOfName% "Erdos30.erdos_30" := by
  norm_num
#print axioms probe_6_131

-- ATTACK fc-379fc029-erdos30-erdos-30-c75cce8ff6-formalized-v1 decide
theorem probe_6_132 : fcTypeOfName% "Erdos30.erdos_30" := by
  decide
#print axioms probe_6_132

-- ATTACK fc-379fc029-erdos30-erdos-30-c75cce8ff6-formalized-v1 native_decide
theorem probe_6_133 : fcTypeOfName% "Erdos30.erdos_30" := by
  native_decide
#print axioms probe_6_133

-- ATTACK fc-379fc029-erdos30-erdos-30-c75cce8ff6-formalized-v1 true_intro
theorem probe_6_134 : fcTypeOfName% "Erdos30.erdos_30" := by
  exact True.intro
#print axioms probe_6_134

-- ATTACK fc-379fc029-erdos30-erdos-30-c75cce8ff6-formalized-v1 false_elim_simp
theorem probe_6_135 : fcTypeOfName% "Erdos30.erdos_30" := by
  apply False.elim
  simp_all
#print axioms probe_6_135

-- ATTACK fc-379fc029-erdos30-erdos-30-c75cce8ff6-formalized-v1 constructor
theorem probe_6_136 : fcTypeOfName% "Erdos30.erdos_30" := by
  constructor
#print axioms probe_6_136

-- ATTACK fc-379fc029-erdos30-erdos-30-c75cce8ff6-formalized-v1 constructor_simp
theorem probe_6_137 : fcTypeOfName% "Erdos30.erdos_30" := by
  constructor <;> simp
#print axioms probe_6_137

-- ATTACK fc-379fc029-erdos30-erdos-30-c75cce8ff6-formalized-v1 constructor_aesop
theorem probe_6_138 : fcTypeOfName% "Erdos30.erdos_30" := by
  constructor <;> aesop
#print axioms probe_6_138

-- ATTACK fc-379fc029-erdos30-erdos-30-c75cce8ff6-formalized-v1 rfl
theorem probe_6_139 : fcTypeOfName% "Erdos30.erdos_30" := by
  rfl
#print axioms probe_6_139

-- ATTACK fc-379fc029-erdos30-erdos-30-c75cce8ff6-formalized-v1 trivial
theorem probe_6_140 : fcTypeOfName% "Erdos30.erdos_30" := by
  trivial
#print axioms probe_6_140

-- ATTACK fc-379fc029-erdos30-erdos-30-c75cce8ff6-formalized-v1 tauto
theorem probe_6_141 : fcTypeOfName% "Erdos30.erdos_30" := by
  tauto
#print axioms probe_6_141

-- ATTACK fc-379fc029-erdos30-erdos-30-c75cce8ff6-formalized-v1 positivity
theorem probe_6_142 : fcTypeOfName% "Erdos30.erdos_30" := by
  positivity
#print axioms probe_6_142

-- ATTACK fc-379fc029-erdos30-erdos-30-c75cce8ff6-formalized-v1 linarith
theorem probe_6_143 : fcTypeOfName% "Erdos30.erdos_30" := by
  linarith
#print axioms probe_6_143

-- ATTACK fc-379fc029-erdos30-erdos-30-c75cce8ff6-formalized-v1 nlinarith
theorem probe_6_144 : fcTypeOfName% "Erdos30.erdos_30" := by
  nlinarith
#print axioms probe_6_144

-- ATTACK fc-379fc029-erdos30-erdos-30-c75cce8ff6-formalized-v1 intros_simp_all
theorem probe_6_145 : fcTypeOfName% "Erdos30.erdos_30" := by
  intros
  simp_all
#print axioms probe_6_145

-- ATTACK fc-379fc029-erdos30-erdos-30-c75cce8ff6-formalized-v1 intros_omega
theorem probe_6_146 : fcTypeOfName% "Erdos30.erdos_30" := by
  intros
  omega
#print axioms probe_6_146

-- ATTACK fc-379fc029-erdos30-erdos-30-c75cce8ff6-formalized-v1 intros_norm_num
theorem probe_6_147 : fcTypeOfName% "Erdos30.erdos_30" := by
  intros
  norm_num at *
#print axioms probe_6_147

-- ATTACK fc-379fc029-erdos30-erdos-30-c75cce8ff6-formalized-v1 intros_aesop
theorem probe_6_148 : fcTypeOfName% "Erdos30.erdos_30" := by
  intros
  aesop
#print axioms probe_6_148

-- ATTACK fc-379fc029-erdos30-erdos-30-c75cce8ff6-formalized-v1 by_contra_simp_all
theorem probe_6_149 : fcTypeOfName% "Erdos30.erdos_30" := by
  by_contra h
  simp_all
#print axioms probe_6_149

-- ATTACK fc-379fc029-erdos30-erdos-30-c75cce8ff6-formalized-v1 classical_simp_all
theorem probe_6_150 : fcTypeOfName% "Erdos30.erdos_30" := by
  classical
  simp_all
#print axioms probe_6_150

-- ATTACK fc-379fc029-erdos30-erdos-30-c75cce8ff6-formalized-v1 classical_aesop
theorem probe_6_151 : fcTypeOfName% "Erdos30.erdos_30" := by
  classical
  aesop
#print axioms probe_6_151

-- ATTACK fc-379fc029-erdos30-erdos-30-c75cce8ff6-formalized-v1 refine_pair_simp
theorem probe_6_152 : fcTypeOfName% "Erdos30.erdos_30" := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_6_152

-- ATTACK fc-379fc029-erdos30-erdos-30-c75cce8ff6-formalized-v1 refine_pair_aesop
theorem probe_6_153 : fcTypeOfName% "Erdos30.erdos_30" := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_6_153

-- ATTACK fc-379fc029-erdos30-erdos-30-c75cce8ff6-formalized-v1 use_zero_simp
theorem probe_6_154 : fcTypeOfName% "Erdos30.erdos_30" := by
  use 0 <;> simp
#print axioms probe_6_154

-- ATTACK fc-379fc029-erdos30-erdos-30-c75cce8ff6-formalized-v1 use_one_simp
theorem probe_6_155 : fcTypeOfName% "Erdos30.erdos_30" := by
  use 1 <;> simp
#print axioms probe_6_155

-- ATTACK fc-379fc029-erdos30-erdos-30-c75cce8ff6-formalized-v1 use_empty_simp
theorem probe_6_156 : fcTypeOfName% "Erdos30.erdos_30" := by
  use ∅ <;> simp
#print axioms probe_6_156

-- ATTACK fc-379fc029-erdos30-erdos-30-c75cce8ff6-formalized-v1 assumption
theorem probe_6_157 : fcTypeOfName% "Erdos30.erdos_30" := by
  assumption
#print axioms probe_6_157

-- ATTACK fc-379fc029-erdos30-erdos-30-c75cce8ff6-formalized-v1 infer_instance
theorem probe_6_158 : fcTypeOfName% "Erdos30.erdos_30" := by
  infer_instance
#print axioms probe_6_158

-- ATTACK fc-379fc029-erdos30-erdos-30-c75cce8ff6-formalized-v1 contradiction
theorem probe_6_159 : fcTypeOfName% "Erdos30.erdos_30" := by
  contradiction
#print axioms probe_6_159

-- ATTACK fc-379fc029-erdos30-erdos-30-c75cce8ff6-formalized-v1 solve_by_elim
theorem probe_6_160 : fcTypeOfName% "Erdos30.erdos_30" := by
  solve_by_elim
#print axioms probe_6_160

-- ATTACK fc-379fc029-erdos30-erdos-30-c75cce8ff6-formalized-v1 first_order
theorem probe_6_161 : fcTypeOfName% "Erdos30.erdos_30" := by
  first_order
#print axioms probe_6_161

-- ATTACK fc-379fc029-erdos30-erdos-30-c75cce8ff6-formalized-v1 grind
theorem probe_6_162 : fcTypeOfName% "Erdos30.erdos_30" := by
  grind
#print axioms probe_6_162

-- ATTACK fc-379fc029-erdos30-erdos-30-c75cce8ff6-formalized-v1 exact_search
theorem probe_6_163 : fcTypeOfName% "Erdos30.erdos_30" := by
  exact?
#print axioms probe_6_163

-- ATTACK fc-379fc029-erdos30-erdos-30-c75cce8ff6-formalized-v1 apply_search
theorem probe_6_164 : fcTypeOfName% "Erdos30.erdos_30" := by
  apply?
#print axioms probe_6_164

-- ATTACK fc-379fc029-erdos30-erdos-30-c75cce8ff6-formalized-v1 library_search
theorem probe_6_165 : fcTypeOfName% "Erdos30.erdos_30" := by
  library_search
#print axioms probe_6_165

-- ATTACK fc-379fc029-erdos30-erdos-30-c75cce8ff6-formalized-v1 aesop_search
theorem probe_6_166 : fcTypeOfName% "Erdos30.erdos_30" := by
  aesop?
#print axioms probe_6_166

-- ATTACK fc-379fc029-erdos30-erdos-30-c75cce8ff6-formalized-v1 simp_search
theorem probe_6_167 : fcTypeOfName% "Erdos30.erdos_30" := by
  simp?
#print axioms probe_6_167

-- ATTACK fc-379fc029-parts-i-a290e29580-formalized-v1 simp
theorem probe_6_168 : fcTypeOfName% "Erdos323.erdos_323.parts.i" := by
  simp
#print axioms probe_6_168

-- ATTACK fc-379fc029-parts-i-a290e29580-formalized-v1 simpa
theorem probe_6_169 : fcTypeOfName% "Erdos323.erdos_323.parts.i" := by
  simpa
#print axioms probe_6_169

-- ATTACK fc-379fc029-parts-i-a290e29580-formalized-v1 simp_all
theorem probe_6_170 : fcTypeOfName% "Erdos323.erdos_323.parts.i" := by
  simp_all
#print axioms probe_6_170

-- ATTACK fc-379fc029-parts-i-a290e29580-formalized-v1 aesop
theorem probe_6_171 : fcTypeOfName% "Erdos323.erdos_323.parts.i" := by
  aesop
#print axioms probe_6_171

-- ATTACK fc-379fc029-parts-i-a290e29580-formalized-v1 omega
theorem probe_6_172 : fcTypeOfName% "Erdos323.erdos_323.parts.i" := by
  omega
#print axioms probe_6_172

-- ATTACK fc-379fc029-parts-i-a290e29580-formalized-v1 norm_num
theorem probe_6_173 : fcTypeOfName% "Erdos323.erdos_323.parts.i" := by
  norm_num
#print axioms probe_6_173

-- ATTACK fc-379fc029-parts-i-a290e29580-formalized-v1 decide
theorem probe_6_174 : fcTypeOfName% "Erdos323.erdos_323.parts.i" := by
  decide
#print axioms probe_6_174

-- ATTACK fc-379fc029-parts-i-a290e29580-formalized-v1 native_decide
theorem probe_6_175 : fcTypeOfName% "Erdos323.erdos_323.parts.i" := by
  native_decide
#print axioms probe_6_175

-- ATTACK fc-379fc029-parts-i-a290e29580-formalized-v1 true_intro
theorem probe_6_176 : fcTypeOfName% "Erdos323.erdos_323.parts.i" := by
  exact True.intro
#print axioms probe_6_176

-- ATTACK fc-379fc029-parts-i-a290e29580-formalized-v1 false_elim_simp
theorem probe_6_177 : fcTypeOfName% "Erdos323.erdos_323.parts.i" := by
  apply False.elim
  simp_all
#print axioms probe_6_177

-- ATTACK fc-379fc029-parts-i-a290e29580-formalized-v1 constructor
theorem probe_6_178 : fcTypeOfName% "Erdos323.erdos_323.parts.i" := by
  constructor
#print axioms probe_6_178

-- ATTACK fc-379fc029-parts-i-a290e29580-formalized-v1 constructor_simp
theorem probe_6_179 : fcTypeOfName% "Erdos323.erdos_323.parts.i" := by
  constructor <;> simp
#print axioms probe_6_179

-- ATTACK fc-379fc029-parts-i-a290e29580-formalized-v1 constructor_aesop
theorem probe_6_180 : fcTypeOfName% "Erdos323.erdos_323.parts.i" := by
  constructor <;> aesop
#print axioms probe_6_180

-- ATTACK fc-379fc029-parts-i-a290e29580-formalized-v1 rfl
theorem probe_6_181 : fcTypeOfName% "Erdos323.erdos_323.parts.i" := by
  rfl
#print axioms probe_6_181

-- ATTACK fc-379fc029-parts-i-a290e29580-formalized-v1 trivial
theorem probe_6_182 : fcTypeOfName% "Erdos323.erdos_323.parts.i" := by
  trivial
#print axioms probe_6_182

-- ATTACK fc-379fc029-parts-i-a290e29580-formalized-v1 tauto
theorem probe_6_183 : fcTypeOfName% "Erdos323.erdos_323.parts.i" := by
  tauto
#print axioms probe_6_183

-- ATTACK fc-379fc029-parts-i-a290e29580-formalized-v1 positivity
theorem probe_6_184 : fcTypeOfName% "Erdos323.erdos_323.parts.i" := by
  positivity
#print axioms probe_6_184

-- ATTACK fc-379fc029-parts-i-a290e29580-formalized-v1 linarith
theorem probe_6_185 : fcTypeOfName% "Erdos323.erdos_323.parts.i" := by
  linarith
#print axioms probe_6_185

-- ATTACK fc-379fc029-parts-i-a290e29580-formalized-v1 nlinarith
theorem probe_6_186 : fcTypeOfName% "Erdos323.erdos_323.parts.i" := by
  nlinarith
#print axioms probe_6_186

-- ATTACK fc-379fc029-parts-i-a290e29580-formalized-v1 intros_simp_all
theorem probe_6_187 : fcTypeOfName% "Erdos323.erdos_323.parts.i" := by
  intros
  simp_all
#print axioms probe_6_187

-- ATTACK fc-379fc029-parts-i-a290e29580-formalized-v1 intros_omega
theorem probe_6_188 : fcTypeOfName% "Erdos323.erdos_323.parts.i" := by
  intros
  omega
#print axioms probe_6_188

-- ATTACK fc-379fc029-parts-i-a290e29580-formalized-v1 intros_norm_num
theorem probe_6_189 : fcTypeOfName% "Erdos323.erdos_323.parts.i" := by
  intros
  norm_num at *
#print axioms probe_6_189

-- ATTACK fc-379fc029-parts-i-a290e29580-formalized-v1 intros_aesop
theorem probe_6_190 : fcTypeOfName% "Erdos323.erdos_323.parts.i" := by
  intros
  aesop
#print axioms probe_6_190

-- ATTACK fc-379fc029-parts-i-a290e29580-formalized-v1 by_contra_simp_all
theorem probe_6_191 : fcTypeOfName% "Erdos323.erdos_323.parts.i" := by
  by_contra h
  simp_all
#print axioms probe_6_191

-- ATTACK fc-379fc029-parts-i-a290e29580-formalized-v1 classical_simp_all
theorem probe_6_192 : fcTypeOfName% "Erdos323.erdos_323.parts.i" := by
  classical
  simp_all
#print axioms probe_6_192

-- ATTACK fc-379fc029-parts-i-a290e29580-formalized-v1 classical_aesop
theorem probe_6_193 : fcTypeOfName% "Erdos323.erdos_323.parts.i" := by
  classical
  aesop
#print axioms probe_6_193

-- ATTACK fc-379fc029-parts-i-a290e29580-formalized-v1 refine_pair_simp
theorem probe_6_194 : fcTypeOfName% "Erdos323.erdos_323.parts.i" := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_6_194

-- ATTACK fc-379fc029-parts-i-a290e29580-formalized-v1 refine_pair_aesop
theorem probe_6_195 : fcTypeOfName% "Erdos323.erdos_323.parts.i" := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_6_195

-- ATTACK fc-379fc029-parts-i-a290e29580-formalized-v1 use_zero_simp
theorem probe_6_196 : fcTypeOfName% "Erdos323.erdos_323.parts.i" := by
  use 0 <;> simp
#print axioms probe_6_196

-- ATTACK fc-379fc029-parts-i-a290e29580-formalized-v1 use_one_simp
theorem probe_6_197 : fcTypeOfName% "Erdos323.erdos_323.parts.i" := by
  use 1 <;> simp
#print axioms probe_6_197

-- ATTACK fc-379fc029-parts-i-a290e29580-formalized-v1 use_empty_simp
theorem probe_6_198 : fcTypeOfName% "Erdos323.erdos_323.parts.i" := by
  use ∅ <;> simp
#print axioms probe_6_198

-- ATTACK fc-379fc029-parts-i-a290e29580-formalized-v1 assumption
theorem probe_6_199 : fcTypeOfName% "Erdos323.erdos_323.parts.i" := by
  assumption
#print axioms probe_6_199

-- ATTACK fc-379fc029-parts-i-a290e29580-formalized-v1 infer_instance
theorem probe_6_200 : fcTypeOfName% "Erdos323.erdos_323.parts.i" := by
  infer_instance
#print axioms probe_6_200

-- ATTACK fc-379fc029-parts-i-a290e29580-formalized-v1 contradiction
theorem probe_6_201 : fcTypeOfName% "Erdos323.erdos_323.parts.i" := by
  contradiction
#print axioms probe_6_201

-- ATTACK fc-379fc029-parts-i-a290e29580-formalized-v1 solve_by_elim
theorem probe_6_202 : fcTypeOfName% "Erdos323.erdos_323.parts.i" := by
  solve_by_elim
#print axioms probe_6_202

-- ATTACK fc-379fc029-parts-i-a290e29580-formalized-v1 first_order
theorem probe_6_203 : fcTypeOfName% "Erdos323.erdos_323.parts.i" := by
  first_order
#print axioms probe_6_203

-- ATTACK fc-379fc029-parts-i-a290e29580-formalized-v1 grind
theorem probe_6_204 : fcTypeOfName% "Erdos323.erdos_323.parts.i" := by
  grind
#print axioms probe_6_204

-- ATTACK fc-379fc029-parts-i-a290e29580-formalized-v1 exact_search
theorem probe_6_205 : fcTypeOfName% "Erdos323.erdos_323.parts.i" := by
  exact?
#print axioms probe_6_205

-- ATTACK fc-379fc029-parts-i-a290e29580-formalized-v1 apply_search
theorem probe_6_206 : fcTypeOfName% "Erdos323.erdos_323.parts.i" := by
  apply?
#print axioms probe_6_206

-- ATTACK fc-379fc029-parts-i-a290e29580-formalized-v1 library_search
theorem probe_6_207 : fcTypeOfName% "Erdos323.erdos_323.parts.i" := by
  library_search
#print axioms probe_6_207

-- ATTACK fc-379fc029-parts-i-a290e29580-formalized-v1 aesop_search
theorem probe_6_208 : fcTypeOfName% "Erdos323.erdos_323.parts.i" := by
  aesop?
#print axioms probe_6_208

-- ATTACK fc-379fc029-parts-i-a290e29580-formalized-v1 simp_search
theorem probe_6_209 : fcTypeOfName% "Erdos323.erdos_323.parts.i" := by
  simp?
#print axioms probe_6_209

-- ATTACK fc-379fc029-parts-i-2c9a98b27f-formalized-v1 simp
theorem probe_6_210 : fcTypeOfName% "Erdos413.erdos_413.parts.i" := by
  simp
#print axioms probe_6_210

-- ATTACK fc-379fc029-parts-i-2c9a98b27f-formalized-v1 simpa
theorem probe_6_211 : fcTypeOfName% "Erdos413.erdos_413.parts.i" := by
  simpa
#print axioms probe_6_211

-- ATTACK fc-379fc029-parts-i-2c9a98b27f-formalized-v1 simp_all
theorem probe_6_212 : fcTypeOfName% "Erdos413.erdos_413.parts.i" := by
  simp_all
#print axioms probe_6_212

-- ATTACK fc-379fc029-parts-i-2c9a98b27f-formalized-v1 aesop
theorem probe_6_213 : fcTypeOfName% "Erdos413.erdos_413.parts.i" := by
  aesop
#print axioms probe_6_213

-- ATTACK fc-379fc029-parts-i-2c9a98b27f-formalized-v1 omega
theorem probe_6_214 : fcTypeOfName% "Erdos413.erdos_413.parts.i" := by
  omega
#print axioms probe_6_214

-- ATTACK fc-379fc029-parts-i-2c9a98b27f-formalized-v1 norm_num
theorem probe_6_215 : fcTypeOfName% "Erdos413.erdos_413.parts.i" := by
  norm_num
#print axioms probe_6_215

-- ATTACK fc-379fc029-parts-i-2c9a98b27f-formalized-v1 decide
theorem probe_6_216 : fcTypeOfName% "Erdos413.erdos_413.parts.i" := by
  decide
#print axioms probe_6_216

-- ATTACK fc-379fc029-parts-i-2c9a98b27f-formalized-v1 native_decide
theorem probe_6_217 : fcTypeOfName% "Erdos413.erdos_413.parts.i" := by
  native_decide
#print axioms probe_6_217

-- ATTACK fc-379fc029-parts-i-2c9a98b27f-formalized-v1 true_intro
theorem probe_6_218 : fcTypeOfName% "Erdos413.erdos_413.parts.i" := by
  exact True.intro
#print axioms probe_6_218

-- ATTACK fc-379fc029-parts-i-2c9a98b27f-formalized-v1 false_elim_simp
theorem probe_6_219 : fcTypeOfName% "Erdos413.erdos_413.parts.i" := by
  apply False.elim
  simp_all
#print axioms probe_6_219

-- ATTACK fc-379fc029-parts-i-2c9a98b27f-formalized-v1 constructor
theorem probe_6_220 : fcTypeOfName% "Erdos413.erdos_413.parts.i" := by
  constructor
#print axioms probe_6_220

-- ATTACK fc-379fc029-parts-i-2c9a98b27f-formalized-v1 constructor_simp
theorem probe_6_221 : fcTypeOfName% "Erdos413.erdos_413.parts.i" := by
  constructor <;> simp
#print axioms probe_6_221

-- ATTACK fc-379fc029-parts-i-2c9a98b27f-formalized-v1 constructor_aesop
theorem probe_6_222 : fcTypeOfName% "Erdos413.erdos_413.parts.i" := by
  constructor <;> aesop
#print axioms probe_6_222

-- ATTACK fc-379fc029-parts-i-2c9a98b27f-formalized-v1 rfl
theorem probe_6_223 : fcTypeOfName% "Erdos413.erdos_413.parts.i" := by
  rfl
#print axioms probe_6_223

-- ATTACK fc-379fc029-parts-i-2c9a98b27f-formalized-v1 trivial
theorem probe_6_224 : fcTypeOfName% "Erdos413.erdos_413.parts.i" := by
  trivial
#print axioms probe_6_224

-- ATTACK fc-379fc029-parts-i-2c9a98b27f-formalized-v1 tauto
theorem probe_6_225 : fcTypeOfName% "Erdos413.erdos_413.parts.i" := by
  tauto
#print axioms probe_6_225

-- ATTACK fc-379fc029-parts-i-2c9a98b27f-formalized-v1 positivity
theorem probe_6_226 : fcTypeOfName% "Erdos413.erdos_413.parts.i" := by
  positivity
#print axioms probe_6_226

-- ATTACK fc-379fc029-parts-i-2c9a98b27f-formalized-v1 linarith
theorem probe_6_227 : fcTypeOfName% "Erdos413.erdos_413.parts.i" := by
  linarith
#print axioms probe_6_227

-- ATTACK fc-379fc029-parts-i-2c9a98b27f-formalized-v1 nlinarith
theorem probe_6_228 : fcTypeOfName% "Erdos413.erdos_413.parts.i" := by
  nlinarith
#print axioms probe_6_228

-- ATTACK fc-379fc029-parts-i-2c9a98b27f-formalized-v1 intros_simp_all
theorem probe_6_229 : fcTypeOfName% "Erdos413.erdos_413.parts.i" := by
  intros
  simp_all
#print axioms probe_6_229

-- ATTACK fc-379fc029-parts-i-2c9a98b27f-formalized-v1 intros_omega
theorem probe_6_230 : fcTypeOfName% "Erdos413.erdos_413.parts.i" := by
  intros
  omega
#print axioms probe_6_230

-- ATTACK fc-379fc029-parts-i-2c9a98b27f-formalized-v1 intros_norm_num
theorem probe_6_231 : fcTypeOfName% "Erdos413.erdos_413.parts.i" := by
  intros
  norm_num at *
#print axioms probe_6_231

-- ATTACK fc-379fc029-parts-i-2c9a98b27f-formalized-v1 intros_aesop
theorem probe_6_232 : fcTypeOfName% "Erdos413.erdos_413.parts.i" := by
  intros
  aesop
#print axioms probe_6_232

-- ATTACK fc-379fc029-parts-i-2c9a98b27f-formalized-v1 by_contra_simp_all
theorem probe_6_233 : fcTypeOfName% "Erdos413.erdos_413.parts.i" := by
  by_contra h
  simp_all
#print axioms probe_6_233

-- ATTACK fc-379fc029-parts-i-2c9a98b27f-formalized-v1 classical_simp_all
theorem probe_6_234 : fcTypeOfName% "Erdos413.erdos_413.parts.i" := by
  classical
  simp_all
#print axioms probe_6_234

-- ATTACK fc-379fc029-parts-i-2c9a98b27f-formalized-v1 classical_aesop
theorem probe_6_235 : fcTypeOfName% "Erdos413.erdos_413.parts.i" := by
  classical
  aesop
#print axioms probe_6_235

-- ATTACK fc-379fc029-parts-i-2c9a98b27f-formalized-v1 refine_pair_simp
theorem probe_6_236 : fcTypeOfName% "Erdos413.erdos_413.parts.i" := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_6_236

-- ATTACK fc-379fc029-parts-i-2c9a98b27f-formalized-v1 refine_pair_aesop
theorem probe_6_237 : fcTypeOfName% "Erdos413.erdos_413.parts.i" := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_6_237

-- ATTACK fc-379fc029-parts-i-2c9a98b27f-formalized-v1 use_zero_simp
theorem probe_6_238 : fcTypeOfName% "Erdos413.erdos_413.parts.i" := by
  use 0 <;> simp
#print axioms probe_6_238

-- ATTACK fc-379fc029-parts-i-2c9a98b27f-formalized-v1 use_one_simp
theorem probe_6_239 : fcTypeOfName% "Erdos413.erdos_413.parts.i" := by
  use 1 <;> simp
#print axioms probe_6_239

-- ATTACK fc-379fc029-parts-i-2c9a98b27f-formalized-v1 use_empty_simp
theorem probe_6_240 : fcTypeOfName% "Erdos413.erdos_413.parts.i" := by
  use ∅ <;> simp
#print axioms probe_6_240

-- ATTACK fc-379fc029-parts-i-2c9a98b27f-formalized-v1 assumption
theorem probe_6_241 : fcTypeOfName% "Erdos413.erdos_413.parts.i" := by
  assumption
#print axioms probe_6_241

-- ATTACK fc-379fc029-parts-i-2c9a98b27f-formalized-v1 infer_instance
theorem probe_6_242 : fcTypeOfName% "Erdos413.erdos_413.parts.i" := by
  infer_instance
#print axioms probe_6_242

-- ATTACK fc-379fc029-parts-i-2c9a98b27f-formalized-v1 contradiction
theorem probe_6_243 : fcTypeOfName% "Erdos413.erdos_413.parts.i" := by
  contradiction
#print axioms probe_6_243

-- ATTACK fc-379fc029-parts-i-2c9a98b27f-formalized-v1 solve_by_elim
theorem probe_6_244 : fcTypeOfName% "Erdos413.erdos_413.parts.i" := by
  solve_by_elim
#print axioms probe_6_244

-- ATTACK fc-379fc029-parts-i-2c9a98b27f-formalized-v1 first_order
theorem probe_6_245 : fcTypeOfName% "Erdos413.erdos_413.parts.i" := by
  first_order
#print axioms probe_6_245

-- ATTACK fc-379fc029-parts-i-2c9a98b27f-formalized-v1 grind
theorem probe_6_246 : fcTypeOfName% "Erdos413.erdos_413.parts.i" := by
  grind
#print axioms probe_6_246

-- ATTACK fc-379fc029-parts-i-2c9a98b27f-formalized-v1 exact_search
theorem probe_6_247 : fcTypeOfName% "Erdos413.erdos_413.parts.i" := by
  exact?
#print axioms probe_6_247

-- ATTACK fc-379fc029-parts-i-2c9a98b27f-formalized-v1 apply_search
theorem probe_6_248 : fcTypeOfName% "Erdos413.erdos_413.parts.i" := by
  apply?
#print axioms probe_6_248

-- ATTACK fc-379fc029-parts-i-2c9a98b27f-formalized-v1 library_search
theorem probe_6_249 : fcTypeOfName% "Erdos413.erdos_413.parts.i" := by
  library_search
#print axioms probe_6_249

-- ATTACK fc-379fc029-parts-i-2c9a98b27f-formalized-v1 aesop_search
theorem probe_6_250 : fcTypeOfName% "Erdos413.erdos_413.parts.i" := by
  aesop?
#print axioms probe_6_250

-- ATTACK fc-379fc029-parts-i-2c9a98b27f-formalized-v1 simp_search
theorem probe_6_251 : fcTypeOfName% "Erdos413.erdos_413.parts.i" := by
  simp?
#print axioms probe_6_251

-- ATTACK fc-379fc029-erdos647-erdos-647-87a8507c4a-formalized-v1 simp
theorem probe_6_252 : fcTypeOfName% "Erdos647.erdos_647" := by
  simp
#print axioms probe_6_252

-- ATTACK fc-379fc029-erdos647-erdos-647-87a8507c4a-formalized-v1 simpa
theorem probe_6_253 : fcTypeOfName% "Erdos647.erdos_647" := by
  simpa
#print axioms probe_6_253

-- ATTACK fc-379fc029-erdos647-erdos-647-87a8507c4a-formalized-v1 simp_all
theorem probe_6_254 : fcTypeOfName% "Erdos647.erdos_647" := by
  simp_all
#print axioms probe_6_254

-- ATTACK fc-379fc029-erdos647-erdos-647-87a8507c4a-formalized-v1 aesop
theorem probe_6_255 : fcTypeOfName% "Erdos647.erdos_647" := by
  aesop
#print axioms probe_6_255

-- ATTACK fc-379fc029-erdos647-erdos-647-87a8507c4a-formalized-v1 omega
theorem probe_6_256 : fcTypeOfName% "Erdos647.erdos_647" := by
  omega
#print axioms probe_6_256

-- ATTACK fc-379fc029-erdos647-erdos-647-87a8507c4a-formalized-v1 norm_num
theorem probe_6_257 : fcTypeOfName% "Erdos647.erdos_647" := by
  norm_num
#print axioms probe_6_257

-- ATTACK fc-379fc029-erdos647-erdos-647-87a8507c4a-formalized-v1 decide
theorem probe_6_258 : fcTypeOfName% "Erdos647.erdos_647" := by
  decide
#print axioms probe_6_258

-- ATTACK fc-379fc029-erdos647-erdos-647-87a8507c4a-formalized-v1 native_decide
theorem probe_6_259 : fcTypeOfName% "Erdos647.erdos_647" := by
  native_decide
#print axioms probe_6_259

-- ATTACK fc-379fc029-erdos647-erdos-647-87a8507c4a-formalized-v1 true_intro
theorem probe_6_260 : fcTypeOfName% "Erdos647.erdos_647" := by
  exact True.intro
#print axioms probe_6_260

-- ATTACK fc-379fc029-erdos647-erdos-647-87a8507c4a-formalized-v1 false_elim_simp
theorem probe_6_261 : fcTypeOfName% "Erdos647.erdos_647" := by
  apply False.elim
  simp_all
#print axioms probe_6_261

-- ATTACK fc-379fc029-erdos647-erdos-647-87a8507c4a-formalized-v1 constructor
theorem probe_6_262 : fcTypeOfName% "Erdos647.erdos_647" := by
  constructor
#print axioms probe_6_262

-- ATTACK fc-379fc029-erdos647-erdos-647-87a8507c4a-formalized-v1 constructor_simp
theorem probe_6_263 : fcTypeOfName% "Erdos647.erdos_647" := by
  constructor <;> simp
#print axioms probe_6_263

-- ATTACK fc-379fc029-erdos647-erdos-647-87a8507c4a-formalized-v1 constructor_aesop
theorem probe_6_264 : fcTypeOfName% "Erdos647.erdos_647" := by
  constructor <;> aesop
#print axioms probe_6_264

-- ATTACK fc-379fc029-erdos647-erdos-647-87a8507c4a-formalized-v1 rfl
theorem probe_6_265 : fcTypeOfName% "Erdos647.erdos_647" := by
  rfl
#print axioms probe_6_265

-- ATTACK fc-379fc029-erdos647-erdos-647-87a8507c4a-formalized-v1 trivial
theorem probe_6_266 : fcTypeOfName% "Erdos647.erdos_647" := by
  trivial
#print axioms probe_6_266

-- ATTACK fc-379fc029-erdos647-erdos-647-87a8507c4a-formalized-v1 tauto
theorem probe_6_267 : fcTypeOfName% "Erdos647.erdos_647" := by
  tauto
#print axioms probe_6_267

-- ATTACK fc-379fc029-erdos647-erdos-647-87a8507c4a-formalized-v1 positivity
theorem probe_6_268 : fcTypeOfName% "Erdos647.erdos_647" := by
  positivity
#print axioms probe_6_268

-- ATTACK fc-379fc029-erdos647-erdos-647-87a8507c4a-formalized-v1 linarith
theorem probe_6_269 : fcTypeOfName% "Erdos647.erdos_647" := by
  linarith
#print axioms probe_6_269

-- ATTACK fc-379fc029-erdos647-erdos-647-87a8507c4a-formalized-v1 nlinarith
theorem probe_6_270 : fcTypeOfName% "Erdos647.erdos_647" := by
  nlinarith
#print axioms probe_6_270

-- ATTACK fc-379fc029-erdos647-erdos-647-87a8507c4a-formalized-v1 intros_simp_all
theorem probe_6_271 : fcTypeOfName% "Erdos647.erdos_647" := by
  intros
  simp_all
#print axioms probe_6_271

-- ATTACK fc-379fc029-erdos647-erdos-647-87a8507c4a-formalized-v1 intros_omega
theorem probe_6_272 : fcTypeOfName% "Erdos647.erdos_647" := by
  intros
  omega
#print axioms probe_6_272

-- ATTACK fc-379fc029-erdos647-erdos-647-87a8507c4a-formalized-v1 intros_norm_num
theorem probe_6_273 : fcTypeOfName% "Erdos647.erdos_647" := by
  intros
  norm_num at *
#print axioms probe_6_273

-- ATTACK fc-379fc029-erdos647-erdos-647-87a8507c4a-formalized-v1 intros_aesop
theorem probe_6_274 : fcTypeOfName% "Erdos647.erdos_647" := by
  intros
  aesop
#print axioms probe_6_274

-- ATTACK fc-379fc029-erdos647-erdos-647-87a8507c4a-formalized-v1 by_contra_simp_all
theorem probe_6_275 : fcTypeOfName% "Erdos647.erdos_647" := by
  by_contra h
  simp_all
#print axioms probe_6_275

-- ATTACK fc-379fc029-erdos647-erdos-647-87a8507c4a-formalized-v1 classical_simp_all
theorem probe_6_276 : fcTypeOfName% "Erdos647.erdos_647" := by
  classical
  simp_all
#print axioms probe_6_276

-- ATTACK fc-379fc029-erdos647-erdos-647-87a8507c4a-formalized-v1 classical_aesop
theorem probe_6_277 : fcTypeOfName% "Erdos647.erdos_647" := by
  classical
  aesop
#print axioms probe_6_277

-- ATTACK fc-379fc029-erdos647-erdos-647-87a8507c4a-formalized-v1 refine_pair_simp
theorem probe_6_278 : fcTypeOfName% "Erdos647.erdos_647" := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_6_278

-- ATTACK fc-379fc029-erdos647-erdos-647-87a8507c4a-formalized-v1 refine_pair_aesop
theorem probe_6_279 : fcTypeOfName% "Erdos647.erdos_647" := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_6_279

-- ATTACK fc-379fc029-erdos647-erdos-647-87a8507c4a-formalized-v1 use_zero_simp
theorem probe_6_280 : fcTypeOfName% "Erdos647.erdos_647" := by
  use 0 <;> simp
#print axioms probe_6_280

-- ATTACK fc-379fc029-erdos647-erdos-647-87a8507c4a-formalized-v1 use_one_simp
theorem probe_6_281 : fcTypeOfName% "Erdos647.erdos_647" := by
  use 1 <;> simp
#print axioms probe_6_281

-- ATTACK fc-379fc029-erdos647-erdos-647-87a8507c4a-formalized-v1 use_empty_simp
theorem probe_6_282 : fcTypeOfName% "Erdos647.erdos_647" := by
  use ∅ <;> simp
#print axioms probe_6_282

-- ATTACK fc-379fc029-erdos647-erdos-647-87a8507c4a-formalized-v1 assumption
theorem probe_6_283 : fcTypeOfName% "Erdos647.erdos_647" := by
  assumption
#print axioms probe_6_283

-- ATTACK fc-379fc029-erdos647-erdos-647-87a8507c4a-formalized-v1 infer_instance
theorem probe_6_284 : fcTypeOfName% "Erdos647.erdos_647" := by
  infer_instance
#print axioms probe_6_284

-- ATTACK fc-379fc029-erdos647-erdos-647-87a8507c4a-formalized-v1 contradiction
theorem probe_6_285 : fcTypeOfName% "Erdos647.erdos_647" := by
  contradiction
#print axioms probe_6_285

-- ATTACK fc-379fc029-erdos647-erdos-647-87a8507c4a-formalized-v1 solve_by_elim
theorem probe_6_286 : fcTypeOfName% "Erdos647.erdos_647" := by
  solve_by_elim
#print axioms probe_6_286

-- ATTACK fc-379fc029-erdos647-erdos-647-87a8507c4a-formalized-v1 first_order
theorem probe_6_287 : fcTypeOfName% "Erdos647.erdos_647" := by
  first_order
#print axioms probe_6_287

-- ATTACK fc-379fc029-erdos647-erdos-647-87a8507c4a-formalized-v1 grind
theorem probe_6_288 : fcTypeOfName% "Erdos647.erdos_647" := by
  grind
#print axioms probe_6_288

-- ATTACK fc-379fc029-erdos647-erdos-647-87a8507c4a-formalized-v1 exact_search
theorem probe_6_289 : fcTypeOfName% "Erdos647.erdos_647" := by
  exact?
#print axioms probe_6_289

-- ATTACK fc-379fc029-erdos647-erdos-647-87a8507c4a-formalized-v1 apply_search
theorem probe_6_290 : fcTypeOfName% "Erdos647.erdos_647" := by
  apply?
#print axioms probe_6_290

-- ATTACK fc-379fc029-erdos647-erdos-647-87a8507c4a-formalized-v1 library_search
theorem probe_6_291 : fcTypeOfName% "Erdos647.erdos_647" := by
  library_search
#print axioms probe_6_291

-- ATTACK fc-379fc029-erdos647-erdos-647-87a8507c4a-formalized-v1 aesop_search
theorem probe_6_292 : fcTypeOfName% "Erdos647.erdos_647" := by
  aesop?
#print axioms probe_6_292

-- ATTACK fc-379fc029-erdos647-erdos-647-87a8507c4a-formalized-v1 simp_search
theorem probe_6_293 : fcTypeOfName% "Erdos647.erdos_647" := by
  simp?
#print axioms probe_6_293

-- ATTACK fc-379fc029-parts-i-811f908e25-formalized-v1 simp
theorem probe_6_294 : fcTypeOfName% "Erdos770.erdos_770.parts.i" := by
  simp
#print axioms probe_6_294

-- ATTACK fc-379fc029-parts-i-811f908e25-formalized-v1 simpa
theorem probe_6_295 : fcTypeOfName% "Erdos770.erdos_770.parts.i" := by
  simpa
#print axioms probe_6_295

-- ATTACK fc-379fc029-parts-i-811f908e25-formalized-v1 simp_all
theorem probe_6_296 : fcTypeOfName% "Erdos770.erdos_770.parts.i" := by
  simp_all
#print axioms probe_6_296

-- ATTACK fc-379fc029-parts-i-811f908e25-formalized-v1 aesop
theorem probe_6_297 : fcTypeOfName% "Erdos770.erdos_770.parts.i" := by
  aesop
#print axioms probe_6_297

-- ATTACK fc-379fc029-parts-i-811f908e25-formalized-v1 omega
theorem probe_6_298 : fcTypeOfName% "Erdos770.erdos_770.parts.i" := by
  omega
#print axioms probe_6_298

-- ATTACK fc-379fc029-parts-i-811f908e25-formalized-v1 norm_num
theorem probe_6_299 : fcTypeOfName% "Erdos770.erdos_770.parts.i" := by
  norm_num
#print axioms probe_6_299

-- ATTACK fc-379fc029-parts-i-811f908e25-formalized-v1 decide
theorem probe_6_300 : fcTypeOfName% "Erdos770.erdos_770.parts.i" := by
  decide
#print axioms probe_6_300

-- ATTACK fc-379fc029-parts-i-811f908e25-formalized-v1 native_decide
theorem probe_6_301 : fcTypeOfName% "Erdos770.erdos_770.parts.i" := by
  native_decide
#print axioms probe_6_301

-- ATTACK fc-379fc029-parts-i-811f908e25-formalized-v1 true_intro
theorem probe_6_302 : fcTypeOfName% "Erdos770.erdos_770.parts.i" := by
  exact True.intro
#print axioms probe_6_302

-- ATTACK fc-379fc029-parts-i-811f908e25-formalized-v1 false_elim_simp
theorem probe_6_303 : fcTypeOfName% "Erdos770.erdos_770.parts.i" := by
  apply False.elim
  simp_all
#print axioms probe_6_303

-- ATTACK fc-379fc029-parts-i-811f908e25-formalized-v1 constructor
theorem probe_6_304 : fcTypeOfName% "Erdos770.erdos_770.parts.i" := by
  constructor
#print axioms probe_6_304

-- ATTACK fc-379fc029-parts-i-811f908e25-formalized-v1 constructor_simp
theorem probe_6_305 : fcTypeOfName% "Erdos770.erdos_770.parts.i" := by
  constructor <;> simp
#print axioms probe_6_305

-- ATTACK fc-379fc029-parts-i-811f908e25-formalized-v1 constructor_aesop
theorem probe_6_306 : fcTypeOfName% "Erdos770.erdos_770.parts.i" := by
  constructor <;> aesop
#print axioms probe_6_306

-- ATTACK fc-379fc029-parts-i-811f908e25-formalized-v1 rfl
theorem probe_6_307 : fcTypeOfName% "Erdos770.erdos_770.parts.i" := by
  rfl
#print axioms probe_6_307

-- ATTACK fc-379fc029-parts-i-811f908e25-formalized-v1 trivial
theorem probe_6_308 : fcTypeOfName% "Erdos770.erdos_770.parts.i" := by
  trivial
#print axioms probe_6_308

-- ATTACK fc-379fc029-parts-i-811f908e25-formalized-v1 tauto
theorem probe_6_309 : fcTypeOfName% "Erdos770.erdos_770.parts.i" := by
  tauto
#print axioms probe_6_309

-- ATTACK fc-379fc029-parts-i-811f908e25-formalized-v1 positivity
theorem probe_6_310 : fcTypeOfName% "Erdos770.erdos_770.parts.i" := by
  positivity
#print axioms probe_6_310

-- ATTACK fc-379fc029-parts-i-811f908e25-formalized-v1 linarith
theorem probe_6_311 : fcTypeOfName% "Erdos770.erdos_770.parts.i" := by
  linarith
#print axioms probe_6_311

-- ATTACK fc-379fc029-parts-i-811f908e25-formalized-v1 nlinarith
theorem probe_6_312 : fcTypeOfName% "Erdos770.erdos_770.parts.i" := by
  nlinarith
#print axioms probe_6_312

-- ATTACK fc-379fc029-parts-i-811f908e25-formalized-v1 intros_simp_all
theorem probe_6_313 : fcTypeOfName% "Erdos770.erdos_770.parts.i" := by
  intros
  simp_all
#print axioms probe_6_313

-- ATTACK fc-379fc029-parts-i-811f908e25-formalized-v1 intros_omega
theorem probe_6_314 : fcTypeOfName% "Erdos770.erdos_770.parts.i" := by
  intros
  omega
#print axioms probe_6_314

-- ATTACK fc-379fc029-parts-i-811f908e25-formalized-v1 intros_norm_num
theorem probe_6_315 : fcTypeOfName% "Erdos770.erdos_770.parts.i" := by
  intros
  norm_num at *
#print axioms probe_6_315

-- ATTACK fc-379fc029-parts-i-811f908e25-formalized-v1 intros_aesop
theorem probe_6_316 : fcTypeOfName% "Erdos770.erdos_770.parts.i" := by
  intros
  aesop
#print axioms probe_6_316

-- ATTACK fc-379fc029-parts-i-811f908e25-formalized-v1 by_contra_simp_all
theorem probe_6_317 : fcTypeOfName% "Erdos770.erdos_770.parts.i" := by
  by_contra h
  simp_all
#print axioms probe_6_317

-- ATTACK fc-379fc029-parts-i-811f908e25-formalized-v1 classical_simp_all
theorem probe_6_318 : fcTypeOfName% "Erdos770.erdos_770.parts.i" := by
  classical
  simp_all
#print axioms probe_6_318

-- ATTACK fc-379fc029-parts-i-811f908e25-formalized-v1 classical_aesop
theorem probe_6_319 : fcTypeOfName% "Erdos770.erdos_770.parts.i" := by
  classical
  aesop
#print axioms probe_6_319

-- ATTACK fc-379fc029-parts-i-811f908e25-formalized-v1 refine_pair_simp
theorem probe_6_320 : fcTypeOfName% "Erdos770.erdos_770.parts.i" := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_6_320

-- ATTACK fc-379fc029-parts-i-811f908e25-formalized-v1 refine_pair_aesop
theorem probe_6_321 : fcTypeOfName% "Erdos770.erdos_770.parts.i" := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_6_321

-- ATTACK fc-379fc029-parts-i-811f908e25-formalized-v1 use_zero_simp
theorem probe_6_322 : fcTypeOfName% "Erdos770.erdos_770.parts.i" := by
  use 0 <;> simp
#print axioms probe_6_322

-- ATTACK fc-379fc029-parts-i-811f908e25-formalized-v1 use_one_simp
theorem probe_6_323 : fcTypeOfName% "Erdos770.erdos_770.parts.i" := by
  use 1 <;> simp
#print axioms probe_6_323

-- ATTACK fc-379fc029-parts-i-811f908e25-formalized-v1 use_empty_simp
theorem probe_6_324 : fcTypeOfName% "Erdos770.erdos_770.parts.i" := by
  use ∅ <;> simp
#print axioms probe_6_324

-- ATTACK fc-379fc029-parts-i-811f908e25-formalized-v1 assumption
theorem probe_6_325 : fcTypeOfName% "Erdos770.erdos_770.parts.i" := by
  assumption
#print axioms probe_6_325

-- ATTACK fc-379fc029-parts-i-811f908e25-formalized-v1 infer_instance
theorem probe_6_326 : fcTypeOfName% "Erdos770.erdos_770.parts.i" := by
  infer_instance
#print axioms probe_6_326

-- ATTACK fc-379fc029-parts-i-811f908e25-formalized-v1 contradiction
theorem probe_6_327 : fcTypeOfName% "Erdos770.erdos_770.parts.i" := by
  contradiction
#print axioms probe_6_327

-- ATTACK fc-379fc029-parts-i-811f908e25-formalized-v1 solve_by_elim
theorem probe_6_328 : fcTypeOfName% "Erdos770.erdos_770.parts.i" := by
  solve_by_elim
#print axioms probe_6_328

-- ATTACK fc-379fc029-parts-i-811f908e25-formalized-v1 first_order
theorem probe_6_329 : fcTypeOfName% "Erdos770.erdos_770.parts.i" := by
  first_order
#print axioms probe_6_329

-- ATTACK fc-379fc029-parts-i-811f908e25-formalized-v1 grind
theorem probe_6_330 : fcTypeOfName% "Erdos770.erdos_770.parts.i" := by
  grind
#print axioms probe_6_330

-- ATTACK fc-379fc029-parts-i-811f908e25-formalized-v1 exact_search
theorem probe_6_331 : fcTypeOfName% "Erdos770.erdos_770.parts.i" := by
  exact?
#print axioms probe_6_331

-- ATTACK fc-379fc029-parts-i-811f908e25-formalized-v1 apply_search
theorem probe_6_332 : fcTypeOfName% "Erdos770.erdos_770.parts.i" := by
  apply?
#print axioms probe_6_332

-- ATTACK fc-379fc029-parts-i-811f908e25-formalized-v1 library_search
theorem probe_6_333 : fcTypeOfName% "Erdos770.erdos_770.parts.i" := by
  library_search
#print axioms probe_6_333

-- ATTACK fc-379fc029-parts-i-811f908e25-formalized-v1 aesop_search
theorem probe_6_334 : fcTypeOfName% "Erdos770.erdos_770.parts.i" := by
  aesop?
#print axioms probe_6_334

-- ATTACK fc-379fc029-parts-i-811f908e25-formalized-v1 simp_search
theorem probe_6_335 : fcTypeOfName% "Erdos770.erdos_770.parts.i" := by
  simp?
#print axioms probe_6_335

-- ATTACK fc-379fc029-erdos930-erdos-930-7a01dea539-formalized-v1 simp
theorem probe_6_336 : fcTypeOfName% "Erdos930.erdos_930" := by
  simp
#print axioms probe_6_336

-- ATTACK fc-379fc029-erdos930-erdos-930-7a01dea539-formalized-v1 simpa
theorem probe_6_337 : fcTypeOfName% "Erdos930.erdos_930" := by
  simpa
#print axioms probe_6_337

-- ATTACK fc-379fc029-erdos930-erdos-930-7a01dea539-formalized-v1 simp_all
theorem probe_6_338 : fcTypeOfName% "Erdos930.erdos_930" := by
  simp_all
#print axioms probe_6_338

-- ATTACK fc-379fc029-erdos930-erdos-930-7a01dea539-formalized-v1 aesop
theorem probe_6_339 : fcTypeOfName% "Erdos930.erdos_930" := by
  aesop
#print axioms probe_6_339

-- ATTACK fc-379fc029-erdos930-erdos-930-7a01dea539-formalized-v1 omega
theorem probe_6_340 : fcTypeOfName% "Erdos930.erdos_930" := by
  omega
#print axioms probe_6_340

-- ATTACK fc-379fc029-erdos930-erdos-930-7a01dea539-formalized-v1 norm_num
theorem probe_6_341 : fcTypeOfName% "Erdos930.erdos_930" := by
  norm_num
#print axioms probe_6_341

-- ATTACK fc-379fc029-erdos930-erdos-930-7a01dea539-formalized-v1 decide
theorem probe_6_342 : fcTypeOfName% "Erdos930.erdos_930" := by
  decide
#print axioms probe_6_342

-- ATTACK fc-379fc029-erdos930-erdos-930-7a01dea539-formalized-v1 native_decide
theorem probe_6_343 : fcTypeOfName% "Erdos930.erdos_930" := by
  native_decide
#print axioms probe_6_343

-- ATTACK fc-379fc029-erdos930-erdos-930-7a01dea539-formalized-v1 true_intro
theorem probe_6_344 : fcTypeOfName% "Erdos930.erdos_930" := by
  exact True.intro
#print axioms probe_6_344

-- ATTACK fc-379fc029-erdos930-erdos-930-7a01dea539-formalized-v1 false_elim_simp
theorem probe_6_345 : fcTypeOfName% "Erdos930.erdos_930" := by
  apply False.elim
  simp_all
#print axioms probe_6_345

-- ATTACK fc-379fc029-erdos930-erdos-930-7a01dea539-formalized-v1 constructor
theorem probe_6_346 : fcTypeOfName% "Erdos930.erdos_930" := by
  constructor
#print axioms probe_6_346

-- ATTACK fc-379fc029-erdos930-erdos-930-7a01dea539-formalized-v1 constructor_simp
theorem probe_6_347 : fcTypeOfName% "Erdos930.erdos_930" := by
  constructor <;> simp
#print axioms probe_6_347

-- ATTACK fc-379fc029-erdos930-erdos-930-7a01dea539-formalized-v1 constructor_aesop
theorem probe_6_348 : fcTypeOfName% "Erdos930.erdos_930" := by
  constructor <;> aesop
#print axioms probe_6_348

-- ATTACK fc-379fc029-erdos930-erdos-930-7a01dea539-formalized-v1 rfl
theorem probe_6_349 : fcTypeOfName% "Erdos930.erdos_930" := by
  rfl
#print axioms probe_6_349

-- ATTACK fc-379fc029-erdos930-erdos-930-7a01dea539-formalized-v1 trivial
theorem probe_6_350 : fcTypeOfName% "Erdos930.erdos_930" := by
  trivial
#print axioms probe_6_350

-- ATTACK fc-379fc029-erdos930-erdos-930-7a01dea539-formalized-v1 tauto
theorem probe_6_351 : fcTypeOfName% "Erdos930.erdos_930" := by
  tauto
#print axioms probe_6_351

-- ATTACK fc-379fc029-erdos930-erdos-930-7a01dea539-formalized-v1 positivity
theorem probe_6_352 : fcTypeOfName% "Erdos930.erdos_930" := by
  positivity
#print axioms probe_6_352

-- ATTACK fc-379fc029-erdos930-erdos-930-7a01dea539-formalized-v1 linarith
theorem probe_6_353 : fcTypeOfName% "Erdos930.erdos_930" := by
  linarith
#print axioms probe_6_353

-- ATTACK fc-379fc029-erdos930-erdos-930-7a01dea539-formalized-v1 nlinarith
theorem probe_6_354 : fcTypeOfName% "Erdos930.erdos_930" := by
  nlinarith
#print axioms probe_6_354

-- ATTACK fc-379fc029-erdos930-erdos-930-7a01dea539-formalized-v1 intros_simp_all
theorem probe_6_355 : fcTypeOfName% "Erdos930.erdos_930" := by
  intros
  simp_all
#print axioms probe_6_355

-- ATTACK fc-379fc029-erdos930-erdos-930-7a01dea539-formalized-v1 intros_omega
theorem probe_6_356 : fcTypeOfName% "Erdos930.erdos_930" := by
  intros
  omega
#print axioms probe_6_356

-- ATTACK fc-379fc029-erdos930-erdos-930-7a01dea539-formalized-v1 intros_norm_num
theorem probe_6_357 : fcTypeOfName% "Erdos930.erdos_930" := by
  intros
  norm_num at *
#print axioms probe_6_357

-- ATTACK fc-379fc029-erdos930-erdos-930-7a01dea539-formalized-v1 intros_aesop
theorem probe_6_358 : fcTypeOfName% "Erdos930.erdos_930" := by
  intros
  aesop
#print axioms probe_6_358

-- ATTACK fc-379fc029-erdos930-erdos-930-7a01dea539-formalized-v1 by_contra_simp_all
theorem probe_6_359 : fcTypeOfName% "Erdos930.erdos_930" := by
  by_contra h
  simp_all
#print axioms probe_6_359

-- ATTACK fc-379fc029-erdos930-erdos-930-7a01dea539-formalized-v1 classical_simp_all
theorem probe_6_360 : fcTypeOfName% "Erdos930.erdos_930" := by
  classical
  simp_all
#print axioms probe_6_360

-- ATTACK fc-379fc029-erdos930-erdos-930-7a01dea539-formalized-v1 classical_aesop
theorem probe_6_361 : fcTypeOfName% "Erdos930.erdos_930" := by
  classical
  aesop
#print axioms probe_6_361

-- ATTACK fc-379fc029-erdos930-erdos-930-7a01dea539-formalized-v1 refine_pair_simp
theorem probe_6_362 : fcTypeOfName% "Erdos930.erdos_930" := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_6_362

-- ATTACK fc-379fc029-erdos930-erdos-930-7a01dea539-formalized-v1 refine_pair_aesop
theorem probe_6_363 : fcTypeOfName% "Erdos930.erdos_930" := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_6_363

-- ATTACK fc-379fc029-erdos930-erdos-930-7a01dea539-formalized-v1 use_zero_simp
theorem probe_6_364 : fcTypeOfName% "Erdos930.erdos_930" := by
  use 0 <;> simp
#print axioms probe_6_364

-- ATTACK fc-379fc029-erdos930-erdos-930-7a01dea539-formalized-v1 use_one_simp
theorem probe_6_365 : fcTypeOfName% "Erdos930.erdos_930" := by
  use 1 <;> simp
#print axioms probe_6_365

-- ATTACK fc-379fc029-erdos930-erdos-930-7a01dea539-formalized-v1 use_empty_simp
theorem probe_6_366 : fcTypeOfName% "Erdos930.erdos_930" := by
  use ∅ <;> simp
#print axioms probe_6_366

-- ATTACK fc-379fc029-erdos930-erdos-930-7a01dea539-formalized-v1 assumption
theorem probe_6_367 : fcTypeOfName% "Erdos930.erdos_930" := by
  assumption
#print axioms probe_6_367

-- ATTACK fc-379fc029-erdos930-erdos-930-7a01dea539-formalized-v1 infer_instance
theorem probe_6_368 : fcTypeOfName% "Erdos930.erdos_930" := by
  infer_instance
#print axioms probe_6_368

-- ATTACK fc-379fc029-erdos930-erdos-930-7a01dea539-formalized-v1 contradiction
theorem probe_6_369 : fcTypeOfName% "Erdos930.erdos_930" := by
  contradiction
#print axioms probe_6_369

-- ATTACK fc-379fc029-erdos930-erdos-930-7a01dea539-formalized-v1 solve_by_elim
theorem probe_6_370 : fcTypeOfName% "Erdos930.erdos_930" := by
  solve_by_elim
#print axioms probe_6_370

-- ATTACK fc-379fc029-erdos930-erdos-930-7a01dea539-formalized-v1 first_order
theorem probe_6_371 : fcTypeOfName% "Erdos930.erdos_930" := by
  first_order
#print axioms probe_6_371

-- ATTACK fc-379fc029-erdos930-erdos-930-7a01dea539-formalized-v1 grind
theorem probe_6_372 : fcTypeOfName% "Erdos930.erdos_930" := by
  grind
#print axioms probe_6_372

-- ATTACK fc-379fc029-erdos930-erdos-930-7a01dea539-formalized-v1 exact_search
theorem probe_6_373 : fcTypeOfName% "Erdos930.erdos_930" := by
  exact?
#print axioms probe_6_373

-- ATTACK fc-379fc029-erdos930-erdos-930-7a01dea539-formalized-v1 apply_search
theorem probe_6_374 : fcTypeOfName% "Erdos930.erdos_930" := by
  apply?
#print axioms probe_6_374

-- ATTACK fc-379fc029-erdos930-erdos-930-7a01dea539-formalized-v1 library_search
theorem probe_6_375 : fcTypeOfName% "Erdos930.erdos_930" := by
  library_search
#print axioms probe_6_375

-- ATTACK fc-379fc029-erdos930-erdos-930-7a01dea539-formalized-v1 aesop_search
theorem probe_6_376 : fcTypeOfName% "Erdos930.erdos_930" := by
  aesop?
#print axioms probe_6_376

-- ATTACK fc-379fc029-erdos930-erdos-930-7a01dea539-formalized-v1 simp_search
theorem probe_6_377 : fcTypeOfName% "Erdos930.erdos_930" := by
  simp?
#print axioms probe_6_377

-- ATTACK fc-379fc029-erdos944-erdos-944-94f8bb3de6-formalized-v1 simp
theorem probe_6_378 : fcTypeOfName% "Erdos944.erdos_944" := by
  simp
#print axioms probe_6_378

-- ATTACK fc-379fc029-erdos944-erdos-944-94f8bb3de6-formalized-v1 simpa
theorem probe_6_379 : fcTypeOfName% "Erdos944.erdos_944" := by
  simpa
#print axioms probe_6_379

-- ATTACK fc-379fc029-erdos944-erdos-944-94f8bb3de6-formalized-v1 simp_all
theorem probe_6_380 : fcTypeOfName% "Erdos944.erdos_944" := by
  simp_all
#print axioms probe_6_380

-- ATTACK fc-379fc029-erdos944-erdos-944-94f8bb3de6-formalized-v1 aesop
theorem probe_6_381 : fcTypeOfName% "Erdos944.erdos_944" := by
  aesop
#print axioms probe_6_381

-- ATTACK fc-379fc029-erdos944-erdos-944-94f8bb3de6-formalized-v1 omega
theorem probe_6_382 : fcTypeOfName% "Erdos944.erdos_944" := by
  omega
#print axioms probe_6_382

-- ATTACK fc-379fc029-erdos944-erdos-944-94f8bb3de6-formalized-v1 norm_num
theorem probe_6_383 : fcTypeOfName% "Erdos944.erdos_944" := by
  norm_num
#print axioms probe_6_383

-- ATTACK fc-379fc029-erdos944-erdos-944-94f8bb3de6-formalized-v1 decide
theorem probe_6_384 : fcTypeOfName% "Erdos944.erdos_944" := by
  decide
#print axioms probe_6_384

-- ATTACK fc-379fc029-erdos944-erdos-944-94f8bb3de6-formalized-v1 native_decide
theorem probe_6_385 : fcTypeOfName% "Erdos944.erdos_944" := by
  native_decide
#print axioms probe_6_385

-- ATTACK fc-379fc029-erdos944-erdos-944-94f8bb3de6-formalized-v1 true_intro
theorem probe_6_386 : fcTypeOfName% "Erdos944.erdos_944" := by
  exact True.intro
#print axioms probe_6_386

-- ATTACK fc-379fc029-erdos944-erdos-944-94f8bb3de6-formalized-v1 false_elim_simp
theorem probe_6_387 : fcTypeOfName% "Erdos944.erdos_944" := by
  apply False.elim
  simp_all
#print axioms probe_6_387

-- ATTACK fc-379fc029-erdos944-erdos-944-94f8bb3de6-formalized-v1 constructor
theorem probe_6_388 : fcTypeOfName% "Erdos944.erdos_944" := by
  constructor
#print axioms probe_6_388

-- ATTACK fc-379fc029-erdos944-erdos-944-94f8bb3de6-formalized-v1 constructor_simp
theorem probe_6_389 : fcTypeOfName% "Erdos944.erdos_944" := by
  constructor <;> simp
#print axioms probe_6_389

-- ATTACK fc-379fc029-erdos944-erdos-944-94f8bb3de6-formalized-v1 constructor_aesop
theorem probe_6_390 : fcTypeOfName% "Erdos944.erdos_944" := by
  constructor <;> aesop
#print axioms probe_6_390

-- ATTACK fc-379fc029-erdos944-erdos-944-94f8bb3de6-formalized-v1 rfl
theorem probe_6_391 : fcTypeOfName% "Erdos944.erdos_944" := by
  rfl
#print axioms probe_6_391

-- ATTACK fc-379fc029-erdos944-erdos-944-94f8bb3de6-formalized-v1 trivial
theorem probe_6_392 : fcTypeOfName% "Erdos944.erdos_944" := by
  trivial
#print axioms probe_6_392

-- ATTACK fc-379fc029-erdos944-erdos-944-94f8bb3de6-formalized-v1 tauto
theorem probe_6_393 : fcTypeOfName% "Erdos944.erdos_944" := by
  tauto
#print axioms probe_6_393

-- ATTACK fc-379fc029-erdos944-erdos-944-94f8bb3de6-formalized-v1 positivity
theorem probe_6_394 : fcTypeOfName% "Erdos944.erdos_944" := by
  positivity
#print axioms probe_6_394

-- ATTACK fc-379fc029-erdos944-erdos-944-94f8bb3de6-formalized-v1 linarith
theorem probe_6_395 : fcTypeOfName% "Erdos944.erdos_944" := by
  linarith
#print axioms probe_6_395

-- ATTACK fc-379fc029-erdos944-erdos-944-94f8bb3de6-formalized-v1 nlinarith
theorem probe_6_396 : fcTypeOfName% "Erdos944.erdos_944" := by
  nlinarith
#print axioms probe_6_396

-- ATTACK fc-379fc029-erdos944-erdos-944-94f8bb3de6-formalized-v1 intros_simp_all
theorem probe_6_397 : fcTypeOfName% "Erdos944.erdos_944" := by
  intros
  simp_all
#print axioms probe_6_397

-- ATTACK fc-379fc029-erdos944-erdos-944-94f8bb3de6-formalized-v1 intros_omega
theorem probe_6_398 : fcTypeOfName% "Erdos944.erdos_944" := by
  intros
  omega
#print axioms probe_6_398

-- ATTACK fc-379fc029-erdos944-erdos-944-94f8bb3de6-formalized-v1 intros_norm_num
theorem probe_6_399 : fcTypeOfName% "Erdos944.erdos_944" := by
  intros
  norm_num at *
#print axioms probe_6_399

-- ATTACK fc-379fc029-erdos944-erdos-944-94f8bb3de6-formalized-v1 intros_aesop
theorem probe_6_400 : fcTypeOfName% "Erdos944.erdos_944" := by
  intros
  aesop
#print axioms probe_6_400

-- ATTACK fc-379fc029-erdos944-erdos-944-94f8bb3de6-formalized-v1 by_contra_simp_all
theorem probe_6_401 : fcTypeOfName% "Erdos944.erdos_944" := by
  by_contra h
  simp_all
#print axioms probe_6_401

-- ATTACK fc-379fc029-erdos944-erdos-944-94f8bb3de6-formalized-v1 classical_simp_all
theorem probe_6_402 : fcTypeOfName% "Erdos944.erdos_944" := by
  classical
  simp_all
#print axioms probe_6_402

-- ATTACK fc-379fc029-erdos944-erdos-944-94f8bb3de6-formalized-v1 classical_aesop
theorem probe_6_403 : fcTypeOfName% "Erdos944.erdos_944" := by
  classical
  aesop
#print axioms probe_6_403

-- ATTACK fc-379fc029-erdos944-erdos-944-94f8bb3de6-formalized-v1 refine_pair_simp
theorem probe_6_404 : fcTypeOfName% "Erdos944.erdos_944" := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_6_404

-- ATTACK fc-379fc029-erdos944-erdos-944-94f8bb3de6-formalized-v1 refine_pair_aesop
theorem probe_6_405 : fcTypeOfName% "Erdos944.erdos_944" := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_6_405

-- ATTACK fc-379fc029-erdos944-erdos-944-94f8bb3de6-formalized-v1 use_zero_simp
theorem probe_6_406 : fcTypeOfName% "Erdos944.erdos_944" := by
  use 0 <;> simp
#print axioms probe_6_406

-- ATTACK fc-379fc029-erdos944-erdos-944-94f8bb3de6-formalized-v1 use_one_simp
theorem probe_6_407 : fcTypeOfName% "Erdos944.erdos_944" := by
  use 1 <;> simp
#print axioms probe_6_407

-- ATTACK fc-379fc029-erdos944-erdos-944-94f8bb3de6-formalized-v1 use_empty_simp
theorem probe_6_408 : fcTypeOfName% "Erdos944.erdos_944" := by
  use ∅ <;> simp
#print axioms probe_6_408

-- ATTACK fc-379fc029-erdos944-erdos-944-94f8bb3de6-formalized-v1 assumption
theorem probe_6_409 : fcTypeOfName% "Erdos944.erdos_944" := by
  assumption
#print axioms probe_6_409

-- ATTACK fc-379fc029-erdos944-erdos-944-94f8bb3de6-formalized-v1 infer_instance
theorem probe_6_410 : fcTypeOfName% "Erdos944.erdos_944" := by
  infer_instance
#print axioms probe_6_410

-- ATTACK fc-379fc029-erdos944-erdos-944-94f8bb3de6-formalized-v1 contradiction
theorem probe_6_411 : fcTypeOfName% "Erdos944.erdos_944" := by
  contradiction
#print axioms probe_6_411

-- ATTACK fc-379fc029-erdos944-erdos-944-94f8bb3de6-formalized-v1 solve_by_elim
theorem probe_6_412 : fcTypeOfName% "Erdos944.erdos_944" := by
  solve_by_elim
#print axioms probe_6_412

-- ATTACK fc-379fc029-erdos944-erdos-944-94f8bb3de6-formalized-v1 first_order
theorem probe_6_413 : fcTypeOfName% "Erdos944.erdos_944" := by
  first_order
#print axioms probe_6_413

-- ATTACK fc-379fc029-erdos944-erdos-944-94f8bb3de6-formalized-v1 grind
theorem probe_6_414 : fcTypeOfName% "Erdos944.erdos_944" := by
  grind
#print axioms probe_6_414

-- ATTACK fc-379fc029-erdos944-erdos-944-94f8bb3de6-formalized-v1 exact_search
theorem probe_6_415 : fcTypeOfName% "Erdos944.erdos_944" := by
  exact?
#print axioms probe_6_415

-- ATTACK fc-379fc029-erdos944-erdos-944-94f8bb3de6-formalized-v1 apply_search
theorem probe_6_416 : fcTypeOfName% "Erdos944.erdos_944" := by
  apply?
#print axioms probe_6_416

-- ATTACK fc-379fc029-erdos944-erdos-944-94f8bb3de6-formalized-v1 library_search
theorem probe_6_417 : fcTypeOfName% "Erdos944.erdos_944" := by
  library_search
#print axioms probe_6_417

-- ATTACK fc-379fc029-erdos944-erdos-944-94f8bb3de6-formalized-v1 aesop_search
theorem probe_6_418 : fcTypeOfName% "Erdos944.erdos_944" := by
  aesop?
#print axioms probe_6_418

-- ATTACK fc-379fc029-erdos944-erdos-944-94f8bb3de6-formalized-v1 simp_search
theorem probe_6_419 : fcTypeOfName% "Erdos944.erdos_944" := by
  simp?
#print axioms probe_6_419

-- ATTACK fc-379fc029-erdos979-erdos-979-f2e596c3c2-formalized-v1 simp
theorem probe_6_420 : fcTypeOfName% "Erdos979.erdos_979" := by
  simp
#print axioms probe_6_420

-- ATTACK fc-379fc029-erdos979-erdos-979-f2e596c3c2-formalized-v1 simpa
theorem probe_6_421 : fcTypeOfName% "Erdos979.erdos_979" := by
  simpa
#print axioms probe_6_421

-- ATTACK fc-379fc029-erdos979-erdos-979-f2e596c3c2-formalized-v1 simp_all
theorem probe_6_422 : fcTypeOfName% "Erdos979.erdos_979" := by
  simp_all
#print axioms probe_6_422

-- ATTACK fc-379fc029-erdos979-erdos-979-f2e596c3c2-formalized-v1 aesop
theorem probe_6_423 : fcTypeOfName% "Erdos979.erdos_979" := by
  aesop
#print axioms probe_6_423

-- ATTACK fc-379fc029-erdos979-erdos-979-f2e596c3c2-formalized-v1 omega
theorem probe_6_424 : fcTypeOfName% "Erdos979.erdos_979" := by
  omega
#print axioms probe_6_424

-- ATTACK fc-379fc029-erdos979-erdos-979-f2e596c3c2-formalized-v1 norm_num
theorem probe_6_425 : fcTypeOfName% "Erdos979.erdos_979" := by
  norm_num
#print axioms probe_6_425

-- ATTACK fc-379fc029-erdos979-erdos-979-f2e596c3c2-formalized-v1 decide
theorem probe_6_426 : fcTypeOfName% "Erdos979.erdos_979" := by
  decide
#print axioms probe_6_426

-- ATTACK fc-379fc029-erdos979-erdos-979-f2e596c3c2-formalized-v1 native_decide
theorem probe_6_427 : fcTypeOfName% "Erdos979.erdos_979" := by
  native_decide
#print axioms probe_6_427

-- ATTACK fc-379fc029-erdos979-erdos-979-f2e596c3c2-formalized-v1 true_intro
theorem probe_6_428 : fcTypeOfName% "Erdos979.erdos_979" := by
  exact True.intro
#print axioms probe_6_428

-- ATTACK fc-379fc029-erdos979-erdos-979-f2e596c3c2-formalized-v1 false_elim_simp
theorem probe_6_429 : fcTypeOfName% "Erdos979.erdos_979" := by
  apply False.elim
  simp_all
#print axioms probe_6_429

-- ATTACK fc-379fc029-erdos979-erdos-979-f2e596c3c2-formalized-v1 constructor
theorem probe_6_430 : fcTypeOfName% "Erdos979.erdos_979" := by
  constructor
#print axioms probe_6_430

-- ATTACK fc-379fc029-erdos979-erdos-979-f2e596c3c2-formalized-v1 constructor_simp
theorem probe_6_431 : fcTypeOfName% "Erdos979.erdos_979" := by
  constructor <;> simp
#print axioms probe_6_431

-- ATTACK fc-379fc029-erdos979-erdos-979-f2e596c3c2-formalized-v1 constructor_aesop
theorem probe_6_432 : fcTypeOfName% "Erdos979.erdos_979" := by
  constructor <;> aesop
#print axioms probe_6_432

-- ATTACK fc-379fc029-erdos979-erdos-979-f2e596c3c2-formalized-v1 rfl
theorem probe_6_433 : fcTypeOfName% "Erdos979.erdos_979" := by
  rfl
#print axioms probe_6_433

-- ATTACK fc-379fc029-erdos979-erdos-979-f2e596c3c2-formalized-v1 trivial
theorem probe_6_434 : fcTypeOfName% "Erdos979.erdos_979" := by
  trivial
#print axioms probe_6_434

-- ATTACK fc-379fc029-erdos979-erdos-979-f2e596c3c2-formalized-v1 tauto
theorem probe_6_435 : fcTypeOfName% "Erdos979.erdos_979" := by
  tauto
#print axioms probe_6_435

-- ATTACK fc-379fc029-erdos979-erdos-979-f2e596c3c2-formalized-v1 positivity
theorem probe_6_436 : fcTypeOfName% "Erdos979.erdos_979" := by
  positivity
#print axioms probe_6_436

-- ATTACK fc-379fc029-erdos979-erdos-979-f2e596c3c2-formalized-v1 linarith
theorem probe_6_437 : fcTypeOfName% "Erdos979.erdos_979" := by
  linarith
#print axioms probe_6_437

-- ATTACK fc-379fc029-erdos979-erdos-979-f2e596c3c2-formalized-v1 nlinarith
theorem probe_6_438 : fcTypeOfName% "Erdos979.erdos_979" := by
  nlinarith
#print axioms probe_6_438

-- ATTACK fc-379fc029-erdos979-erdos-979-f2e596c3c2-formalized-v1 intros_simp_all
theorem probe_6_439 : fcTypeOfName% "Erdos979.erdos_979" := by
  intros
  simp_all
#print axioms probe_6_439

-- ATTACK fc-379fc029-erdos979-erdos-979-f2e596c3c2-formalized-v1 intros_omega
theorem probe_6_440 : fcTypeOfName% "Erdos979.erdos_979" := by
  intros
  omega
#print axioms probe_6_440

-- ATTACK fc-379fc029-erdos979-erdos-979-f2e596c3c2-formalized-v1 intros_norm_num
theorem probe_6_441 : fcTypeOfName% "Erdos979.erdos_979" := by
  intros
  norm_num at *
#print axioms probe_6_441

-- ATTACK fc-379fc029-erdos979-erdos-979-f2e596c3c2-formalized-v1 intros_aesop
theorem probe_6_442 : fcTypeOfName% "Erdos979.erdos_979" := by
  intros
  aesop
#print axioms probe_6_442

-- ATTACK fc-379fc029-erdos979-erdos-979-f2e596c3c2-formalized-v1 by_contra_simp_all
theorem probe_6_443 : fcTypeOfName% "Erdos979.erdos_979" := by
  by_contra h
  simp_all
#print axioms probe_6_443

-- ATTACK fc-379fc029-erdos979-erdos-979-f2e596c3c2-formalized-v1 classical_simp_all
theorem probe_6_444 : fcTypeOfName% "Erdos979.erdos_979" := by
  classical
  simp_all
#print axioms probe_6_444

-- ATTACK fc-379fc029-erdos979-erdos-979-f2e596c3c2-formalized-v1 classical_aesop
theorem probe_6_445 : fcTypeOfName% "Erdos979.erdos_979" := by
  classical
  aesop
#print axioms probe_6_445

-- ATTACK fc-379fc029-erdos979-erdos-979-f2e596c3c2-formalized-v1 refine_pair_simp
theorem probe_6_446 : fcTypeOfName% "Erdos979.erdos_979" := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_6_446

-- ATTACK fc-379fc029-erdos979-erdos-979-f2e596c3c2-formalized-v1 refine_pair_aesop
theorem probe_6_447 : fcTypeOfName% "Erdos979.erdos_979" := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_6_447

-- ATTACK fc-379fc029-erdos979-erdos-979-f2e596c3c2-formalized-v1 use_zero_simp
theorem probe_6_448 : fcTypeOfName% "Erdos979.erdos_979" := by
  use 0 <;> simp
#print axioms probe_6_448

-- ATTACK fc-379fc029-erdos979-erdos-979-f2e596c3c2-formalized-v1 use_one_simp
theorem probe_6_449 : fcTypeOfName% "Erdos979.erdos_979" := by
  use 1 <;> simp
#print axioms probe_6_449

-- ATTACK fc-379fc029-erdos979-erdos-979-f2e596c3c2-formalized-v1 use_empty_simp
theorem probe_6_450 : fcTypeOfName% "Erdos979.erdos_979" := by
  use ∅ <;> simp
#print axioms probe_6_450

-- ATTACK fc-379fc029-erdos979-erdos-979-f2e596c3c2-formalized-v1 assumption
theorem probe_6_451 : fcTypeOfName% "Erdos979.erdos_979" := by
  assumption
#print axioms probe_6_451

-- ATTACK fc-379fc029-erdos979-erdos-979-f2e596c3c2-formalized-v1 infer_instance
theorem probe_6_452 : fcTypeOfName% "Erdos979.erdos_979" := by
  infer_instance
#print axioms probe_6_452

-- ATTACK fc-379fc029-erdos979-erdos-979-f2e596c3c2-formalized-v1 contradiction
theorem probe_6_453 : fcTypeOfName% "Erdos979.erdos_979" := by
  contradiction
#print axioms probe_6_453

-- ATTACK fc-379fc029-erdos979-erdos-979-f2e596c3c2-formalized-v1 solve_by_elim
theorem probe_6_454 : fcTypeOfName% "Erdos979.erdos_979" := by
  solve_by_elim
#print axioms probe_6_454

-- ATTACK fc-379fc029-erdos979-erdos-979-f2e596c3c2-formalized-v1 first_order
theorem probe_6_455 : fcTypeOfName% "Erdos979.erdos_979" := by
  first_order
#print axioms probe_6_455

-- ATTACK fc-379fc029-erdos979-erdos-979-f2e596c3c2-formalized-v1 grind
theorem probe_6_456 : fcTypeOfName% "Erdos979.erdos_979" := by
  grind
#print axioms probe_6_456

-- ATTACK fc-379fc029-erdos979-erdos-979-f2e596c3c2-formalized-v1 exact_search
theorem probe_6_457 : fcTypeOfName% "Erdos979.erdos_979" := by
  exact?
#print axioms probe_6_457

-- ATTACK fc-379fc029-erdos979-erdos-979-f2e596c3c2-formalized-v1 apply_search
theorem probe_6_458 : fcTypeOfName% "Erdos979.erdos_979" := by
  apply?
#print axioms probe_6_458

-- ATTACK fc-379fc029-erdos979-erdos-979-f2e596c3c2-formalized-v1 library_search
theorem probe_6_459 : fcTypeOfName% "Erdos979.erdos_979" := by
  library_search
#print axioms probe_6_459

-- ATTACK fc-379fc029-erdos979-erdos-979-f2e596c3c2-formalized-v1 aesop_search
theorem probe_6_460 : fcTypeOfName% "Erdos979.erdos_979" := by
  aesop?
#print axioms probe_6_460

-- ATTACK fc-379fc029-erdos979-erdos-979-f2e596c3c2-formalized-v1 simp_search
theorem probe_6_461 : fcTypeOfName% "Erdos979.erdos_979" := by
  simp?
#print axioms probe_6_461

-- ATTACK fc-379fc029-green44-green-44-b621bc6c6d-formalized-v1 simp
theorem probe_6_462 : fcTypeOfName% "Green44.green_44" := by
  simp
#print axioms probe_6_462

-- ATTACK fc-379fc029-green44-green-44-b621bc6c6d-formalized-v1 simpa
theorem probe_6_463 : fcTypeOfName% "Green44.green_44" := by
  simpa
#print axioms probe_6_463

-- ATTACK fc-379fc029-green44-green-44-b621bc6c6d-formalized-v1 simp_all
theorem probe_6_464 : fcTypeOfName% "Green44.green_44" := by
  simp_all
#print axioms probe_6_464

-- ATTACK fc-379fc029-green44-green-44-b621bc6c6d-formalized-v1 aesop
theorem probe_6_465 : fcTypeOfName% "Green44.green_44" := by
  aesop
#print axioms probe_6_465

-- ATTACK fc-379fc029-green44-green-44-b621bc6c6d-formalized-v1 omega
theorem probe_6_466 : fcTypeOfName% "Green44.green_44" := by
  omega
#print axioms probe_6_466

-- ATTACK fc-379fc029-green44-green-44-b621bc6c6d-formalized-v1 norm_num
theorem probe_6_467 : fcTypeOfName% "Green44.green_44" := by
  norm_num
#print axioms probe_6_467

-- ATTACK fc-379fc029-green44-green-44-b621bc6c6d-formalized-v1 decide
theorem probe_6_468 : fcTypeOfName% "Green44.green_44" := by
  decide
#print axioms probe_6_468

-- ATTACK fc-379fc029-green44-green-44-b621bc6c6d-formalized-v1 native_decide
theorem probe_6_469 : fcTypeOfName% "Green44.green_44" := by
  native_decide
#print axioms probe_6_469

-- ATTACK fc-379fc029-green44-green-44-b621bc6c6d-formalized-v1 true_intro
theorem probe_6_470 : fcTypeOfName% "Green44.green_44" := by
  exact True.intro
#print axioms probe_6_470

-- ATTACK fc-379fc029-green44-green-44-b621bc6c6d-formalized-v1 false_elim_simp
theorem probe_6_471 : fcTypeOfName% "Green44.green_44" := by
  apply False.elim
  simp_all
#print axioms probe_6_471

-- ATTACK fc-379fc029-green44-green-44-b621bc6c6d-formalized-v1 constructor
theorem probe_6_472 : fcTypeOfName% "Green44.green_44" := by
  constructor
#print axioms probe_6_472

-- ATTACK fc-379fc029-green44-green-44-b621bc6c6d-formalized-v1 constructor_simp
theorem probe_6_473 : fcTypeOfName% "Green44.green_44" := by
  constructor <;> simp
#print axioms probe_6_473

-- ATTACK fc-379fc029-green44-green-44-b621bc6c6d-formalized-v1 constructor_aesop
theorem probe_6_474 : fcTypeOfName% "Green44.green_44" := by
  constructor <;> aesop
#print axioms probe_6_474

-- ATTACK fc-379fc029-green44-green-44-b621bc6c6d-formalized-v1 rfl
theorem probe_6_475 : fcTypeOfName% "Green44.green_44" := by
  rfl
#print axioms probe_6_475

-- ATTACK fc-379fc029-green44-green-44-b621bc6c6d-formalized-v1 trivial
theorem probe_6_476 : fcTypeOfName% "Green44.green_44" := by
  trivial
#print axioms probe_6_476

-- ATTACK fc-379fc029-green44-green-44-b621bc6c6d-formalized-v1 tauto
theorem probe_6_477 : fcTypeOfName% "Green44.green_44" := by
  tauto
#print axioms probe_6_477

-- ATTACK fc-379fc029-green44-green-44-b621bc6c6d-formalized-v1 positivity
theorem probe_6_478 : fcTypeOfName% "Green44.green_44" := by
  positivity
#print axioms probe_6_478

-- ATTACK fc-379fc029-green44-green-44-b621bc6c6d-formalized-v1 linarith
theorem probe_6_479 : fcTypeOfName% "Green44.green_44" := by
  linarith
#print axioms probe_6_479

-- ATTACK fc-379fc029-green44-green-44-b621bc6c6d-formalized-v1 nlinarith
theorem probe_6_480 : fcTypeOfName% "Green44.green_44" := by
  nlinarith
#print axioms probe_6_480

-- ATTACK fc-379fc029-green44-green-44-b621bc6c6d-formalized-v1 intros_simp_all
theorem probe_6_481 : fcTypeOfName% "Green44.green_44" := by
  intros
  simp_all
#print axioms probe_6_481

-- ATTACK fc-379fc029-green44-green-44-b621bc6c6d-formalized-v1 intros_omega
theorem probe_6_482 : fcTypeOfName% "Green44.green_44" := by
  intros
  omega
#print axioms probe_6_482

-- ATTACK fc-379fc029-green44-green-44-b621bc6c6d-formalized-v1 intros_norm_num
theorem probe_6_483 : fcTypeOfName% "Green44.green_44" := by
  intros
  norm_num at *
#print axioms probe_6_483

-- ATTACK fc-379fc029-green44-green-44-b621bc6c6d-formalized-v1 intros_aesop
theorem probe_6_484 : fcTypeOfName% "Green44.green_44" := by
  intros
  aesop
#print axioms probe_6_484

-- ATTACK fc-379fc029-green44-green-44-b621bc6c6d-formalized-v1 by_contra_simp_all
theorem probe_6_485 : fcTypeOfName% "Green44.green_44" := by
  by_contra h
  simp_all
#print axioms probe_6_485

-- ATTACK fc-379fc029-green44-green-44-b621bc6c6d-formalized-v1 classical_simp_all
theorem probe_6_486 : fcTypeOfName% "Green44.green_44" := by
  classical
  simp_all
#print axioms probe_6_486

-- ATTACK fc-379fc029-green44-green-44-b621bc6c6d-formalized-v1 classical_aesop
theorem probe_6_487 : fcTypeOfName% "Green44.green_44" := by
  classical
  aesop
#print axioms probe_6_487

-- ATTACK fc-379fc029-green44-green-44-b621bc6c6d-formalized-v1 refine_pair_simp
theorem probe_6_488 : fcTypeOfName% "Green44.green_44" := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_6_488

-- ATTACK fc-379fc029-green44-green-44-b621bc6c6d-formalized-v1 refine_pair_aesop
theorem probe_6_489 : fcTypeOfName% "Green44.green_44" := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_6_489

-- ATTACK fc-379fc029-green44-green-44-b621bc6c6d-formalized-v1 use_zero_simp
theorem probe_6_490 : fcTypeOfName% "Green44.green_44" := by
  use 0 <;> simp
#print axioms probe_6_490

-- ATTACK fc-379fc029-green44-green-44-b621bc6c6d-formalized-v1 use_one_simp
theorem probe_6_491 : fcTypeOfName% "Green44.green_44" := by
  use 1 <;> simp
#print axioms probe_6_491

-- ATTACK fc-379fc029-green44-green-44-b621bc6c6d-formalized-v1 use_empty_simp
theorem probe_6_492 : fcTypeOfName% "Green44.green_44" := by
  use ∅ <;> simp
#print axioms probe_6_492

-- ATTACK fc-379fc029-green44-green-44-b621bc6c6d-formalized-v1 assumption
theorem probe_6_493 : fcTypeOfName% "Green44.green_44" := by
  assumption
#print axioms probe_6_493

-- ATTACK fc-379fc029-green44-green-44-b621bc6c6d-formalized-v1 infer_instance
theorem probe_6_494 : fcTypeOfName% "Green44.green_44" := by
  infer_instance
#print axioms probe_6_494

-- ATTACK fc-379fc029-green44-green-44-b621bc6c6d-formalized-v1 contradiction
theorem probe_6_495 : fcTypeOfName% "Green44.green_44" := by
  contradiction
#print axioms probe_6_495

-- ATTACK fc-379fc029-green44-green-44-b621bc6c6d-formalized-v1 solve_by_elim
theorem probe_6_496 : fcTypeOfName% "Green44.green_44" := by
  solve_by_elim
#print axioms probe_6_496

-- ATTACK fc-379fc029-green44-green-44-b621bc6c6d-formalized-v1 first_order
theorem probe_6_497 : fcTypeOfName% "Green44.green_44" := by
  first_order
#print axioms probe_6_497

-- ATTACK fc-379fc029-green44-green-44-b621bc6c6d-formalized-v1 grind
theorem probe_6_498 : fcTypeOfName% "Green44.green_44" := by
  grind
#print axioms probe_6_498

-- ATTACK fc-379fc029-green44-green-44-b621bc6c6d-formalized-v1 exact_search
theorem probe_6_499 : fcTypeOfName% "Green44.green_44" := by
  exact?
#print axioms probe_6_499

-- ATTACK fc-379fc029-green44-green-44-b621bc6c6d-formalized-v1 apply_search
theorem probe_6_500 : fcTypeOfName% "Green44.green_44" := by
  apply?
#print axioms probe_6_500

-- ATTACK fc-379fc029-green44-green-44-b621bc6c6d-formalized-v1 library_search
theorem probe_6_501 : fcTypeOfName% "Green44.green_44" := by
  library_search
#print axioms probe_6_501

-- ATTACK fc-379fc029-green44-green-44-b621bc6c6d-formalized-v1 aesop_search
theorem probe_6_502 : fcTypeOfName% "Green44.green_44" := by
  aesop?
#print axioms probe_6_502

-- ATTACK fc-379fc029-green44-green-44-b621bc6c6d-formalized-v1 simp_search
theorem probe_6_503 : fcTypeOfName% "Green44.green_44" := by
  simp?
#print axioms probe_6_503

end AttackBattery
