import FormalConjectures.ErdosProblems.«1062»
import FormalConjectures.ErdosProblems.«1175»
import FormalConjectures.ErdosProblems.«168»
import FormalConjectures.ErdosProblems.«291»
import FormalConjectures.ErdosProblems.«317»
import FormalConjectures.ErdosProblems.«410»
import FormalConjectures.ErdosProblems.«61»
import FormalConjectures.ErdosProblems.«749»
import FormalConjectures.ErdosProblems.«91»
import FormalConjectures.ErdosProblems.«936»
import FormalConjectures.ErdosProblems.«962»
import FormalConjectures.GreensOpenProblems.«39»
import FormalConjectures.GreensOpenProblems.«94»
import TaskSupport

set_option maxHeartbeats 20000
namespace AttackBattery

-- ATTACK fc-379fc029-parts-ii-87ba819c8b-formalized-v1 simp
theorem probe_4_0 : fcTypeOfName% "Erdos1062.erdos_1062.parts.ii" := by
  simp
#print axioms probe_4_0

-- ATTACK fc-379fc029-parts-ii-87ba819c8b-formalized-v1 simpa
theorem probe_4_1 : fcTypeOfName% "Erdos1062.erdos_1062.parts.ii" := by
  simpa
#print axioms probe_4_1

-- ATTACK fc-379fc029-parts-ii-87ba819c8b-formalized-v1 simp_all
theorem probe_4_2 : fcTypeOfName% "Erdos1062.erdos_1062.parts.ii" := by
  simp_all
#print axioms probe_4_2

-- ATTACK fc-379fc029-parts-ii-87ba819c8b-formalized-v1 aesop
theorem probe_4_3 : fcTypeOfName% "Erdos1062.erdos_1062.parts.ii" := by
  aesop
#print axioms probe_4_3

-- ATTACK fc-379fc029-parts-ii-87ba819c8b-formalized-v1 omega
theorem probe_4_4 : fcTypeOfName% "Erdos1062.erdos_1062.parts.ii" := by
  omega
#print axioms probe_4_4

-- ATTACK fc-379fc029-parts-ii-87ba819c8b-formalized-v1 norm_num
theorem probe_4_5 : fcTypeOfName% "Erdos1062.erdos_1062.parts.ii" := by
  norm_num
#print axioms probe_4_5

-- ATTACK fc-379fc029-parts-ii-87ba819c8b-formalized-v1 decide
theorem probe_4_6 : fcTypeOfName% "Erdos1062.erdos_1062.parts.ii" := by
  decide
#print axioms probe_4_6

-- ATTACK fc-379fc029-parts-ii-87ba819c8b-formalized-v1 native_decide
theorem probe_4_7 : fcTypeOfName% "Erdos1062.erdos_1062.parts.ii" := by
  native_decide
#print axioms probe_4_7

-- ATTACK fc-379fc029-parts-ii-87ba819c8b-formalized-v1 true_intro
theorem probe_4_8 : fcTypeOfName% "Erdos1062.erdos_1062.parts.ii" := by
  exact True.intro
#print axioms probe_4_8

-- ATTACK fc-379fc029-parts-ii-87ba819c8b-formalized-v1 false_elim_simp
theorem probe_4_9 : fcTypeOfName% "Erdos1062.erdos_1062.parts.ii" := by
  apply False.elim
  simp_all
#print axioms probe_4_9

-- ATTACK fc-379fc029-parts-ii-87ba819c8b-formalized-v1 constructor
theorem probe_4_10 : fcTypeOfName% "Erdos1062.erdos_1062.parts.ii" := by
  constructor
#print axioms probe_4_10

-- ATTACK fc-379fc029-parts-ii-87ba819c8b-formalized-v1 constructor_simp
theorem probe_4_11 : fcTypeOfName% "Erdos1062.erdos_1062.parts.ii" := by
  constructor <;> simp
#print axioms probe_4_11

-- ATTACK fc-379fc029-parts-ii-87ba819c8b-formalized-v1 constructor_aesop
theorem probe_4_12 : fcTypeOfName% "Erdos1062.erdos_1062.parts.ii" := by
  constructor <;> aesop
#print axioms probe_4_12

-- ATTACK fc-379fc029-parts-ii-87ba819c8b-formalized-v1 rfl
theorem probe_4_13 : fcTypeOfName% "Erdos1062.erdos_1062.parts.ii" := by
  rfl
#print axioms probe_4_13

-- ATTACK fc-379fc029-parts-ii-87ba819c8b-formalized-v1 trivial
theorem probe_4_14 : fcTypeOfName% "Erdos1062.erdos_1062.parts.ii" := by
  trivial
#print axioms probe_4_14

-- ATTACK fc-379fc029-parts-ii-87ba819c8b-formalized-v1 tauto
theorem probe_4_15 : fcTypeOfName% "Erdos1062.erdos_1062.parts.ii" := by
  tauto
#print axioms probe_4_15

-- ATTACK fc-379fc029-parts-ii-87ba819c8b-formalized-v1 positivity
theorem probe_4_16 : fcTypeOfName% "Erdos1062.erdos_1062.parts.ii" := by
  positivity
#print axioms probe_4_16

-- ATTACK fc-379fc029-parts-ii-87ba819c8b-formalized-v1 linarith
theorem probe_4_17 : fcTypeOfName% "Erdos1062.erdos_1062.parts.ii" := by
  linarith
#print axioms probe_4_17

-- ATTACK fc-379fc029-parts-ii-87ba819c8b-formalized-v1 nlinarith
theorem probe_4_18 : fcTypeOfName% "Erdos1062.erdos_1062.parts.ii" := by
  nlinarith
#print axioms probe_4_18

-- ATTACK fc-379fc029-parts-ii-87ba819c8b-formalized-v1 intros_simp_all
theorem probe_4_19 : fcTypeOfName% "Erdos1062.erdos_1062.parts.ii" := by
  intros
  simp_all
#print axioms probe_4_19

-- ATTACK fc-379fc029-parts-ii-87ba819c8b-formalized-v1 intros_omega
theorem probe_4_20 : fcTypeOfName% "Erdos1062.erdos_1062.parts.ii" := by
  intros
  omega
#print axioms probe_4_20

-- ATTACK fc-379fc029-parts-ii-87ba819c8b-formalized-v1 intros_norm_num
theorem probe_4_21 : fcTypeOfName% "Erdos1062.erdos_1062.parts.ii" := by
  intros
  norm_num at *
#print axioms probe_4_21

-- ATTACK fc-379fc029-parts-ii-87ba819c8b-formalized-v1 intros_aesop
theorem probe_4_22 : fcTypeOfName% "Erdos1062.erdos_1062.parts.ii" := by
  intros
  aesop
#print axioms probe_4_22

-- ATTACK fc-379fc029-parts-ii-87ba819c8b-formalized-v1 by_contra_simp_all
theorem probe_4_23 : fcTypeOfName% "Erdos1062.erdos_1062.parts.ii" := by
  by_contra h
  simp_all
#print axioms probe_4_23

-- ATTACK fc-379fc029-parts-ii-87ba819c8b-formalized-v1 classical_simp_all
theorem probe_4_24 : fcTypeOfName% "Erdos1062.erdos_1062.parts.ii" := by
  classical
  simp_all
#print axioms probe_4_24

-- ATTACK fc-379fc029-parts-ii-87ba819c8b-formalized-v1 classical_aesop
theorem probe_4_25 : fcTypeOfName% "Erdos1062.erdos_1062.parts.ii" := by
  classical
  aesop
#print axioms probe_4_25

-- ATTACK fc-379fc029-parts-ii-87ba819c8b-formalized-v1 refine_pair_simp
theorem probe_4_26 : fcTypeOfName% "Erdos1062.erdos_1062.parts.ii" := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_4_26

-- ATTACK fc-379fc029-parts-ii-87ba819c8b-formalized-v1 refine_pair_aesop
theorem probe_4_27 : fcTypeOfName% "Erdos1062.erdos_1062.parts.ii" := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_4_27

-- ATTACK fc-379fc029-parts-ii-87ba819c8b-formalized-v1 use_zero_simp
theorem probe_4_28 : fcTypeOfName% "Erdos1062.erdos_1062.parts.ii" := by
  use 0 <;> simp
#print axioms probe_4_28

-- ATTACK fc-379fc029-parts-ii-87ba819c8b-formalized-v1 use_one_simp
theorem probe_4_29 : fcTypeOfName% "Erdos1062.erdos_1062.parts.ii" := by
  use 1 <;> simp
#print axioms probe_4_29

-- ATTACK fc-379fc029-parts-ii-87ba819c8b-formalized-v1 use_empty_simp
theorem probe_4_30 : fcTypeOfName% "Erdos1062.erdos_1062.parts.ii" := by
  use ∅ <;> simp
#print axioms probe_4_30

-- ATTACK fc-379fc029-parts-ii-87ba819c8b-formalized-v1 assumption
theorem probe_4_31 : fcTypeOfName% "Erdos1062.erdos_1062.parts.ii" := by
  assumption
#print axioms probe_4_31

-- ATTACK fc-379fc029-parts-ii-87ba819c8b-formalized-v1 infer_instance
theorem probe_4_32 : fcTypeOfName% "Erdos1062.erdos_1062.parts.ii" := by
  infer_instance
#print axioms probe_4_32

-- ATTACK fc-379fc029-parts-ii-87ba819c8b-formalized-v1 contradiction
theorem probe_4_33 : fcTypeOfName% "Erdos1062.erdos_1062.parts.ii" := by
  contradiction
#print axioms probe_4_33

-- ATTACK fc-379fc029-parts-ii-87ba819c8b-formalized-v1 solve_by_elim
theorem probe_4_34 : fcTypeOfName% "Erdos1062.erdos_1062.parts.ii" := by
  solve_by_elim
#print axioms probe_4_34

-- ATTACK fc-379fc029-parts-ii-87ba819c8b-formalized-v1 first_order
theorem probe_4_35 : fcTypeOfName% "Erdos1062.erdos_1062.parts.ii" := by
  first_order
#print axioms probe_4_35

-- ATTACK fc-379fc029-parts-ii-87ba819c8b-formalized-v1 grind
theorem probe_4_36 : fcTypeOfName% "Erdos1062.erdos_1062.parts.ii" := by
  grind
#print axioms probe_4_36

-- ATTACK fc-379fc029-parts-ii-87ba819c8b-formalized-v1 exact_search
theorem probe_4_37 : fcTypeOfName% "Erdos1062.erdos_1062.parts.ii" := by
  exact?
#print axioms probe_4_37

-- ATTACK fc-379fc029-parts-ii-87ba819c8b-formalized-v1 apply_search
theorem probe_4_38 : fcTypeOfName% "Erdos1062.erdos_1062.parts.ii" := by
  apply?
#print axioms probe_4_38

-- ATTACK fc-379fc029-parts-ii-87ba819c8b-formalized-v1 library_search
theorem probe_4_39 : fcTypeOfName% "Erdos1062.erdos_1062.parts.ii" := by
  library_search
#print axioms probe_4_39

-- ATTACK fc-379fc029-parts-ii-87ba819c8b-formalized-v1 aesop_search
theorem probe_4_40 : fcTypeOfName% "Erdos1062.erdos_1062.parts.ii" := by
  aesop?
#print axioms probe_4_40

-- ATTACK fc-379fc029-parts-ii-87ba819c8b-formalized-v1 simp_search
theorem probe_4_41 : fcTypeOfName% "Erdos1062.erdos_1062.parts.ii" := by
  simp?
#print axioms probe_4_41

-- ATTACK fc-379fc029-erdos1175-erdos-1175-2336ecb2bf-formalized-v1 simp
theorem probe_4_42 : fcTypeOfName% "Erdos1175.erdos_1175" := by
  simp
#print axioms probe_4_42

-- ATTACK fc-379fc029-erdos1175-erdos-1175-2336ecb2bf-formalized-v1 simpa
theorem probe_4_43 : fcTypeOfName% "Erdos1175.erdos_1175" := by
  simpa
#print axioms probe_4_43

-- ATTACK fc-379fc029-erdos1175-erdos-1175-2336ecb2bf-formalized-v1 simp_all
theorem probe_4_44 : fcTypeOfName% "Erdos1175.erdos_1175" := by
  simp_all
#print axioms probe_4_44

-- ATTACK fc-379fc029-erdos1175-erdos-1175-2336ecb2bf-formalized-v1 aesop
theorem probe_4_45 : fcTypeOfName% "Erdos1175.erdos_1175" := by
  aesop
#print axioms probe_4_45

-- ATTACK fc-379fc029-erdos1175-erdos-1175-2336ecb2bf-formalized-v1 omega
theorem probe_4_46 : fcTypeOfName% "Erdos1175.erdos_1175" := by
  omega
#print axioms probe_4_46

-- ATTACK fc-379fc029-erdos1175-erdos-1175-2336ecb2bf-formalized-v1 norm_num
theorem probe_4_47 : fcTypeOfName% "Erdos1175.erdos_1175" := by
  norm_num
#print axioms probe_4_47

-- ATTACK fc-379fc029-erdos1175-erdos-1175-2336ecb2bf-formalized-v1 decide
theorem probe_4_48 : fcTypeOfName% "Erdos1175.erdos_1175" := by
  decide
#print axioms probe_4_48

-- ATTACK fc-379fc029-erdos1175-erdos-1175-2336ecb2bf-formalized-v1 native_decide
theorem probe_4_49 : fcTypeOfName% "Erdos1175.erdos_1175" := by
  native_decide
#print axioms probe_4_49

-- ATTACK fc-379fc029-erdos1175-erdos-1175-2336ecb2bf-formalized-v1 true_intro
theorem probe_4_50 : fcTypeOfName% "Erdos1175.erdos_1175" := by
  exact True.intro
#print axioms probe_4_50

-- ATTACK fc-379fc029-erdos1175-erdos-1175-2336ecb2bf-formalized-v1 false_elim_simp
theorem probe_4_51 : fcTypeOfName% "Erdos1175.erdos_1175" := by
  apply False.elim
  simp_all
#print axioms probe_4_51

-- ATTACK fc-379fc029-erdos1175-erdos-1175-2336ecb2bf-formalized-v1 constructor
theorem probe_4_52 : fcTypeOfName% "Erdos1175.erdos_1175" := by
  constructor
#print axioms probe_4_52

-- ATTACK fc-379fc029-erdos1175-erdos-1175-2336ecb2bf-formalized-v1 constructor_simp
theorem probe_4_53 : fcTypeOfName% "Erdos1175.erdos_1175" := by
  constructor <;> simp
#print axioms probe_4_53

-- ATTACK fc-379fc029-erdos1175-erdos-1175-2336ecb2bf-formalized-v1 constructor_aesop
theorem probe_4_54 : fcTypeOfName% "Erdos1175.erdos_1175" := by
  constructor <;> aesop
#print axioms probe_4_54

-- ATTACK fc-379fc029-erdos1175-erdos-1175-2336ecb2bf-formalized-v1 rfl
theorem probe_4_55 : fcTypeOfName% "Erdos1175.erdos_1175" := by
  rfl
#print axioms probe_4_55

-- ATTACK fc-379fc029-erdos1175-erdos-1175-2336ecb2bf-formalized-v1 trivial
theorem probe_4_56 : fcTypeOfName% "Erdos1175.erdos_1175" := by
  trivial
#print axioms probe_4_56

-- ATTACK fc-379fc029-erdos1175-erdos-1175-2336ecb2bf-formalized-v1 tauto
theorem probe_4_57 : fcTypeOfName% "Erdos1175.erdos_1175" := by
  tauto
#print axioms probe_4_57

-- ATTACK fc-379fc029-erdos1175-erdos-1175-2336ecb2bf-formalized-v1 positivity
theorem probe_4_58 : fcTypeOfName% "Erdos1175.erdos_1175" := by
  positivity
#print axioms probe_4_58

-- ATTACK fc-379fc029-erdos1175-erdos-1175-2336ecb2bf-formalized-v1 linarith
theorem probe_4_59 : fcTypeOfName% "Erdos1175.erdos_1175" := by
  linarith
#print axioms probe_4_59

-- ATTACK fc-379fc029-erdos1175-erdos-1175-2336ecb2bf-formalized-v1 nlinarith
theorem probe_4_60 : fcTypeOfName% "Erdos1175.erdos_1175" := by
  nlinarith
#print axioms probe_4_60

-- ATTACK fc-379fc029-erdos1175-erdos-1175-2336ecb2bf-formalized-v1 intros_simp_all
theorem probe_4_61 : fcTypeOfName% "Erdos1175.erdos_1175" := by
  intros
  simp_all
#print axioms probe_4_61

-- ATTACK fc-379fc029-erdos1175-erdos-1175-2336ecb2bf-formalized-v1 intros_omega
theorem probe_4_62 : fcTypeOfName% "Erdos1175.erdos_1175" := by
  intros
  omega
#print axioms probe_4_62

-- ATTACK fc-379fc029-erdos1175-erdos-1175-2336ecb2bf-formalized-v1 intros_norm_num
theorem probe_4_63 : fcTypeOfName% "Erdos1175.erdos_1175" := by
  intros
  norm_num at *
#print axioms probe_4_63

-- ATTACK fc-379fc029-erdos1175-erdos-1175-2336ecb2bf-formalized-v1 intros_aesop
theorem probe_4_64 : fcTypeOfName% "Erdos1175.erdos_1175" := by
  intros
  aesop
#print axioms probe_4_64

-- ATTACK fc-379fc029-erdos1175-erdos-1175-2336ecb2bf-formalized-v1 by_contra_simp_all
theorem probe_4_65 : fcTypeOfName% "Erdos1175.erdos_1175" := by
  by_contra h
  simp_all
#print axioms probe_4_65

-- ATTACK fc-379fc029-erdos1175-erdos-1175-2336ecb2bf-formalized-v1 classical_simp_all
theorem probe_4_66 : fcTypeOfName% "Erdos1175.erdos_1175" := by
  classical
  simp_all
#print axioms probe_4_66

-- ATTACK fc-379fc029-erdos1175-erdos-1175-2336ecb2bf-formalized-v1 classical_aesop
theorem probe_4_67 : fcTypeOfName% "Erdos1175.erdos_1175" := by
  classical
  aesop
#print axioms probe_4_67

-- ATTACK fc-379fc029-erdos1175-erdos-1175-2336ecb2bf-formalized-v1 refine_pair_simp
theorem probe_4_68 : fcTypeOfName% "Erdos1175.erdos_1175" := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_4_68

-- ATTACK fc-379fc029-erdos1175-erdos-1175-2336ecb2bf-formalized-v1 refine_pair_aesop
theorem probe_4_69 : fcTypeOfName% "Erdos1175.erdos_1175" := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_4_69

-- ATTACK fc-379fc029-erdos1175-erdos-1175-2336ecb2bf-formalized-v1 use_zero_simp
theorem probe_4_70 : fcTypeOfName% "Erdos1175.erdos_1175" := by
  use 0 <;> simp
#print axioms probe_4_70

-- ATTACK fc-379fc029-erdos1175-erdos-1175-2336ecb2bf-formalized-v1 use_one_simp
theorem probe_4_71 : fcTypeOfName% "Erdos1175.erdos_1175" := by
  use 1 <;> simp
#print axioms probe_4_71

-- ATTACK fc-379fc029-erdos1175-erdos-1175-2336ecb2bf-formalized-v1 use_empty_simp
theorem probe_4_72 : fcTypeOfName% "Erdos1175.erdos_1175" := by
  use ∅ <;> simp
#print axioms probe_4_72

-- ATTACK fc-379fc029-erdos1175-erdos-1175-2336ecb2bf-formalized-v1 assumption
theorem probe_4_73 : fcTypeOfName% "Erdos1175.erdos_1175" := by
  assumption
#print axioms probe_4_73

-- ATTACK fc-379fc029-erdos1175-erdos-1175-2336ecb2bf-formalized-v1 infer_instance
theorem probe_4_74 : fcTypeOfName% "Erdos1175.erdos_1175" := by
  infer_instance
#print axioms probe_4_74

-- ATTACK fc-379fc029-erdos1175-erdos-1175-2336ecb2bf-formalized-v1 contradiction
theorem probe_4_75 : fcTypeOfName% "Erdos1175.erdos_1175" := by
  contradiction
#print axioms probe_4_75

-- ATTACK fc-379fc029-erdos1175-erdos-1175-2336ecb2bf-formalized-v1 solve_by_elim
theorem probe_4_76 : fcTypeOfName% "Erdos1175.erdos_1175" := by
  solve_by_elim
#print axioms probe_4_76

-- ATTACK fc-379fc029-erdos1175-erdos-1175-2336ecb2bf-formalized-v1 first_order
theorem probe_4_77 : fcTypeOfName% "Erdos1175.erdos_1175" := by
  first_order
#print axioms probe_4_77

-- ATTACK fc-379fc029-erdos1175-erdos-1175-2336ecb2bf-formalized-v1 grind
theorem probe_4_78 : fcTypeOfName% "Erdos1175.erdos_1175" := by
  grind
#print axioms probe_4_78

-- ATTACK fc-379fc029-erdos1175-erdos-1175-2336ecb2bf-formalized-v1 exact_search
theorem probe_4_79 : fcTypeOfName% "Erdos1175.erdos_1175" := by
  exact?
#print axioms probe_4_79

-- ATTACK fc-379fc029-erdos1175-erdos-1175-2336ecb2bf-formalized-v1 apply_search
theorem probe_4_80 : fcTypeOfName% "Erdos1175.erdos_1175" := by
  apply?
#print axioms probe_4_80

-- ATTACK fc-379fc029-erdos1175-erdos-1175-2336ecb2bf-formalized-v1 library_search
theorem probe_4_81 : fcTypeOfName% "Erdos1175.erdos_1175" := by
  library_search
#print axioms probe_4_81

-- ATTACK fc-379fc029-erdos1175-erdos-1175-2336ecb2bf-formalized-v1 aesop_search
theorem probe_4_82 : fcTypeOfName% "Erdos1175.erdos_1175" := by
  aesop?
#print axioms probe_4_82

-- ATTACK fc-379fc029-erdos1175-erdos-1175-2336ecb2bf-formalized-v1 simp_search
theorem probe_4_83 : fcTypeOfName% "Erdos1175.erdos_1175" := by
  simp?
#print axioms probe_4_83

-- ATTACK fc-379fc029-parts-ii-43cff5703f-formalized-v1 simp
theorem probe_4_84 : fcTypeOfName% "Erdos168.erdos_168.parts.ii" := by
  simp
#print axioms probe_4_84

-- ATTACK fc-379fc029-parts-ii-43cff5703f-formalized-v1 simpa
theorem probe_4_85 : fcTypeOfName% "Erdos168.erdos_168.parts.ii" := by
  simpa
#print axioms probe_4_85

-- ATTACK fc-379fc029-parts-ii-43cff5703f-formalized-v1 simp_all
theorem probe_4_86 : fcTypeOfName% "Erdos168.erdos_168.parts.ii" := by
  simp_all
#print axioms probe_4_86

-- ATTACK fc-379fc029-parts-ii-43cff5703f-formalized-v1 aesop
theorem probe_4_87 : fcTypeOfName% "Erdos168.erdos_168.parts.ii" := by
  aesop
#print axioms probe_4_87

-- ATTACK fc-379fc029-parts-ii-43cff5703f-formalized-v1 omega
theorem probe_4_88 : fcTypeOfName% "Erdos168.erdos_168.parts.ii" := by
  omega
#print axioms probe_4_88

-- ATTACK fc-379fc029-parts-ii-43cff5703f-formalized-v1 norm_num
theorem probe_4_89 : fcTypeOfName% "Erdos168.erdos_168.parts.ii" := by
  norm_num
#print axioms probe_4_89

-- ATTACK fc-379fc029-parts-ii-43cff5703f-formalized-v1 decide
theorem probe_4_90 : fcTypeOfName% "Erdos168.erdos_168.parts.ii" := by
  decide
#print axioms probe_4_90

-- ATTACK fc-379fc029-parts-ii-43cff5703f-formalized-v1 native_decide
theorem probe_4_91 : fcTypeOfName% "Erdos168.erdos_168.parts.ii" := by
  native_decide
#print axioms probe_4_91

-- ATTACK fc-379fc029-parts-ii-43cff5703f-formalized-v1 true_intro
theorem probe_4_92 : fcTypeOfName% "Erdos168.erdos_168.parts.ii" := by
  exact True.intro
#print axioms probe_4_92

-- ATTACK fc-379fc029-parts-ii-43cff5703f-formalized-v1 false_elim_simp
theorem probe_4_93 : fcTypeOfName% "Erdos168.erdos_168.parts.ii" := by
  apply False.elim
  simp_all
#print axioms probe_4_93

-- ATTACK fc-379fc029-parts-ii-43cff5703f-formalized-v1 constructor
theorem probe_4_94 : fcTypeOfName% "Erdos168.erdos_168.parts.ii" := by
  constructor
#print axioms probe_4_94

-- ATTACK fc-379fc029-parts-ii-43cff5703f-formalized-v1 constructor_simp
theorem probe_4_95 : fcTypeOfName% "Erdos168.erdos_168.parts.ii" := by
  constructor <;> simp
#print axioms probe_4_95

-- ATTACK fc-379fc029-parts-ii-43cff5703f-formalized-v1 constructor_aesop
theorem probe_4_96 : fcTypeOfName% "Erdos168.erdos_168.parts.ii" := by
  constructor <;> aesop
#print axioms probe_4_96

-- ATTACK fc-379fc029-parts-ii-43cff5703f-formalized-v1 rfl
theorem probe_4_97 : fcTypeOfName% "Erdos168.erdos_168.parts.ii" := by
  rfl
#print axioms probe_4_97

-- ATTACK fc-379fc029-parts-ii-43cff5703f-formalized-v1 trivial
theorem probe_4_98 : fcTypeOfName% "Erdos168.erdos_168.parts.ii" := by
  trivial
#print axioms probe_4_98

-- ATTACK fc-379fc029-parts-ii-43cff5703f-formalized-v1 tauto
theorem probe_4_99 : fcTypeOfName% "Erdos168.erdos_168.parts.ii" := by
  tauto
#print axioms probe_4_99

-- ATTACK fc-379fc029-parts-ii-43cff5703f-formalized-v1 positivity
theorem probe_4_100 : fcTypeOfName% "Erdos168.erdos_168.parts.ii" := by
  positivity
#print axioms probe_4_100

-- ATTACK fc-379fc029-parts-ii-43cff5703f-formalized-v1 linarith
theorem probe_4_101 : fcTypeOfName% "Erdos168.erdos_168.parts.ii" := by
  linarith
#print axioms probe_4_101

-- ATTACK fc-379fc029-parts-ii-43cff5703f-formalized-v1 nlinarith
theorem probe_4_102 : fcTypeOfName% "Erdos168.erdos_168.parts.ii" := by
  nlinarith
#print axioms probe_4_102

-- ATTACK fc-379fc029-parts-ii-43cff5703f-formalized-v1 intros_simp_all
theorem probe_4_103 : fcTypeOfName% "Erdos168.erdos_168.parts.ii" := by
  intros
  simp_all
#print axioms probe_4_103

-- ATTACK fc-379fc029-parts-ii-43cff5703f-formalized-v1 intros_omega
theorem probe_4_104 : fcTypeOfName% "Erdos168.erdos_168.parts.ii" := by
  intros
  omega
#print axioms probe_4_104

-- ATTACK fc-379fc029-parts-ii-43cff5703f-formalized-v1 intros_norm_num
theorem probe_4_105 : fcTypeOfName% "Erdos168.erdos_168.parts.ii" := by
  intros
  norm_num at *
#print axioms probe_4_105

-- ATTACK fc-379fc029-parts-ii-43cff5703f-formalized-v1 intros_aesop
theorem probe_4_106 : fcTypeOfName% "Erdos168.erdos_168.parts.ii" := by
  intros
  aesop
#print axioms probe_4_106

-- ATTACK fc-379fc029-parts-ii-43cff5703f-formalized-v1 by_contra_simp_all
theorem probe_4_107 : fcTypeOfName% "Erdos168.erdos_168.parts.ii" := by
  by_contra h
  simp_all
#print axioms probe_4_107

-- ATTACK fc-379fc029-parts-ii-43cff5703f-formalized-v1 classical_simp_all
theorem probe_4_108 : fcTypeOfName% "Erdos168.erdos_168.parts.ii" := by
  classical
  simp_all
#print axioms probe_4_108

-- ATTACK fc-379fc029-parts-ii-43cff5703f-formalized-v1 classical_aesop
theorem probe_4_109 : fcTypeOfName% "Erdos168.erdos_168.parts.ii" := by
  classical
  aesop
#print axioms probe_4_109

-- ATTACK fc-379fc029-parts-ii-43cff5703f-formalized-v1 refine_pair_simp
theorem probe_4_110 : fcTypeOfName% "Erdos168.erdos_168.parts.ii" := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_4_110

-- ATTACK fc-379fc029-parts-ii-43cff5703f-formalized-v1 refine_pair_aesop
theorem probe_4_111 : fcTypeOfName% "Erdos168.erdos_168.parts.ii" := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_4_111

-- ATTACK fc-379fc029-parts-ii-43cff5703f-formalized-v1 use_zero_simp
theorem probe_4_112 : fcTypeOfName% "Erdos168.erdos_168.parts.ii" := by
  use 0 <;> simp
#print axioms probe_4_112

-- ATTACK fc-379fc029-parts-ii-43cff5703f-formalized-v1 use_one_simp
theorem probe_4_113 : fcTypeOfName% "Erdos168.erdos_168.parts.ii" := by
  use 1 <;> simp
#print axioms probe_4_113

-- ATTACK fc-379fc029-parts-ii-43cff5703f-formalized-v1 use_empty_simp
theorem probe_4_114 : fcTypeOfName% "Erdos168.erdos_168.parts.ii" := by
  use ∅ <;> simp
#print axioms probe_4_114

-- ATTACK fc-379fc029-parts-ii-43cff5703f-formalized-v1 assumption
theorem probe_4_115 : fcTypeOfName% "Erdos168.erdos_168.parts.ii" := by
  assumption
#print axioms probe_4_115

-- ATTACK fc-379fc029-parts-ii-43cff5703f-formalized-v1 infer_instance
theorem probe_4_116 : fcTypeOfName% "Erdos168.erdos_168.parts.ii" := by
  infer_instance
#print axioms probe_4_116

-- ATTACK fc-379fc029-parts-ii-43cff5703f-formalized-v1 contradiction
theorem probe_4_117 : fcTypeOfName% "Erdos168.erdos_168.parts.ii" := by
  contradiction
#print axioms probe_4_117

-- ATTACK fc-379fc029-parts-ii-43cff5703f-formalized-v1 solve_by_elim
theorem probe_4_118 : fcTypeOfName% "Erdos168.erdos_168.parts.ii" := by
  solve_by_elim
#print axioms probe_4_118

-- ATTACK fc-379fc029-parts-ii-43cff5703f-formalized-v1 first_order
theorem probe_4_119 : fcTypeOfName% "Erdos168.erdos_168.parts.ii" := by
  first_order
#print axioms probe_4_119

-- ATTACK fc-379fc029-parts-ii-43cff5703f-formalized-v1 grind
theorem probe_4_120 : fcTypeOfName% "Erdos168.erdos_168.parts.ii" := by
  grind
#print axioms probe_4_120

-- ATTACK fc-379fc029-parts-ii-43cff5703f-formalized-v1 exact_search
theorem probe_4_121 : fcTypeOfName% "Erdos168.erdos_168.parts.ii" := by
  exact?
#print axioms probe_4_121

-- ATTACK fc-379fc029-parts-ii-43cff5703f-formalized-v1 apply_search
theorem probe_4_122 : fcTypeOfName% "Erdos168.erdos_168.parts.ii" := by
  apply?
#print axioms probe_4_122

-- ATTACK fc-379fc029-parts-ii-43cff5703f-formalized-v1 library_search
theorem probe_4_123 : fcTypeOfName% "Erdos168.erdos_168.parts.ii" := by
  library_search
#print axioms probe_4_123

-- ATTACK fc-379fc029-parts-ii-43cff5703f-formalized-v1 aesop_search
theorem probe_4_124 : fcTypeOfName% "Erdos168.erdos_168.parts.ii" := by
  aesop?
#print axioms probe_4_124

-- ATTACK fc-379fc029-parts-ii-43cff5703f-formalized-v1 simp_search
theorem probe_4_125 : fcTypeOfName% "Erdos168.erdos_168.parts.ii" := by
  simp?
#print axioms probe_4_125

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-d302ea5a09-formalized-v1 simp
theorem probe_4_126 : fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero" := by
  simp
#print axioms probe_4_126

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-d302ea5a09-formalized-v1 simpa
theorem probe_4_127 : fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero" := by
  simpa
#print axioms probe_4_127

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-d302ea5a09-formalized-v1 simp_all
theorem probe_4_128 : fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero" := by
  simp_all
#print axioms probe_4_128

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-d302ea5a09-formalized-v1 aesop
theorem probe_4_129 : fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero" := by
  aesop
#print axioms probe_4_129

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-d302ea5a09-formalized-v1 omega
theorem probe_4_130 : fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero" := by
  omega
#print axioms probe_4_130

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-d302ea5a09-formalized-v1 norm_num
theorem probe_4_131 : fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero" := by
  norm_num
#print axioms probe_4_131

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-d302ea5a09-formalized-v1 decide
theorem probe_4_132 : fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero" := by
  decide
#print axioms probe_4_132

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-d302ea5a09-formalized-v1 native_decide
theorem probe_4_133 : fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero" := by
  native_decide
#print axioms probe_4_133

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-d302ea5a09-formalized-v1 true_intro
theorem probe_4_134 : fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero" := by
  exact True.intro
#print axioms probe_4_134

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-d302ea5a09-formalized-v1 false_elim_simp
theorem probe_4_135 : fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero" := by
  apply False.elim
  simp_all
#print axioms probe_4_135

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-d302ea5a09-formalized-v1 constructor
theorem probe_4_136 : fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero" := by
  constructor
#print axioms probe_4_136

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-d302ea5a09-formalized-v1 constructor_simp
theorem probe_4_137 : fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero" := by
  constructor <;> simp
#print axioms probe_4_137

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-d302ea5a09-formalized-v1 constructor_aesop
theorem probe_4_138 : fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero" := by
  constructor <;> aesop
#print axioms probe_4_138

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-d302ea5a09-formalized-v1 rfl
theorem probe_4_139 : fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero" := by
  rfl
#print axioms probe_4_139

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-d302ea5a09-formalized-v1 trivial
theorem probe_4_140 : fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero" := by
  trivial
#print axioms probe_4_140

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-d302ea5a09-formalized-v1 tauto
theorem probe_4_141 : fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero" := by
  tauto
#print axioms probe_4_141

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-d302ea5a09-formalized-v1 positivity
theorem probe_4_142 : fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero" := by
  positivity
#print axioms probe_4_142

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-d302ea5a09-formalized-v1 linarith
theorem probe_4_143 : fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero" := by
  linarith
#print axioms probe_4_143

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-d302ea5a09-formalized-v1 nlinarith
theorem probe_4_144 : fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero" := by
  nlinarith
#print axioms probe_4_144

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-d302ea5a09-formalized-v1 intros_simp_all
theorem probe_4_145 : fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero" := by
  intros
  simp_all
#print axioms probe_4_145

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-d302ea5a09-formalized-v1 intros_omega
theorem probe_4_146 : fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero" := by
  intros
  omega
#print axioms probe_4_146

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-d302ea5a09-formalized-v1 intros_norm_num
theorem probe_4_147 : fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero" := by
  intros
  norm_num at *
#print axioms probe_4_147

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-d302ea5a09-formalized-v1 intros_aesop
theorem probe_4_148 : fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero" := by
  intros
  aesop
#print axioms probe_4_148

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-d302ea5a09-formalized-v1 by_contra_simp_all
theorem probe_4_149 : fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero" := by
  by_contra h
  simp_all
#print axioms probe_4_149

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-d302ea5a09-formalized-v1 classical_simp_all
theorem probe_4_150 : fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero" := by
  classical
  simp_all
#print axioms probe_4_150

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-d302ea5a09-formalized-v1 classical_aesop
theorem probe_4_151 : fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero" := by
  classical
  aesop
#print axioms probe_4_151

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-d302ea5a09-formalized-v1 refine_pair_simp
theorem probe_4_152 : fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero" := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_4_152

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-d302ea5a09-formalized-v1 refine_pair_aesop
theorem probe_4_153 : fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero" := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_4_153

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-d302ea5a09-formalized-v1 use_zero_simp
theorem probe_4_154 : fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero" := by
  use 0 <;> simp
#print axioms probe_4_154

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-d302ea5a09-formalized-v1 use_one_simp
theorem probe_4_155 : fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero" := by
  use 1 <;> simp
#print axioms probe_4_155

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-d302ea5a09-formalized-v1 use_empty_simp
theorem probe_4_156 : fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero" := by
  use ∅ <;> simp
#print axioms probe_4_156

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-d302ea5a09-formalized-v1 assumption
theorem probe_4_157 : fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero" := by
  assumption
#print axioms probe_4_157

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-d302ea5a09-formalized-v1 infer_instance
theorem probe_4_158 : fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero" := by
  infer_instance
#print axioms probe_4_158

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-d302ea5a09-formalized-v1 contradiction
theorem probe_4_159 : fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero" := by
  contradiction
#print axioms probe_4_159

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-d302ea5a09-formalized-v1 solve_by_elim
theorem probe_4_160 : fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero" := by
  solve_by_elim
#print axioms probe_4_160

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-d302ea5a09-formalized-v1 first_order
theorem probe_4_161 : fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero" := by
  first_order
#print axioms probe_4_161

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-d302ea5a09-formalized-v1 grind
theorem probe_4_162 : fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero" := by
  grind
#print axioms probe_4_162

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-d302ea5a09-formalized-v1 exact_search
theorem probe_4_163 : fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero" := by
  exact?
#print axioms probe_4_163

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-d302ea5a09-formalized-v1 apply_search
theorem probe_4_164 : fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero" := by
  apply?
#print axioms probe_4_164

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-d302ea5a09-formalized-v1 library_search
theorem probe_4_165 : fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero" := by
  library_search
#print axioms probe_4_165

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-d302ea5a09-formalized-v1 aesop_search
theorem probe_4_166 : fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero" := by
  aesop?
#print axioms probe_4_166

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-d302ea5a09-formalized-v1 simp_search
theorem probe_4_167 : fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero" := by
  simp?
#print axioms probe_4_167

-- ATTACK fc-379fc029-variants-claim2-38c7dae282-formalized-v1 simp
theorem probe_4_168 : fcTypeOfName% "Erdos317.erdos_317.variants.claim2" := by
  simp
#print axioms probe_4_168

-- ATTACK fc-379fc029-variants-claim2-38c7dae282-formalized-v1 simpa
theorem probe_4_169 : fcTypeOfName% "Erdos317.erdos_317.variants.claim2" := by
  simpa
#print axioms probe_4_169

-- ATTACK fc-379fc029-variants-claim2-38c7dae282-formalized-v1 simp_all
theorem probe_4_170 : fcTypeOfName% "Erdos317.erdos_317.variants.claim2" := by
  simp_all
#print axioms probe_4_170

-- ATTACK fc-379fc029-variants-claim2-38c7dae282-formalized-v1 aesop
theorem probe_4_171 : fcTypeOfName% "Erdos317.erdos_317.variants.claim2" := by
  aesop
#print axioms probe_4_171

-- ATTACK fc-379fc029-variants-claim2-38c7dae282-formalized-v1 omega
theorem probe_4_172 : fcTypeOfName% "Erdos317.erdos_317.variants.claim2" := by
  omega
#print axioms probe_4_172

-- ATTACK fc-379fc029-variants-claim2-38c7dae282-formalized-v1 norm_num
theorem probe_4_173 : fcTypeOfName% "Erdos317.erdos_317.variants.claim2" := by
  norm_num
#print axioms probe_4_173

-- ATTACK fc-379fc029-variants-claim2-38c7dae282-formalized-v1 decide
theorem probe_4_174 : fcTypeOfName% "Erdos317.erdos_317.variants.claim2" := by
  decide
#print axioms probe_4_174

-- ATTACK fc-379fc029-variants-claim2-38c7dae282-formalized-v1 native_decide
theorem probe_4_175 : fcTypeOfName% "Erdos317.erdos_317.variants.claim2" := by
  native_decide
#print axioms probe_4_175

-- ATTACK fc-379fc029-variants-claim2-38c7dae282-formalized-v1 true_intro
theorem probe_4_176 : fcTypeOfName% "Erdos317.erdos_317.variants.claim2" := by
  exact True.intro
#print axioms probe_4_176

-- ATTACK fc-379fc029-variants-claim2-38c7dae282-formalized-v1 false_elim_simp
theorem probe_4_177 : fcTypeOfName% "Erdos317.erdos_317.variants.claim2" := by
  apply False.elim
  simp_all
#print axioms probe_4_177

-- ATTACK fc-379fc029-variants-claim2-38c7dae282-formalized-v1 constructor
theorem probe_4_178 : fcTypeOfName% "Erdos317.erdos_317.variants.claim2" := by
  constructor
#print axioms probe_4_178

-- ATTACK fc-379fc029-variants-claim2-38c7dae282-formalized-v1 constructor_simp
theorem probe_4_179 : fcTypeOfName% "Erdos317.erdos_317.variants.claim2" := by
  constructor <;> simp
#print axioms probe_4_179

-- ATTACK fc-379fc029-variants-claim2-38c7dae282-formalized-v1 constructor_aesop
theorem probe_4_180 : fcTypeOfName% "Erdos317.erdos_317.variants.claim2" := by
  constructor <;> aesop
#print axioms probe_4_180

-- ATTACK fc-379fc029-variants-claim2-38c7dae282-formalized-v1 rfl
theorem probe_4_181 : fcTypeOfName% "Erdos317.erdos_317.variants.claim2" := by
  rfl
#print axioms probe_4_181

-- ATTACK fc-379fc029-variants-claim2-38c7dae282-formalized-v1 trivial
theorem probe_4_182 : fcTypeOfName% "Erdos317.erdos_317.variants.claim2" := by
  trivial
#print axioms probe_4_182

-- ATTACK fc-379fc029-variants-claim2-38c7dae282-formalized-v1 tauto
theorem probe_4_183 : fcTypeOfName% "Erdos317.erdos_317.variants.claim2" := by
  tauto
#print axioms probe_4_183

-- ATTACK fc-379fc029-variants-claim2-38c7dae282-formalized-v1 positivity
theorem probe_4_184 : fcTypeOfName% "Erdos317.erdos_317.variants.claim2" := by
  positivity
#print axioms probe_4_184

-- ATTACK fc-379fc029-variants-claim2-38c7dae282-formalized-v1 linarith
theorem probe_4_185 : fcTypeOfName% "Erdos317.erdos_317.variants.claim2" := by
  linarith
#print axioms probe_4_185

-- ATTACK fc-379fc029-variants-claim2-38c7dae282-formalized-v1 nlinarith
theorem probe_4_186 : fcTypeOfName% "Erdos317.erdos_317.variants.claim2" := by
  nlinarith
#print axioms probe_4_186

-- ATTACK fc-379fc029-variants-claim2-38c7dae282-formalized-v1 intros_simp_all
theorem probe_4_187 : fcTypeOfName% "Erdos317.erdos_317.variants.claim2" := by
  intros
  simp_all
#print axioms probe_4_187

-- ATTACK fc-379fc029-variants-claim2-38c7dae282-formalized-v1 intros_omega
theorem probe_4_188 : fcTypeOfName% "Erdos317.erdos_317.variants.claim2" := by
  intros
  omega
#print axioms probe_4_188

-- ATTACK fc-379fc029-variants-claim2-38c7dae282-formalized-v1 intros_norm_num
theorem probe_4_189 : fcTypeOfName% "Erdos317.erdos_317.variants.claim2" := by
  intros
  norm_num at *
#print axioms probe_4_189

-- ATTACK fc-379fc029-variants-claim2-38c7dae282-formalized-v1 intros_aesop
theorem probe_4_190 : fcTypeOfName% "Erdos317.erdos_317.variants.claim2" := by
  intros
  aesop
#print axioms probe_4_190

-- ATTACK fc-379fc029-variants-claim2-38c7dae282-formalized-v1 by_contra_simp_all
theorem probe_4_191 : fcTypeOfName% "Erdos317.erdos_317.variants.claim2" := by
  by_contra h
  simp_all
#print axioms probe_4_191

-- ATTACK fc-379fc029-variants-claim2-38c7dae282-formalized-v1 classical_simp_all
theorem probe_4_192 : fcTypeOfName% "Erdos317.erdos_317.variants.claim2" := by
  classical
  simp_all
#print axioms probe_4_192

-- ATTACK fc-379fc029-variants-claim2-38c7dae282-formalized-v1 classical_aesop
theorem probe_4_193 : fcTypeOfName% "Erdos317.erdos_317.variants.claim2" := by
  classical
  aesop
#print axioms probe_4_193

-- ATTACK fc-379fc029-variants-claim2-38c7dae282-formalized-v1 refine_pair_simp
theorem probe_4_194 : fcTypeOfName% "Erdos317.erdos_317.variants.claim2" := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_4_194

-- ATTACK fc-379fc029-variants-claim2-38c7dae282-formalized-v1 refine_pair_aesop
theorem probe_4_195 : fcTypeOfName% "Erdos317.erdos_317.variants.claim2" := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_4_195

-- ATTACK fc-379fc029-variants-claim2-38c7dae282-formalized-v1 use_zero_simp
theorem probe_4_196 : fcTypeOfName% "Erdos317.erdos_317.variants.claim2" := by
  use 0 <;> simp
#print axioms probe_4_196

-- ATTACK fc-379fc029-variants-claim2-38c7dae282-formalized-v1 use_one_simp
theorem probe_4_197 : fcTypeOfName% "Erdos317.erdos_317.variants.claim2" := by
  use 1 <;> simp
#print axioms probe_4_197

-- ATTACK fc-379fc029-variants-claim2-38c7dae282-formalized-v1 use_empty_simp
theorem probe_4_198 : fcTypeOfName% "Erdos317.erdos_317.variants.claim2" := by
  use ∅ <;> simp
#print axioms probe_4_198

-- ATTACK fc-379fc029-variants-claim2-38c7dae282-formalized-v1 assumption
theorem probe_4_199 : fcTypeOfName% "Erdos317.erdos_317.variants.claim2" := by
  assumption
#print axioms probe_4_199

-- ATTACK fc-379fc029-variants-claim2-38c7dae282-formalized-v1 infer_instance
theorem probe_4_200 : fcTypeOfName% "Erdos317.erdos_317.variants.claim2" := by
  infer_instance
#print axioms probe_4_200

-- ATTACK fc-379fc029-variants-claim2-38c7dae282-formalized-v1 contradiction
theorem probe_4_201 : fcTypeOfName% "Erdos317.erdos_317.variants.claim2" := by
  contradiction
#print axioms probe_4_201

-- ATTACK fc-379fc029-variants-claim2-38c7dae282-formalized-v1 solve_by_elim
theorem probe_4_202 : fcTypeOfName% "Erdos317.erdos_317.variants.claim2" := by
  solve_by_elim
#print axioms probe_4_202

-- ATTACK fc-379fc029-variants-claim2-38c7dae282-formalized-v1 first_order
theorem probe_4_203 : fcTypeOfName% "Erdos317.erdos_317.variants.claim2" := by
  first_order
#print axioms probe_4_203

-- ATTACK fc-379fc029-variants-claim2-38c7dae282-formalized-v1 grind
theorem probe_4_204 : fcTypeOfName% "Erdos317.erdos_317.variants.claim2" := by
  grind
#print axioms probe_4_204

-- ATTACK fc-379fc029-variants-claim2-38c7dae282-formalized-v1 exact_search
theorem probe_4_205 : fcTypeOfName% "Erdos317.erdos_317.variants.claim2" := by
  exact?
#print axioms probe_4_205

-- ATTACK fc-379fc029-variants-claim2-38c7dae282-formalized-v1 apply_search
theorem probe_4_206 : fcTypeOfName% "Erdos317.erdos_317.variants.claim2" := by
  apply?
#print axioms probe_4_206

-- ATTACK fc-379fc029-variants-claim2-38c7dae282-formalized-v1 library_search
theorem probe_4_207 : fcTypeOfName% "Erdos317.erdos_317.variants.claim2" := by
  library_search
#print axioms probe_4_207

-- ATTACK fc-379fc029-variants-claim2-38c7dae282-formalized-v1 aesop_search
theorem probe_4_208 : fcTypeOfName% "Erdos317.erdos_317.variants.claim2" := by
  aesop?
#print axioms probe_4_208

-- ATTACK fc-379fc029-variants-claim2-38c7dae282-formalized-v1 simp_search
theorem probe_4_209 : fcTypeOfName% "Erdos317.erdos_317.variants.claim2" := by
  simp?
#print axioms probe_4_209

-- ATTACK fc-379fc029-erdos410-erdos-410-201e0bce8a-formalized-v1 simp
theorem probe_4_210 : fcTypeOfName% "Erdos410.erdos_410" := by
  simp
#print axioms probe_4_210

-- ATTACK fc-379fc029-erdos410-erdos-410-201e0bce8a-formalized-v1 simpa
theorem probe_4_211 : fcTypeOfName% "Erdos410.erdos_410" := by
  simpa
#print axioms probe_4_211

-- ATTACK fc-379fc029-erdos410-erdos-410-201e0bce8a-formalized-v1 simp_all
theorem probe_4_212 : fcTypeOfName% "Erdos410.erdos_410" := by
  simp_all
#print axioms probe_4_212

-- ATTACK fc-379fc029-erdos410-erdos-410-201e0bce8a-formalized-v1 aesop
theorem probe_4_213 : fcTypeOfName% "Erdos410.erdos_410" := by
  aesop
#print axioms probe_4_213

-- ATTACK fc-379fc029-erdos410-erdos-410-201e0bce8a-formalized-v1 omega
theorem probe_4_214 : fcTypeOfName% "Erdos410.erdos_410" := by
  omega
#print axioms probe_4_214

-- ATTACK fc-379fc029-erdos410-erdos-410-201e0bce8a-formalized-v1 norm_num
theorem probe_4_215 : fcTypeOfName% "Erdos410.erdos_410" := by
  norm_num
#print axioms probe_4_215

-- ATTACK fc-379fc029-erdos410-erdos-410-201e0bce8a-formalized-v1 decide
theorem probe_4_216 : fcTypeOfName% "Erdos410.erdos_410" := by
  decide
#print axioms probe_4_216

-- ATTACK fc-379fc029-erdos410-erdos-410-201e0bce8a-formalized-v1 native_decide
theorem probe_4_217 : fcTypeOfName% "Erdos410.erdos_410" := by
  native_decide
#print axioms probe_4_217

-- ATTACK fc-379fc029-erdos410-erdos-410-201e0bce8a-formalized-v1 true_intro
theorem probe_4_218 : fcTypeOfName% "Erdos410.erdos_410" := by
  exact True.intro
#print axioms probe_4_218

-- ATTACK fc-379fc029-erdos410-erdos-410-201e0bce8a-formalized-v1 false_elim_simp
theorem probe_4_219 : fcTypeOfName% "Erdos410.erdos_410" := by
  apply False.elim
  simp_all
#print axioms probe_4_219

-- ATTACK fc-379fc029-erdos410-erdos-410-201e0bce8a-formalized-v1 constructor
theorem probe_4_220 : fcTypeOfName% "Erdos410.erdos_410" := by
  constructor
#print axioms probe_4_220

-- ATTACK fc-379fc029-erdos410-erdos-410-201e0bce8a-formalized-v1 constructor_simp
theorem probe_4_221 : fcTypeOfName% "Erdos410.erdos_410" := by
  constructor <;> simp
#print axioms probe_4_221

-- ATTACK fc-379fc029-erdos410-erdos-410-201e0bce8a-formalized-v1 constructor_aesop
theorem probe_4_222 : fcTypeOfName% "Erdos410.erdos_410" := by
  constructor <;> aesop
#print axioms probe_4_222

-- ATTACK fc-379fc029-erdos410-erdos-410-201e0bce8a-formalized-v1 rfl
theorem probe_4_223 : fcTypeOfName% "Erdos410.erdos_410" := by
  rfl
#print axioms probe_4_223

-- ATTACK fc-379fc029-erdos410-erdos-410-201e0bce8a-formalized-v1 trivial
theorem probe_4_224 : fcTypeOfName% "Erdos410.erdos_410" := by
  trivial
#print axioms probe_4_224

-- ATTACK fc-379fc029-erdos410-erdos-410-201e0bce8a-formalized-v1 tauto
theorem probe_4_225 : fcTypeOfName% "Erdos410.erdos_410" := by
  tauto
#print axioms probe_4_225

-- ATTACK fc-379fc029-erdos410-erdos-410-201e0bce8a-formalized-v1 positivity
theorem probe_4_226 : fcTypeOfName% "Erdos410.erdos_410" := by
  positivity
#print axioms probe_4_226

-- ATTACK fc-379fc029-erdos410-erdos-410-201e0bce8a-formalized-v1 linarith
theorem probe_4_227 : fcTypeOfName% "Erdos410.erdos_410" := by
  linarith
#print axioms probe_4_227

-- ATTACK fc-379fc029-erdos410-erdos-410-201e0bce8a-formalized-v1 nlinarith
theorem probe_4_228 : fcTypeOfName% "Erdos410.erdos_410" := by
  nlinarith
#print axioms probe_4_228

-- ATTACK fc-379fc029-erdos410-erdos-410-201e0bce8a-formalized-v1 intros_simp_all
theorem probe_4_229 : fcTypeOfName% "Erdos410.erdos_410" := by
  intros
  simp_all
#print axioms probe_4_229

-- ATTACK fc-379fc029-erdos410-erdos-410-201e0bce8a-formalized-v1 intros_omega
theorem probe_4_230 : fcTypeOfName% "Erdos410.erdos_410" := by
  intros
  omega
#print axioms probe_4_230

-- ATTACK fc-379fc029-erdos410-erdos-410-201e0bce8a-formalized-v1 intros_norm_num
theorem probe_4_231 : fcTypeOfName% "Erdos410.erdos_410" := by
  intros
  norm_num at *
#print axioms probe_4_231

-- ATTACK fc-379fc029-erdos410-erdos-410-201e0bce8a-formalized-v1 intros_aesop
theorem probe_4_232 : fcTypeOfName% "Erdos410.erdos_410" := by
  intros
  aesop
#print axioms probe_4_232

-- ATTACK fc-379fc029-erdos410-erdos-410-201e0bce8a-formalized-v1 by_contra_simp_all
theorem probe_4_233 : fcTypeOfName% "Erdos410.erdos_410" := by
  by_contra h
  simp_all
#print axioms probe_4_233

-- ATTACK fc-379fc029-erdos410-erdos-410-201e0bce8a-formalized-v1 classical_simp_all
theorem probe_4_234 : fcTypeOfName% "Erdos410.erdos_410" := by
  classical
  simp_all
#print axioms probe_4_234

-- ATTACK fc-379fc029-erdos410-erdos-410-201e0bce8a-formalized-v1 classical_aesop
theorem probe_4_235 : fcTypeOfName% "Erdos410.erdos_410" := by
  classical
  aesop
#print axioms probe_4_235

-- ATTACK fc-379fc029-erdos410-erdos-410-201e0bce8a-formalized-v1 refine_pair_simp
theorem probe_4_236 : fcTypeOfName% "Erdos410.erdos_410" := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_4_236

-- ATTACK fc-379fc029-erdos410-erdos-410-201e0bce8a-formalized-v1 refine_pair_aesop
theorem probe_4_237 : fcTypeOfName% "Erdos410.erdos_410" := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_4_237

-- ATTACK fc-379fc029-erdos410-erdos-410-201e0bce8a-formalized-v1 use_zero_simp
theorem probe_4_238 : fcTypeOfName% "Erdos410.erdos_410" := by
  use 0 <;> simp
#print axioms probe_4_238

-- ATTACK fc-379fc029-erdos410-erdos-410-201e0bce8a-formalized-v1 use_one_simp
theorem probe_4_239 : fcTypeOfName% "Erdos410.erdos_410" := by
  use 1 <;> simp
#print axioms probe_4_239

-- ATTACK fc-379fc029-erdos410-erdos-410-201e0bce8a-formalized-v1 use_empty_simp
theorem probe_4_240 : fcTypeOfName% "Erdos410.erdos_410" := by
  use ∅ <;> simp
#print axioms probe_4_240

-- ATTACK fc-379fc029-erdos410-erdos-410-201e0bce8a-formalized-v1 assumption
theorem probe_4_241 : fcTypeOfName% "Erdos410.erdos_410" := by
  assumption
#print axioms probe_4_241

-- ATTACK fc-379fc029-erdos410-erdos-410-201e0bce8a-formalized-v1 infer_instance
theorem probe_4_242 : fcTypeOfName% "Erdos410.erdos_410" := by
  infer_instance
#print axioms probe_4_242

-- ATTACK fc-379fc029-erdos410-erdos-410-201e0bce8a-formalized-v1 contradiction
theorem probe_4_243 : fcTypeOfName% "Erdos410.erdos_410" := by
  contradiction
#print axioms probe_4_243

-- ATTACK fc-379fc029-erdos410-erdos-410-201e0bce8a-formalized-v1 solve_by_elim
theorem probe_4_244 : fcTypeOfName% "Erdos410.erdos_410" := by
  solve_by_elim
#print axioms probe_4_244

-- ATTACK fc-379fc029-erdos410-erdos-410-201e0bce8a-formalized-v1 first_order
theorem probe_4_245 : fcTypeOfName% "Erdos410.erdos_410" := by
  first_order
#print axioms probe_4_245

-- ATTACK fc-379fc029-erdos410-erdos-410-201e0bce8a-formalized-v1 grind
theorem probe_4_246 : fcTypeOfName% "Erdos410.erdos_410" := by
  grind
#print axioms probe_4_246

-- ATTACK fc-379fc029-erdos410-erdos-410-201e0bce8a-formalized-v1 exact_search
theorem probe_4_247 : fcTypeOfName% "Erdos410.erdos_410" := by
  exact?
#print axioms probe_4_247

-- ATTACK fc-379fc029-erdos410-erdos-410-201e0bce8a-formalized-v1 apply_search
theorem probe_4_248 : fcTypeOfName% "Erdos410.erdos_410" := by
  apply?
#print axioms probe_4_248

-- ATTACK fc-379fc029-erdos410-erdos-410-201e0bce8a-formalized-v1 library_search
theorem probe_4_249 : fcTypeOfName% "Erdos410.erdos_410" := by
  library_search
#print axioms probe_4_249

-- ATTACK fc-379fc029-erdos410-erdos-410-201e0bce8a-formalized-v1 aesop_search
theorem probe_4_250 : fcTypeOfName% "Erdos410.erdos_410" := by
  aesop?
#print axioms probe_4_250

-- ATTACK fc-379fc029-erdos410-erdos-410-201e0bce8a-formalized-v1 simp_search
theorem probe_4_251 : fcTypeOfName% "Erdos410.erdos_410" := by
  simp?
#print axioms probe_4_251

-- ATTACK fc-379fc029-erdos61-erdos-61-362e8086fe-formalized-v1 simp
theorem probe_4_252 : fcTypeOfName% "Erdos61.erdos_61" := by
  simp
#print axioms probe_4_252

-- ATTACK fc-379fc029-erdos61-erdos-61-362e8086fe-formalized-v1 simpa
theorem probe_4_253 : fcTypeOfName% "Erdos61.erdos_61" := by
  simpa
#print axioms probe_4_253

-- ATTACK fc-379fc029-erdos61-erdos-61-362e8086fe-formalized-v1 simp_all
theorem probe_4_254 : fcTypeOfName% "Erdos61.erdos_61" := by
  simp_all
#print axioms probe_4_254

-- ATTACK fc-379fc029-erdos61-erdos-61-362e8086fe-formalized-v1 aesop
theorem probe_4_255 : fcTypeOfName% "Erdos61.erdos_61" := by
  aesop
#print axioms probe_4_255

-- ATTACK fc-379fc029-erdos61-erdos-61-362e8086fe-formalized-v1 omega
theorem probe_4_256 : fcTypeOfName% "Erdos61.erdos_61" := by
  omega
#print axioms probe_4_256

-- ATTACK fc-379fc029-erdos61-erdos-61-362e8086fe-formalized-v1 norm_num
theorem probe_4_257 : fcTypeOfName% "Erdos61.erdos_61" := by
  norm_num
#print axioms probe_4_257

-- ATTACK fc-379fc029-erdos61-erdos-61-362e8086fe-formalized-v1 decide
theorem probe_4_258 : fcTypeOfName% "Erdos61.erdos_61" := by
  decide
#print axioms probe_4_258

-- ATTACK fc-379fc029-erdos61-erdos-61-362e8086fe-formalized-v1 native_decide
theorem probe_4_259 : fcTypeOfName% "Erdos61.erdos_61" := by
  native_decide
#print axioms probe_4_259

-- ATTACK fc-379fc029-erdos61-erdos-61-362e8086fe-formalized-v1 true_intro
theorem probe_4_260 : fcTypeOfName% "Erdos61.erdos_61" := by
  exact True.intro
#print axioms probe_4_260

-- ATTACK fc-379fc029-erdos61-erdos-61-362e8086fe-formalized-v1 false_elim_simp
theorem probe_4_261 : fcTypeOfName% "Erdos61.erdos_61" := by
  apply False.elim
  simp_all
#print axioms probe_4_261

-- ATTACK fc-379fc029-erdos61-erdos-61-362e8086fe-formalized-v1 constructor
theorem probe_4_262 : fcTypeOfName% "Erdos61.erdos_61" := by
  constructor
#print axioms probe_4_262

-- ATTACK fc-379fc029-erdos61-erdos-61-362e8086fe-formalized-v1 constructor_simp
theorem probe_4_263 : fcTypeOfName% "Erdos61.erdos_61" := by
  constructor <;> simp
#print axioms probe_4_263

-- ATTACK fc-379fc029-erdos61-erdos-61-362e8086fe-formalized-v1 constructor_aesop
theorem probe_4_264 : fcTypeOfName% "Erdos61.erdos_61" := by
  constructor <;> aesop
#print axioms probe_4_264

-- ATTACK fc-379fc029-erdos61-erdos-61-362e8086fe-formalized-v1 rfl
theorem probe_4_265 : fcTypeOfName% "Erdos61.erdos_61" := by
  rfl
#print axioms probe_4_265

-- ATTACK fc-379fc029-erdos61-erdos-61-362e8086fe-formalized-v1 trivial
theorem probe_4_266 : fcTypeOfName% "Erdos61.erdos_61" := by
  trivial
#print axioms probe_4_266

-- ATTACK fc-379fc029-erdos61-erdos-61-362e8086fe-formalized-v1 tauto
theorem probe_4_267 : fcTypeOfName% "Erdos61.erdos_61" := by
  tauto
#print axioms probe_4_267

-- ATTACK fc-379fc029-erdos61-erdos-61-362e8086fe-formalized-v1 positivity
theorem probe_4_268 : fcTypeOfName% "Erdos61.erdos_61" := by
  positivity
#print axioms probe_4_268

-- ATTACK fc-379fc029-erdos61-erdos-61-362e8086fe-formalized-v1 linarith
theorem probe_4_269 : fcTypeOfName% "Erdos61.erdos_61" := by
  linarith
#print axioms probe_4_269

-- ATTACK fc-379fc029-erdos61-erdos-61-362e8086fe-formalized-v1 nlinarith
theorem probe_4_270 : fcTypeOfName% "Erdos61.erdos_61" := by
  nlinarith
#print axioms probe_4_270

-- ATTACK fc-379fc029-erdos61-erdos-61-362e8086fe-formalized-v1 intros_simp_all
theorem probe_4_271 : fcTypeOfName% "Erdos61.erdos_61" := by
  intros
  simp_all
#print axioms probe_4_271

-- ATTACK fc-379fc029-erdos61-erdos-61-362e8086fe-formalized-v1 intros_omega
theorem probe_4_272 : fcTypeOfName% "Erdos61.erdos_61" := by
  intros
  omega
#print axioms probe_4_272

-- ATTACK fc-379fc029-erdos61-erdos-61-362e8086fe-formalized-v1 intros_norm_num
theorem probe_4_273 : fcTypeOfName% "Erdos61.erdos_61" := by
  intros
  norm_num at *
#print axioms probe_4_273

-- ATTACK fc-379fc029-erdos61-erdos-61-362e8086fe-formalized-v1 intros_aesop
theorem probe_4_274 : fcTypeOfName% "Erdos61.erdos_61" := by
  intros
  aesop
#print axioms probe_4_274

-- ATTACK fc-379fc029-erdos61-erdos-61-362e8086fe-formalized-v1 by_contra_simp_all
theorem probe_4_275 : fcTypeOfName% "Erdos61.erdos_61" := by
  by_contra h
  simp_all
#print axioms probe_4_275

-- ATTACK fc-379fc029-erdos61-erdos-61-362e8086fe-formalized-v1 classical_simp_all
theorem probe_4_276 : fcTypeOfName% "Erdos61.erdos_61" := by
  classical
  simp_all
#print axioms probe_4_276

-- ATTACK fc-379fc029-erdos61-erdos-61-362e8086fe-formalized-v1 classical_aesop
theorem probe_4_277 : fcTypeOfName% "Erdos61.erdos_61" := by
  classical
  aesop
#print axioms probe_4_277

-- ATTACK fc-379fc029-erdos61-erdos-61-362e8086fe-formalized-v1 refine_pair_simp
theorem probe_4_278 : fcTypeOfName% "Erdos61.erdos_61" := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_4_278

-- ATTACK fc-379fc029-erdos61-erdos-61-362e8086fe-formalized-v1 refine_pair_aesop
theorem probe_4_279 : fcTypeOfName% "Erdos61.erdos_61" := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_4_279

-- ATTACK fc-379fc029-erdos61-erdos-61-362e8086fe-formalized-v1 use_zero_simp
theorem probe_4_280 : fcTypeOfName% "Erdos61.erdos_61" := by
  use 0 <;> simp
#print axioms probe_4_280

-- ATTACK fc-379fc029-erdos61-erdos-61-362e8086fe-formalized-v1 use_one_simp
theorem probe_4_281 : fcTypeOfName% "Erdos61.erdos_61" := by
  use 1 <;> simp
#print axioms probe_4_281

-- ATTACK fc-379fc029-erdos61-erdos-61-362e8086fe-formalized-v1 use_empty_simp
theorem probe_4_282 : fcTypeOfName% "Erdos61.erdos_61" := by
  use ∅ <;> simp
#print axioms probe_4_282

-- ATTACK fc-379fc029-erdos61-erdos-61-362e8086fe-formalized-v1 assumption
theorem probe_4_283 : fcTypeOfName% "Erdos61.erdos_61" := by
  assumption
#print axioms probe_4_283

-- ATTACK fc-379fc029-erdos61-erdos-61-362e8086fe-formalized-v1 infer_instance
theorem probe_4_284 : fcTypeOfName% "Erdos61.erdos_61" := by
  infer_instance
#print axioms probe_4_284

-- ATTACK fc-379fc029-erdos61-erdos-61-362e8086fe-formalized-v1 contradiction
theorem probe_4_285 : fcTypeOfName% "Erdos61.erdos_61" := by
  contradiction
#print axioms probe_4_285

-- ATTACK fc-379fc029-erdos61-erdos-61-362e8086fe-formalized-v1 solve_by_elim
theorem probe_4_286 : fcTypeOfName% "Erdos61.erdos_61" := by
  solve_by_elim
#print axioms probe_4_286

-- ATTACK fc-379fc029-erdos61-erdos-61-362e8086fe-formalized-v1 first_order
theorem probe_4_287 : fcTypeOfName% "Erdos61.erdos_61" := by
  first_order
#print axioms probe_4_287

-- ATTACK fc-379fc029-erdos61-erdos-61-362e8086fe-formalized-v1 grind
theorem probe_4_288 : fcTypeOfName% "Erdos61.erdos_61" := by
  grind
#print axioms probe_4_288

-- ATTACK fc-379fc029-erdos61-erdos-61-362e8086fe-formalized-v1 exact_search
theorem probe_4_289 : fcTypeOfName% "Erdos61.erdos_61" := by
  exact?
#print axioms probe_4_289

-- ATTACK fc-379fc029-erdos61-erdos-61-362e8086fe-formalized-v1 apply_search
theorem probe_4_290 : fcTypeOfName% "Erdos61.erdos_61" := by
  apply?
#print axioms probe_4_290

-- ATTACK fc-379fc029-erdos61-erdos-61-362e8086fe-formalized-v1 library_search
theorem probe_4_291 : fcTypeOfName% "Erdos61.erdos_61" := by
  library_search
#print axioms probe_4_291

-- ATTACK fc-379fc029-erdos61-erdos-61-362e8086fe-formalized-v1 aesop_search
theorem probe_4_292 : fcTypeOfName% "Erdos61.erdos_61" := by
  aesop?
#print axioms probe_4_292

-- ATTACK fc-379fc029-erdos61-erdos-61-362e8086fe-formalized-v1 simp_search
theorem probe_4_293 : fcTypeOfName% "Erdos61.erdos_61" := by
  simp?
#print axioms probe_4_293

-- ATTACK fc-379fc029-erdos749-erdos-749-00c9d45362-formalized-v1 simp
theorem probe_4_294 : fcTypeOfName% "Erdos749.erdos_749" := by
  simp
#print axioms probe_4_294

-- ATTACK fc-379fc029-erdos749-erdos-749-00c9d45362-formalized-v1 simpa
theorem probe_4_295 : fcTypeOfName% "Erdos749.erdos_749" := by
  simpa
#print axioms probe_4_295

-- ATTACK fc-379fc029-erdos749-erdos-749-00c9d45362-formalized-v1 simp_all
theorem probe_4_296 : fcTypeOfName% "Erdos749.erdos_749" := by
  simp_all
#print axioms probe_4_296

-- ATTACK fc-379fc029-erdos749-erdos-749-00c9d45362-formalized-v1 aesop
theorem probe_4_297 : fcTypeOfName% "Erdos749.erdos_749" := by
  aesop
#print axioms probe_4_297

-- ATTACK fc-379fc029-erdos749-erdos-749-00c9d45362-formalized-v1 omega
theorem probe_4_298 : fcTypeOfName% "Erdos749.erdos_749" := by
  omega
#print axioms probe_4_298

-- ATTACK fc-379fc029-erdos749-erdos-749-00c9d45362-formalized-v1 norm_num
theorem probe_4_299 : fcTypeOfName% "Erdos749.erdos_749" := by
  norm_num
#print axioms probe_4_299

-- ATTACK fc-379fc029-erdos749-erdos-749-00c9d45362-formalized-v1 decide
theorem probe_4_300 : fcTypeOfName% "Erdos749.erdos_749" := by
  decide
#print axioms probe_4_300

-- ATTACK fc-379fc029-erdos749-erdos-749-00c9d45362-formalized-v1 native_decide
theorem probe_4_301 : fcTypeOfName% "Erdos749.erdos_749" := by
  native_decide
#print axioms probe_4_301

-- ATTACK fc-379fc029-erdos749-erdos-749-00c9d45362-formalized-v1 true_intro
theorem probe_4_302 : fcTypeOfName% "Erdos749.erdos_749" := by
  exact True.intro
#print axioms probe_4_302

-- ATTACK fc-379fc029-erdos749-erdos-749-00c9d45362-formalized-v1 false_elim_simp
theorem probe_4_303 : fcTypeOfName% "Erdos749.erdos_749" := by
  apply False.elim
  simp_all
#print axioms probe_4_303

-- ATTACK fc-379fc029-erdos749-erdos-749-00c9d45362-formalized-v1 constructor
theorem probe_4_304 : fcTypeOfName% "Erdos749.erdos_749" := by
  constructor
#print axioms probe_4_304

-- ATTACK fc-379fc029-erdos749-erdos-749-00c9d45362-formalized-v1 constructor_simp
theorem probe_4_305 : fcTypeOfName% "Erdos749.erdos_749" := by
  constructor <;> simp
#print axioms probe_4_305

-- ATTACK fc-379fc029-erdos749-erdos-749-00c9d45362-formalized-v1 constructor_aesop
theorem probe_4_306 : fcTypeOfName% "Erdos749.erdos_749" := by
  constructor <;> aesop
#print axioms probe_4_306

-- ATTACK fc-379fc029-erdos749-erdos-749-00c9d45362-formalized-v1 rfl
theorem probe_4_307 : fcTypeOfName% "Erdos749.erdos_749" := by
  rfl
#print axioms probe_4_307

-- ATTACK fc-379fc029-erdos749-erdos-749-00c9d45362-formalized-v1 trivial
theorem probe_4_308 : fcTypeOfName% "Erdos749.erdos_749" := by
  trivial
#print axioms probe_4_308

-- ATTACK fc-379fc029-erdos749-erdos-749-00c9d45362-formalized-v1 tauto
theorem probe_4_309 : fcTypeOfName% "Erdos749.erdos_749" := by
  tauto
#print axioms probe_4_309

-- ATTACK fc-379fc029-erdos749-erdos-749-00c9d45362-formalized-v1 positivity
theorem probe_4_310 : fcTypeOfName% "Erdos749.erdos_749" := by
  positivity
#print axioms probe_4_310

-- ATTACK fc-379fc029-erdos749-erdos-749-00c9d45362-formalized-v1 linarith
theorem probe_4_311 : fcTypeOfName% "Erdos749.erdos_749" := by
  linarith
#print axioms probe_4_311

-- ATTACK fc-379fc029-erdos749-erdos-749-00c9d45362-formalized-v1 nlinarith
theorem probe_4_312 : fcTypeOfName% "Erdos749.erdos_749" := by
  nlinarith
#print axioms probe_4_312

-- ATTACK fc-379fc029-erdos749-erdos-749-00c9d45362-formalized-v1 intros_simp_all
theorem probe_4_313 : fcTypeOfName% "Erdos749.erdos_749" := by
  intros
  simp_all
#print axioms probe_4_313

-- ATTACK fc-379fc029-erdos749-erdos-749-00c9d45362-formalized-v1 intros_omega
theorem probe_4_314 : fcTypeOfName% "Erdos749.erdos_749" := by
  intros
  omega
#print axioms probe_4_314

-- ATTACK fc-379fc029-erdos749-erdos-749-00c9d45362-formalized-v1 intros_norm_num
theorem probe_4_315 : fcTypeOfName% "Erdos749.erdos_749" := by
  intros
  norm_num at *
#print axioms probe_4_315

-- ATTACK fc-379fc029-erdos749-erdos-749-00c9d45362-formalized-v1 intros_aesop
theorem probe_4_316 : fcTypeOfName% "Erdos749.erdos_749" := by
  intros
  aesop
#print axioms probe_4_316

-- ATTACK fc-379fc029-erdos749-erdos-749-00c9d45362-formalized-v1 by_contra_simp_all
theorem probe_4_317 : fcTypeOfName% "Erdos749.erdos_749" := by
  by_contra h
  simp_all
#print axioms probe_4_317

-- ATTACK fc-379fc029-erdos749-erdos-749-00c9d45362-formalized-v1 classical_simp_all
theorem probe_4_318 : fcTypeOfName% "Erdos749.erdos_749" := by
  classical
  simp_all
#print axioms probe_4_318

-- ATTACK fc-379fc029-erdos749-erdos-749-00c9d45362-formalized-v1 classical_aesop
theorem probe_4_319 : fcTypeOfName% "Erdos749.erdos_749" := by
  classical
  aesop
#print axioms probe_4_319

-- ATTACK fc-379fc029-erdos749-erdos-749-00c9d45362-formalized-v1 refine_pair_simp
theorem probe_4_320 : fcTypeOfName% "Erdos749.erdos_749" := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_4_320

-- ATTACK fc-379fc029-erdos749-erdos-749-00c9d45362-formalized-v1 refine_pair_aesop
theorem probe_4_321 : fcTypeOfName% "Erdos749.erdos_749" := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_4_321

-- ATTACK fc-379fc029-erdos749-erdos-749-00c9d45362-formalized-v1 use_zero_simp
theorem probe_4_322 : fcTypeOfName% "Erdos749.erdos_749" := by
  use 0 <;> simp
#print axioms probe_4_322

-- ATTACK fc-379fc029-erdos749-erdos-749-00c9d45362-formalized-v1 use_one_simp
theorem probe_4_323 : fcTypeOfName% "Erdos749.erdos_749" := by
  use 1 <;> simp
#print axioms probe_4_323

-- ATTACK fc-379fc029-erdos749-erdos-749-00c9d45362-formalized-v1 use_empty_simp
theorem probe_4_324 : fcTypeOfName% "Erdos749.erdos_749" := by
  use ∅ <;> simp
#print axioms probe_4_324

-- ATTACK fc-379fc029-erdos749-erdos-749-00c9d45362-formalized-v1 assumption
theorem probe_4_325 : fcTypeOfName% "Erdos749.erdos_749" := by
  assumption
#print axioms probe_4_325

-- ATTACK fc-379fc029-erdos749-erdos-749-00c9d45362-formalized-v1 infer_instance
theorem probe_4_326 : fcTypeOfName% "Erdos749.erdos_749" := by
  infer_instance
#print axioms probe_4_326

-- ATTACK fc-379fc029-erdos749-erdos-749-00c9d45362-formalized-v1 contradiction
theorem probe_4_327 : fcTypeOfName% "Erdos749.erdos_749" := by
  contradiction
#print axioms probe_4_327

-- ATTACK fc-379fc029-erdos749-erdos-749-00c9d45362-formalized-v1 solve_by_elim
theorem probe_4_328 : fcTypeOfName% "Erdos749.erdos_749" := by
  solve_by_elim
#print axioms probe_4_328

-- ATTACK fc-379fc029-erdos749-erdos-749-00c9d45362-formalized-v1 first_order
theorem probe_4_329 : fcTypeOfName% "Erdos749.erdos_749" := by
  first_order
#print axioms probe_4_329

-- ATTACK fc-379fc029-erdos749-erdos-749-00c9d45362-formalized-v1 grind
theorem probe_4_330 : fcTypeOfName% "Erdos749.erdos_749" := by
  grind
#print axioms probe_4_330

-- ATTACK fc-379fc029-erdos749-erdos-749-00c9d45362-formalized-v1 exact_search
theorem probe_4_331 : fcTypeOfName% "Erdos749.erdos_749" := by
  exact?
#print axioms probe_4_331

-- ATTACK fc-379fc029-erdos749-erdos-749-00c9d45362-formalized-v1 apply_search
theorem probe_4_332 : fcTypeOfName% "Erdos749.erdos_749" := by
  apply?
#print axioms probe_4_332

-- ATTACK fc-379fc029-erdos749-erdos-749-00c9d45362-formalized-v1 library_search
theorem probe_4_333 : fcTypeOfName% "Erdos749.erdos_749" := by
  library_search
#print axioms probe_4_333

-- ATTACK fc-379fc029-erdos749-erdos-749-00c9d45362-formalized-v1 aesop_search
theorem probe_4_334 : fcTypeOfName% "Erdos749.erdos_749" := by
  aesop?
#print axioms probe_4_334

-- ATTACK fc-379fc029-erdos749-erdos-749-00c9d45362-formalized-v1 simp_search
theorem probe_4_335 : fcTypeOfName% "Erdos749.erdos_749" := by
  simp?
#print axioms probe_4_335

-- ATTACK fc-379fc029-erdos91-erdos-91-19ee923159-formalized-v1 simp
theorem probe_4_336 : fcTypeOfName% "Erdos91.erdos_91" := by
  simp
#print axioms probe_4_336

-- ATTACK fc-379fc029-erdos91-erdos-91-19ee923159-formalized-v1 simpa
theorem probe_4_337 : fcTypeOfName% "Erdos91.erdos_91" := by
  simpa
#print axioms probe_4_337

-- ATTACK fc-379fc029-erdos91-erdos-91-19ee923159-formalized-v1 simp_all
theorem probe_4_338 : fcTypeOfName% "Erdos91.erdos_91" := by
  simp_all
#print axioms probe_4_338

-- ATTACK fc-379fc029-erdos91-erdos-91-19ee923159-formalized-v1 aesop
theorem probe_4_339 : fcTypeOfName% "Erdos91.erdos_91" := by
  aesop
#print axioms probe_4_339

-- ATTACK fc-379fc029-erdos91-erdos-91-19ee923159-formalized-v1 omega
theorem probe_4_340 : fcTypeOfName% "Erdos91.erdos_91" := by
  omega
#print axioms probe_4_340

-- ATTACK fc-379fc029-erdos91-erdos-91-19ee923159-formalized-v1 norm_num
theorem probe_4_341 : fcTypeOfName% "Erdos91.erdos_91" := by
  norm_num
#print axioms probe_4_341

-- ATTACK fc-379fc029-erdos91-erdos-91-19ee923159-formalized-v1 decide
theorem probe_4_342 : fcTypeOfName% "Erdos91.erdos_91" := by
  decide
#print axioms probe_4_342

-- ATTACK fc-379fc029-erdos91-erdos-91-19ee923159-formalized-v1 native_decide
theorem probe_4_343 : fcTypeOfName% "Erdos91.erdos_91" := by
  native_decide
#print axioms probe_4_343

-- ATTACK fc-379fc029-erdos91-erdos-91-19ee923159-formalized-v1 true_intro
theorem probe_4_344 : fcTypeOfName% "Erdos91.erdos_91" := by
  exact True.intro
#print axioms probe_4_344

-- ATTACK fc-379fc029-erdos91-erdos-91-19ee923159-formalized-v1 false_elim_simp
theorem probe_4_345 : fcTypeOfName% "Erdos91.erdos_91" := by
  apply False.elim
  simp_all
#print axioms probe_4_345

-- ATTACK fc-379fc029-erdos91-erdos-91-19ee923159-formalized-v1 constructor
theorem probe_4_346 : fcTypeOfName% "Erdos91.erdos_91" := by
  constructor
#print axioms probe_4_346

-- ATTACK fc-379fc029-erdos91-erdos-91-19ee923159-formalized-v1 constructor_simp
theorem probe_4_347 : fcTypeOfName% "Erdos91.erdos_91" := by
  constructor <;> simp
#print axioms probe_4_347

-- ATTACK fc-379fc029-erdos91-erdos-91-19ee923159-formalized-v1 constructor_aesop
theorem probe_4_348 : fcTypeOfName% "Erdos91.erdos_91" := by
  constructor <;> aesop
#print axioms probe_4_348

-- ATTACK fc-379fc029-erdos91-erdos-91-19ee923159-formalized-v1 rfl
theorem probe_4_349 : fcTypeOfName% "Erdos91.erdos_91" := by
  rfl
#print axioms probe_4_349

-- ATTACK fc-379fc029-erdos91-erdos-91-19ee923159-formalized-v1 trivial
theorem probe_4_350 : fcTypeOfName% "Erdos91.erdos_91" := by
  trivial
#print axioms probe_4_350

-- ATTACK fc-379fc029-erdos91-erdos-91-19ee923159-formalized-v1 tauto
theorem probe_4_351 : fcTypeOfName% "Erdos91.erdos_91" := by
  tauto
#print axioms probe_4_351

-- ATTACK fc-379fc029-erdos91-erdos-91-19ee923159-formalized-v1 positivity
theorem probe_4_352 : fcTypeOfName% "Erdos91.erdos_91" := by
  positivity
#print axioms probe_4_352

-- ATTACK fc-379fc029-erdos91-erdos-91-19ee923159-formalized-v1 linarith
theorem probe_4_353 : fcTypeOfName% "Erdos91.erdos_91" := by
  linarith
#print axioms probe_4_353

-- ATTACK fc-379fc029-erdos91-erdos-91-19ee923159-formalized-v1 nlinarith
theorem probe_4_354 : fcTypeOfName% "Erdos91.erdos_91" := by
  nlinarith
#print axioms probe_4_354

-- ATTACK fc-379fc029-erdos91-erdos-91-19ee923159-formalized-v1 intros_simp_all
theorem probe_4_355 : fcTypeOfName% "Erdos91.erdos_91" := by
  intros
  simp_all
#print axioms probe_4_355

-- ATTACK fc-379fc029-erdos91-erdos-91-19ee923159-formalized-v1 intros_omega
theorem probe_4_356 : fcTypeOfName% "Erdos91.erdos_91" := by
  intros
  omega
#print axioms probe_4_356

-- ATTACK fc-379fc029-erdos91-erdos-91-19ee923159-formalized-v1 intros_norm_num
theorem probe_4_357 : fcTypeOfName% "Erdos91.erdos_91" := by
  intros
  norm_num at *
#print axioms probe_4_357

-- ATTACK fc-379fc029-erdos91-erdos-91-19ee923159-formalized-v1 intros_aesop
theorem probe_4_358 : fcTypeOfName% "Erdos91.erdos_91" := by
  intros
  aesop
#print axioms probe_4_358

-- ATTACK fc-379fc029-erdos91-erdos-91-19ee923159-formalized-v1 by_contra_simp_all
theorem probe_4_359 : fcTypeOfName% "Erdos91.erdos_91" := by
  by_contra h
  simp_all
#print axioms probe_4_359

-- ATTACK fc-379fc029-erdos91-erdos-91-19ee923159-formalized-v1 classical_simp_all
theorem probe_4_360 : fcTypeOfName% "Erdos91.erdos_91" := by
  classical
  simp_all
#print axioms probe_4_360

-- ATTACK fc-379fc029-erdos91-erdos-91-19ee923159-formalized-v1 classical_aesop
theorem probe_4_361 : fcTypeOfName% "Erdos91.erdos_91" := by
  classical
  aesop
#print axioms probe_4_361

-- ATTACK fc-379fc029-erdos91-erdos-91-19ee923159-formalized-v1 refine_pair_simp
theorem probe_4_362 : fcTypeOfName% "Erdos91.erdos_91" := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_4_362

-- ATTACK fc-379fc029-erdos91-erdos-91-19ee923159-formalized-v1 refine_pair_aesop
theorem probe_4_363 : fcTypeOfName% "Erdos91.erdos_91" := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_4_363

-- ATTACK fc-379fc029-erdos91-erdos-91-19ee923159-formalized-v1 use_zero_simp
theorem probe_4_364 : fcTypeOfName% "Erdos91.erdos_91" := by
  use 0 <;> simp
#print axioms probe_4_364

-- ATTACK fc-379fc029-erdos91-erdos-91-19ee923159-formalized-v1 use_one_simp
theorem probe_4_365 : fcTypeOfName% "Erdos91.erdos_91" := by
  use 1 <;> simp
#print axioms probe_4_365

-- ATTACK fc-379fc029-erdos91-erdos-91-19ee923159-formalized-v1 use_empty_simp
theorem probe_4_366 : fcTypeOfName% "Erdos91.erdos_91" := by
  use ∅ <;> simp
#print axioms probe_4_366

-- ATTACK fc-379fc029-erdos91-erdos-91-19ee923159-formalized-v1 assumption
theorem probe_4_367 : fcTypeOfName% "Erdos91.erdos_91" := by
  assumption
#print axioms probe_4_367

-- ATTACK fc-379fc029-erdos91-erdos-91-19ee923159-formalized-v1 infer_instance
theorem probe_4_368 : fcTypeOfName% "Erdos91.erdos_91" := by
  infer_instance
#print axioms probe_4_368

-- ATTACK fc-379fc029-erdos91-erdos-91-19ee923159-formalized-v1 contradiction
theorem probe_4_369 : fcTypeOfName% "Erdos91.erdos_91" := by
  contradiction
#print axioms probe_4_369

-- ATTACK fc-379fc029-erdos91-erdos-91-19ee923159-formalized-v1 solve_by_elim
theorem probe_4_370 : fcTypeOfName% "Erdos91.erdos_91" := by
  solve_by_elim
#print axioms probe_4_370

-- ATTACK fc-379fc029-erdos91-erdos-91-19ee923159-formalized-v1 first_order
theorem probe_4_371 : fcTypeOfName% "Erdos91.erdos_91" := by
  first_order
#print axioms probe_4_371

-- ATTACK fc-379fc029-erdos91-erdos-91-19ee923159-formalized-v1 grind
theorem probe_4_372 : fcTypeOfName% "Erdos91.erdos_91" := by
  grind
#print axioms probe_4_372

-- ATTACK fc-379fc029-erdos91-erdos-91-19ee923159-formalized-v1 exact_search
theorem probe_4_373 : fcTypeOfName% "Erdos91.erdos_91" := by
  exact?
#print axioms probe_4_373

-- ATTACK fc-379fc029-erdos91-erdos-91-19ee923159-formalized-v1 apply_search
theorem probe_4_374 : fcTypeOfName% "Erdos91.erdos_91" := by
  apply?
#print axioms probe_4_374

-- ATTACK fc-379fc029-erdos91-erdos-91-19ee923159-formalized-v1 library_search
theorem probe_4_375 : fcTypeOfName% "Erdos91.erdos_91" := by
  library_search
#print axioms probe_4_375

-- ATTACK fc-379fc029-erdos91-erdos-91-19ee923159-formalized-v1 aesop_search
theorem probe_4_376 : fcTypeOfName% "Erdos91.erdos_91" := by
  aesop?
#print axioms probe_4_376

-- ATTACK fc-379fc029-erdos91-erdos-91-19ee923159-formalized-v1 simp_search
theorem probe_4_377 : fcTypeOfName% "Erdos91.erdos_91" := by
  simp?
#print axioms probe_4_377

-- ATTACK fc-379fc029-variants-factorial-sub-one-d1c73fed57-formalized-v1 simp
theorem probe_4_378 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one" := by
  simp
#print axioms probe_4_378

-- ATTACK fc-379fc029-variants-factorial-sub-one-d1c73fed57-formalized-v1 simpa
theorem probe_4_379 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one" := by
  simpa
#print axioms probe_4_379

-- ATTACK fc-379fc029-variants-factorial-sub-one-d1c73fed57-formalized-v1 simp_all
theorem probe_4_380 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one" := by
  simp_all
#print axioms probe_4_380

-- ATTACK fc-379fc029-variants-factorial-sub-one-d1c73fed57-formalized-v1 aesop
theorem probe_4_381 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one" := by
  aesop
#print axioms probe_4_381

-- ATTACK fc-379fc029-variants-factorial-sub-one-d1c73fed57-formalized-v1 omega
theorem probe_4_382 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one" := by
  omega
#print axioms probe_4_382

-- ATTACK fc-379fc029-variants-factorial-sub-one-d1c73fed57-formalized-v1 norm_num
theorem probe_4_383 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one" := by
  norm_num
#print axioms probe_4_383

-- ATTACK fc-379fc029-variants-factorial-sub-one-d1c73fed57-formalized-v1 decide
theorem probe_4_384 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one" := by
  decide
#print axioms probe_4_384

-- ATTACK fc-379fc029-variants-factorial-sub-one-d1c73fed57-formalized-v1 native_decide
theorem probe_4_385 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one" := by
  native_decide
#print axioms probe_4_385

-- ATTACK fc-379fc029-variants-factorial-sub-one-d1c73fed57-formalized-v1 true_intro
theorem probe_4_386 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one" := by
  exact True.intro
#print axioms probe_4_386

-- ATTACK fc-379fc029-variants-factorial-sub-one-d1c73fed57-formalized-v1 false_elim_simp
theorem probe_4_387 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one" := by
  apply False.elim
  simp_all
#print axioms probe_4_387

-- ATTACK fc-379fc029-variants-factorial-sub-one-d1c73fed57-formalized-v1 constructor
theorem probe_4_388 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one" := by
  constructor
#print axioms probe_4_388

-- ATTACK fc-379fc029-variants-factorial-sub-one-d1c73fed57-formalized-v1 constructor_simp
theorem probe_4_389 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one" := by
  constructor <;> simp
#print axioms probe_4_389

-- ATTACK fc-379fc029-variants-factorial-sub-one-d1c73fed57-formalized-v1 constructor_aesop
theorem probe_4_390 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one" := by
  constructor <;> aesop
#print axioms probe_4_390

-- ATTACK fc-379fc029-variants-factorial-sub-one-d1c73fed57-formalized-v1 rfl
theorem probe_4_391 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one" := by
  rfl
#print axioms probe_4_391

-- ATTACK fc-379fc029-variants-factorial-sub-one-d1c73fed57-formalized-v1 trivial
theorem probe_4_392 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one" := by
  trivial
#print axioms probe_4_392

-- ATTACK fc-379fc029-variants-factorial-sub-one-d1c73fed57-formalized-v1 tauto
theorem probe_4_393 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one" := by
  tauto
#print axioms probe_4_393

-- ATTACK fc-379fc029-variants-factorial-sub-one-d1c73fed57-formalized-v1 positivity
theorem probe_4_394 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one" := by
  positivity
#print axioms probe_4_394

-- ATTACK fc-379fc029-variants-factorial-sub-one-d1c73fed57-formalized-v1 linarith
theorem probe_4_395 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one" := by
  linarith
#print axioms probe_4_395

-- ATTACK fc-379fc029-variants-factorial-sub-one-d1c73fed57-formalized-v1 nlinarith
theorem probe_4_396 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one" := by
  nlinarith
#print axioms probe_4_396

-- ATTACK fc-379fc029-variants-factorial-sub-one-d1c73fed57-formalized-v1 intros_simp_all
theorem probe_4_397 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one" := by
  intros
  simp_all
#print axioms probe_4_397

-- ATTACK fc-379fc029-variants-factorial-sub-one-d1c73fed57-formalized-v1 intros_omega
theorem probe_4_398 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one" := by
  intros
  omega
#print axioms probe_4_398

-- ATTACK fc-379fc029-variants-factorial-sub-one-d1c73fed57-formalized-v1 intros_norm_num
theorem probe_4_399 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one" := by
  intros
  norm_num at *
#print axioms probe_4_399

-- ATTACK fc-379fc029-variants-factorial-sub-one-d1c73fed57-formalized-v1 intros_aesop
theorem probe_4_400 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one" := by
  intros
  aesop
#print axioms probe_4_400

-- ATTACK fc-379fc029-variants-factorial-sub-one-d1c73fed57-formalized-v1 by_contra_simp_all
theorem probe_4_401 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one" := by
  by_contra h
  simp_all
#print axioms probe_4_401

-- ATTACK fc-379fc029-variants-factorial-sub-one-d1c73fed57-formalized-v1 classical_simp_all
theorem probe_4_402 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one" := by
  classical
  simp_all
#print axioms probe_4_402

-- ATTACK fc-379fc029-variants-factorial-sub-one-d1c73fed57-formalized-v1 classical_aesop
theorem probe_4_403 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one" := by
  classical
  aesop
#print axioms probe_4_403

-- ATTACK fc-379fc029-variants-factorial-sub-one-d1c73fed57-formalized-v1 refine_pair_simp
theorem probe_4_404 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one" := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_4_404

-- ATTACK fc-379fc029-variants-factorial-sub-one-d1c73fed57-formalized-v1 refine_pair_aesop
theorem probe_4_405 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one" := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_4_405

-- ATTACK fc-379fc029-variants-factorial-sub-one-d1c73fed57-formalized-v1 use_zero_simp
theorem probe_4_406 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one" := by
  use 0 <;> simp
#print axioms probe_4_406

-- ATTACK fc-379fc029-variants-factorial-sub-one-d1c73fed57-formalized-v1 use_one_simp
theorem probe_4_407 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one" := by
  use 1 <;> simp
#print axioms probe_4_407

-- ATTACK fc-379fc029-variants-factorial-sub-one-d1c73fed57-formalized-v1 use_empty_simp
theorem probe_4_408 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one" := by
  use ∅ <;> simp
#print axioms probe_4_408

-- ATTACK fc-379fc029-variants-factorial-sub-one-d1c73fed57-formalized-v1 assumption
theorem probe_4_409 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one" := by
  assumption
#print axioms probe_4_409

-- ATTACK fc-379fc029-variants-factorial-sub-one-d1c73fed57-formalized-v1 infer_instance
theorem probe_4_410 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one" := by
  infer_instance
#print axioms probe_4_410

-- ATTACK fc-379fc029-variants-factorial-sub-one-d1c73fed57-formalized-v1 contradiction
theorem probe_4_411 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one" := by
  contradiction
#print axioms probe_4_411

-- ATTACK fc-379fc029-variants-factorial-sub-one-d1c73fed57-formalized-v1 solve_by_elim
theorem probe_4_412 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one" := by
  solve_by_elim
#print axioms probe_4_412

-- ATTACK fc-379fc029-variants-factorial-sub-one-d1c73fed57-formalized-v1 first_order
theorem probe_4_413 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one" := by
  first_order
#print axioms probe_4_413

-- ATTACK fc-379fc029-variants-factorial-sub-one-d1c73fed57-formalized-v1 grind
theorem probe_4_414 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one" := by
  grind
#print axioms probe_4_414

-- ATTACK fc-379fc029-variants-factorial-sub-one-d1c73fed57-formalized-v1 exact_search
theorem probe_4_415 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one" := by
  exact?
#print axioms probe_4_415

-- ATTACK fc-379fc029-variants-factorial-sub-one-d1c73fed57-formalized-v1 apply_search
theorem probe_4_416 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one" := by
  apply?
#print axioms probe_4_416

-- ATTACK fc-379fc029-variants-factorial-sub-one-d1c73fed57-formalized-v1 library_search
theorem probe_4_417 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one" := by
  library_search
#print axioms probe_4_417

-- ATTACK fc-379fc029-variants-factorial-sub-one-d1c73fed57-formalized-v1 aesop_search
theorem probe_4_418 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one" := by
  aesop?
#print axioms probe_4_418

-- ATTACK fc-379fc029-variants-factorial-sub-one-d1c73fed57-formalized-v1 simp_search
theorem probe_4_419 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one" := by
  simp?
#print axioms probe_4_419

-- ATTACK fc-379fc029-erdos962-erdos-962-2ac8825e80-formalized-v1 simp
theorem probe_4_420 : fcTypeOfName% "Erdos962.erdos_962" := by
  simp
#print axioms probe_4_420

-- ATTACK fc-379fc029-erdos962-erdos-962-2ac8825e80-formalized-v1 simpa
theorem probe_4_421 : fcTypeOfName% "Erdos962.erdos_962" := by
  simpa
#print axioms probe_4_421

-- ATTACK fc-379fc029-erdos962-erdos-962-2ac8825e80-formalized-v1 simp_all
theorem probe_4_422 : fcTypeOfName% "Erdos962.erdos_962" := by
  simp_all
#print axioms probe_4_422

-- ATTACK fc-379fc029-erdos962-erdos-962-2ac8825e80-formalized-v1 aesop
theorem probe_4_423 : fcTypeOfName% "Erdos962.erdos_962" := by
  aesop
#print axioms probe_4_423

-- ATTACK fc-379fc029-erdos962-erdos-962-2ac8825e80-formalized-v1 omega
theorem probe_4_424 : fcTypeOfName% "Erdos962.erdos_962" := by
  omega
#print axioms probe_4_424

-- ATTACK fc-379fc029-erdos962-erdos-962-2ac8825e80-formalized-v1 norm_num
theorem probe_4_425 : fcTypeOfName% "Erdos962.erdos_962" := by
  norm_num
#print axioms probe_4_425

-- ATTACK fc-379fc029-erdos962-erdos-962-2ac8825e80-formalized-v1 decide
theorem probe_4_426 : fcTypeOfName% "Erdos962.erdos_962" := by
  decide
#print axioms probe_4_426

-- ATTACK fc-379fc029-erdos962-erdos-962-2ac8825e80-formalized-v1 native_decide
theorem probe_4_427 : fcTypeOfName% "Erdos962.erdos_962" := by
  native_decide
#print axioms probe_4_427

-- ATTACK fc-379fc029-erdos962-erdos-962-2ac8825e80-formalized-v1 true_intro
theorem probe_4_428 : fcTypeOfName% "Erdos962.erdos_962" := by
  exact True.intro
#print axioms probe_4_428

-- ATTACK fc-379fc029-erdos962-erdos-962-2ac8825e80-formalized-v1 false_elim_simp
theorem probe_4_429 : fcTypeOfName% "Erdos962.erdos_962" := by
  apply False.elim
  simp_all
#print axioms probe_4_429

-- ATTACK fc-379fc029-erdos962-erdos-962-2ac8825e80-formalized-v1 constructor
theorem probe_4_430 : fcTypeOfName% "Erdos962.erdos_962" := by
  constructor
#print axioms probe_4_430

-- ATTACK fc-379fc029-erdos962-erdos-962-2ac8825e80-formalized-v1 constructor_simp
theorem probe_4_431 : fcTypeOfName% "Erdos962.erdos_962" := by
  constructor <;> simp
#print axioms probe_4_431

-- ATTACK fc-379fc029-erdos962-erdos-962-2ac8825e80-formalized-v1 constructor_aesop
theorem probe_4_432 : fcTypeOfName% "Erdos962.erdos_962" := by
  constructor <;> aesop
#print axioms probe_4_432

-- ATTACK fc-379fc029-erdos962-erdos-962-2ac8825e80-formalized-v1 rfl
theorem probe_4_433 : fcTypeOfName% "Erdos962.erdos_962" := by
  rfl
#print axioms probe_4_433

-- ATTACK fc-379fc029-erdos962-erdos-962-2ac8825e80-formalized-v1 trivial
theorem probe_4_434 : fcTypeOfName% "Erdos962.erdos_962" := by
  trivial
#print axioms probe_4_434

-- ATTACK fc-379fc029-erdos962-erdos-962-2ac8825e80-formalized-v1 tauto
theorem probe_4_435 : fcTypeOfName% "Erdos962.erdos_962" := by
  tauto
#print axioms probe_4_435

-- ATTACK fc-379fc029-erdos962-erdos-962-2ac8825e80-formalized-v1 positivity
theorem probe_4_436 : fcTypeOfName% "Erdos962.erdos_962" := by
  positivity
#print axioms probe_4_436

-- ATTACK fc-379fc029-erdos962-erdos-962-2ac8825e80-formalized-v1 linarith
theorem probe_4_437 : fcTypeOfName% "Erdos962.erdos_962" := by
  linarith
#print axioms probe_4_437

-- ATTACK fc-379fc029-erdos962-erdos-962-2ac8825e80-formalized-v1 nlinarith
theorem probe_4_438 : fcTypeOfName% "Erdos962.erdos_962" := by
  nlinarith
#print axioms probe_4_438

-- ATTACK fc-379fc029-erdos962-erdos-962-2ac8825e80-formalized-v1 intros_simp_all
theorem probe_4_439 : fcTypeOfName% "Erdos962.erdos_962" := by
  intros
  simp_all
#print axioms probe_4_439

-- ATTACK fc-379fc029-erdos962-erdos-962-2ac8825e80-formalized-v1 intros_omega
theorem probe_4_440 : fcTypeOfName% "Erdos962.erdos_962" := by
  intros
  omega
#print axioms probe_4_440

-- ATTACK fc-379fc029-erdos962-erdos-962-2ac8825e80-formalized-v1 intros_norm_num
theorem probe_4_441 : fcTypeOfName% "Erdos962.erdos_962" := by
  intros
  norm_num at *
#print axioms probe_4_441

-- ATTACK fc-379fc029-erdos962-erdos-962-2ac8825e80-formalized-v1 intros_aesop
theorem probe_4_442 : fcTypeOfName% "Erdos962.erdos_962" := by
  intros
  aesop
#print axioms probe_4_442

-- ATTACK fc-379fc029-erdos962-erdos-962-2ac8825e80-formalized-v1 by_contra_simp_all
theorem probe_4_443 : fcTypeOfName% "Erdos962.erdos_962" := by
  by_contra h
  simp_all
#print axioms probe_4_443

-- ATTACK fc-379fc029-erdos962-erdos-962-2ac8825e80-formalized-v1 classical_simp_all
theorem probe_4_444 : fcTypeOfName% "Erdos962.erdos_962" := by
  classical
  simp_all
#print axioms probe_4_444

-- ATTACK fc-379fc029-erdos962-erdos-962-2ac8825e80-formalized-v1 classical_aesop
theorem probe_4_445 : fcTypeOfName% "Erdos962.erdos_962" := by
  classical
  aesop
#print axioms probe_4_445

-- ATTACK fc-379fc029-erdos962-erdos-962-2ac8825e80-formalized-v1 refine_pair_simp
theorem probe_4_446 : fcTypeOfName% "Erdos962.erdos_962" := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_4_446

-- ATTACK fc-379fc029-erdos962-erdos-962-2ac8825e80-formalized-v1 refine_pair_aesop
theorem probe_4_447 : fcTypeOfName% "Erdos962.erdos_962" := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_4_447

-- ATTACK fc-379fc029-erdos962-erdos-962-2ac8825e80-formalized-v1 use_zero_simp
theorem probe_4_448 : fcTypeOfName% "Erdos962.erdos_962" := by
  use 0 <;> simp
#print axioms probe_4_448

-- ATTACK fc-379fc029-erdos962-erdos-962-2ac8825e80-formalized-v1 use_one_simp
theorem probe_4_449 : fcTypeOfName% "Erdos962.erdos_962" := by
  use 1 <;> simp
#print axioms probe_4_449

-- ATTACK fc-379fc029-erdos962-erdos-962-2ac8825e80-formalized-v1 use_empty_simp
theorem probe_4_450 : fcTypeOfName% "Erdos962.erdos_962" := by
  use ∅ <;> simp
#print axioms probe_4_450

-- ATTACK fc-379fc029-erdos962-erdos-962-2ac8825e80-formalized-v1 assumption
theorem probe_4_451 : fcTypeOfName% "Erdos962.erdos_962" := by
  assumption
#print axioms probe_4_451

-- ATTACK fc-379fc029-erdos962-erdos-962-2ac8825e80-formalized-v1 infer_instance
theorem probe_4_452 : fcTypeOfName% "Erdos962.erdos_962" := by
  infer_instance
#print axioms probe_4_452

-- ATTACK fc-379fc029-erdos962-erdos-962-2ac8825e80-formalized-v1 contradiction
theorem probe_4_453 : fcTypeOfName% "Erdos962.erdos_962" := by
  contradiction
#print axioms probe_4_453

-- ATTACK fc-379fc029-erdos962-erdos-962-2ac8825e80-formalized-v1 solve_by_elim
theorem probe_4_454 : fcTypeOfName% "Erdos962.erdos_962" := by
  solve_by_elim
#print axioms probe_4_454

-- ATTACK fc-379fc029-erdos962-erdos-962-2ac8825e80-formalized-v1 first_order
theorem probe_4_455 : fcTypeOfName% "Erdos962.erdos_962" := by
  first_order
#print axioms probe_4_455

-- ATTACK fc-379fc029-erdos962-erdos-962-2ac8825e80-formalized-v1 grind
theorem probe_4_456 : fcTypeOfName% "Erdos962.erdos_962" := by
  grind
#print axioms probe_4_456

-- ATTACK fc-379fc029-erdos962-erdos-962-2ac8825e80-formalized-v1 exact_search
theorem probe_4_457 : fcTypeOfName% "Erdos962.erdos_962" := by
  exact?
#print axioms probe_4_457

-- ATTACK fc-379fc029-erdos962-erdos-962-2ac8825e80-formalized-v1 apply_search
theorem probe_4_458 : fcTypeOfName% "Erdos962.erdos_962" := by
  apply?
#print axioms probe_4_458

-- ATTACK fc-379fc029-erdos962-erdos-962-2ac8825e80-formalized-v1 library_search
theorem probe_4_459 : fcTypeOfName% "Erdos962.erdos_962" := by
  library_search
#print axioms probe_4_459

-- ATTACK fc-379fc029-erdos962-erdos-962-2ac8825e80-formalized-v1 aesop_search
theorem probe_4_460 : fcTypeOfName% "Erdos962.erdos_962" := by
  aesop?
#print axioms probe_4_460

-- ATTACK fc-379fc029-erdos962-erdos-962-2ac8825e80-formalized-v1 simp_search
theorem probe_4_461 : fcTypeOfName% "Erdos962.erdos_962" := by
  simp?
#print axioms probe_4_461

-- ATTACK fc-379fc029-green39-green-39-e47c05a716-formalized-v1 simp
theorem probe_4_462 : fcTypeOfName% "Green39.green_39" := by
  simp
#print axioms probe_4_462

-- ATTACK fc-379fc029-green39-green-39-e47c05a716-formalized-v1 simpa
theorem probe_4_463 : fcTypeOfName% "Green39.green_39" := by
  simpa
#print axioms probe_4_463

-- ATTACK fc-379fc029-green39-green-39-e47c05a716-formalized-v1 simp_all
theorem probe_4_464 : fcTypeOfName% "Green39.green_39" := by
  simp_all
#print axioms probe_4_464

-- ATTACK fc-379fc029-green39-green-39-e47c05a716-formalized-v1 aesop
theorem probe_4_465 : fcTypeOfName% "Green39.green_39" := by
  aesop
#print axioms probe_4_465

-- ATTACK fc-379fc029-green39-green-39-e47c05a716-formalized-v1 omega
theorem probe_4_466 : fcTypeOfName% "Green39.green_39" := by
  omega
#print axioms probe_4_466

-- ATTACK fc-379fc029-green39-green-39-e47c05a716-formalized-v1 norm_num
theorem probe_4_467 : fcTypeOfName% "Green39.green_39" := by
  norm_num
#print axioms probe_4_467

-- ATTACK fc-379fc029-green39-green-39-e47c05a716-formalized-v1 decide
theorem probe_4_468 : fcTypeOfName% "Green39.green_39" := by
  decide
#print axioms probe_4_468

-- ATTACK fc-379fc029-green39-green-39-e47c05a716-formalized-v1 native_decide
theorem probe_4_469 : fcTypeOfName% "Green39.green_39" := by
  native_decide
#print axioms probe_4_469

-- ATTACK fc-379fc029-green39-green-39-e47c05a716-formalized-v1 true_intro
theorem probe_4_470 : fcTypeOfName% "Green39.green_39" := by
  exact True.intro
#print axioms probe_4_470

-- ATTACK fc-379fc029-green39-green-39-e47c05a716-formalized-v1 false_elim_simp
theorem probe_4_471 : fcTypeOfName% "Green39.green_39" := by
  apply False.elim
  simp_all
#print axioms probe_4_471

-- ATTACK fc-379fc029-green39-green-39-e47c05a716-formalized-v1 constructor
theorem probe_4_472 : fcTypeOfName% "Green39.green_39" := by
  constructor
#print axioms probe_4_472

-- ATTACK fc-379fc029-green39-green-39-e47c05a716-formalized-v1 constructor_simp
theorem probe_4_473 : fcTypeOfName% "Green39.green_39" := by
  constructor <;> simp
#print axioms probe_4_473

-- ATTACK fc-379fc029-green39-green-39-e47c05a716-formalized-v1 constructor_aesop
theorem probe_4_474 : fcTypeOfName% "Green39.green_39" := by
  constructor <;> aesop
#print axioms probe_4_474

-- ATTACK fc-379fc029-green39-green-39-e47c05a716-formalized-v1 rfl
theorem probe_4_475 : fcTypeOfName% "Green39.green_39" := by
  rfl
#print axioms probe_4_475

-- ATTACK fc-379fc029-green39-green-39-e47c05a716-formalized-v1 trivial
theorem probe_4_476 : fcTypeOfName% "Green39.green_39" := by
  trivial
#print axioms probe_4_476

-- ATTACK fc-379fc029-green39-green-39-e47c05a716-formalized-v1 tauto
theorem probe_4_477 : fcTypeOfName% "Green39.green_39" := by
  tauto
#print axioms probe_4_477

-- ATTACK fc-379fc029-green39-green-39-e47c05a716-formalized-v1 positivity
theorem probe_4_478 : fcTypeOfName% "Green39.green_39" := by
  positivity
#print axioms probe_4_478

-- ATTACK fc-379fc029-green39-green-39-e47c05a716-formalized-v1 linarith
theorem probe_4_479 : fcTypeOfName% "Green39.green_39" := by
  linarith
#print axioms probe_4_479

-- ATTACK fc-379fc029-green39-green-39-e47c05a716-formalized-v1 nlinarith
theorem probe_4_480 : fcTypeOfName% "Green39.green_39" := by
  nlinarith
#print axioms probe_4_480

-- ATTACK fc-379fc029-green39-green-39-e47c05a716-formalized-v1 intros_simp_all
theorem probe_4_481 : fcTypeOfName% "Green39.green_39" := by
  intros
  simp_all
#print axioms probe_4_481

-- ATTACK fc-379fc029-green39-green-39-e47c05a716-formalized-v1 intros_omega
theorem probe_4_482 : fcTypeOfName% "Green39.green_39" := by
  intros
  omega
#print axioms probe_4_482

-- ATTACK fc-379fc029-green39-green-39-e47c05a716-formalized-v1 intros_norm_num
theorem probe_4_483 : fcTypeOfName% "Green39.green_39" := by
  intros
  norm_num at *
#print axioms probe_4_483

-- ATTACK fc-379fc029-green39-green-39-e47c05a716-formalized-v1 intros_aesop
theorem probe_4_484 : fcTypeOfName% "Green39.green_39" := by
  intros
  aesop
#print axioms probe_4_484

-- ATTACK fc-379fc029-green39-green-39-e47c05a716-formalized-v1 by_contra_simp_all
theorem probe_4_485 : fcTypeOfName% "Green39.green_39" := by
  by_contra h
  simp_all
#print axioms probe_4_485

-- ATTACK fc-379fc029-green39-green-39-e47c05a716-formalized-v1 classical_simp_all
theorem probe_4_486 : fcTypeOfName% "Green39.green_39" := by
  classical
  simp_all
#print axioms probe_4_486

-- ATTACK fc-379fc029-green39-green-39-e47c05a716-formalized-v1 classical_aesop
theorem probe_4_487 : fcTypeOfName% "Green39.green_39" := by
  classical
  aesop
#print axioms probe_4_487

-- ATTACK fc-379fc029-green39-green-39-e47c05a716-formalized-v1 refine_pair_simp
theorem probe_4_488 : fcTypeOfName% "Green39.green_39" := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_4_488

-- ATTACK fc-379fc029-green39-green-39-e47c05a716-formalized-v1 refine_pair_aesop
theorem probe_4_489 : fcTypeOfName% "Green39.green_39" := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_4_489

-- ATTACK fc-379fc029-green39-green-39-e47c05a716-formalized-v1 use_zero_simp
theorem probe_4_490 : fcTypeOfName% "Green39.green_39" := by
  use 0 <;> simp
#print axioms probe_4_490

-- ATTACK fc-379fc029-green39-green-39-e47c05a716-formalized-v1 use_one_simp
theorem probe_4_491 : fcTypeOfName% "Green39.green_39" := by
  use 1 <;> simp
#print axioms probe_4_491

-- ATTACK fc-379fc029-green39-green-39-e47c05a716-formalized-v1 use_empty_simp
theorem probe_4_492 : fcTypeOfName% "Green39.green_39" := by
  use ∅ <;> simp
#print axioms probe_4_492

-- ATTACK fc-379fc029-green39-green-39-e47c05a716-formalized-v1 assumption
theorem probe_4_493 : fcTypeOfName% "Green39.green_39" := by
  assumption
#print axioms probe_4_493

-- ATTACK fc-379fc029-green39-green-39-e47c05a716-formalized-v1 infer_instance
theorem probe_4_494 : fcTypeOfName% "Green39.green_39" := by
  infer_instance
#print axioms probe_4_494

-- ATTACK fc-379fc029-green39-green-39-e47c05a716-formalized-v1 contradiction
theorem probe_4_495 : fcTypeOfName% "Green39.green_39" := by
  contradiction
#print axioms probe_4_495

-- ATTACK fc-379fc029-green39-green-39-e47c05a716-formalized-v1 solve_by_elim
theorem probe_4_496 : fcTypeOfName% "Green39.green_39" := by
  solve_by_elim
#print axioms probe_4_496

-- ATTACK fc-379fc029-green39-green-39-e47c05a716-formalized-v1 first_order
theorem probe_4_497 : fcTypeOfName% "Green39.green_39" := by
  first_order
#print axioms probe_4_497

-- ATTACK fc-379fc029-green39-green-39-e47c05a716-formalized-v1 grind
theorem probe_4_498 : fcTypeOfName% "Green39.green_39" := by
  grind
#print axioms probe_4_498

-- ATTACK fc-379fc029-green39-green-39-e47c05a716-formalized-v1 exact_search
theorem probe_4_499 : fcTypeOfName% "Green39.green_39" := by
  exact?
#print axioms probe_4_499

-- ATTACK fc-379fc029-green39-green-39-e47c05a716-formalized-v1 apply_search
theorem probe_4_500 : fcTypeOfName% "Green39.green_39" := by
  apply?
#print axioms probe_4_500

-- ATTACK fc-379fc029-green39-green-39-e47c05a716-formalized-v1 library_search
theorem probe_4_501 : fcTypeOfName% "Green39.green_39" := by
  library_search
#print axioms probe_4_501

-- ATTACK fc-379fc029-green39-green-39-e47c05a716-formalized-v1 aesop_search
theorem probe_4_502 : fcTypeOfName% "Green39.green_39" := by
  aesop?
#print axioms probe_4_502

-- ATTACK fc-379fc029-green39-green-39-e47c05a716-formalized-v1 simp_search
theorem probe_4_503 : fcTypeOfName% "Green39.green_39" := by
  simp?
#print axioms probe_4_503

-- ATTACK fc-379fc029-green94-green-94-61d97ece0d-formalized-v1 simp
theorem probe_4_504 : fcTypeOfName% "Green94.green_94" := by
  simp
#print axioms probe_4_504

-- ATTACK fc-379fc029-green94-green-94-61d97ece0d-formalized-v1 simpa
theorem probe_4_505 : fcTypeOfName% "Green94.green_94" := by
  simpa
#print axioms probe_4_505

-- ATTACK fc-379fc029-green94-green-94-61d97ece0d-formalized-v1 simp_all
theorem probe_4_506 : fcTypeOfName% "Green94.green_94" := by
  simp_all
#print axioms probe_4_506

-- ATTACK fc-379fc029-green94-green-94-61d97ece0d-formalized-v1 aesop
theorem probe_4_507 : fcTypeOfName% "Green94.green_94" := by
  aesop
#print axioms probe_4_507

-- ATTACK fc-379fc029-green94-green-94-61d97ece0d-formalized-v1 omega
theorem probe_4_508 : fcTypeOfName% "Green94.green_94" := by
  omega
#print axioms probe_4_508

-- ATTACK fc-379fc029-green94-green-94-61d97ece0d-formalized-v1 norm_num
theorem probe_4_509 : fcTypeOfName% "Green94.green_94" := by
  norm_num
#print axioms probe_4_509

-- ATTACK fc-379fc029-green94-green-94-61d97ece0d-formalized-v1 decide
theorem probe_4_510 : fcTypeOfName% "Green94.green_94" := by
  decide
#print axioms probe_4_510

-- ATTACK fc-379fc029-green94-green-94-61d97ece0d-formalized-v1 native_decide
theorem probe_4_511 : fcTypeOfName% "Green94.green_94" := by
  native_decide
#print axioms probe_4_511

-- ATTACK fc-379fc029-green94-green-94-61d97ece0d-formalized-v1 true_intro
theorem probe_4_512 : fcTypeOfName% "Green94.green_94" := by
  exact True.intro
#print axioms probe_4_512

-- ATTACK fc-379fc029-green94-green-94-61d97ece0d-formalized-v1 false_elim_simp
theorem probe_4_513 : fcTypeOfName% "Green94.green_94" := by
  apply False.elim
  simp_all
#print axioms probe_4_513

-- ATTACK fc-379fc029-green94-green-94-61d97ece0d-formalized-v1 constructor
theorem probe_4_514 : fcTypeOfName% "Green94.green_94" := by
  constructor
#print axioms probe_4_514

-- ATTACK fc-379fc029-green94-green-94-61d97ece0d-formalized-v1 constructor_simp
theorem probe_4_515 : fcTypeOfName% "Green94.green_94" := by
  constructor <;> simp
#print axioms probe_4_515

-- ATTACK fc-379fc029-green94-green-94-61d97ece0d-formalized-v1 constructor_aesop
theorem probe_4_516 : fcTypeOfName% "Green94.green_94" := by
  constructor <;> aesop
#print axioms probe_4_516

-- ATTACK fc-379fc029-green94-green-94-61d97ece0d-formalized-v1 rfl
theorem probe_4_517 : fcTypeOfName% "Green94.green_94" := by
  rfl
#print axioms probe_4_517

-- ATTACK fc-379fc029-green94-green-94-61d97ece0d-formalized-v1 trivial
theorem probe_4_518 : fcTypeOfName% "Green94.green_94" := by
  trivial
#print axioms probe_4_518

-- ATTACK fc-379fc029-green94-green-94-61d97ece0d-formalized-v1 tauto
theorem probe_4_519 : fcTypeOfName% "Green94.green_94" := by
  tauto
#print axioms probe_4_519

-- ATTACK fc-379fc029-green94-green-94-61d97ece0d-formalized-v1 positivity
theorem probe_4_520 : fcTypeOfName% "Green94.green_94" := by
  positivity
#print axioms probe_4_520

-- ATTACK fc-379fc029-green94-green-94-61d97ece0d-formalized-v1 linarith
theorem probe_4_521 : fcTypeOfName% "Green94.green_94" := by
  linarith
#print axioms probe_4_521

-- ATTACK fc-379fc029-green94-green-94-61d97ece0d-formalized-v1 nlinarith
theorem probe_4_522 : fcTypeOfName% "Green94.green_94" := by
  nlinarith
#print axioms probe_4_522

-- ATTACK fc-379fc029-green94-green-94-61d97ece0d-formalized-v1 intros_simp_all
theorem probe_4_523 : fcTypeOfName% "Green94.green_94" := by
  intros
  simp_all
#print axioms probe_4_523

-- ATTACK fc-379fc029-green94-green-94-61d97ece0d-formalized-v1 intros_omega
theorem probe_4_524 : fcTypeOfName% "Green94.green_94" := by
  intros
  omega
#print axioms probe_4_524

-- ATTACK fc-379fc029-green94-green-94-61d97ece0d-formalized-v1 intros_norm_num
theorem probe_4_525 : fcTypeOfName% "Green94.green_94" := by
  intros
  norm_num at *
#print axioms probe_4_525

-- ATTACK fc-379fc029-green94-green-94-61d97ece0d-formalized-v1 intros_aesop
theorem probe_4_526 : fcTypeOfName% "Green94.green_94" := by
  intros
  aesop
#print axioms probe_4_526

-- ATTACK fc-379fc029-green94-green-94-61d97ece0d-formalized-v1 by_contra_simp_all
theorem probe_4_527 : fcTypeOfName% "Green94.green_94" := by
  by_contra h
  simp_all
#print axioms probe_4_527

-- ATTACK fc-379fc029-green94-green-94-61d97ece0d-formalized-v1 classical_simp_all
theorem probe_4_528 : fcTypeOfName% "Green94.green_94" := by
  classical
  simp_all
#print axioms probe_4_528

-- ATTACK fc-379fc029-green94-green-94-61d97ece0d-formalized-v1 classical_aesop
theorem probe_4_529 : fcTypeOfName% "Green94.green_94" := by
  classical
  aesop
#print axioms probe_4_529

-- ATTACK fc-379fc029-green94-green-94-61d97ece0d-formalized-v1 refine_pair_simp
theorem probe_4_530 : fcTypeOfName% "Green94.green_94" := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_4_530

-- ATTACK fc-379fc029-green94-green-94-61d97ece0d-formalized-v1 refine_pair_aesop
theorem probe_4_531 : fcTypeOfName% "Green94.green_94" := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_4_531

-- ATTACK fc-379fc029-green94-green-94-61d97ece0d-formalized-v1 use_zero_simp
theorem probe_4_532 : fcTypeOfName% "Green94.green_94" := by
  use 0 <;> simp
#print axioms probe_4_532

-- ATTACK fc-379fc029-green94-green-94-61d97ece0d-formalized-v1 use_one_simp
theorem probe_4_533 : fcTypeOfName% "Green94.green_94" := by
  use 1 <;> simp
#print axioms probe_4_533

-- ATTACK fc-379fc029-green94-green-94-61d97ece0d-formalized-v1 use_empty_simp
theorem probe_4_534 : fcTypeOfName% "Green94.green_94" := by
  use ∅ <;> simp
#print axioms probe_4_534

-- ATTACK fc-379fc029-green94-green-94-61d97ece0d-formalized-v1 assumption
theorem probe_4_535 : fcTypeOfName% "Green94.green_94" := by
  assumption
#print axioms probe_4_535

-- ATTACK fc-379fc029-green94-green-94-61d97ece0d-formalized-v1 infer_instance
theorem probe_4_536 : fcTypeOfName% "Green94.green_94" := by
  infer_instance
#print axioms probe_4_536

-- ATTACK fc-379fc029-green94-green-94-61d97ece0d-formalized-v1 contradiction
theorem probe_4_537 : fcTypeOfName% "Green94.green_94" := by
  contradiction
#print axioms probe_4_537

-- ATTACK fc-379fc029-green94-green-94-61d97ece0d-formalized-v1 solve_by_elim
theorem probe_4_538 : fcTypeOfName% "Green94.green_94" := by
  solve_by_elim
#print axioms probe_4_538

-- ATTACK fc-379fc029-green94-green-94-61d97ece0d-formalized-v1 first_order
theorem probe_4_539 : fcTypeOfName% "Green94.green_94" := by
  first_order
#print axioms probe_4_539

-- ATTACK fc-379fc029-green94-green-94-61d97ece0d-formalized-v1 grind
theorem probe_4_540 : fcTypeOfName% "Green94.green_94" := by
  grind
#print axioms probe_4_540

-- ATTACK fc-379fc029-green94-green-94-61d97ece0d-formalized-v1 exact_search
theorem probe_4_541 : fcTypeOfName% "Green94.green_94" := by
  exact?
#print axioms probe_4_541

-- ATTACK fc-379fc029-green94-green-94-61d97ece0d-formalized-v1 apply_search
theorem probe_4_542 : fcTypeOfName% "Green94.green_94" := by
  apply?
#print axioms probe_4_542

-- ATTACK fc-379fc029-green94-green-94-61d97ece0d-formalized-v1 library_search
theorem probe_4_543 : fcTypeOfName% "Green94.green_94" := by
  library_search
#print axioms probe_4_543

-- ATTACK fc-379fc029-green94-green-94-61d97ece0d-formalized-v1 aesop_search
theorem probe_4_544 : fcTypeOfName% "Green94.green_94" := by
  aesop?
#print axioms probe_4_544

-- ATTACK fc-379fc029-green94-green-94-61d97ece0d-formalized-v1 simp_search
theorem probe_4_545 : fcTypeOfName% "Green94.green_94" := by
  simp?
#print axioms probe_4_545

end AttackBattery
