import FormalConjectures.ErdosProblems.«1101»
import FormalConjectures.ErdosProblems.«138»
import FormalConjectures.ErdosProblems.«25»
import FormalConjectures.ErdosProblems.«304»
import FormalConjectures.ErdosProblems.«323»
import FormalConjectures.ErdosProblems.«495»
import FormalConjectures.ErdosProblems.«681»
import FormalConjectures.ErdosProblems.«886»
import FormalConjectures.ErdosProblems.«933»
import FormalConjectures.ErdosProblems.«949»
import FormalConjectures.ErdosProblems.«98»
import FormalConjectures.GreensOpenProblems.«47»
import TaskSupport

set_option maxHeartbeats 20000
namespace AttackBattery

-- ATTACK fc-379fc029-parts-i-38118392ca-formalized-v1 simp
theorem probe_8_0 : fcTypeOfName% "Erdos1101.erdos_1101.parts.i" := by
  simp
#print axioms probe_8_0

-- ATTACK fc-379fc029-parts-i-38118392ca-formalized-v1 simpa
theorem probe_8_1 : fcTypeOfName% "Erdos1101.erdos_1101.parts.i" := by
  simpa
#print axioms probe_8_1

-- ATTACK fc-379fc029-parts-i-38118392ca-formalized-v1 simp_all
theorem probe_8_2 : fcTypeOfName% "Erdos1101.erdos_1101.parts.i" := by
  simp_all
#print axioms probe_8_2

-- ATTACK fc-379fc029-parts-i-38118392ca-formalized-v1 aesop
theorem probe_8_3 : fcTypeOfName% "Erdos1101.erdos_1101.parts.i" := by
  aesop
#print axioms probe_8_3

-- ATTACK fc-379fc029-parts-i-38118392ca-formalized-v1 omega
theorem probe_8_4 : fcTypeOfName% "Erdos1101.erdos_1101.parts.i" := by
  omega
#print axioms probe_8_4

-- ATTACK fc-379fc029-parts-i-38118392ca-formalized-v1 norm_num
theorem probe_8_5 : fcTypeOfName% "Erdos1101.erdos_1101.parts.i" := by
  norm_num
#print axioms probe_8_5

-- ATTACK fc-379fc029-parts-i-38118392ca-formalized-v1 decide
theorem probe_8_6 : fcTypeOfName% "Erdos1101.erdos_1101.parts.i" := by
  decide
#print axioms probe_8_6

-- ATTACK fc-379fc029-parts-i-38118392ca-formalized-v1 native_decide
theorem probe_8_7 : fcTypeOfName% "Erdos1101.erdos_1101.parts.i" := by
  native_decide
#print axioms probe_8_7

-- ATTACK fc-379fc029-parts-i-38118392ca-formalized-v1 true_intro
theorem probe_8_8 : fcTypeOfName% "Erdos1101.erdos_1101.parts.i" := by
  exact True.intro
#print axioms probe_8_8

-- ATTACK fc-379fc029-parts-i-38118392ca-formalized-v1 false_elim_simp
theorem probe_8_9 : fcTypeOfName% "Erdos1101.erdos_1101.parts.i" := by
  apply False.elim
  simp_all
#print axioms probe_8_9

-- ATTACK fc-379fc029-parts-i-38118392ca-formalized-v1 constructor
theorem probe_8_10 : fcTypeOfName% "Erdos1101.erdos_1101.parts.i" := by
  constructor
#print axioms probe_8_10

-- ATTACK fc-379fc029-parts-i-38118392ca-formalized-v1 constructor_simp
theorem probe_8_11 : fcTypeOfName% "Erdos1101.erdos_1101.parts.i" := by
  constructor <;> simp
#print axioms probe_8_11

-- ATTACK fc-379fc029-parts-i-38118392ca-formalized-v1 constructor_aesop
theorem probe_8_12 : fcTypeOfName% "Erdos1101.erdos_1101.parts.i" := by
  constructor <;> aesop
#print axioms probe_8_12

-- ATTACK fc-379fc029-parts-i-38118392ca-formalized-v1 rfl
theorem probe_8_13 : fcTypeOfName% "Erdos1101.erdos_1101.parts.i" := by
  rfl
#print axioms probe_8_13

-- ATTACK fc-379fc029-parts-i-38118392ca-formalized-v1 trivial
theorem probe_8_14 : fcTypeOfName% "Erdos1101.erdos_1101.parts.i" := by
  trivial
#print axioms probe_8_14

-- ATTACK fc-379fc029-parts-i-38118392ca-formalized-v1 tauto
theorem probe_8_15 : fcTypeOfName% "Erdos1101.erdos_1101.parts.i" := by
  tauto
#print axioms probe_8_15

-- ATTACK fc-379fc029-parts-i-38118392ca-formalized-v1 positivity
theorem probe_8_16 : fcTypeOfName% "Erdos1101.erdos_1101.parts.i" := by
  positivity
#print axioms probe_8_16

-- ATTACK fc-379fc029-parts-i-38118392ca-formalized-v1 linarith
theorem probe_8_17 : fcTypeOfName% "Erdos1101.erdos_1101.parts.i" := by
  linarith
#print axioms probe_8_17

-- ATTACK fc-379fc029-parts-i-38118392ca-formalized-v1 nlinarith
theorem probe_8_18 : fcTypeOfName% "Erdos1101.erdos_1101.parts.i" := by
  nlinarith
#print axioms probe_8_18

-- ATTACK fc-379fc029-parts-i-38118392ca-formalized-v1 intros_simp_all
theorem probe_8_19 : fcTypeOfName% "Erdos1101.erdos_1101.parts.i" := by
  intros
  simp_all
#print axioms probe_8_19

-- ATTACK fc-379fc029-parts-i-38118392ca-formalized-v1 intros_omega
theorem probe_8_20 : fcTypeOfName% "Erdos1101.erdos_1101.parts.i" := by
  intros
  omega
#print axioms probe_8_20

-- ATTACK fc-379fc029-parts-i-38118392ca-formalized-v1 intros_norm_num
theorem probe_8_21 : fcTypeOfName% "Erdos1101.erdos_1101.parts.i" := by
  intros
  norm_num at *
#print axioms probe_8_21

-- ATTACK fc-379fc029-parts-i-38118392ca-formalized-v1 intros_aesop
theorem probe_8_22 : fcTypeOfName% "Erdos1101.erdos_1101.parts.i" := by
  intros
  aesop
#print axioms probe_8_22

-- ATTACK fc-379fc029-parts-i-38118392ca-formalized-v1 by_contra_simp_all
theorem probe_8_23 : fcTypeOfName% "Erdos1101.erdos_1101.parts.i" := by
  by_contra h
  simp_all
#print axioms probe_8_23

-- ATTACK fc-379fc029-parts-i-38118392ca-formalized-v1 classical_simp_all
theorem probe_8_24 : fcTypeOfName% "Erdos1101.erdos_1101.parts.i" := by
  classical
  simp_all
#print axioms probe_8_24

-- ATTACK fc-379fc029-parts-i-38118392ca-formalized-v1 classical_aesop
theorem probe_8_25 : fcTypeOfName% "Erdos1101.erdos_1101.parts.i" := by
  classical
  aesop
#print axioms probe_8_25

-- ATTACK fc-379fc029-parts-i-38118392ca-formalized-v1 refine_pair_simp
theorem probe_8_26 : fcTypeOfName% "Erdos1101.erdos_1101.parts.i" := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_8_26

-- ATTACK fc-379fc029-parts-i-38118392ca-formalized-v1 refine_pair_aesop
theorem probe_8_27 : fcTypeOfName% "Erdos1101.erdos_1101.parts.i" := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_8_27

-- ATTACK fc-379fc029-parts-i-38118392ca-formalized-v1 use_zero_simp
theorem probe_8_28 : fcTypeOfName% "Erdos1101.erdos_1101.parts.i" := by
  use 0 <;> simp
#print axioms probe_8_28

-- ATTACK fc-379fc029-parts-i-38118392ca-formalized-v1 use_one_simp
theorem probe_8_29 : fcTypeOfName% "Erdos1101.erdos_1101.parts.i" := by
  use 1 <;> simp
#print axioms probe_8_29

-- ATTACK fc-379fc029-parts-i-38118392ca-formalized-v1 use_empty_simp
theorem probe_8_30 : fcTypeOfName% "Erdos1101.erdos_1101.parts.i" := by
  use ∅ <;> simp
#print axioms probe_8_30

-- ATTACK fc-379fc029-parts-i-38118392ca-formalized-v1 assumption
theorem probe_8_31 : fcTypeOfName% "Erdos1101.erdos_1101.parts.i" := by
  assumption
#print axioms probe_8_31

-- ATTACK fc-379fc029-parts-i-38118392ca-formalized-v1 infer_instance
theorem probe_8_32 : fcTypeOfName% "Erdos1101.erdos_1101.parts.i" := by
  infer_instance
#print axioms probe_8_32

-- ATTACK fc-379fc029-parts-i-38118392ca-formalized-v1 contradiction
theorem probe_8_33 : fcTypeOfName% "Erdos1101.erdos_1101.parts.i" := by
  contradiction
#print axioms probe_8_33

-- ATTACK fc-379fc029-parts-i-38118392ca-formalized-v1 solve_by_elim
theorem probe_8_34 : fcTypeOfName% "Erdos1101.erdos_1101.parts.i" := by
  solve_by_elim
#print axioms probe_8_34

-- ATTACK fc-379fc029-parts-i-38118392ca-formalized-v1 first_order
theorem probe_8_35 : fcTypeOfName% "Erdos1101.erdos_1101.parts.i" := by
  first_order
#print axioms probe_8_35

-- ATTACK fc-379fc029-parts-i-38118392ca-formalized-v1 grind
theorem probe_8_36 : fcTypeOfName% "Erdos1101.erdos_1101.parts.i" := by
  grind
#print axioms probe_8_36

-- ATTACK fc-379fc029-parts-i-38118392ca-formalized-v1 exact_search
theorem probe_8_37 : fcTypeOfName% "Erdos1101.erdos_1101.parts.i" := by
  exact?
#print axioms probe_8_37

-- ATTACK fc-379fc029-parts-i-38118392ca-formalized-v1 apply_search
theorem probe_8_38 : fcTypeOfName% "Erdos1101.erdos_1101.parts.i" := by
  apply?
#print axioms probe_8_38

-- ATTACK fc-379fc029-parts-i-38118392ca-formalized-v1 library_search
theorem probe_8_39 : fcTypeOfName% "Erdos1101.erdos_1101.parts.i" := by
  library_search
#print axioms probe_8_39

-- ATTACK fc-379fc029-parts-i-38118392ca-formalized-v1 aesop_search
theorem probe_8_40 : fcTypeOfName% "Erdos1101.erdos_1101.parts.i" := by
  aesop?
#print axioms probe_8_40

-- ATTACK fc-379fc029-parts-i-38118392ca-formalized-v1 simp_search
theorem probe_8_41 : fcTypeOfName% "Erdos1101.erdos_1101.parts.i" := by
  simp?
#print axioms probe_8_41

-- ATTACK fc-379fc029-erdos138-erdos-138-1025cbb296-formalized-v1 simp
theorem probe_8_42 : fcTypeOfName% "Erdos138.erdos_138" := by
  simp
#print axioms probe_8_42

-- ATTACK fc-379fc029-erdos138-erdos-138-1025cbb296-formalized-v1 simpa
theorem probe_8_43 : fcTypeOfName% "Erdos138.erdos_138" := by
  simpa
#print axioms probe_8_43

-- ATTACK fc-379fc029-erdos138-erdos-138-1025cbb296-formalized-v1 simp_all
theorem probe_8_44 : fcTypeOfName% "Erdos138.erdos_138" := by
  simp_all
#print axioms probe_8_44

-- ATTACK fc-379fc029-erdos138-erdos-138-1025cbb296-formalized-v1 aesop
theorem probe_8_45 : fcTypeOfName% "Erdos138.erdos_138" := by
  aesop
#print axioms probe_8_45

-- ATTACK fc-379fc029-erdos138-erdos-138-1025cbb296-formalized-v1 omega
theorem probe_8_46 : fcTypeOfName% "Erdos138.erdos_138" := by
  omega
#print axioms probe_8_46

-- ATTACK fc-379fc029-erdos138-erdos-138-1025cbb296-formalized-v1 norm_num
theorem probe_8_47 : fcTypeOfName% "Erdos138.erdos_138" := by
  norm_num
#print axioms probe_8_47

-- ATTACK fc-379fc029-erdos138-erdos-138-1025cbb296-formalized-v1 decide
theorem probe_8_48 : fcTypeOfName% "Erdos138.erdos_138" := by
  decide
#print axioms probe_8_48

-- ATTACK fc-379fc029-erdos138-erdos-138-1025cbb296-formalized-v1 native_decide
theorem probe_8_49 : fcTypeOfName% "Erdos138.erdos_138" := by
  native_decide
#print axioms probe_8_49

-- ATTACK fc-379fc029-erdos138-erdos-138-1025cbb296-formalized-v1 true_intro
theorem probe_8_50 : fcTypeOfName% "Erdos138.erdos_138" := by
  exact True.intro
#print axioms probe_8_50

-- ATTACK fc-379fc029-erdos138-erdos-138-1025cbb296-formalized-v1 false_elim_simp
theorem probe_8_51 : fcTypeOfName% "Erdos138.erdos_138" := by
  apply False.elim
  simp_all
#print axioms probe_8_51

-- ATTACK fc-379fc029-erdos138-erdos-138-1025cbb296-formalized-v1 constructor
theorem probe_8_52 : fcTypeOfName% "Erdos138.erdos_138" := by
  constructor
#print axioms probe_8_52

-- ATTACK fc-379fc029-erdos138-erdos-138-1025cbb296-formalized-v1 constructor_simp
theorem probe_8_53 : fcTypeOfName% "Erdos138.erdos_138" := by
  constructor <;> simp
#print axioms probe_8_53

-- ATTACK fc-379fc029-erdos138-erdos-138-1025cbb296-formalized-v1 constructor_aesop
theorem probe_8_54 : fcTypeOfName% "Erdos138.erdos_138" := by
  constructor <;> aesop
#print axioms probe_8_54

-- ATTACK fc-379fc029-erdos138-erdos-138-1025cbb296-formalized-v1 rfl
theorem probe_8_55 : fcTypeOfName% "Erdos138.erdos_138" := by
  rfl
#print axioms probe_8_55

-- ATTACK fc-379fc029-erdos138-erdos-138-1025cbb296-formalized-v1 trivial
theorem probe_8_56 : fcTypeOfName% "Erdos138.erdos_138" := by
  trivial
#print axioms probe_8_56

-- ATTACK fc-379fc029-erdos138-erdos-138-1025cbb296-formalized-v1 tauto
theorem probe_8_57 : fcTypeOfName% "Erdos138.erdos_138" := by
  tauto
#print axioms probe_8_57

-- ATTACK fc-379fc029-erdos138-erdos-138-1025cbb296-formalized-v1 positivity
theorem probe_8_58 : fcTypeOfName% "Erdos138.erdos_138" := by
  positivity
#print axioms probe_8_58

-- ATTACK fc-379fc029-erdos138-erdos-138-1025cbb296-formalized-v1 linarith
theorem probe_8_59 : fcTypeOfName% "Erdos138.erdos_138" := by
  linarith
#print axioms probe_8_59

-- ATTACK fc-379fc029-erdos138-erdos-138-1025cbb296-formalized-v1 nlinarith
theorem probe_8_60 : fcTypeOfName% "Erdos138.erdos_138" := by
  nlinarith
#print axioms probe_8_60

-- ATTACK fc-379fc029-erdos138-erdos-138-1025cbb296-formalized-v1 intros_simp_all
theorem probe_8_61 : fcTypeOfName% "Erdos138.erdos_138" := by
  intros
  simp_all
#print axioms probe_8_61

-- ATTACK fc-379fc029-erdos138-erdos-138-1025cbb296-formalized-v1 intros_omega
theorem probe_8_62 : fcTypeOfName% "Erdos138.erdos_138" := by
  intros
  omega
#print axioms probe_8_62

-- ATTACK fc-379fc029-erdos138-erdos-138-1025cbb296-formalized-v1 intros_norm_num
theorem probe_8_63 : fcTypeOfName% "Erdos138.erdos_138" := by
  intros
  norm_num at *
#print axioms probe_8_63

-- ATTACK fc-379fc029-erdos138-erdos-138-1025cbb296-formalized-v1 intros_aesop
theorem probe_8_64 : fcTypeOfName% "Erdos138.erdos_138" := by
  intros
  aesop
#print axioms probe_8_64

-- ATTACK fc-379fc029-erdos138-erdos-138-1025cbb296-formalized-v1 by_contra_simp_all
theorem probe_8_65 : fcTypeOfName% "Erdos138.erdos_138" := by
  by_contra h
  simp_all
#print axioms probe_8_65

-- ATTACK fc-379fc029-erdos138-erdos-138-1025cbb296-formalized-v1 classical_simp_all
theorem probe_8_66 : fcTypeOfName% "Erdos138.erdos_138" := by
  classical
  simp_all
#print axioms probe_8_66

-- ATTACK fc-379fc029-erdos138-erdos-138-1025cbb296-formalized-v1 classical_aesop
theorem probe_8_67 : fcTypeOfName% "Erdos138.erdos_138" := by
  classical
  aesop
#print axioms probe_8_67

-- ATTACK fc-379fc029-erdos138-erdos-138-1025cbb296-formalized-v1 refine_pair_simp
theorem probe_8_68 : fcTypeOfName% "Erdos138.erdos_138" := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_8_68

-- ATTACK fc-379fc029-erdos138-erdos-138-1025cbb296-formalized-v1 refine_pair_aesop
theorem probe_8_69 : fcTypeOfName% "Erdos138.erdos_138" := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_8_69

-- ATTACK fc-379fc029-erdos138-erdos-138-1025cbb296-formalized-v1 use_zero_simp
theorem probe_8_70 : fcTypeOfName% "Erdos138.erdos_138" := by
  use 0 <;> simp
#print axioms probe_8_70

-- ATTACK fc-379fc029-erdos138-erdos-138-1025cbb296-formalized-v1 use_one_simp
theorem probe_8_71 : fcTypeOfName% "Erdos138.erdos_138" := by
  use 1 <;> simp
#print axioms probe_8_71

-- ATTACK fc-379fc029-erdos138-erdos-138-1025cbb296-formalized-v1 use_empty_simp
theorem probe_8_72 : fcTypeOfName% "Erdos138.erdos_138" := by
  use ∅ <;> simp
#print axioms probe_8_72

-- ATTACK fc-379fc029-erdos138-erdos-138-1025cbb296-formalized-v1 assumption
theorem probe_8_73 : fcTypeOfName% "Erdos138.erdos_138" := by
  assumption
#print axioms probe_8_73

-- ATTACK fc-379fc029-erdos138-erdos-138-1025cbb296-formalized-v1 infer_instance
theorem probe_8_74 : fcTypeOfName% "Erdos138.erdos_138" := by
  infer_instance
#print axioms probe_8_74

-- ATTACK fc-379fc029-erdos138-erdos-138-1025cbb296-formalized-v1 contradiction
theorem probe_8_75 : fcTypeOfName% "Erdos138.erdos_138" := by
  contradiction
#print axioms probe_8_75

-- ATTACK fc-379fc029-erdos138-erdos-138-1025cbb296-formalized-v1 solve_by_elim
theorem probe_8_76 : fcTypeOfName% "Erdos138.erdos_138" := by
  solve_by_elim
#print axioms probe_8_76

-- ATTACK fc-379fc029-erdos138-erdos-138-1025cbb296-formalized-v1 first_order
theorem probe_8_77 : fcTypeOfName% "Erdos138.erdos_138" := by
  first_order
#print axioms probe_8_77

-- ATTACK fc-379fc029-erdos138-erdos-138-1025cbb296-formalized-v1 grind
theorem probe_8_78 : fcTypeOfName% "Erdos138.erdos_138" := by
  grind
#print axioms probe_8_78

-- ATTACK fc-379fc029-erdos138-erdos-138-1025cbb296-formalized-v1 exact_search
theorem probe_8_79 : fcTypeOfName% "Erdos138.erdos_138" := by
  exact?
#print axioms probe_8_79

-- ATTACK fc-379fc029-erdos138-erdos-138-1025cbb296-formalized-v1 apply_search
theorem probe_8_80 : fcTypeOfName% "Erdos138.erdos_138" := by
  apply?
#print axioms probe_8_80

-- ATTACK fc-379fc029-erdos138-erdos-138-1025cbb296-formalized-v1 library_search
theorem probe_8_81 : fcTypeOfName% "Erdos138.erdos_138" := by
  library_search
#print axioms probe_8_81

-- ATTACK fc-379fc029-erdos138-erdos-138-1025cbb296-formalized-v1 aesop_search
theorem probe_8_82 : fcTypeOfName% "Erdos138.erdos_138" := by
  aesop?
#print axioms probe_8_82

-- ATTACK fc-379fc029-erdos138-erdos-138-1025cbb296-formalized-v1 simp_search
theorem probe_8_83 : fcTypeOfName% "Erdos138.erdos_138" := by
  simp?
#print axioms probe_8_83

-- ATTACK fc-379fc029-erdos25-erdos-25-8bf77ee9ec-formalized-v1 simp
theorem probe_8_84 : fcTypeOfName% "Erdos25.erdos_25" := by
  simp
#print axioms probe_8_84

-- ATTACK fc-379fc029-erdos25-erdos-25-8bf77ee9ec-formalized-v1 simpa
theorem probe_8_85 : fcTypeOfName% "Erdos25.erdos_25" := by
  simpa
#print axioms probe_8_85

-- ATTACK fc-379fc029-erdos25-erdos-25-8bf77ee9ec-formalized-v1 simp_all
theorem probe_8_86 : fcTypeOfName% "Erdos25.erdos_25" := by
  simp_all
#print axioms probe_8_86

-- ATTACK fc-379fc029-erdos25-erdos-25-8bf77ee9ec-formalized-v1 aesop
theorem probe_8_87 : fcTypeOfName% "Erdos25.erdos_25" := by
  aesop
#print axioms probe_8_87

-- ATTACK fc-379fc029-erdos25-erdos-25-8bf77ee9ec-formalized-v1 omega
theorem probe_8_88 : fcTypeOfName% "Erdos25.erdos_25" := by
  omega
#print axioms probe_8_88

-- ATTACK fc-379fc029-erdos25-erdos-25-8bf77ee9ec-formalized-v1 norm_num
theorem probe_8_89 : fcTypeOfName% "Erdos25.erdos_25" := by
  norm_num
#print axioms probe_8_89

-- ATTACK fc-379fc029-erdos25-erdos-25-8bf77ee9ec-formalized-v1 decide
theorem probe_8_90 : fcTypeOfName% "Erdos25.erdos_25" := by
  decide
#print axioms probe_8_90

-- ATTACK fc-379fc029-erdos25-erdos-25-8bf77ee9ec-formalized-v1 native_decide
theorem probe_8_91 : fcTypeOfName% "Erdos25.erdos_25" := by
  native_decide
#print axioms probe_8_91

-- ATTACK fc-379fc029-erdos25-erdos-25-8bf77ee9ec-formalized-v1 true_intro
theorem probe_8_92 : fcTypeOfName% "Erdos25.erdos_25" := by
  exact True.intro
#print axioms probe_8_92

-- ATTACK fc-379fc029-erdos25-erdos-25-8bf77ee9ec-formalized-v1 false_elim_simp
theorem probe_8_93 : fcTypeOfName% "Erdos25.erdos_25" := by
  apply False.elim
  simp_all
#print axioms probe_8_93

-- ATTACK fc-379fc029-erdos25-erdos-25-8bf77ee9ec-formalized-v1 constructor
theorem probe_8_94 : fcTypeOfName% "Erdos25.erdos_25" := by
  constructor
#print axioms probe_8_94

-- ATTACK fc-379fc029-erdos25-erdos-25-8bf77ee9ec-formalized-v1 constructor_simp
theorem probe_8_95 : fcTypeOfName% "Erdos25.erdos_25" := by
  constructor <;> simp
#print axioms probe_8_95

-- ATTACK fc-379fc029-erdos25-erdos-25-8bf77ee9ec-formalized-v1 constructor_aesop
theorem probe_8_96 : fcTypeOfName% "Erdos25.erdos_25" := by
  constructor <;> aesop
#print axioms probe_8_96

-- ATTACK fc-379fc029-erdos25-erdos-25-8bf77ee9ec-formalized-v1 rfl
theorem probe_8_97 : fcTypeOfName% "Erdos25.erdos_25" := by
  rfl
#print axioms probe_8_97

-- ATTACK fc-379fc029-erdos25-erdos-25-8bf77ee9ec-formalized-v1 trivial
theorem probe_8_98 : fcTypeOfName% "Erdos25.erdos_25" := by
  trivial
#print axioms probe_8_98

-- ATTACK fc-379fc029-erdos25-erdos-25-8bf77ee9ec-formalized-v1 tauto
theorem probe_8_99 : fcTypeOfName% "Erdos25.erdos_25" := by
  tauto
#print axioms probe_8_99

-- ATTACK fc-379fc029-erdos25-erdos-25-8bf77ee9ec-formalized-v1 positivity
theorem probe_8_100 : fcTypeOfName% "Erdos25.erdos_25" := by
  positivity
#print axioms probe_8_100

-- ATTACK fc-379fc029-erdos25-erdos-25-8bf77ee9ec-formalized-v1 linarith
theorem probe_8_101 : fcTypeOfName% "Erdos25.erdos_25" := by
  linarith
#print axioms probe_8_101

-- ATTACK fc-379fc029-erdos25-erdos-25-8bf77ee9ec-formalized-v1 nlinarith
theorem probe_8_102 : fcTypeOfName% "Erdos25.erdos_25" := by
  nlinarith
#print axioms probe_8_102

-- ATTACK fc-379fc029-erdos25-erdos-25-8bf77ee9ec-formalized-v1 intros_simp_all
theorem probe_8_103 : fcTypeOfName% "Erdos25.erdos_25" := by
  intros
  simp_all
#print axioms probe_8_103

-- ATTACK fc-379fc029-erdos25-erdos-25-8bf77ee9ec-formalized-v1 intros_omega
theorem probe_8_104 : fcTypeOfName% "Erdos25.erdos_25" := by
  intros
  omega
#print axioms probe_8_104

-- ATTACK fc-379fc029-erdos25-erdos-25-8bf77ee9ec-formalized-v1 intros_norm_num
theorem probe_8_105 : fcTypeOfName% "Erdos25.erdos_25" := by
  intros
  norm_num at *
#print axioms probe_8_105

-- ATTACK fc-379fc029-erdos25-erdos-25-8bf77ee9ec-formalized-v1 intros_aesop
theorem probe_8_106 : fcTypeOfName% "Erdos25.erdos_25" := by
  intros
  aesop
#print axioms probe_8_106

-- ATTACK fc-379fc029-erdos25-erdos-25-8bf77ee9ec-formalized-v1 by_contra_simp_all
theorem probe_8_107 : fcTypeOfName% "Erdos25.erdos_25" := by
  by_contra h
  simp_all
#print axioms probe_8_107

-- ATTACK fc-379fc029-erdos25-erdos-25-8bf77ee9ec-formalized-v1 classical_simp_all
theorem probe_8_108 : fcTypeOfName% "Erdos25.erdos_25" := by
  classical
  simp_all
#print axioms probe_8_108

-- ATTACK fc-379fc029-erdos25-erdos-25-8bf77ee9ec-formalized-v1 classical_aesop
theorem probe_8_109 : fcTypeOfName% "Erdos25.erdos_25" := by
  classical
  aesop
#print axioms probe_8_109

-- ATTACK fc-379fc029-erdos25-erdos-25-8bf77ee9ec-formalized-v1 refine_pair_simp
theorem probe_8_110 : fcTypeOfName% "Erdos25.erdos_25" := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_8_110

-- ATTACK fc-379fc029-erdos25-erdos-25-8bf77ee9ec-formalized-v1 refine_pair_aesop
theorem probe_8_111 : fcTypeOfName% "Erdos25.erdos_25" := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_8_111

-- ATTACK fc-379fc029-erdos25-erdos-25-8bf77ee9ec-formalized-v1 use_zero_simp
theorem probe_8_112 : fcTypeOfName% "Erdos25.erdos_25" := by
  use 0 <;> simp
#print axioms probe_8_112

-- ATTACK fc-379fc029-erdos25-erdos-25-8bf77ee9ec-formalized-v1 use_one_simp
theorem probe_8_113 : fcTypeOfName% "Erdos25.erdos_25" := by
  use 1 <;> simp
#print axioms probe_8_113

-- ATTACK fc-379fc029-erdos25-erdos-25-8bf77ee9ec-formalized-v1 use_empty_simp
theorem probe_8_114 : fcTypeOfName% "Erdos25.erdos_25" := by
  use ∅ <;> simp
#print axioms probe_8_114

-- ATTACK fc-379fc029-erdos25-erdos-25-8bf77ee9ec-formalized-v1 assumption
theorem probe_8_115 : fcTypeOfName% "Erdos25.erdos_25" := by
  assumption
#print axioms probe_8_115

-- ATTACK fc-379fc029-erdos25-erdos-25-8bf77ee9ec-formalized-v1 infer_instance
theorem probe_8_116 : fcTypeOfName% "Erdos25.erdos_25" := by
  infer_instance
#print axioms probe_8_116

-- ATTACK fc-379fc029-erdos25-erdos-25-8bf77ee9ec-formalized-v1 contradiction
theorem probe_8_117 : fcTypeOfName% "Erdos25.erdos_25" := by
  contradiction
#print axioms probe_8_117

-- ATTACK fc-379fc029-erdos25-erdos-25-8bf77ee9ec-formalized-v1 solve_by_elim
theorem probe_8_118 : fcTypeOfName% "Erdos25.erdos_25" := by
  solve_by_elim
#print axioms probe_8_118

-- ATTACK fc-379fc029-erdos25-erdos-25-8bf77ee9ec-formalized-v1 first_order
theorem probe_8_119 : fcTypeOfName% "Erdos25.erdos_25" := by
  first_order
#print axioms probe_8_119

-- ATTACK fc-379fc029-erdos25-erdos-25-8bf77ee9ec-formalized-v1 grind
theorem probe_8_120 : fcTypeOfName% "Erdos25.erdos_25" := by
  grind
#print axioms probe_8_120

-- ATTACK fc-379fc029-erdos25-erdos-25-8bf77ee9ec-formalized-v1 exact_search
theorem probe_8_121 : fcTypeOfName% "Erdos25.erdos_25" := by
  exact?
#print axioms probe_8_121

-- ATTACK fc-379fc029-erdos25-erdos-25-8bf77ee9ec-formalized-v1 apply_search
theorem probe_8_122 : fcTypeOfName% "Erdos25.erdos_25" := by
  apply?
#print axioms probe_8_122

-- ATTACK fc-379fc029-erdos25-erdos-25-8bf77ee9ec-formalized-v1 library_search
theorem probe_8_123 : fcTypeOfName% "Erdos25.erdos_25" := by
  library_search
#print axioms probe_8_123

-- ATTACK fc-379fc029-erdos25-erdos-25-8bf77ee9ec-formalized-v1 aesop_search
theorem probe_8_124 : fcTypeOfName% "Erdos25.erdos_25" := by
  aesop?
#print axioms probe_8_124

-- ATTACK fc-379fc029-erdos25-erdos-25-8bf77ee9ec-formalized-v1 simp_search
theorem probe_8_125 : fcTypeOfName% "Erdos25.erdos_25" := by
  simp?
#print axioms probe_8_125

-- ATTACK fc-379fc029-erdos304-upper-bound-cb0424ba31-formalized-v1 simp
theorem probe_8_126 : fcTypeOfName% "Erdos304.upper_bound" := by
  simp
#print axioms probe_8_126

-- ATTACK fc-379fc029-erdos304-upper-bound-cb0424ba31-formalized-v1 simpa
theorem probe_8_127 : fcTypeOfName% "Erdos304.upper_bound" := by
  simpa
#print axioms probe_8_127

-- ATTACK fc-379fc029-erdos304-upper-bound-cb0424ba31-formalized-v1 simp_all
theorem probe_8_128 : fcTypeOfName% "Erdos304.upper_bound" := by
  simp_all
#print axioms probe_8_128

-- ATTACK fc-379fc029-erdos304-upper-bound-cb0424ba31-formalized-v1 aesop
theorem probe_8_129 : fcTypeOfName% "Erdos304.upper_bound" := by
  aesop
#print axioms probe_8_129

-- ATTACK fc-379fc029-erdos304-upper-bound-cb0424ba31-formalized-v1 omega
theorem probe_8_130 : fcTypeOfName% "Erdos304.upper_bound" := by
  omega
#print axioms probe_8_130

-- ATTACK fc-379fc029-erdos304-upper-bound-cb0424ba31-formalized-v1 norm_num
theorem probe_8_131 : fcTypeOfName% "Erdos304.upper_bound" := by
  norm_num
#print axioms probe_8_131

-- ATTACK fc-379fc029-erdos304-upper-bound-cb0424ba31-formalized-v1 decide
theorem probe_8_132 : fcTypeOfName% "Erdos304.upper_bound" := by
  decide
#print axioms probe_8_132

-- ATTACK fc-379fc029-erdos304-upper-bound-cb0424ba31-formalized-v1 native_decide
theorem probe_8_133 : fcTypeOfName% "Erdos304.upper_bound" := by
  native_decide
#print axioms probe_8_133

-- ATTACK fc-379fc029-erdos304-upper-bound-cb0424ba31-formalized-v1 true_intro
theorem probe_8_134 : fcTypeOfName% "Erdos304.upper_bound" := by
  exact True.intro
#print axioms probe_8_134

-- ATTACK fc-379fc029-erdos304-upper-bound-cb0424ba31-formalized-v1 false_elim_simp
theorem probe_8_135 : fcTypeOfName% "Erdos304.upper_bound" := by
  apply False.elim
  simp_all
#print axioms probe_8_135

-- ATTACK fc-379fc029-erdos304-upper-bound-cb0424ba31-formalized-v1 constructor
theorem probe_8_136 : fcTypeOfName% "Erdos304.upper_bound" := by
  constructor
#print axioms probe_8_136

-- ATTACK fc-379fc029-erdos304-upper-bound-cb0424ba31-formalized-v1 constructor_simp
theorem probe_8_137 : fcTypeOfName% "Erdos304.upper_bound" := by
  constructor <;> simp
#print axioms probe_8_137

-- ATTACK fc-379fc029-erdos304-upper-bound-cb0424ba31-formalized-v1 constructor_aesop
theorem probe_8_138 : fcTypeOfName% "Erdos304.upper_bound" := by
  constructor <;> aesop
#print axioms probe_8_138

-- ATTACK fc-379fc029-erdos304-upper-bound-cb0424ba31-formalized-v1 rfl
theorem probe_8_139 : fcTypeOfName% "Erdos304.upper_bound" := by
  rfl
#print axioms probe_8_139

-- ATTACK fc-379fc029-erdos304-upper-bound-cb0424ba31-formalized-v1 trivial
theorem probe_8_140 : fcTypeOfName% "Erdos304.upper_bound" := by
  trivial
#print axioms probe_8_140

-- ATTACK fc-379fc029-erdos304-upper-bound-cb0424ba31-formalized-v1 tauto
theorem probe_8_141 : fcTypeOfName% "Erdos304.upper_bound" := by
  tauto
#print axioms probe_8_141

-- ATTACK fc-379fc029-erdos304-upper-bound-cb0424ba31-formalized-v1 positivity
theorem probe_8_142 : fcTypeOfName% "Erdos304.upper_bound" := by
  positivity
#print axioms probe_8_142

-- ATTACK fc-379fc029-erdos304-upper-bound-cb0424ba31-formalized-v1 linarith
theorem probe_8_143 : fcTypeOfName% "Erdos304.upper_bound" := by
  linarith
#print axioms probe_8_143

-- ATTACK fc-379fc029-erdos304-upper-bound-cb0424ba31-formalized-v1 nlinarith
theorem probe_8_144 : fcTypeOfName% "Erdos304.upper_bound" := by
  nlinarith
#print axioms probe_8_144

-- ATTACK fc-379fc029-erdos304-upper-bound-cb0424ba31-formalized-v1 intros_simp_all
theorem probe_8_145 : fcTypeOfName% "Erdos304.upper_bound" := by
  intros
  simp_all
#print axioms probe_8_145

-- ATTACK fc-379fc029-erdos304-upper-bound-cb0424ba31-formalized-v1 intros_omega
theorem probe_8_146 : fcTypeOfName% "Erdos304.upper_bound" := by
  intros
  omega
#print axioms probe_8_146

-- ATTACK fc-379fc029-erdos304-upper-bound-cb0424ba31-formalized-v1 intros_norm_num
theorem probe_8_147 : fcTypeOfName% "Erdos304.upper_bound" := by
  intros
  norm_num at *
#print axioms probe_8_147

-- ATTACK fc-379fc029-erdos304-upper-bound-cb0424ba31-formalized-v1 intros_aesop
theorem probe_8_148 : fcTypeOfName% "Erdos304.upper_bound" := by
  intros
  aesop
#print axioms probe_8_148

-- ATTACK fc-379fc029-erdos304-upper-bound-cb0424ba31-formalized-v1 by_contra_simp_all
theorem probe_8_149 : fcTypeOfName% "Erdos304.upper_bound" := by
  by_contra h
  simp_all
#print axioms probe_8_149

-- ATTACK fc-379fc029-erdos304-upper-bound-cb0424ba31-formalized-v1 classical_simp_all
theorem probe_8_150 : fcTypeOfName% "Erdos304.upper_bound" := by
  classical
  simp_all
#print axioms probe_8_150

-- ATTACK fc-379fc029-erdos304-upper-bound-cb0424ba31-formalized-v1 classical_aesop
theorem probe_8_151 : fcTypeOfName% "Erdos304.upper_bound" := by
  classical
  aesop
#print axioms probe_8_151

-- ATTACK fc-379fc029-erdos304-upper-bound-cb0424ba31-formalized-v1 refine_pair_simp
theorem probe_8_152 : fcTypeOfName% "Erdos304.upper_bound" := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_8_152

-- ATTACK fc-379fc029-erdos304-upper-bound-cb0424ba31-formalized-v1 refine_pair_aesop
theorem probe_8_153 : fcTypeOfName% "Erdos304.upper_bound" := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_8_153

-- ATTACK fc-379fc029-erdos304-upper-bound-cb0424ba31-formalized-v1 use_zero_simp
theorem probe_8_154 : fcTypeOfName% "Erdos304.upper_bound" := by
  use 0 <;> simp
#print axioms probe_8_154

-- ATTACK fc-379fc029-erdos304-upper-bound-cb0424ba31-formalized-v1 use_one_simp
theorem probe_8_155 : fcTypeOfName% "Erdos304.upper_bound" := by
  use 1 <;> simp
#print axioms probe_8_155

-- ATTACK fc-379fc029-erdos304-upper-bound-cb0424ba31-formalized-v1 use_empty_simp
theorem probe_8_156 : fcTypeOfName% "Erdos304.upper_bound" := by
  use ∅ <;> simp
#print axioms probe_8_156

-- ATTACK fc-379fc029-erdos304-upper-bound-cb0424ba31-formalized-v1 assumption
theorem probe_8_157 : fcTypeOfName% "Erdos304.upper_bound" := by
  assumption
#print axioms probe_8_157

-- ATTACK fc-379fc029-erdos304-upper-bound-cb0424ba31-formalized-v1 infer_instance
theorem probe_8_158 : fcTypeOfName% "Erdos304.upper_bound" := by
  infer_instance
#print axioms probe_8_158

-- ATTACK fc-379fc029-erdos304-upper-bound-cb0424ba31-formalized-v1 contradiction
theorem probe_8_159 : fcTypeOfName% "Erdos304.upper_bound" := by
  contradiction
#print axioms probe_8_159

-- ATTACK fc-379fc029-erdos304-upper-bound-cb0424ba31-formalized-v1 solve_by_elim
theorem probe_8_160 : fcTypeOfName% "Erdos304.upper_bound" := by
  solve_by_elim
#print axioms probe_8_160

-- ATTACK fc-379fc029-erdos304-upper-bound-cb0424ba31-formalized-v1 first_order
theorem probe_8_161 : fcTypeOfName% "Erdos304.upper_bound" := by
  first_order
#print axioms probe_8_161

-- ATTACK fc-379fc029-erdos304-upper-bound-cb0424ba31-formalized-v1 grind
theorem probe_8_162 : fcTypeOfName% "Erdos304.upper_bound" := by
  grind
#print axioms probe_8_162

-- ATTACK fc-379fc029-erdos304-upper-bound-cb0424ba31-formalized-v1 exact_search
theorem probe_8_163 : fcTypeOfName% "Erdos304.upper_bound" := by
  exact?
#print axioms probe_8_163

-- ATTACK fc-379fc029-erdos304-upper-bound-cb0424ba31-formalized-v1 apply_search
theorem probe_8_164 : fcTypeOfName% "Erdos304.upper_bound" := by
  apply?
#print axioms probe_8_164

-- ATTACK fc-379fc029-erdos304-upper-bound-cb0424ba31-formalized-v1 library_search
theorem probe_8_165 : fcTypeOfName% "Erdos304.upper_bound" := by
  library_search
#print axioms probe_8_165

-- ATTACK fc-379fc029-erdos304-upper-bound-cb0424ba31-formalized-v1 aesop_search
theorem probe_8_166 : fcTypeOfName% "Erdos304.upper_bound" := by
  aesop?
#print axioms probe_8_166

-- ATTACK fc-379fc029-erdos304-upper-bound-cb0424ba31-formalized-v1 simp_search
theorem probe_8_167 : fcTypeOfName% "Erdos304.upper_bound" := by
  simp?
#print axioms probe_8_167

-- ATTACK fc-379fc029-parts-ii-03354d0abd-formalized-v1 simp
theorem probe_8_168 : fcTypeOfName% "Erdos323.erdos_323.parts.ii" := by
  simp
#print axioms probe_8_168

-- ATTACK fc-379fc029-parts-ii-03354d0abd-formalized-v1 simpa
theorem probe_8_169 : fcTypeOfName% "Erdos323.erdos_323.parts.ii" := by
  simpa
#print axioms probe_8_169

-- ATTACK fc-379fc029-parts-ii-03354d0abd-formalized-v1 simp_all
theorem probe_8_170 : fcTypeOfName% "Erdos323.erdos_323.parts.ii" := by
  simp_all
#print axioms probe_8_170

-- ATTACK fc-379fc029-parts-ii-03354d0abd-formalized-v1 aesop
theorem probe_8_171 : fcTypeOfName% "Erdos323.erdos_323.parts.ii" := by
  aesop
#print axioms probe_8_171

-- ATTACK fc-379fc029-parts-ii-03354d0abd-formalized-v1 omega
theorem probe_8_172 : fcTypeOfName% "Erdos323.erdos_323.parts.ii" := by
  omega
#print axioms probe_8_172

-- ATTACK fc-379fc029-parts-ii-03354d0abd-formalized-v1 norm_num
theorem probe_8_173 : fcTypeOfName% "Erdos323.erdos_323.parts.ii" := by
  norm_num
#print axioms probe_8_173

-- ATTACK fc-379fc029-parts-ii-03354d0abd-formalized-v1 decide
theorem probe_8_174 : fcTypeOfName% "Erdos323.erdos_323.parts.ii" := by
  decide
#print axioms probe_8_174

-- ATTACK fc-379fc029-parts-ii-03354d0abd-formalized-v1 native_decide
theorem probe_8_175 : fcTypeOfName% "Erdos323.erdos_323.parts.ii" := by
  native_decide
#print axioms probe_8_175

-- ATTACK fc-379fc029-parts-ii-03354d0abd-formalized-v1 true_intro
theorem probe_8_176 : fcTypeOfName% "Erdos323.erdos_323.parts.ii" := by
  exact True.intro
#print axioms probe_8_176

-- ATTACK fc-379fc029-parts-ii-03354d0abd-formalized-v1 false_elim_simp
theorem probe_8_177 : fcTypeOfName% "Erdos323.erdos_323.parts.ii" := by
  apply False.elim
  simp_all
#print axioms probe_8_177

-- ATTACK fc-379fc029-parts-ii-03354d0abd-formalized-v1 constructor
theorem probe_8_178 : fcTypeOfName% "Erdos323.erdos_323.parts.ii" := by
  constructor
#print axioms probe_8_178

-- ATTACK fc-379fc029-parts-ii-03354d0abd-formalized-v1 constructor_simp
theorem probe_8_179 : fcTypeOfName% "Erdos323.erdos_323.parts.ii" := by
  constructor <;> simp
#print axioms probe_8_179

-- ATTACK fc-379fc029-parts-ii-03354d0abd-formalized-v1 constructor_aesop
theorem probe_8_180 : fcTypeOfName% "Erdos323.erdos_323.parts.ii" := by
  constructor <;> aesop
#print axioms probe_8_180

-- ATTACK fc-379fc029-parts-ii-03354d0abd-formalized-v1 rfl
theorem probe_8_181 : fcTypeOfName% "Erdos323.erdos_323.parts.ii" := by
  rfl
#print axioms probe_8_181

-- ATTACK fc-379fc029-parts-ii-03354d0abd-formalized-v1 trivial
theorem probe_8_182 : fcTypeOfName% "Erdos323.erdos_323.parts.ii" := by
  trivial
#print axioms probe_8_182

-- ATTACK fc-379fc029-parts-ii-03354d0abd-formalized-v1 tauto
theorem probe_8_183 : fcTypeOfName% "Erdos323.erdos_323.parts.ii" := by
  tauto
#print axioms probe_8_183

-- ATTACK fc-379fc029-parts-ii-03354d0abd-formalized-v1 positivity
theorem probe_8_184 : fcTypeOfName% "Erdos323.erdos_323.parts.ii" := by
  positivity
#print axioms probe_8_184

-- ATTACK fc-379fc029-parts-ii-03354d0abd-formalized-v1 linarith
theorem probe_8_185 : fcTypeOfName% "Erdos323.erdos_323.parts.ii" := by
  linarith
#print axioms probe_8_185

-- ATTACK fc-379fc029-parts-ii-03354d0abd-formalized-v1 nlinarith
theorem probe_8_186 : fcTypeOfName% "Erdos323.erdos_323.parts.ii" := by
  nlinarith
#print axioms probe_8_186

-- ATTACK fc-379fc029-parts-ii-03354d0abd-formalized-v1 intros_simp_all
theorem probe_8_187 : fcTypeOfName% "Erdos323.erdos_323.parts.ii" := by
  intros
  simp_all
#print axioms probe_8_187

-- ATTACK fc-379fc029-parts-ii-03354d0abd-formalized-v1 intros_omega
theorem probe_8_188 : fcTypeOfName% "Erdos323.erdos_323.parts.ii" := by
  intros
  omega
#print axioms probe_8_188

-- ATTACK fc-379fc029-parts-ii-03354d0abd-formalized-v1 intros_norm_num
theorem probe_8_189 : fcTypeOfName% "Erdos323.erdos_323.parts.ii" := by
  intros
  norm_num at *
#print axioms probe_8_189

-- ATTACK fc-379fc029-parts-ii-03354d0abd-formalized-v1 intros_aesop
theorem probe_8_190 : fcTypeOfName% "Erdos323.erdos_323.parts.ii" := by
  intros
  aesop
#print axioms probe_8_190

-- ATTACK fc-379fc029-parts-ii-03354d0abd-formalized-v1 by_contra_simp_all
theorem probe_8_191 : fcTypeOfName% "Erdos323.erdos_323.parts.ii" := by
  by_contra h
  simp_all
#print axioms probe_8_191

-- ATTACK fc-379fc029-parts-ii-03354d0abd-formalized-v1 classical_simp_all
theorem probe_8_192 : fcTypeOfName% "Erdos323.erdos_323.parts.ii" := by
  classical
  simp_all
#print axioms probe_8_192

-- ATTACK fc-379fc029-parts-ii-03354d0abd-formalized-v1 classical_aesop
theorem probe_8_193 : fcTypeOfName% "Erdos323.erdos_323.parts.ii" := by
  classical
  aesop
#print axioms probe_8_193

-- ATTACK fc-379fc029-parts-ii-03354d0abd-formalized-v1 refine_pair_simp
theorem probe_8_194 : fcTypeOfName% "Erdos323.erdos_323.parts.ii" := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_8_194

-- ATTACK fc-379fc029-parts-ii-03354d0abd-formalized-v1 refine_pair_aesop
theorem probe_8_195 : fcTypeOfName% "Erdos323.erdos_323.parts.ii" := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_8_195

-- ATTACK fc-379fc029-parts-ii-03354d0abd-formalized-v1 use_zero_simp
theorem probe_8_196 : fcTypeOfName% "Erdos323.erdos_323.parts.ii" := by
  use 0 <;> simp
#print axioms probe_8_196

-- ATTACK fc-379fc029-parts-ii-03354d0abd-formalized-v1 use_one_simp
theorem probe_8_197 : fcTypeOfName% "Erdos323.erdos_323.parts.ii" := by
  use 1 <;> simp
#print axioms probe_8_197

-- ATTACK fc-379fc029-parts-ii-03354d0abd-formalized-v1 use_empty_simp
theorem probe_8_198 : fcTypeOfName% "Erdos323.erdos_323.parts.ii" := by
  use ∅ <;> simp
#print axioms probe_8_198

-- ATTACK fc-379fc029-parts-ii-03354d0abd-formalized-v1 assumption
theorem probe_8_199 : fcTypeOfName% "Erdos323.erdos_323.parts.ii" := by
  assumption
#print axioms probe_8_199

-- ATTACK fc-379fc029-parts-ii-03354d0abd-formalized-v1 infer_instance
theorem probe_8_200 : fcTypeOfName% "Erdos323.erdos_323.parts.ii" := by
  infer_instance
#print axioms probe_8_200

-- ATTACK fc-379fc029-parts-ii-03354d0abd-formalized-v1 contradiction
theorem probe_8_201 : fcTypeOfName% "Erdos323.erdos_323.parts.ii" := by
  contradiction
#print axioms probe_8_201

-- ATTACK fc-379fc029-parts-ii-03354d0abd-formalized-v1 solve_by_elim
theorem probe_8_202 : fcTypeOfName% "Erdos323.erdos_323.parts.ii" := by
  solve_by_elim
#print axioms probe_8_202

-- ATTACK fc-379fc029-parts-ii-03354d0abd-formalized-v1 first_order
theorem probe_8_203 : fcTypeOfName% "Erdos323.erdos_323.parts.ii" := by
  first_order
#print axioms probe_8_203

-- ATTACK fc-379fc029-parts-ii-03354d0abd-formalized-v1 grind
theorem probe_8_204 : fcTypeOfName% "Erdos323.erdos_323.parts.ii" := by
  grind
#print axioms probe_8_204

-- ATTACK fc-379fc029-parts-ii-03354d0abd-formalized-v1 exact_search
theorem probe_8_205 : fcTypeOfName% "Erdos323.erdos_323.parts.ii" := by
  exact?
#print axioms probe_8_205

-- ATTACK fc-379fc029-parts-ii-03354d0abd-formalized-v1 apply_search
theorem probe_8_206 : fcTypeOfName% "Erdos323.erdos_323.parts.ii" := by
  apply?
#print axioms probe_8_206

-- ATTACK fc-379fc029-parts-ii-03354d0abd-formalized-v1 library_search
theorem probe_8_207 : fcTypeOfName% "Erdos323.erdos_323.parts.ii" := by
  library_search
#print axioms probe_8_207

-- ATTACK fc-379fc029-parts-ii-03354d0abd-formalized-v1 aesop_search
theorem probe_8_208 : fcTypeOfName% "Erdos323.erdos_323.parts.ii" := by
  aesop?
#print axioms probe_8_208

-- ATTACK fc-379fc029-parts-ii-03354d0abd-formalized-v1 simp_search
theorem probe_8_209 : fcTypeOfName% "Erdos323.erdos_323.parts.ii" := by
  simp?
#print axioms probe_8_209

-- ATTACK fc-379fc029-erdos495-erdos-495-c49ac6fa53-formalized-v1 simp
theorem probe_8_210 : fcTypeOfName% "Erdos495.erdos_495" := by
  simp
#print axioms probe_8_210

-- ATTACK fc-379fc029-erdos495-erdos-495-c49ac6fa53-formalized-v1 simpa
theorem probe_8_211 : fcTypeOfName% "Erdos495.erdos_495" := by
  simpa
#print axioms probe_8_211

-- ATTACK fc-379fc029-erdos495-erdos-495-c49ac6fa53-formalized-v1 simp_all
theorem probe_8_212 : fcTypeOfName% "Erdos495.erdos_495" := by
  simp_all
#print axioms probe_8_212

-- ATTACK fc-379fc029-erdos495-erdos-495-c49ac6fa53-formalized-v1 aesop
theorem probe_8_213 : fcTypeOfName% "Erdos495.erdos_495" := by
  aesop
#print axioms probe_8_213

-- ATTACK fc-379fc029-erdos495-erdos-495-c49ac6fa53-formalized-v1 omega
theorem probe_8_214 : fcTypeOfName% "Erdos495.erdos_495" := by
  omega
#print axioms probe_8_214

-- ATTACK fc-379fc029-erdos495-erdos-495-c49ac6fa53-formalized-v1 norm_num
theorem probe_8_215 : fcTypeOfName% "Erdos495.erdos_495" := by
  norm_num
#print axioms probe_8_215

-- ATTACK fc-379fc029-erdos495-erdos-495-c49ac6fa53-formalized-v1 decide
theorem probe_8_216 : fcTypeOfName% "Erdos495.erdos_495" := by
  decide
#print axioms probe_8_216

-- ATTACK fc-379fc029-erdos495-erdos-495-c49ac6fa53-formalized-v1 native_decide
theorem probe_8_217 : fcTypeOfName% "Erdos495.erdos_495" := by
  native_decide
#print axioms probe_8_217

-- ATTACK fc-379fc029-erdos495-erdos-495-c49ac6fa53-formalized-v1 true_intro
theorem probe_8_218 : fcTypeOfName% "Erdos495.erdos_495" := by
  exact True.intro
#print axioms probe_8_218

-- ATTACK fc-379fc029-erdos495-erdos-495-c49ac6fa53-formalized-v1 false_elim_simp
theorem probe_8_219 : fcTypeOfName% "Erdos495.erdos_495" := by
  apply False.elim
  simp_all
#print axioms probe_8_219

-- ATTACK fc-379fc029-erdos495-erdos-495-c49ac6fa53-formalized-v1 constructor
theorem probe_8_220 : fcTypeOfName% "Erdos495.erdos_495" := by
  constructor
#print axioms probe_8_220

-- ATTACK fc-379fc029-erdos495-erdos-495-c49ac6fa53-formalized-v1 constructor_simp
theorem probe_8_221 : fcTypeOfName% "Erdos495.erdos_495" := by
  constructor <;> simp
#print axioms probe_8_221

-- ATTACK fc-379fc029-erdos495-erdos-495-c49ac6fa53-formalized-v1 constructor_aesop
theorem probe_8_222 : fcTypeOfName% "Erdos495.erdos_495" := by
  constructor <;> aesop
#print axioms probe_8_222

-- ATTACK fc-379fc029-erdos495-erdos-495-c49ac6fa53-formalized-v1 rfl
theorem probe_8_223 : fcTypeOfName% "Erdos495.erdos_495" := by
  rfl
#print axioms probe_8_223

-- ATTACK fc-379fc029-erdos495-erdos-495-c49ac6fa53-formalized-v1 trivial
theorem probe_8_224 : fcTypeOfName% "Erdos495.erdos_495" := by
  trivial
#print axioms probe_8_224

-- ATTACK fc-379fc029-erdos495-erdos-495-c49ac6fa53-formalized-v1 tauto
theorem probe_8_225 : fcTypeOfName% "Erdos495.erdos_495" := by
  tauto
#print axioms probe_8_225

-- ATTACK fc-379fc029-erdos495-erdos-495-c49ac6fa53-formalized-v1 positivity
theorem probe_8_226 : fcTypeOfName% "Erdos495.erdos_495" := by
  positivity
#print axioms probe_8_226

-- ATTACK fc-379fc029-erdos495-erdos-495-c49ac6fa53-formalized-v1 linarith
theorem probe_8_227 : fcTypeOfName% "Erdos495.erdos_495" := by
  linarith
#print axioms probe_8_227

-- ATTACK fc-379fc029-erdos495-erdos-495-c49ac6fa53-formalized-v1 nlinarith
theorem probe_8_228 : fcTypeOfName% "Erdos495.erdos_495" := by
  nlinarith
#print axioms probe_8_228

-- ATTACK fc-379fc029-erdos495-erdos-495-c49ac6fa53-formalized-v1 intros_simp_all
theorem probe_8_229 : fcTypeOfName% "Erdos495.erdos_495" := by
  intros
  simp_all
#print axioms probe_8_229

-- ATTACK fc-379fc029-erdos495-erdos-495-c49ac6fa53-formalized-v1 intros_omega
theorem probe_8_230 : fcTypeOfName% "Erdos495.erdos_495" := by
  intros
  omega
#print axioms probe_8_230

-- ATTACK fc-379fc029-erdos495-erdos-495-c49ac6fa53-formalized-v1 intros_norm_num
theorem probe_8_231 : fcTypeOfName% "Erdos495.erdos_495" := by
  intros
  norm_num at *
#print axioms probe_8_231

-- ATTACK fc-379fc029-erdos495-erdos-495-c49ac6fa53-formalized-v1 intros_aesop
theorem probe_8_232 : fcTypeOfName% "Erdos495.erdos_495" := by
  intros
  aesop
#print axioms probe_8_232

-- ATTACK fc-379fc029-erdos495-erdos-495-c49ac6fa53-formalized-v1 by_contra_simp_all
theorem probe_8_233 : fcTypeOfName% "Erdos495.erdos_495" := by
  by_contra h
  simp_all
#print axioms probe_8_233

-- ATTACK fc-379fc029-erdos495-erdos-495-c49ac6fa53-formalized-v1 classical_simp_all
theorem probe_8_234 : fcTypeOfName% "Erdos495.erdos_495" := by
  classical
  simp_all
#print axioms probe_8_234

-- ATTACK fc-379fc029-erdos495-erdos-495-c49ac6fa53-formalized-v1 classical_aesop
theorem probe_8_235 : fcTypeOfName% "Erdos495.erdos_495" := by
  classical
  aesop
#print axioms probe_8_235

-- ATTACK fc-379fc029-erdos495-erdos-495-c49ac6fa53-formalized-v1 refine_pair_simp
theorem probe_8_236 : fcTypeOfName% "Erdos495.erdos_495" := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_8_236

-- ATTACK fc-379fc029-erdos495-erdos-495-c49ac6fa53-formalized-v1 refine_pair_aesop
theorem probe_8_237 : fcTypeOfName% "Erdos495.erdos_495" := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_8_237

-- ATTACK fc-379fc029-erdos495-erdos-495-c49ac6fa53-formalized-v1 use_zero_simp
theorem probe_8_238 : fcTypeOfName% "Erdos495.erdos_495" := by
  use 0 <;> simp
#print axioms probe_8_238

-- ATTACK fc-379fc029-erdos495-erdos-495-c49ac6fa53-formalized-v1 use_one_simp
theorem probe_8_239 : fcTypeOfName% "Erdos495.erdos_495" := by
  use 1 <;> simp
#print axioms probe_8_239

-- ATTACK fc-379fc029-erdos495-erdos-495-c49ac6fa53-formalized-v1 use_empty_simp
theorem probe_8_240 : fcTypeOfName% "Erdos495.erdos_495" := by
  use ∅ <;> simp
#print axioms probe_8_240

-- ATTACK fc-379fc029-erdos495-erdos-495-c49ac6fa53-formalized-v1 assumption
theorem probe_8_241 : fcTypeOfName% "Erdos495.erdos_495" := by
  assumption
#print axioms probe_8_241

-- ATTACK fc-379fc029-erdos495-erdos-495-c49ac6fa53-formalized-v1 infer_instance
theorem probe_8_242 : fcTypeOfName% "Erdos495.erdos_495" := by
  infer_instance
#print axioms probe_8_242

-- ATTACK fc-379fc029-erdos495-erdos-495-c49ac6fa53-formalized-v1 contradiction
theorem probe_8_243 : fcTypeOfName% "Erdos495.erdos_495" := by
  contradiction
#print axioms probe_8_243

-- ATTACK fc-379fc029-erdos495-erdos-495-c49ac6fa53-formalized-v1 solve_by_elim
theorem probe_8_244 : fcTypeOfName% "Erdos495.erdos_495" := by
  solve_by_elim
#print axioms probe_8_244

-- ATTACK fc-379fc029-erdos495-erdos-495-c49ac6fa53-formalized-v1 first_order
theorem probe_8_245 : fcTypeOfName% "Erdos495.erdos_495" := by
  first_order
#print axioms probe_8_245

-- ATTACK fc-379fc029-erdos495-erdos-495-c49ac6fa53-formalized-v1 grind
theorem probe_8_246 : fcTypeOfName% "Erdos495.erdos_495" := by
  grind
#print axioms probe_8_246

-- ATTACK fc-379fc029-erdos495-erdos-495-c49ac6fa53-formalized-v1 exact_search
theorem probe_8_247 : fcTypeOfName% "Erdos495.erdos_495" := by
  exact?
#print axioms probe_8_247

-- ATTACK fc-379fc029-erdos495-erdos-495-c49ac6fa53-formalized-v1 apply_search
theorem probe_8_248 : fcTypeOfName% "Erdos495.erdos_495" := by
  apply?
#print axioms probe_8_248

-- ATTACK fc-379fc029-erdos495-erdos-495-c49ac6fa53-formalized-v1 library_search
theorem probe_8_249 : fcTypeOfName% "Erdos495.erdos_495" := by
  library_search
#print axioms probe_8_249

-- ATTACK fc-379fc029-erdos495-erdos-495-c49ac6fa53-formalized-v1 aesop_search
theorem probe_8_250 : fcTypeOfName% "Erdos495.erdos_495" := by
  aesop?
#print axioms probe_8_250

-- ATTACK fc-379fc029-erdos495-erdos-495-c49ac6fa53-formalized-v1 simp_search
theorem probe_8_251 : fcTypeOfName% "Erdos495.erdos_495" := by
  simp?
#print axioms probe_8_251

-- ATTACK fc-379fc029-erdos681-erdos-681-eb69052278-formalized-v1 simp
theorem probe_8_252 : fcTypeOfName% "Erdos681.erdos_681" := by
  simp
#print axioms probe_8_252

-- ATTACK fc-379fc029-erdos681-erdos-681-eb69052278-formalized-v1 simpa
theorem probe_8_253 : fcTypeOfName% "Erdos681.erdos_681" := by
  simpa
#print axioms probe_8_253

-- ATTACK fc-379fc029-erdos681-erdos-681-eb69052278-formalized-v1 simp_all
theorem probe_8_254 : fcTypeOfName% "Erdos681.erdos_681" := by
  simp_all
#print axioms probe_8_254

-- ATTACK fc-379fc029-erdos681-erdos-681-eb69052278-formalized-v1 aesop
theorem probe_8_255 : fcTypeOfName% "Erdos681.erdos_681" := by
  aesop
#print axioms probe_8_255

-- ATTACK fc-379fc029-erdos681-erdos-681-eb69052278-formalized-v1 omega
theorem probe_8_256 : fcTypeOfName% "Erdos681.erdos_681" := by
  omega
#print axioms probe_8_256

-- ATTACK fc-379fc029-erdos681-erdos-681-eb69052278-formalized-v1 norm_num
theorem probe_8_257 : fcTypeOfName% "Erdos681.erdos_681" := by
  norm_num
#print axioms probe_8_257

-- ATTACK fc-379fc029-erdos681-erdos-681-eb69052278-formalized-v1 decide
theorem probe_8_258 : fcTypeOfName% "Erdos681.erdos_681" := by
  decide
#print axioms probe_8_258

-- ATTACK fc-379fc029-erdos681-erdos-681-eb69052278-formalized-v1 native_decide
theorem probe_8_259 : fcTypeOfName% "Erdos681.erdos_681" := by
  native_decide
#print axioms probe_8_259

-- ATTACK fc-379fc029-erdos681-erdos-681-eb69052278-formalized-v1 true_intro
theorem probe_8_260 : fcTypeOfName% "Erdos681.erdos_681" := by
  exact True.intro
#print axioms probe_8_260

-- ATTACK fc-379fc029-erdos681-erdos-681-eb69052278-formalized-v1 false_elim_simp
theorem probe_8_261 : fcTypeOfName% "Erdos681.erdos_681" := by
  apply False.elim
  simp_all
#print axioms probe_8_261

-- ATTACK fc-379fc029-erdos681-erdos-681-eb69052278-formalized-v1 constructor
theorem probe_8_262 : fcTypeOfName% "Erdos681.erdos_681" := by
  constructor
#print axioms probe_8_262

-- ATTACK fc-379fc029-erdos681-erdos-681-eb69052278-formalized-v1 constructor_simp
theorem probe_8_263 : fcTypeOfName% "Erdos681.erdos_681" := by
  constructor <;> simp
#print axioms probe_8_263

-- ATTACK fc-379fc029-erdos681-erdos-681-eb69052278-formalized-v1 constructor_aesop
theorem probe_8_264 : fcTypeOfName% "Erdos681.erdos_681" := by
  constructor <;> aesop
#print axioms probe_8_264

-- ATTACK fc-379fc029-erdos681-erdos-681-eb69052278-formalized-v1 rfl
theorem probe_8_265 : fcTypeOfName% "Erdos681.erdos_681" := by
  rfl
#print axioms probe_8_265

-- ATTACK fc-379fc029-erdos681-erdos-681-eb69052278-formalized-v1 trivial
theorem probe_8_266 : fcTypeOfName% "Erdos681.erdos_681" := by
  trivial
#print axioms probe_8_266

-- ATTACK fc-379fc029-erdos681-erdos-681-eb69052278-formalized-v1 tauto
theorem probe_8_267 : fcTypeOfName% "Erdos681.erdos_681" := by
  tauto
#print axioms probe_8_267

-- ATTACK fc-379fc029-erdos681-erdos-681-eb69052278-formalized-v1 positivity
theorem probe_8_268 : fcTypeOfName% "Erdos681.erdos_681" := by
  positivity
#print axioms probe_8_268

-- ATTACK fc-379fc029-erdos681-erdos-681-eb69052278-formalized-v1 linarith
theorem probe_8_269 : fcTypeOfName% "Erdos681.erdos_681" := by
  linarith
#print axioms probe_8_269

-- ATTACK fc-379fc029-erdos681-erdos-681-eb69052278-formalized-v1 nlinarith
theorem probe_8_270 : fcTypeOfName% "Erdos681.erdos_681" := by
  nlinarith
#print axioms probe_8_270

-- ATTACK fc-379fc029-erdos681-erdos-681-eb69052278-formalized-v1 intros_simp_all
theorem probe_8_271 : fcTypeOfName% "Erdos681.erdos_681" := by
  intros
  simp_all
#print axioms probe_8_271

-- ATTACK fc-379fc029-erdos681-erdos-681-eb69052278-formalized-v1 intros_omega
theorem probe_8_272 : fcTypeOfName% "Erdos681.erdos_681" := by
  intros
  omega
#print axioms probe_8_272

-- ATTACK fc-379fc029-erdos681-erdos-681-eb69052278-formalized-v1 intros_norm_num
theorem probe_8_273 : fcTypeOfName% "Erdos681.erdos_681" := by
  intros
  norm_num at *
#print axioms probe_8_273

-- ATTACK fc-379fc029-erdos681-erdos-681-eb69052278-formalized-v1 intros_aesop
theorem probe_8_274 : fcTypeOfName% "Erdos681.erdos_681" := by
  intros
  aesop
#print axioms probe_8_274

-- ATTACK fc-379fc029-erdos681-erdos-681-eb69052278-formalized-v1 by_contra_simp_all
theorem probe_8_275 : fcTypeOfName% "Erdos681.erdos_681" := by
  by_contra h
  simp_all
#print axioms probe_8_275

-- ATTACK fc-379fc029-erdos681-erdos-681-eb69052278-formalized-v1 classical_simp_all
theorem probe_8_276 : fcTypeOfName% "Erdos681.erdos_681" := by
  classical
  simp_all
#print axioms probe_8_276

-- ATTACK fc-379fc029-erdos681-erdos-681-eb69052278-formalized-v1 classical_aesop
theorem probe_8_277 : fcTypeOfName% "Erdos681.erdos_681" := by
  classical
  aesop
#print axioms probe_8_277

-- ATTACK fc-379fc029-erdos681-erdos-681-eb69052278-formalized-v1 refine_pair_simp
theorem probe_8_278 : fcTypeOfName% "Erdos681.erdos_681" := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_8_278

-- ATTACK fc-379fc029-erdos681-erdos-681-eb69052278-formalized-v1 refine_pair_aesop
theorem probe_8_279 : fcTypeOfName% "Erdos681.erdos_681" := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_8_279

-- ATTACK fc-379fc029-erdos681-erdos-681-eb69052278-formalized-v1 use_zero_simp
theorem probe_8_280 : fcTypeOfName% "Erdos681.erdos_681" := by
  use 0 <;> simp
#print axioms probe_8_280

-- ATTACK fc-379fc029-erdos681-erdos-681-eb69052278-formalized-v1 use_one_simp
theorem probe_8_281 : fcTypeOfName% "Erdos681.erdos_681" := by
  use 1 <;> simp
#print axioms probe_8_281

-- ATTACK fc-379fc029-erdos681-erdos-681-eb69052278-formalized-v1 use_empty_simp
theorem probe_8_282 : fcTypeOfName% "Erdos681.erdos_681" := by
  use ∅ <;> simp
#print axioms probe_8_282

-- ATTACK fc-379fc029-erdos681-erdos-681-eb69052278-formalized-v1 assumption
theorem probe_8_283 : fcTypeOfName% "Erdos681.erdos_681" := by
  assumption
#print axioms probe_8_283

-- ATTACK fc-379fc029-erdos681-erdos-681-eb69052278-formalized-v1 infer_instance
theorem probe_8_284 : fcTypeOfName% "Erdos681.erdos_681" := by
  infer_instance
#print axioms probe_8_284

-- ATTACK fc-379fc029-erdos681-erdos-681-eb69052278-formalized-v1 contradiction
theorem probe_8_285 : fcTypeOfName% "Erdos681.erdos_681" := by
  contradiction
#print axioms probe_8_285

-- ATTACK fc-379fc029-erdos681-erdos-681-eb69052278-formalized-v1 solve_by_elim
theorem probe_8_286 : fcTypeOfName% "Erdos681.erdos_681" := by
  solve_by_elim
#print axioms probe_8_286

-- ATTACK fc-379fc029-erdos681-erdos-681-eb69052278-formalized-v1 first_order
theorem probe_8_287 : fcTypeOfName% "Erdos681.erdos_681" := by
  first_order
#print axioms probe_8_287

-- ATTACK fc-379fc029-erdos681-erdos-681-eb69052278-formalized-v1 grind
theorem probe_8_288 : fcTypeOfName% "Erdos681.erdos_681" := by
  grind
#print axioms probe_8_288

-- ATTACK fc-379fc029-erdos681-erdos-681-eb69052278-formalized-v1 exact_search
theorem probe_8_289 : fcTypeOfName% "Erdos681.erdos_681" := by
  exact?
#print axioms probe_8_289

-- ATTACK fc-379fc029-erdos681-erdos-681-eb69052278-formalized-v1 apply_search
theorem probe_8_290 : fcTypeOfName% "Erdos681.erdos_681" := by
  apply?
#print axioms probe_8_290

-- ATTACK fc-379fc029-erdos681-erdos-681-eb69052278-formalized-v1 library_search
theorem probe_8_291 : fcTypeOfName% "Erdos681.erdos_681" := by
  library_search
#print axioms probe_8_291

-- ATTACK fc-379fc029-erdos681-erdos-681-eb69052278-formalized-v1 aesop_search
theorem probe_8_292 : fcTypeOfName% "Erdos681.erdos_681" := by
  aesop?
#print axioms probe_8_292

-- ATTACK fc-379fc029-erdos681-erdos-681-eb69052278-formalized-v1 simp_search
theorem probe_8_293 : fcTypeOfName% "Erdos681.erdos_681" := by
  simp?
#print axioms probe_8_293

-- ATTACK fc-379fc029-erdos886-erdos-886-2ee4c9e168-formalized-v1 simp
theorem probe_8_294 : fcTypeOfName% "Erdos886.erdos_886" := by
  simp
#print axioms probe_8_294

-- ATTACK fc-379fc029-erdos886-erdos-886-2ee4c9e168-formalized-v1 simpa
theorem probe_8_295 : fcTypeOfName% "Erdos886.erdos_886" := by
  simpa
#print axioms probe_8_295

-- ATTACK fc-379fc029-erdos886-erdos-886-2ee4c9e168-formalized-v1 simp_all
theorem probe_8_296 : fcTypeOfName% "Erdos886.erdos_886" := by
  simp_all
#print axioms probe_8_296

-- ATTACK fc-379fc029-erdos886-erdos-886-2ee4c9e168-formalized-v1 aesop
theorem probe_8_297 : fcTypeOfName% "Erdos886.erdos_886" := by
  aesop
#print axioms probe_8_297

-- ATTACK fc-379fc029-erdos886-erdos-886-2ee4c9e168-formalized-v1 omega
theorem probe_8_298 : fcTypeOfName% "Erdos886.erdos_886" := by
  omega
#print axioms probe_8_298

-- ATTACK fc-379fc029-erdos886-erdos-886-2ee4c9e168-formalized-v1 norm_num
theorem probe_8_299 : fcTypeOfName% "Erdos886.erdos_886" := by
  norm_num
#print axioms probe_8_299

-- ATTACK fc-379fc029-erdos886-erdos-886-2ee4c9e168-formalized-v1 decide
theorem probe_8_300 : fcTypeOfName% "Erdos886.erdos_886" := by
  decide
#print axioms probe_8_300

-- ATTACK fc-379fc029-erdos886-erdos-886-2ee4c9e168-formalized-v1 native_decide
theorem probe_8_301 : fcTypeOfName% "Erdos886.erdos_886" := by
  native_decide
#print axioms probe_8_301

-- ATTACK fc-379fc029-erdos886-erdos-886-2ee4c9e168-formalized-v1 true_intro
theorem probe_8_302 : fcTypeOfName% "Erdos886.erdos_886" := by
  exact True.intro
#print axioms probe_8_302

-- ATTACK fc-379fc029-erdos886-erdos-886-2ee4c9e168-formalized-v1 false_elim_simp
theorem probe_8_303 : fcTypeOfName% "Erdos886.erdos_886" := by
  apply False.elim
  simp_all
#print axioms probe_8_303

-- ATTACK fc-379fc029-erdos886-erdos-886-2ee4c9e168-formalized-v1 constructor
theorem probe_8_304 : fcTypeOfName% "Erdos886.erdos_886" := by
  constructor
#print axioms probe_8_304

-- ATTACK fc-379fc029-erdos886-erdos-886-2ee4c9e168-formalized-v1 constructor_simp
theorem probe_8_305 : fcTypeOfName% "Erdos886.erdos_886" := by
  constructor <;> simp
#print axioms probe_8_305

-- ATTACK fc-379fc029-erdos886-erdos-886-2ee4c9e168-formalized-v1 constructor_aesop
theorem probe_8_306 : fcTypeOfName% "Erdos886.erdos_886" := by
  constructor <;> aesop
#print axioms probe_8_306

-- ATTACK fc-379fc029-erdos886-erdos-886-2ee4c9e168-formalized-v1 rfl
theorem probe_8_307 : fcTypeOfName% "Erdos886.erdos_886" := by
  rfl
#print axioms probe_8_307

-- ATTACK fc-379fc029-erdos886-erdos-886-2ee4c9e168-formalized-v1 trivial
theorem probe_8_308 : fcTypeOfName% "Erdos886.erdos_886" := by
  trivial
#print axioms probe_8_308

-- ATTACK fc-379fc029-erdos886-erdos-886-2ee4c9e168-formalized-v1 tauto
theorem probe_8_309 : fcTypeOfName% "Erdos886.erdos_886" := by
  tauto
#print axioms probe_8_309

-- ATTACK fc-379fc029-erdos886-erdos-886-2ee4c9e168-formalized-v1 positivity
theorem probe_8_310 : fcTypeOfName% "Erdos886.erdos_886" := by
  positivity
#print axioms probe_8_310

-- ATTACK fc-379fc029-erdos886-erdos-886-2ee4c9e168-formalized-v1 linarith
theorem probe_8_311 : fcTypeOfName% "Erdos886.erdos_886" := by
  linarith
#print axioms probe_8_311

-- ATTACK fc-379fc029-erdos886-erdos-886-2ee4c9e168-formalized-v1 nlinarith
theorem probe_8_312 : fcTypeOfName% "Erdos886.erdos_886" := by
  nlinarith
#print axioms probe_8_312

-- ATTACK fc-379fc029-erdos886-erdos-886-2ee4c9e168-formalized-v1 intros_simp_all
theorem probe_8_313 : fcTypeOfName% "Erdos886.erdos_886" := by
  intros
  simp_all
#print axioms probe_8_313

-- ATTACK fc-379fc029-erdos886-erdos-886-2ee4c9e168-formalized-v1 intros_omega
theorem probe_8_314 : fcTypeOfName% "Erdos886.erdos_886" := by
  intros
  omega
#print axioms probe_8_314

-- ATTACK fc-379fc029-erdos886-erdos-886-2ee4c9e168-formalized-v1 intros_norm_num
theorem probe_8_315 : fcTypeOfName% "Erdos886.erdos_886" := by
  intros
  norm_num at *
#print axioms probe_8_315

-- ATTACK fc-379fc029-erdos886-erdos-886-2ee4c9e168-formalized-v1 intros_aesop
theorem probe_8_316 : fcTypeOfName% "Erdos886.erdos_886" := by
  intros
  aesop
#print axioms probe_8_316

-- ATTACK fc-379fc029-erdos886-erdos-886-2ee4c9e168-formalized-v1 by_contra_simp_all
theorem probe_8_317 : fcTypeOfName% "Erdos886.erdos_886" := by
  by_contra h
  simp_all
#print axioms probe_8_317

-- ATTACK fc-379fc029-erdos886-erdos-886-2ee4c9e168-formalized-v1 classical_simp_all
theorem probe_8_318 : fcTypeOfName% "Erdos886.erdos_886" := by
  classical
  simp_all
#print axioms probe_8_318

-- ATTACK fc-379fc029-erdos886-erdos-886-2ee4c9e168-formalized-v1 classical_aesop
theorem probe_8_319 : fcTypeOfName% "Erdos886.erdos_886" := by
  classical
  aesop
#print axioms probe_8_319

-- ATTACK fc-379fc029-erdos886-erdos-886-2ee4c9e168-formalized-v1 refine_pair_simp
theorem probe_8_320 : fcTypeOfName% "Erdos886.erdos_886" := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_8_320

-- ATTACK fc-379fc029-erdos886-erdos-886-2ee4c9e168-formalized-v1 refine_pair_aesop
theorem probe_8_321 : fcTypeOfName% "Erdos886.erdos_886" := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_8_321

-- ATTACK fc-379fc029-erdos886-erdos-886-2ee4c9e168-formalized-v1 use_zero_simp
theorem probe_8_322 : fcTypeOfName% "Erdos886.erdos_886" := by
  use 0 <;> simp
#print axioms probe_8_322

-- ATTACK fc-379fc029-erdos886-erdos-886-2ee4c9e168-formalized-v1 use_one_simp
theorem probe_8_323 : fcTypeOfName% "Erdos886.erdos_886" := by
  use 1 <;> simp
#print axioms probe_8_323

-- ATTACK fc-379fc029-erdos886-erdos-886-2ee4c9e168-formalized-v1 use_empty_simp
theorem probe_8_324 : fcTypeOfName% "Erdos886.erdos_886" := by
  use ∅ <;> simp
#print axioms probe_8_324

-- ATTACK fc-379fc029-erdos886-erdos-886-2ee4c9e168-formalized-v1 assumption
theorem probe_8_325 : fcTypeOfName% "Erdos886.erdos_886" := by
  assumption
#print axioms probe_8_325

-- ATTACK fc-379fc029-erdos886-erdos-886-2ee4c9e168-formalized-v1 infer_instance
theorem probe_8_326 : fcTypeOfName% "Erdos886.erdos_886" := by
  infer_instance
#print axioms probe_8_326

-- ATTACK fc-379fc029-erdos886-erdos-886-2ee4c9e168-formalized-v1 contradiction
theorem probe_8_327 : fcTypeOfName% "Erdos886.erdos_886" := by
  contradiction
#print axioms probe_8_327

-- ATTACK fc-379fc029-erdos886-erdos-886-2ee4c9e168-formalized-v1 solve_by_elim
theorem probe_8_328 : fcTypeOfName% "Erdos886.erdos_886" := by
  solve_by_elim
#print axioms probe_8_328

-- ATTACK fc-379fc029-erdos886-erdos-886-2ee4c9e168-formalized-v1 first_order
theorem probe_8_329 : fcTypeOfName% "Erdos886.erdos_886" := by
  first_order
#print axioms probe_8_329

-- ATTACK fc-379fc029-erdos886-erdos-886-2ee4c9e168-formalized-v1 grind
theorem probe_8_330 : fcTypeOfName% "Erdos886.erdos_886" := by
  grind
#print axioms probe_8_330

-- ATTACK fc-379fc029-erdos886-erdos-886-2ee4c9e168-formalized-v1 exact_search
theorem probe_8_331 : fcTypeOfName% "Erdos886.erdos_886" := by
  exact?
#print axioms probe_8_331

-- ATTACK fc-379fc029-erdos886-erdos-886-2ee4c9e168-formalized-v1 apply_search
theorem probe_8_332 : fcTypeOfName% "Erdos886.erdos_886" := by
  apply?
#print axioms probe_8_332

-- ATTACK fc-379fc029-erdos886-erdos-886-2ee4c9e168-formalized-v1 library_search
theorem probe_8_333 : fcTypeOfName% "Erdos886.erdos_886" := by
  library_search
#print axioms probe_8_333

-- ATTACK fc-379fc029-erdos886-erdos-886-2ee4c9e168-formalized-v1 aesop_search
theorem probe_8_334 : fcTypeOfName% "Erdos886.erdos_886" := by
  aesop?
#print axioms probe_8_334

-- ATTACK fc-379fc029-erdos886-erdos-886-2ee4c9e168-formalized-v1 simp_search
theorem probe_8_335 : fcTypeOfName% "Erdos886.erdos_886" := by
  simp?
#print axioms probe_8_335

-- ATTACK fc-379fc029-erdos933-erdos-933-adbba6e890-formalized-v1 simp
theorem probe_8_336 : fcTypeOfName% "Erdos933.erdos_933" := by
  simp
#print axioms probe_8_336

-- ATTACK fc-379fc029-erdos933-erdos-933-adbba6e890-formalized-v1 simpa
theorem probe_8_337 : fcTypeOfName% "Erdos933.erdos_933" := by
  simpa
#print axioms probe_8_337

-- ATTACK fc-379fc029-erdos933-erdos-933-adbba6e890-formalized-v1 simp_all
theorem probe_8_338 : fcTypeOfName% "Erdos933.erdos_933" := by
  simp_all
#print axioms probe_8_338

-- ATTACK fc-379fc029-erdos933-erdos-933-adbba6e890-formalized-v1 aesop
theorem probe_8_339 : fcTypeOfName% "Erdos933.erdos_933" := by
  aesop
#print axioms probe_8_339

-- ATTACK fc-379fc029-erdos933-erdos-933-adbba6e890-formalized-v1 omega
theorem probe_8_340 : fcTypeOfName% "Erdos933.erdos_933" := by
  omega
#print axioms probe_8_340

-- ATTACK fc-379fc029-erdos933-erdos-933-adbba6e890-formalized-v1 norm_num
theorem probe_8_341 : fcTypeOfName% "Erdos933.erdos_933" := by
  norm_num
#print axioms probe_8_341

-- ATTACK fc-379fc029-erdos933-erdos-933-adbba6e890-formalized-v1 decide
theorem probe_8_342 : fcTypeOfName% "Erdos933.erdos_933" := by
  decide
#print axioms probe_8_342

-- ATTACK fc-379fc029-erdos933-erdos-933-adbba6e890-formalized-v1 native_decide
theorem probe_8_343 : fcTypeOfName% "Erdos933.erdos_933" := by
  native_decide
#print axioms probe_8_343

-- ATTACK fc-379fc029-erdos933-erdos-933-adbba6e890-formalized-v1 true_intro
theorem probe_8_344 : fcTypeOfName% "Erdos933.erdos_933" := by
  exact True.intro
#print axioms probe_8_344

-- ATTACK fc-379fc029-erdos933-erdos-933-adbba6e890-formalized-v1 false_elim_simp
theorem probe_8_345 : fcTypeOfName% "Erdos933.erdos_933" := by
  apply False.elim
  simp_all
#print axioms probe_8_345

-- ATTACK fc-379fc029-erdos933-erdos-933-adbba6e890-formalized-v1 constructor
theorem probe_8_346 : fcTypeOfName% "Erdos933.erdos_933" := by
  constructor
#print axioms probe_8_346

-- ATTACK fc-379fc029-erdos933-erdos-933-adbba6e890-formalized-v1 constructor_simp
theorem probe_8_347 : fcTypeOfName% "Erdos933.erdos_933" := by
  constructor <;> simp
#print axioms probe_8_347

-- ATTACK fc-379fc029-erdos933-erdos-933-adbba6e890-formalized-v1 constructor_aesop
theorem probe_8_348 : fcTypeOfName% "Erdos933.erdos_933" := by
  constructor <;> aesop
#print axioms probe_8_348

-- ATTACK fc-379fc029-erdos933-erdos-933-adbba6e890-formalized-v1 rfl
theorem probe_8_349 : fcTypeOfName% "Erdos933.erdos_933" := by
  rfl
#print axioms probe_8_349

-- ATTACK fc-379fc029-erdos933-erdos-933-adbba6e890-formalized-v1 trivial
theorem probe_8_350 : fcTypeOfName% "Erdos933.erdos_933" := by
  trivial
#print axioms probe_8_350

-- ATTACK fc-379fc029-erdos933-erdos-933-adbba6e890-formalized-v1 tauto
theorem probe_8_351 : fcTypeOfName% "Erdos933.erdos_933" := by
  tauto
#print axioms probe_8_351

-- ATTACK fc-379fc029-erdos933-erdos-933-adbba6e890-formalized-v1 positivity
theorem probe_8_352 : fcTypeOfName% "Erdos933.erdos_933" := by
  positivity
#print axioms probe_8_352

-- ATTACK fc-379fc029-erdos933-erdos-933-adbba6e890-formalized-v1 linarith
theorem probe_8_353 : fcTypeOfName% "Erdos933.erdos_933" := by
  linarith
#print axioms probe_8_353

-- ATTACK fc-379fc029-erdos933-erdos-933-adbba6e890-formalized-v1 nlinarith
theorem probe_8_354 : fcTypeOfName% "Erdos933.erdos_933" := by
  nlinarith
#print axioms probe_8_354

-- ATTACK fc-379fc029-erdos933-erdos-933-adbba6e890-formalized-v1 intros_simp_all
theorem probe_8_355 : fcTypeOfName% "Erdos933.erdos_933" := by
  intros
  simp_all
#print axioms probe_8_355

-- ATTACK fc-379fc029-erdos933-erdos-933-adbba6e890-formalized-v1 intros_omega
theorem probe_8_356 : fcTypeOfName% "Erdos933.erdos_933" := by
  intros
  omega
#print axioms probe_8_356

-- ATTACK fc-379fc029-erdos933-erdos-933-adbba6e890-formalized-v1 intros_norm_num
theorem probe_8_357 : fcTypeOfName% "Erdos933.erdos_933" := by
  intros
  norm_num at *
#print axioms probe_8_357

-- ATTACK fc-379fc029-erdos933-erdos-933-adbba6e890-formalized-v1 intros_aesop
theorem probe_8_358 : fcTypeOfName% "Erdos933.erdos_933" := by
  intros
  aesop
#print axioms probe_8_358

-- ATTACK fc-379fc029-erdos933-erdos-933-adbba6e890-formalized-v1 by_contra_simp_all
theorem probe_8_359 : fcTypeOfName% "Erdos933.erdos_933" := by
  by_contra h
  simp_all
#print axioms probe_8_359

-- ATTACK fc-379fc029-erdos933-erdos-933-adbba6e890-formalized-v1 classical_simp_all
theorem probe_8_360 : fcTypeOfName% "Erdos933.erdos_933" := by
  classical
  simp_all
#print axioms probe_8_360

-- ATTACK fc-379fc029-erdos933-erdos-933-adbba6e890-formalized-v1 classical_aesop
theorem probe_8_361 : fcTypeOfName% "Erdos933.erdos_933" := by
  classical
  aesop
#print axioms probe_8_361

-- ATTACK fc-379fc029-erdos933-erdos-933-adbba6e890-formalized-v1 refine_pair_simp
theorem probe_8_362 : fcTypeOfName% "Erdos933.erdos_933" := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_8_362

-- ATTACK fc-379fc029-erdos933-erdos-933-adbba6e890-formalized-v1 refine_pair_aesop
theorem probe_8_363 : fcTypeOfName% "Erdos933.erdos_933" := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_8_363

-- ATTACK fc-379fc029-erdos933-erdos-933-adbba6e890-formalized-v1 use_zero_simp
theorem probe_8_364 : fcTypeOfName% "Erdos933.erdos_933" := by
  use 0 <;> simp
#print axioms probe_8_364

-- ATTACK fc-379fc029-erdos933-erdos-933-adbba6e890-formalized-v1 use_one_simp
theorem probe_8_365 : fcTypeOfName% "Erdos933.erdos_933" := by
  use 1 <;> simp
#print axioms probe_8_365

-- ATTACK fc-379fc029-erdos933-erdos-933-adbba6e890-formalized-v1 use_empty_simp
theorem probe_8_366 : fcTypeOfName% "Erdos933.erdos_933" := by
  use ∅ <;> simp
#print axioms probe_8_366

-- ATTACK fc-379fc029-erdos933-erdos-933-adbba6e890-formalized-v1 assumption
theorem probe_8_367 : fcTypeOfName% "Erdos933.erdos_933" := by
  assumption
#print axioms probe_8_367

-- ATTACK fc-379fc029-erdos933-erdos-933-adbba6e890-formalized-v1 infer_instance
theorem probe_8_368 : fcTypeOfName% "Erdos933.erdos_933" := by
  infer_instance
#print axioms probe_8_368

-- ATTACK fc-379fc029-erdos933-erdos-933-adbba6e890-formalized-v1 contradiction
theorem probe_8_369 : fcTypeOfName% "Erdos933.erdos_933" := by
  contradiction
#print axioms probe_8_369

-- ATTACK fc-379fc029-erdos933-erdos-933-adbba6e890-formalized-v1 solve_by_elim
theorem probe_8_370 : fcTypeOfName% "Erdos933.erdos_933" := by
  solve_by_elim
#print axioms probe_8_370

-- ATTACK fc-379fc029-erdos933-erdos-933-adbba6e890-formalized-v1 first_order
theorem probe_8_371 : fcTypeOfName% "Erdos933.erdos_933" := by
  first_order
#print axioms probe_8_371

-- ATTACK fc-379fc029-erdos933-erdos-933-adbba6e890-formalized-v1 grind
theorem probe_8_372 : fcTypeOfName% "Erdos933.erdos_933" := by
  grind
#print axioms probe_8_372

-- ATTACK fc-379fc029-erdos933-erdos-933-adbba6e890-formalized-v1 exact_search
theorem probe_8_373 : fcTypeOfName% "Erdos933.erdos_933" := by
  exact?
#print axioms probe_8_373

-- ATTACK fc-379fc029-erdos933-erdos-933-adbba6e890-formalized-v1 apply_search
theorem probe_8_374 : fcTypeOfName% "Erdos933.erdos_933" := by
  apply?
#print axioms probe_8_374

-- ATTACK fc-379fc029-erdos933-erdos-933-adbba6e890-formalized-v1 library_search
theorem probe_8_375 : fcTypeOfName% "Erdos933.erdos_933" := by
  library_search
#print axioms probe_8_375

-- ATTACK fc-379fc029-erdos933-erdos-933-adbba6e890-formalized-v1 aesop_search
theorem probe_8_376 : fcTypeOfName% "Erdos933.erdos_933" := by
  aesop?
#print axioms probe_8_376

-- ATTACK fc-379fc029-erdos933-erdos-933-adbba6e890-formalized-v1 simp_search
theorem probe_8_377 : fcTypeOfName% "Erdos933.erdos_933" := by
  simp?
#print axioms probe_8_377

-- ATTACK fc-379fc029-erdos949-erdos-949-d6737f55ee-formalized-v1 simp
theorem probe_8_378 : fcTypeOfName% "Erdos949.erdos_949" := by
  simp
#print axioms probe_8_378

-- ATTACK fc-379fc029-erdos949-erdos-949-d6737f55ee-formalized-v1 simpa
theorem probe_8_379 : fcTypeOfName% "Erdos949.erdos_949" := by
  simpa
#print axioms probe_8_379

-- ATTACK fc-379fc029-erdos949-erdos-949-d6737f55ee-formalized-v1 simp_all
theorem probe_8_380 : fcTypeOfName% "Erdos949.erdos_949" := by
  simp_all
#print axioms probe_8_380

-- ATTACK fc-379fc029-erdos949-erdos-949-d6737f55ee-formalized-v1 aesop
theorem probe_8_381 : fcTypeOfName% "Erdos949.erdos_949" := by
  aesop
#print axioms probe_8_381

-- ATTACK fc-379fc029-erdos949-erdos-949-d6737f55ee-formalized-v1 omega
theorem probe_8_382 : fcTypeOfName% "Erdos949.erdos_949" := by
  omega
#print axioms probe_8_382

-- ATTACK fc-379fc029-erdos949-erdos-949-d6737f55ee-formalized-v1 norm_num
theorem probe_8_383 : fcTypeOfName% "Erdos949.erdos_949" := by
  norm_num
#print axioms probe_8_383

-- ATTACK fc-379fc029-erdos949-erdos-949-d6737f55ee-formalized-v1 decide
theorem probe_8_384 : fcTypeOfName% "Erdos949.erdos_949" := by
  decide
#print axioms probe_8_384

-- ATTACK fc-379fc029-erdos949-erdos-949-d6737f55ee-formalized-v1 native_decide
theorem probe_8_385 : fcTypeOfName% "Erdos949.erdos_949" := by
  native_decide
#print axioms probe_8_385

-- ATTACK fc-379fc029-erdos949-erdos-949-d6737f55ee-formalized-v1 true_intro
theorem probe_8_386 : fcTypeOfName% "Erdos949.erdos_949" := by
  exact True.intro
#print axioms probe_8_386

-- ATTACK fc-379fc029-erdos949-erdos-949-d6737f55ee-formalized-v1 false_elim_simp
theorem probe_8_387 : fcTypeOfName% "Erdos949.erdos_949" := by
  apply False.elim
  simp_all
#print axioms probe_8_387

-- ATTACK fc-379fc029-erdos949-erdos-949-d6737f55ee-formalized-v1 constructor
theorem probe_8_388 : fcTypeOfName% "Erdos949.erdos_949" := by
  constructor
#print axioms probe_8_388

-- ATTACK fc-379fc029-erdos949-erdos-949-d6737f55ee-formalized-v1 constructor_simp
theorem probe_8_389 : fcTypeOfName% "Erdos949.erdos_949" := by
  constructor <;> simp
#print axioms probe_8_389

-- ATTACK fc-379fc029-erdos949-erdos-949-d6737f55ee-formalized-v1 constructor_aesop
theorem probe_8_390 : fcTypeOfName% "Erdos949.erdos_949" := by
  constructor <;> aesop
#print axioms probe_8_390

-- ATTACK fc-379fc029-erdos949-erdos-949-d6737f55ee-formalized-v1 rfl
theorem probe_8_391 : fcTypeOfName% "Erdos949.erdos_949" := by
  rfl
#print axioms probe_8_391

-- ATTACK fc-379fc029-erdos949-erdos-949-d6737f55ee-formalized-v1 trivial
theorem probe_8_392 : fcTypeOfName% "Erdos949.erdos_949" := by
  trivial
#print axioms probe_8_392

-- ATTACK fc-379fc029-erdos949-erdos-949-d6737f55ee-formalized-v1 tauto
theorem probe_8_393 : fcTypeOfName% "Erdos949.erdos_949" := by
  tauto
#print axioms probe_8_393

-- ATTACK fc-379fc029-erdos949-erdos-949-d6737f55ee-formalized-v1 positivity
theorem probe_8_394 : fcTypeOfName% "Erdos949.erdos_949" := by
  positivity
#print axioms probe_8_394

-- ATTACK fc-379fc029-erdos949-erdos-949-d6737f55ee-formalized-v1 linarith
theorem probe_8_395 : fcTypeOfName% "Erdos949.erdos_949" := by
  linarith
#print axioms probe_8_395

-- ATTACK fc-379fc029-erdos949-erdos-949-d6737f55ee-formalized-v1 nlinarith
theorem probe_8_396 : fcTypeOfName% "Erdos949.erdos_949" := by
  nlinarith
#print axioms probe_8_396

-- ATTACK fc-379fc029-erdos949-erdos-949-d6737f55ee-formalized-v1 intros_simp_all
theorem probe_8_397 : fcTypeOfName% "Erdos949.erdos_949" := by
  intros
  simp_all
#print axioms probe_8_397

-- ATTACK fc-379fc029-erdos949-erdos-949-d6737f55ee-formalized-v1 intros_omega
theorem probe_8_398 : fcTypeOfName% "Erdos949.erdos_949" := by
  intros
  omega
#print axioms probe_8_398

-- ATTACK fc-379fc029-erdos949-erdos-949-d6737f55ee-formalized-v1 intros_norm_num
theorem probe_8_399 : fcTypeOfName% "Erdos949.erdos_949" := by
  intros
  norm_num at *
#print axioms probe_8_399

-- ATTACK fc-379fc029-erdos949-erdos-949-d6737f55ee-formalized-v1 intros_aesop
theorem probe_8_400 : fcTypeOfName% "Erdos949.erdos_949" := by
  intros
  aesop
#print axioms probe_8_400

-- ATTACK fc-379fc029-erdos949-erdos-949-d6737f55ee-formalized-v1 by_contra_simp_all
theorem probe_8_401 : fcTypeOfName% "Erdos949.erdos_949" := by
  by_contra h
  simp_all
#print axioms probe_8_401

-- ATTACK fc-379fc029-erdos949-erdos-949-d6737f55ee-formalized-v1 classical_simp_all
theorem probe_8_402 : fcTypeOfName% "Erdos949.erdos_949" := by
  classical
  simp_all
#print axioms probe_8_402

-- ATTACK fc-379fc029-erdos949-erdos-949-d6737f55ee-formalized-v1 classical_aesop
theorem probe_8_403 : fcTypeOfName% "Erdos949.erdos_949" := by
  classical
  aesop
#print axioms probe_8_403

-- ATTACK fc-379fc029-erdos949-erdos-949-d6737f55ee-formalized-v1 refine_pair_simp
theorem probe_8_404 : fcTypeOfName% "Erdos949.erdos_949" := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_8_404

-- ATTACK fc-379fc029-erdos949-erdos-949-d6737f55ee-formalized-v1 refine_pair_aesop
theorem probe_8_405 : fcTypeOfName% "Erdos949.erdos_949" := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_8_405

-- ATTACK fc-379fc029-erdos949-erdos-949-d6737f55ee-formalized-v1 use_zero_simp
theorem probe_8_406 : fcTypeOfName% "Erdos949.erdos_949" := by
  use 0 <;> simp
#print axioms probe_8_406

-- ATTACK fc-379fc029-erdos949-erdos-949-d6737f55ee-formalized-v1 use_one_simp
theorem probe_8_407 : fcTypeOfName% "Erdos949.erdos_949" := by
  use 1 <;> simp
#print axioms probe_8_407

-- ATTACK fc-379fc029-erdos949-erdos-949-d6737f55ee-formalized-v1 use_empty_simp
theorem probe_8_408 : fcTypeOfName% "Erdos949.erdos_949" := by
  use ∅ <;> simp
#print axioms probe_8_408

-- ATTACK fc-379fc029-erdos949-erdos-949-d6737f55ee-formalized-v1 assumption
theorem probe_8_409 : fcTypeOfName% "Erdos949.erdos_949" := by
  assumption
#print axioms probe_8_409

-- ATTACK fc-379fc029-erdos949-erdos-949-d6737f55ee-formalized-v1 infer_instance
theorem probe_8_410 : fcTypeOfName% "Erdos949.erdos_949" := by
  infer_instance
#print axioms probe_8_410

-- ATTACK fc-379fc029-erdos949-erdos-949-d6737f55ee-formalized-v1 contradiction
theorem probe_8_411 : fcTypeOfName% "Erdos949.erdos_949" := by
  contradiction
#print axioms probe_8_411

-- ATTACK fc-379fc029-erdos949-erdos-949-d6737f55ee-formalized-v1 solve_by_elim
theorem probe_8_412 : fcTypeOfName% "Erdos949.erdos_949" := by
  solve_by_elim
#print axioms probe_8_412

-- ATTACK fc-379fc029-erdos949-erdos-949-d6737f55ee-formalized-v1 first_order
theorem probe_8_413 : fcTypeOfName% "Erdos949.erdos_949" := by
  first_order
#print axioms probe_8_413

-- ATTACK fc-379fc029-erdos949-erdos-949-d6737f55ee-formalized-v1 grind
theorem probe_8_414 : fcTypeOfName% "Erdos949.erdos_949" := by
  grind
#print axioms probe_8_414

-- ATTACK fc-379fc029-erdos949-erdos-949-d6737f55ee-formalized-v1 exact_search
theorem probe_8_415 : fcTypeOfName% "Erdos949.erdos_949" := by
  exact?
#print axioms probe_8_415

-- ATTACK fc-379fc029-erdos949-erdos-949-d6737f55ee-formalized-v1 apply_search
theorem probe_8_416 : fcTypeOfName% "Erdos949.erdos_949" := by
  apply?
#print axioms probe_8_416

-- ATTACK fc-379fc029-erdos949-erdos-949-d6737f55ee-formalized-v1 library_search
theorem probe_8_417 : fcTypeOfName% "Erdos949.erdos_949" := by
  library_search
#print axioms probe_8_417

-- ATTACK fc-379fc029-erdos949-erdos-949-d6737f55ee-formalized-v1 aesop_search
theorem probe_8_418 : fcTypeOfName% "Erdos949.erdos_949" := by
  aesop?
#print axioms probe_8_418

-- ATTACK fc-379fc029-erdos949-erdos-949-d6737f55ee-formalized-v1 simp_search
theorem probe_8_419 : fcTypeOfName% "Erdos949.erdos_949" := by
  simp?
#print axioms probe_8_419

-- ATTACK fc-379fc029-erdos98-erdos-98-5a012c0d40-formalized-v1 simp
theorem probe_8_420 : fcTypeOfName% "Erdos98.erdos_98" := by
  simp
#print axioms probe_8_420

-- ATTACK fc-379fc029-erdos98-erdos-98-5a012c0d40-formalized-v1 simpa
theorem probe_8_421 : fcTypeOfName% "Erdos98.erdos_98" := by
  simpa
#print axioms probe_8_421

-- ATTACK fc-379fc029-erdos98-erdos-98-5a012c0d40-formalized-v1 simp_all
theorem probe_8_422 : fcTypeOfName% "Erdos98.erdos_98" := by
  simp_all
#print axioms probe_8_422

-- ATTACK fc-379fc029-erdos98-erdos-98-5a012c0d40-formalized-v1 aesop
theorem probe_8_423 : fcTypeOfName% "Erdos98.erdos_98" := by
  aesop
#print axioms probe_8_423

-- ATTACK fc-379fc029-erdos98-erdos-98-5a012c0d40-formalized-v1 omega
theorem probe_8_424 : fcTypeOfName% "Erdos98.erdos_98" := by
  omega
#print axioms probe_8_424

-- ATTACK fc-379fc029-erdos98-erdos-98-5a012c0d40-formalized-v1 norm_num
theorem probe_8_425 : fcTypeOfName% "Erdos98.erdos_98" := by
  norm_num
#print axioms probe_8_425

-- ATTACK fc-379fc029-erdos98-erdos-98-5a012c0d40-formalized-v1 decide
theorem probe_8_426 : fcTypeOfName% "Erdos98.erdos_98" := by
  decide
#print axioms probe_8_426

-- ATTACK fc-379fc029-erdos98-erdos-98-5a012c0d40-formalized-v1 native_decide
theorem probe_8_427 : fcTypeOfName% "Erdos98.erdos_98" := by
  native_decide
#print axioms probe_8_427

-- ATTACK fc-379fc029-erdos98-erdos-98-5a012c0d40-formalized-v1 true_intro
theorem probe_8_428 : fcTypeOfName% "Erdos98.erdos_98" := by
  exact True.intro
#print axioms probe_8_428

-- ATTACK fc-379fc029-erdos98-erdos-98-5a012c0d40-formalized-v1 false_elim_simp
theorem probe_8_429 : fcTypeOfName% "Erdos98.erdos_98" := by
  apply False.elim
  simp_all
#print axioms probe_8_429

-- ATTACK fc-379fc029-erdos98-erdos-98-5a012c0d40-formalized-v1 constructor
theorem probe_8_430 : fcTypeOfName% "Erdos98.erdos_98" := by
  constructor
#print axioms probe_8_430

-- ATTACK fc-379fc029-erdos98-erdos-98-5a012c0d40-formalized-v1 constructor_simp
theorem probe_8_431 : fcTypeOfName% "Erdos98.erdos_98" := by
  constructor <;> simp
#print axioms probe_8_431

-- ATTACK fc-379fc029-erdos98-erdos-98-5a012c0d40-formalized-v1 constructor_aesop
theorem probe_8_432 : fcTypeOfName% "Erdos98.erdos_98" := by
  constructor <;> aesop
#print axioms probe_8_432

-- ATTACK fc-379fc029-erdos98-erdos-98-5a012c0d40-formalized-v1 rfl
theorem probe_8_433 : fcTypeOfName% "Erdos98.erdos_98" := by
  rfl
#print axioms probe_8_433

-- ATTACK fc-379fc029-erdos98-erdos-98-5a012c0d40-formalized-v1 trivial
theorem probe_8_434 : fcTypeOfName% "Erdos98.erdos_98" := by
  trivial
#print axioms probe_8_434

-- ATTACK fc-379fc029-erdos98-erdos-98-5a012c0d40-formalized-v1 tauto
theorem probe_8_435 : fcTypeOfName% "Erdos98.erdos_98" := by
  tauto
#print axioms probe_8_435

-- ATTACK fc-379fc029-erdos98-erdos-98-5a012c0d40-formalized-v1 positivity
theorem probe_8_436 : fcTypeOfName% "Erdos98.erdos_98" := by
  positivity
#print axioms probe_8_436

-- ATTACK fc-379fc029-erdos98-erdos-98-5a012c0d40-formalized-v1 linarith
theorem probe_8_437 : fcTypeOfName% "Erdos98.erdos_98" := by
  linarith
#print axioms probe_8_437

-- ATTACK fc-379fc029-erdos98-erdos-98-5a012c0d40-formalized-v1 nlinarith
theorem probe_8_438 : fcTypeOfName% "Erdos98.erdos_98" := by
  nlinarith
#print axioms probe_8_438

-- ATTACK fc-379fc029-erdos98-erdos-98-5a012c0d40-formalized-v1 intros_simp_all
theorem probe_8_439 : fcTypeOfName% "Erdos98.erdos_98" := by
  intros
  simp_all
#print axioms probe_8_439

-- ATTACK fc-379fc029-erdos98-erdos-98-5a012c0d40-formalized-v1 intros_omega
theorem probe_8_440 : fcTypeOfName% "Erdos98.erdos_98" := by
  intros
  omega
#print axioms probe_8_440

-- ATTACK fc-379fc029-erdos98-erdos-98-5a012c0d40-formalized-v1 intros_norm_num
theorem probe_8_441 : fcTypeOfName% "Erdos98.erdos_98" := by
  intros
  norm_num at *
#print axioms probe_8_441

-- ATTACK fc-379fc029-erdos98-erdos-98-5a012c0d40-formalized-v1 intros_aesop
theorem probe_8_442 : fcTypeOfName% "Erdos98.erdos_98" := by
  intros
  aesop
#print axioms probe_8_442

-- ATTACK fc-379fc029-erdos98-erdos-98-5a012c0d40-formalized-v1 by_contra_simp_all
theorem probe_8_443 : fcTypeOfName% "Erdos98.erdos_98" := by
  by_contra h
  simp_all
#print axioms probe_8_443

-- ATTACK fc-379fc029-erdos98-erdos-98-5a012c0d40-formalized-v1 classical_simp_all
theorem probe_8_444 : fcTypeOfName% "Erdos98.erdos_98" := by
  classical
  simp_all
#print axioms probe_8_444

-- ATTACK fc-379fc029-erdos98-erdos-98-5a012c0d40-formalized-v1 classical_aesop
theorem probe_8_445 : fcTypeOfName% "Erdos98.erdos_98" := by
  classical
  aesop
#print axioms probe_8_445

-- ATTACK fc-379fc029-erdos98-erdos-98-5a012c0d40-formalized-v1 refine_pair_simp
theorem probe_8_446 : fcTypeOfName% "Erdos98.erdos_98" := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_8_446

-- ATTACK fc-379fc029-erdos98-erdos-98-5a012c0d40-formalized-v1 refine_pair_aesop
theorem probe_8_447 : fcTypeOfName% "Erdos98.erdos_98" := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_8_447

-- ATTACK fc-379fc029-erdos98-erdos-98-5a012c0d40-formalized-v1 use_zero_simp
theorem probe_8_448 : fcTypeOfName% "Erdos98.erdos_98" := by
  use 0 <;> simp
#print axioms probe_8_448

-- ATTACK fc-379fc029-erdos98-erdos-98-5a012c0d40-formalized-v1 use_one_simp
theorem probe_8_449 : fcTypeOfName% "Erdos98.erdos_98" := by
  use 1 <;> simp
#print axioms probe_8_449

-- ATTACK fc-379fc029-erdos98-erdos-98-5a012c0d40-formalized-v1 use_empty_simp
theorem probe_8_450 : fcTypeOfName% "Erdos98.erdos_98" := by
  use ∅ <;> simp
#print axioms probe_8_450

-- ATTACK fc-379fc029-erdos98-erdos-98-5a012c0d40-formalized-v1 assumption
theorem probe_8_451 : fcTypeOfName% "Erdos98.erdos_98" := by
  assumption
#print axioms probe_8_451

-- ATTACK fc-379fc029-erdos98-erdos-98-5a012c0d40-formalized-v1 infer_instance
theorem probe_8_452 : fcTypeOfName% "Erdos98.erdos_98" := by
  infer_instance
#print axioms probe_8_452

-- ATTACK fc-379fc029-erdos98-erdos-98-5a012c0d40-formalized-v1 contradiction
theorem probe_8_453 : fcTypeOfName% "Erdos98.erdos_98" := by
  contradiction
#print axioms probe_8_453

-- ATTACK fc-379fc029-erdos98-erdos-98-5a012c0d40-formalized-v1 solve_by_elim
theorem probe_8_454 : fcTypeOfName% "Erdos98.erdos_98" := by
  solve_by_elim
#print axioms probe_8_454

-- ATTACK fc-379fc029-erdos98-erdos-98-5a012c0d40-formalized-v1 first_order
theorem probe_8_455 : fcTypeOfName% "Erdos98.erdos_98" := by
  first_order
#print axioms probe_8_455

-- ATTACK fc-379fc029-erdos98-erdos-98-5a012c0d40-formalized-v1 grind
theorem probe_8_456 : fcTypeOfName% "Erdos98.erdos_98" := by
  grind
#print axioms probe_8_456

-- ATTACK fc-379fc029-erdos98-erdos-98-5a012c0d40-formalized-v1 exact_search
theorem probe_8_457 : fcTypeOfName% "Erdos98.erdos_98" := by
  exact?
#print axioms probe_8_457

-- ATTACK fc-379fc029-erdos98-erdos-98-5a012c0d40-formalized-v1 apply_search
theorem probe_8_458 : fcTypeOfName% "Erdos98.erdos_98" := by
  apply?
#print axioms probe_8_458

-- ATTACK fc-379fc029-erdos98-erdos-98-5a012c0d40-formalized-v1 library_search
theorem probe_8_459 : fcTypeOfName% "Erdos98.erdos_98" := by
  library_search
#print axioms probe_8_459

-- ATTACK fc-379fc029-erdos98-erdos-98-5a012c0d40-formalized-v1 aesop_search
theorem probe_8_460 : fcTypeOfName% "Erdos98.erdos_98" := by
  aesop?
#print axioms probe_8_460

-- ATTACK fc-379fc029-erdos98-erdos-98-5a012c0d40-formalized-v1 simp_search
theorem probe_8_461 : fcTypeOfName% "Erdos98.erdos_98" := by
  simp?
#print axioms probe_8_461

-- ATTACK fc-379fc029-green47-green-47-6267b2ccdf-formalized-v1 simp
theorem probe_8_462 : fcTypeOfName% "Green47.green_47" := by
  simp
#print axioms probe_8_462

-- ATTACK fc-379fc029-green47-green-47-6267b2ccdf-formalized-v1 simpa
theorem probe_8_463 : fcTypeOfName% "Green47.green_47" := by
  simpa
#print axioms probe_8_463

-- ATTACK fc-379fc029-green47-green-47-6267b2ccdf-formalized-v1 simp_all
theorem probe_8_464 : fcTypeOfName% "Green47.green_47" := by
  simp_all
#print axioms probe_8_464

-- ATTACK fc-379fc029-green47-green-47-6267b2ccdf-formalized-v1 aesop
theorem probe_8_465 : fcTypeOfName% "Green47.green_47" := by
  aesop
#print axioms probe_8_465

-- ATTACK fc-379fc029-green47-green-47-6267b2ccdf-formalized-v1 omega
theorem probe_8_466 : fcTypeOfName% "Green47.green_47" := by
  omega
#print axioms probe_8_466

-- ATTACK fc-379fc029-green47-green-47-6267b2ccdf-formalized-v1 norm_num
theorem probe_8_467 : fcTypeOfName% "Green47.green_47" := by
  norm_num
#print axioms probe_8_467

-- ATTACK fc-379fc029-green47-green-47-6267b2ccdf-formalized-v1 decide
theorem probe_8_468 : fcTypeOfName% "Green47.green_47" := by
  decide
#print axioms probe_8_468

-- ATTACK fc-379fc029-green47-green-47-6267b2ccdf-formalized-v1 native_decide
theorem probe_8_469 : fcTypeOfName% "Green47.green_47" := by
  native_decide
#print axioms probe_8_469

-- ATTACK fc-379fc029-green47-green-47-6267b2ccdf-formalized-v1 true_intro
theorem probe_8_470 : fcTypeOfName% "Green47.green_47" := by
  exact True.intro
#print axioms probe_8_470

-- ATTACK fc-379fc029-green47-green-47-6267b2ccdf-formalized-v1 false_elim_simp
theorem probe_8_471 : fcTypeOfName% "Green47.green_47" := by
  apply False.elim
  simp_all
#print axioms probe_8_471

-- ATTACK fc-379fc029-green47-green-47-6267b2ccdf-formalized-v1 constructor
theorem probe_8_472 : fcTypeOfName% "Green47.green_47" := by
  constructor
#print axioms probe_8_472

-- ATTACK fc-379fc029-green47-green-47-6267b2ccdf-formalized-v1 constructor_simp
theorem probe_8_473 : fcTypeOfName% "Green47.green_47" := by
  constructor <;> simp
#print axioms probe_8_473

-- ATTACK fc-379fc029-green47-green-47-6267b2ccdf-formalized-v1 constructor_aesop
theorem probe_8_474 : fcTypeOfName% "Green47.green_47" := by
  constructor <;> aesop
#print axioms probe_8_474

-- ATTACK fc-379fc029-green47-green-47-6267b2ccdf-formalized-v1 rfl
theorem probe_8_475 : fcTypeOfName% "Green47.green_47" := by
  rfl
#print axioms probe_8_475

-- ATTACK fc-379fc029-green47-green-47-6267b2ccdf-formalized-v1 trivial
theorem probe_8_476 : fcTypeOfName% "Green47.green_47" := by
  trivial
#print axioms probe_8_476

-- ATTACK fc-379fc029-green47-green-47-6267b2ccdf-formalized-v1 tauto
theorem probe_8_477 : fcTypeOfName% "Green47.green_47" := by
  tauto
#print axioms probe_8_477

-- ATTACK fc-379fc029-green47-green-47-6267b2ccdf-formalized-v1 positivity
theorem probe_8_478 : fcTypeOfName% "Green47.green_47" := by
  positivity
#print axioms probe_8_478

-- ATTACK fc-379fc029-green47-green-47-6267b2ccdf-formalized-v1 linarith
theorem probe_8_479 : fcTypeOfName% "Green47.green_47" := by
  linarith
#print axioms probe_8_479

-- ATTACK fc-379fc029-green47-green-47-6267b2ccdf-formalized-v1 nlinarith
theorem probe_8_480 : fcTypeOfName% "Green47.green_47" := by
  nlinarith
#print axioms probe_8_480

-- ATTACK fc-379fc029-green47-green-47-6267b2ccdf-formalized-v1 intros_simp_all
theorem probe_8_481 : fcTypeOfName% "Green47.green_47" := by
  intros
  simp_all
#print axioms probe_8_481

-- ATTACK fc-379fc029-green47-green-47-6267b2ccdf-formalized-v1 intros_omega
theorem probe_8_482 : fcTypeOfName% "Green47.green_47" := by
  intros
  omega
#print axioms probe_8_482

-- ATTACK fc-379fc029-green47-green-47-6267b2ccdf-formalized-v1 intros_norm_num
theorem probe_8_483 : fcTypeOfName% "Green47.green_47" := by
  intros
  norm_num at *
#print axioms probe_8_483

-- ATTACK fc-379fc029-green47-green-47-6267b2ccdf-formalized-v1 intros_aesop
theorem probe_8_484 : fcTypeOfName% "Green47.green_47" := by
  intros
  aesop
#print axioms probe_8_484

-- ATTACK fc-379fc029-green47-green-47-6267b2ccdf-formalized-v1 by_contra_simp_all
theorem probe_8_485 : fcTypeOfName% "Green47.green_47" := by
  by_contra h
  simp_all
#print axioms probe_8_485

-- ATTACK fc-379fc029-green47-green-47-6267b2ccdf-formalized-v1 classical_simp_all
theorem probe_8_486 : fcTypeOfName% "Green47.green_47" := by
  classical
  simp_all
#print axioms probe_8_486

-- ATTACK fc-379fc029-green47-green-47-6267b2ccdf-formalized-v1 classical_aesop
theorem probe_8_487 : fcTypeOfName% "Green47.green_47" := by
  classical
  aesop
#print axioms probe_8_487

-- ATTACK fc-379fc029-green47-green-47-6267b2ccdf-formalized-v1 refine_pair_simp
theorem probe_8_488 : fcTypeOfName% "Green47.green_47" := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_8_488

-- ATTACK fc-379fc029-green47-green-47-6267b2ccdf-formalized-v1 refine_pair_aesop
theorem probe_8_489 : fcTypeOfName% "Green47.green_47" := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_8_489

-- ATTACK fc-379fc029-green47-green-47-6267b2ccdf-formalized-v1 use_zero_simp
theorem probe_8_490 : fcTypeOfName% "Green47.green_47" := by
  use 0 <;> simp
#print axioms probe_8_490

-- ATTACK fc-379fc029-green47-green-47-6267b2ccdf-formalized-v1 use_one_simp
theorem probe_8_491 : fcTypeOfName% "Green47.green_47" := by
  use 1 <;> simp
#print axioms probe_8_491

-- ATTACK fc-379fc029-green47-green-47-6267b2ccdf-formalized-v1 use_empty_simp
theorem probe_8_492 : fcTypeOfName% "Green47.green_47" := by
  use ∅ <;> simp
#print axioms probe_8_492

-- ATTACK fc-379fc029-green47-green-47-6267b2ccdf-formalized-v1 assumption
theorem probe_8_493 : fcTypeOfName% "Green47.green_47" := by
  assumption
#print axioms probe_8_493

-- ATTACK fc-379fc029-green47-green-47-6267b2ccdf-formalized-v1 infer_instance
theorem probe_8_494 : fcTypeOfName% "Green47.green_47" := by
  infer_instance
#print axioms probe_8_494

-- ATTACK fc-379fc029-green47-green-47-6267b2ccdf-formalized-v1 contradiction
theorem probe_8_495 : fcTypeOfName% "Green47.green_47" := by
  contradiction
#print axioms probe_8_495

-- ATTACK fc-379fc029-green47-green-47-6267b2ccdf-formalized-v1 solve_by_elim
theorem probe_8_496 : fcTypeOfName% "Green47.green_47" := by
  solve_by_elim
#print axioms probe_8_496

-- ATTACK fc-379fc029-green47-green-47-6267b2ccdf-formalized-v1 first_order
theorem probe_8_497 : fcTypeOfName% "Green47.green_47" := by
  first_order
#print axioms probe_8_497

-- ATTACK fc-379fc029-green47-green-47-6267b2ccdf-formalized-v1 grind
theorem probe_8_498 : fcTypeOfName% "Green47.green_47" := by
  grind
#print axioms probe_8_498

-- ATTACK fc-379fc029-green47-green-47-6267b2ccdf-formalized-v1 exact_search
theorem probe_8_499 : fcTypeOfName% "Green47.green_47" := by
  exact?
#print axioms probe_8_499

-- ATTACK fc-379fc029-green47-green-47-6267b2ccdf-formalized-v1 apply_search
theorem probe_8_500 : fcTypeOfName% "Green47.green_47" := by
  apply?
#print axioms probe_8_500

-- ATTACK fc-379fc029-green47-green-47-6267b2ccdf-formalized-v1 library_search
theorem probe_8_501 : fcTypeOfName% "Green47.green_47" := by
  library_search
#print axioms probe_8_501

-- ATTACK fc-379fc029-green47-green-47-6267b2ccdf-formalized-v1 aesop_search
theorem probe_8_502 : fcTypeOfName% "Green47.green_47" := by
  aesop?
#print axioms probe_8_502

-- ATTACK fc-379fc029-green47-green-47-6267b2ccdf-formalized-v1 simp_search
theorem probe_8_503 : fcTypeOfName% "Green47.green_47" := by
  simp?
#print axioms probe_8_503

end AttackBattery
