import FormalConjectures.ErdosProblems.«1056»
import FormalConjectures.ErdosProblems.«1113»
import FormalConjectures.ErdosProblems.«14»
import FormalConjectures.ErdosProblems.«287»
import FormalConjectures.ErdosProblems.«307»
import FormalConjectures.ErdosProblems.«400»
import FormalConjectures.ErdosProblems.«52»
import FormalConjectures.ErdosProblems.«686»
import FormalConjectures.ErdosProblems.«890»
import FormalConjectures.ErdosProblems.«936»
import FormalConjectures.ErdosProblems.«950»
import FormalConjectures.GreensOpenProblems.«36»
import FormalConjectures.GreensOpenProblems.«66»
import TaskSupport

set_option maxHeartbeats 20000
namespace AttackBattery

-- ATTACK fc-379fc029-erdos1056-erdos-1056-7337ef85af-counterexample-v1 simp
theorem probe_1_0 : ¬ (fcTypeOfName% "Erdos1056.erdos_1056") := by
  simp
#print axioms probe_1_0

-- ATTACK fc-379fc029-erdos1056-erdos-1056-7337ef85af-counterexample-v1 simpa
theorem probe_1_1 : ¬ (fcTypeOfName% "Erdos1056.erdos_1056") := by
  simpa
#print axioms probe_1_1

-- ATTACK fc-379fc029-erdos1056-erdos-1056-7337ef85af-counterexample-v1 simp_all
theorem probe_1_2 : ¬ (fcTypeOfName% "Erdos1056.erdos_1056") := by
  simp_all
#print axioms probe_1_2

-- ATTACK fc-379fc029-erdos1056-erdos-1056-7337ef85af-counterexample-v1 aesop
theorem probe_1_3 : ¬ (fcTypeOfName% "Erdos1056.erdos_1056") := by
  aesop
#print axioms probe_1_3

-- ATTACK fc-379fc029-erdos1056-erdos-1056-7337ef85af-counterexample-v1 omega
theorem probe_1_4 : ¬ (fcTypeOfName% "Erdos1056.erdos_1056") := by
  omega
#print axioms probe_1_4

-- ATTACK fc-379fc029-erdos1056-erdos-1056-7337ef85af-counterexample-v1 norm_num
theorem probe_1_5 : ¬ (fcTypeOfName% "Erdos1056.erdos_1056") := by
  norm_num
#print axioms probe_1_5

-- ATTACK fc-379fc029-erdos1056-erdos-1056-7337ef85af-counterexample-v1 decide
theorem probe_1_6 : ¬ (fcTypeOfName% "Erdos1056.erdos_1056") := by
  decide
#print axioms probe_1_6

-- ATTACK fc-379fc029-erdos1056-erdos-1056-7337ef85af-counterexample-v1 native_decide
theorem probe_1_7 : ¬ (fcTypeOfName% "Erdos1056.erdos_1056") := by
  native_decide
#print axioms probe_1_7

-- ATTACK fc-379fc029-erdos1056-erdos-1056-7337ef85af-counterexample-v1 true_intro
theorem probe_1_8 : ¬ (fcTypeOfName% "Erdos1056.erdos_1056") := by
  exact True.intro
#print axioms probe_1_8

-- ATTACK fc-379fc029-erdos1056-erdos-1056-7337ef85af-counterexample-v1 false_elim_simp
theorem probe_1_9 : ¬ (fcTypeOfName% "Erdos1056.erdos_1056") := by
  apply False.elim
  simp_all
#print axioms probe_1_9

-- ATTACK fc-379fc029-erdos1056-erdos-1056-7337ef85af-counterexample-v1 constructor
theorem probe_1_10 : ¬ (fcTypeOfName% "Erdos1056.erdos_1056") := by
  constructor
#print axioms probe_1_10

-- ATTACK fc-379fc029-erdos1056-erdos-1056-7337ef85af-counterexample-v1 constructor_simp
theorem probe_1_11 : ¬ (fcTypeOfName% "Erdos1056.erdos_1056") := by
  constructor <;> simp
#print axioms probe_1_11

-- ATTACK fc-379fc029-erdos1056-erdos-1056-7337ef85af-counterexample-v1 constructor_aesop
theorem probe_1_12 : ¬ (fcTypeOfName% "Erdos1056.erdos_1056") := by
  constructor <;> aesop
#print axioms probe_1_12

-- ATTACK fc-379fc029-erdos1056-erdos-1056-7337ef85af-counterexample-v1 rfl
theorem probe_1_13 : ¬ (fcTypeOfName% "Erdos1056.erdos_1056") := by
  rfl
#print axioms probe_1_13

-- ATTACK fc-379fc029-erdos1056-erdos-1056-7337ef85af-counterexample-v1 trivial
theorem probe_1_14 : ¬ (fcTypeOfName% "Erdos1056.erdos_1056") := by
  trivial
#print axioms probe_1_14

-- ATTACK fc-379fc029-erdos1056-erdos-1056-7337ef85af-counterexample-v1 tauto
theorem probe_1_15 : ¬ (fcTypeOfName% "Erdos1056.erdos_1056") := by
  tauto
#print axioms probe_1_15

-- ATTACK fc-379fc029-erdos1056-erdos-1056-7337ef85af-counterexample-v1 positivity
theorem probe_1_16 : ¬ (fcTypeOfName% "Erdos1056.erdos_1056") := by
  positivity
#print axioms probe_1_16

-- ATTACK fc-379fc029-erdos1056-erdos-1056-7337ef85af-counterexample-v1 linarith
theorem probe_1_17 : ¬ (fcTypeOfName% "Erdos1056.erdos_1056") := by
  linarith
#print axioms probe_1_17

-- ATTACK fc-379fc029-erdos1056-erdos-1056-7337ef85af-counterexample-v1 nlinarith
theorem probe_1_18 : ¬ (fcTypeOfName% "Erdos1056.erdos_1056") := by
  nlinarith
#print axioms probe_1_18

-- ATTACK fc-379fc029-erdos1056-erdos-1056-7337ef85af-counterexample-v1 intros_simp_all
theorem probe_1_19 : ¬ (fcTypeOfName% "Erdos1056.erdos_1056") := by
  intros
  simp_all
#print axioms probe_1_19

-- ATTACK fc-379fc029-erdos1056-erdos-1056-7337ef85af-counterexample-v1 intros_omega
theorem probe_1_20 : ¬ (fcTypeOfName% "Erdos1056.erdos_1056") := by
  intros
  omega
#print axioms probe_1_20

-- ATTACK fc-379fc029-erdos1056-erdos-1056-7337ef85af-counterexample-v1 intros_norm_num
theorem probe_1_21 : ¬ (fcTypeOfName% "Erdos1056.erdos_1056") := by
  intros
  norm_num at *
#print axioms probe_1_21

-- ATTACK fc-379fc029-erdos1056-erdos-1056-7337ef85af-counterexample-v1 intros_aesop
theorem probe_1_22 : ¬ (fcTypeOfName% "Erdos1056.erdos_1056") := by
  intros
  aesop
#print axioms probe_1_22

-- ATTACK fc-379fc029-erdos1056-erdos-1056-7337ef85af-counterexample-v1 by_contra_simp_all
theorem probe_1_23 : ¬ (fcTypeOfName% "Erdos1056.erdos_1056") := by
  by_contra h
  simp_all
#print axioms probe_1_23

-- ATTACK fc-379fc029-erdos1056-erdos-1056-7337ef85af-counterexample-v1 classical_simp_all
theorem probe_1_24 : ¬ (fcTypeOfName% "Erdos1056.erdos_1056") := by
  classical
  simp_all
#print axioms probe_1_24

-- ATTACK fc-379fc029-erdos1056-erdos-1056-7337ef85af-counterexample-v1 classical_aesop
theorem probe_1_25 : ¬ (fcTypeOfName% "Erdos1056.erdos_1056") := by
  classical
  aesop
#print axioms probe_1_25

-- ATTACK fc-379fc029-erdos1056-erdos-1056-7337ef85af-counterexample-v1 refine_pair_simp
theorem probe_1_26 : ¬ (fcTypeOfName% "Erdos1056.erdos_1056") := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_1_26

-- ATTACK fc-379fc029-erdos1056-erdos-1056-7337ef85af-counterexample-v1 refine_pair_aesop
theorem probe_1_27 : ¬ (fcTypeOfName% "Erdos1056.erdos_1056") := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_1_27

-- ATTACK fc-379fc029-erdos1056-erdos-1056-7337ef85af-counterexample-v1 use_zero_simp
theorem probe_1_28 : ¬ (fcTypeOfName% "Erdos1056.erdos_1056") := by
  use 0 <;> simp
#print axioms probe_1_28

-- ATTACK fc-379fc029-erdos1056-erdos-1056-7337ef85af-counterexample-v1 use_one_simp
theorem probe_1_29 : ¬ (fcTypeOfName% "Erdos1056.erdos_1056") := by
  use 1 <;> simp
#print axioms probe_1_29

-- ATTACK fc-379fc029-erdos1056-erdos-1056-7337ef85af-counterexample-v1 use_empty_simp
theorem probe_1_30 : ¬ (fcTypeOfName% "Erdos1056.erdos_1056") := by
  use ∅ <;> simp
#print axioms probe_1_30

-- ATTACK fc-379fc029-erdos1056-erdos-1056-7337ef85af-counterexample-v1 assumption
theorem probe_1_31 : ¬ (fcTypeOfName% "Erdos1056.erdos_1056") := by
  assumption
#print axioms probe_1_31

-- ATTACK fc-379fc029-erdos1056-erdos-1056-7337ef85af-counterexample-v1 infer_instance
theorem probe_1_32 : ¬ (fcTypeOfName% "Erdos1056.erdos_1056") := by
  infer_instance
#print axioms probe_1_32

-- ATTACK fc-379fc029-erdos1056-erdos-1056-7337ef85af-counterexample-v1 contradiction
theorem probe_1_33 : ¬ (fcTypeOfName% "Erdos1056.erdos_1056") := by
  contradiction
#print axioms probe_1_33

-- ATTACK fc-379fc029-erdos1056-erdos-1056-7337ef85af-counterexample-v1 solve_by_elim
theorem probe_1_34 : ¬ (fcTypeOfName% "Erdos1056.erdos_1056") := by
  solve_by_elim
#print axioms probe_1_34

-- ATTACK fc-379fc029-erdos1056-erdos-1056-7337ef85af-counterexample-v1 first_order
theorem probe_1_35 : ¬ (fcTypeOfName% "Erdos1056.erdos_1056") := by
  first_order
#print axioms probe_1_35

-- ATTACK fc-379fc029-erdos1056-erdos-1056-7337ef85af-counterexample-v1 grind
theorem probe_1_36 : ¬ (fcTypeOfName% "Erdos1056.erdos_1056") := by
  grind
#print axioms probe_1_36

-- ATTACK fc-379fc029-erdos1056-erdos-1056-7337ef85af-counterexample-v1 exact_search
theorem probe_1_37 : ¬ (fcTypeOfName% "Erdos1056.erdos_1056") := by
  exact?
#print axioms probe_1_37

-- ATTACK fc-379fc029-erdos1056-erdos-1056-7337ef85af-counterexample-v1 apply_search
theorem probe_1_38 : ¬ (fcTypeOfName% "Erdos1056.erdos_1056") := by
  apply?
#print axioms probe_1_38

-- ATTACK fc-379fc029-erdos1056-erdos-1056-7337ef85af-counterexample-v1 library_search
theorem probe_1_39 : ¬ (fcTypeOfName% "Erdos1056.erdos_1056") := by
  library_search
#print axioms probe_1_39

-- ATTACK fc-379fc029-erdos1056-erdos-1056-7337ef85af-counterexample-v1 aesop_search
theorem probe_1_40 : ¬ (fcTypeOfName% "Erdos1056.erdos_1056") := by
  aesop?
#print axioms probe_1_40

-- ATTACK fc-379fc029-erdos1056-erdos-1056-7337ef85af-counterexample-v1 simp_search
theorem probe_1_41 : ¬ (fcTypeOfName% "Erdos1056.erdos_1056") := by
  simp?
#print axioms probe_1_41

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-78532010aa-counterexample-v1 simp
theorem probe_1_42 : ¬ (fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek") := by
  simp
#print axioms probe_1_42

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-78532010aa-counterexample-v1 simpa
theorem probe_1_43 : ¬ (fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek") := by
  simpa
#print axioms probe_1_43

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-78532010aa-counterexample-v1 simp_all
theorem probe_1_44 : ¬ (fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek") := by
  simp_all
#print axioms probe_1_44

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-78532010aa-counterexample-v1 aesop
theorem probe_1_45 : ¬ (fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek") := by
  aesop
#print axioms probe_1_45

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-78532010aa-counterexample-v1 omega
theorem probe_1_46 : ¬ (fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek") := by
  omega
#print axioms probe_1_46

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-78532010aa-counterexample-v1 norm_num
theorem probe_1_47 : ¬ (fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek") := by
  norm_num
#print axioms probe_1_47

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-78532010aa-counterexample-v1 decide
theorem probe_1_48 : ¬ (fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek") := by
  decide
#print axioms probe_1_48

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-78532010aa-counterexample-v1 native_decide
theorem probe_1_49 : ¬ (fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek") := by
  native_decide
#print axioms probe_1_49

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-78532010aa-counterexample-v1 true_intro
theorem probe_1_50 : ¬ (fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek") := by
  exact True.intro
#print axioms probe_1_50

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-78532010aa-counterexample-v1 false_elim_simp
theorem probe_1_51 : ¬ (fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek") := by
  apply False.elim
  simp_all
#print axioms probe_1_51

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-78532010aa-counterexample-v1 constructor
theorem probe_1_52 : ¬ (fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek") := by
  constructor
#print axioms probe_1_52

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-78532010aa-counterexample-v1 constructor_simp
theorem probe_1_53 : ¬ (fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek") := by
  constructor <;> simp
#print axioms probe_1_53

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-78532010aa-counterexample-v1 constructor_aesop
theorem probe_1_54 : ¬ (fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek") := by
  constructor <;> aesop
#print axioms probe_1_54

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-78532010aa-counterexample-v1 rfl
theorem probe_1_55 : ¬ (fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek") := by
  rfl
#print axioms probe_1_55

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-78532010aa-counterexample-v1 trivial
theorem probe_1_56 : ¬ (fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek") := by
  trivial
#print axioms probe_1_56

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-78532010aa-counterexample-v1 tauto
theorem probe_1_57 : ¬ (fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek") := by
  tauto
#print axioms probe_1_57

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-78532010aa-counterexample-v1 positivity
theorem probe_1_58 : ¬ (fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek") := by
  positivity
#print axioms probe_1_58

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-78532010aa-counterexample-v1 linarith
theorem probe_1_59 : ¬ (fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek") := by
  linarith
#print axioms probe_1_59

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-78532010aa-counterexample-v1 nlinarith
theorem probe_1_60 : ¬ (fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek") := by
  nlinarith
#print axioms probe_1_60

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-78532010aa-counterexample-v1 intros_simp_all
theorem probe_1_61 : ¬ (fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek") := by
  intros
  simp_all
#print axioms probe_1_61

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-78532010aa-counterexample-v1 intros_omega
theorem probe_1_62 : ¬ (fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek") := by
  intros
  omega
#print axioms probe_1_62

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-78532010aa-counterexample-v1 intros_norm_num
theorem probe_1_63 : ¬ (fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek") := by
  intros
  norm_num at *
#print axioms probe_1_63

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-78532010aa-counterexample-v1 intros_aesop
theorem probe_1_64 : ¬ (fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek") := by
  intros
  aesop
#print axioms probe_1_64

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-78532010aa-counterexample-v1 by_contra_simp_all
theorem probe_1_65 : ¬ (fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek") := by
  by_contra h
  simp_all
#print axioms probe_1_65

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-78532010aa-counterexample-v1 classical_simp_all
theorem probe_1_66 : ¬ (fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek") := by
  classical
  simp_all
#print axioms probe_1_66

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-78532010aa-counterexample-v1 classical_aesop
theorem probe_1_67 : ¬ (fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek") := by
  classical
  aesop
#print axioms probe_1_67

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-78532010aa-counterexample-v1 refine_pair_simp
theorem probe_1_68 : ¬ (fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek") := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_1_68

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-78532010aa-counterexample-v1 refine_pair_aesop
theorem probe_1_69 : ¬ (fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek") := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_1_69

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-78532010aa-counterexample-v1 use_zero_simp
theorem probe_1_70 : ¬ (fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek") := by
  use 0 <;> simp
#print axioms probe_1_70

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-78532010aa-counterexample-v1 use_one_simp
theorem probe_1_71 : ¬ (fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek") := by
  use 1 <;> simp
#print axioms probe_1_71

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-78532010aa-counterexample-v1 use_empty_simp
theorem probe_1_72 : ¬ (fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek") := by
  use ∅ <;> simp
#print axioms probe_1_72

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-78532010aa-counterexample-v1 assumption
theorem probe_1_73 : ¬ (fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek") := by
  assumption
#print axioms probe_1_73

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-78532010aa-counterexample-v1 infer_instance
theorem probe_1_74 : ¬ (fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek") := by
  infer_instance
#print axioms probe_1_74

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-78532010aa-counterexample-v1 contradiction
theorem probe_1_75 : ¬ (fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek") := by
  contradiction
#print axioms probe_1_75

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-78532010aa-counterexample-v1 solve_by_elim
theorem probe_1_76 : ¬ (fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek") := by
  solve_by_elim
#print axioms probe_1_76

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-78532010aa-counterexample-v1 first_order
theorem probe_1_77 : ¬ (fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek") := by
  first_order
#print axioms probe_1_77

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-78532010aa-counterexample-v1 grind
theorem probe_1_78 : ¬ (fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek") := by
  grind
#print axioms probe_1_78

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-78532010aa-counterexample-v1 exact_search
theorem probe_1_79 : ¬ (fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek") := by
  exact?
#print axioms probe_1_79

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-78532010aa-counterexample-v1 apply_search
theorem probe_1_80 : ¬ (fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek") := by
  apply?
#print axioms probe_1_80

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-78532010aa-counterexample-v1 library_search
theorem probe_1_81 : ¬ (fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek") := by
  library_search
#print axioms probe_1_81

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-78532010aa-counterexample-v1 aesop_search
theorem probe_1_82 : ¬ (fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek") := by
  aesop?
#print axioms probe_1_82

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-78532010aa-counterexample-v1 simp_search
theorem probe_1_83 : ¬ (fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek") := by
  simp?
#print axioms probe_1_83

-- ATTACK fc-379fc029-parts-i-3c13034a0b-counterexample-v1 simp
theorem probe_1_84 : ¬ (fcTypeOfName% "Erdos14.erdos_14.parts.i") := by
  simp
#print axioms probe_1_84

-- ATTACK fc-379fc029-parts-i-3c13034a0b-counterexample-v1 simpa
theorem probe_1_85 : ¬ (fcTypeOfName% "Erdos14.erdos_14.parts.i") := by
  simpa
#print axioms probe_1_85

-- ATTACK fc-379fc029-parts-i-3c13034a0b-counterexample-v1 simp_all
theorem probe_1_86 : ¬ (fcTypeOfName% "Erdos14.erdos_14.parts.i") := by
  simp_all
#print axioms probe_1_86

-- ATTACK fc-379fc029-parts-i-3c13034a0b-counterexample-v1 aesop
theorem probe_1_87 : ¬ (fcTypeOfName% "Erdos14.erdos_14.parts.i") := by
  aesop
#print axioms probe_1_87

-- ATTACK fc-379fc029-parts-i-3c13034a0b-counterexample-v1 omega
theorem probe_1_88 : ¬ (fcTypeOfName% "Erdos14.erdos_14.parts.i") := by
  omega
#print axioms probe_1_88

-- ATTACK fc-379fc029-parts-i-3c13034a0b-counterexample-v1 norm_num
theorem probe_1_89 : ¬ (fcTypeOfName% "Erdos14.erdos_14.parts.i") := by
  norm_num
#print axioms probe_1_89

-- ATTACK fc-379fc029-parts-i-3c13034a0b-counterexample-v1 decide
theorem probe_1_90 : ¬ (fcTypeOfName% "Erdos14.erdos_14.parts.i") := by
  decide
#print axioms probe_1_90

-- ATTACK fc-379fc029-parts-i-3c13034a0b-counterexample-v1 native_decide
theorem probe_1_91 : ¬ (fcTypeOfName% "Erdos14.erdos_14.parts.i") := by
  native_decide
#print axioms probe_1_91

-- ATTACK fc-379fc029-parts-i-3c13034a0b-counterexample-v1 true_intro
theorem probe_1_92 : ¬ (fcTypeOfName% "Erdos14.erdos_14.parts.i") := by
  exact True.intro
#print axioms probe_1_92

-- ATTACK fc-379fc029-parts-i-3c13034a0b-counterexample-v1 false_elim_simp
theorem probe_1_93 : ¬ (fcTypeOfName% "Erdos14.erdos_14.parts.i") := by
  apply False.elim
  simp_all
#print axioms probe_1_93

-- ATTACK fc-379fc029-parts-i-3c13034a0b-counterexample-v1 constructor
theorem probe_1_94 : ¬ (fcTypeOfName% "Erdos14.erdos_14.parts.i") := by
  constructor
#print axioms probe_1_94

-- ATTACK fc-379fc029-parts-i-3c13034a0b-counterexample-v1 constructor_simp
theorem probe_1_95 : ¬ (fcTypeOfName% "Erdos14.erdos_14.parts.i") := by
  constructor <;> simp
#print axioms probe_1_95

-- ATTACK fc-379fc029-parts-i-3c13034a0b-counterexample-v1 constructor_aesop
theorem probe_1_96 : ¬ (fcTypeOfName% "Erdos14.erdos_14.parts.i") := by
  constructor <;> aesop
#print axioms probe_1_96

-- ATTACK fc-379fc029-parts-i-3c13034a0b-counterexample-v1 rfl
theorem probe_1_97 : ¬ (fcTypeOfName% "Erdos14.erdos_14.parts.i") := by
  rfl
#print axioms probe_1_97

-- ATTACK fc-379fc029-parts-i-3c13034a0b-counterexample-v1 trivial
theorem probe_1_98 : ¬ (fcTypeOfName% "Erdos14.erdos_14.parts.i") := by
  trivial
#print axioms probe_1_98

-- ATTACK fc-379fc029-parts-i-3c13034a0b-counterexample-v1 tauto
theorem probe_1_99 : ¬ (fcTypeOfName% "Erdos14.erdos_14.parts.i") := by
  tauto
#print axioms probe_1_99

-- ATTACK fc-379fc029-parts-i-3c13034a0b-counterexample-v1 positivity
theorem probe_1_100 : ¬ (fcTypeOfName% "Erdos14.erdos_14.parts.i") := by
  positivity
#print axioms probe_1_100

-- ATTACK fc-379fc029-parts-i-3c13034a0b-counterexample-v1 linarith
theorem probe_1_101 : ¬ (fcTypeOfName% "Erdos14.erdos_14.parts.i") := by
  linarith
#print axioms probe_1_101

-- ATTACK fc-379fc029-parts-i-3c13034a0b-counterexample-v1 nlinarith
theorem probe_1_102 : ¬ (fcTypeOfName% "Erdos14.erdos_14.parts.i") := by
  nlinarith
#print axioms probe_1_102

-- ATTACK fc-379fc029-parts-i-3c13034a0b-counterexample-v1 intros_simp_all
theorem probe_1_103 : ¬ (fcTypeOfName% "Erdos14.erdos_14.parts.i") := by
  intros
  simp_all
#print axioms probe_1_103

-- ATTACK fc-379fc029-parts-i-3c13034a0b-counterexample-v1 intros_omega
theorem probe_1_104 : ¬ (fcTypeOfName% "Erdos14.erdos_14.parts.i") := by
  intros
  omega
#print axioms probe_1_104

-- ATTACK fc-379fc029-parts-i-3c13034a0b-counterexample-v1 intros_norm_num
theorem probe_1_105 : ¬ (fcTypeOfName% "Erdos14.erdos_14.parts.i") := by
  intros
  norm_num at *
#print axioms probe_1_105

-- ATTACK fc-379fc029-parts-i-3c13034a0b-counterexample-v1 intros_aesop
theorem probe_1_106 : ¬ (fcTypeOfName% "Erdos14.erdos_14.parts.i") := by
  intros
  aesop
#print axioms probe_1_106

-- ATTACK fc-379fc029-parts-i-3c13034a0b-counterexample-v1 by_contra_simp_all
theorem probe_1_107 : ¬ (fcTypeOfName% "Erdos14.erdos_14.parts.i") := by
  by_contra h
  simp_all
#print axioms probe_1_107

-- ATTACK fc-379fc029-parts-i-3c13034a0b-counterexample-v1 classical_simp_all
theorem probe_1_108 : ¬ (fcTypeOfName% "Erdos14.erdos_14.parts.i") := by
  classical
  simp_all
#print axioms probe_1_108

-- ATTACK fc-379fc029-parts-i-3c13034a0b-counterexample-v1 classical_aesop
theorem probe_1_109 : ¬ (fcTypeOfName% "Erdos14.erdos_14.parts.i") := by
  classical
  aesop
#print axioms probe_1_109

-- ATTACK fc-379fc029-parts-i-3c13034a0b-counterexample-v1 refine_pair_simp
theorem probe_1_110 : ¬ (fcTypeOfName% "Erdos14.erdos_14.parts.i") := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_1_110

-- ATTACK fc-379fc029-parts-i-3c13034a0b-counterexample-v1 refine_pair_aesop
theorem probe_1_111 : ¬ (fcTypeOfName% "Erdos14.erdos_14.parts.i") := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_1_111

-- ATTACK fc-379fc029-parts-i-3c13034a0b-counterexample-v1 use_zero_simp
theorem probe_1_112 : ¬ (fcTypeOfName% "Erdos14.erdos_14.parts.i") := by
  use 0 <;> simp
#print axioms probe_1_112

-- ATTACK fc-379fc029-parts-i-3c13034a0b-counterexample-v1 use_one_simp
theorem probe_1_113 : ¬ (fcTypeOfName% "Erdos14.erdos_14.parts.i") := by
  use 1 <;> simp
#print axioms probe_1_113

-- ATTACK fc-379fc029-parts-i-3c13034a0b-counterexample-v1 use_empty_simp
theorem probe_1_114 : ¬ (fcTypeOfName% "Erdos14.erdos_14.parts.i") := by
  use ∅ <;> simp
#print axioms probe_1_114

-- ATTACK fc-379fc029-parts-i-3c13034a0b-counterexample-v1 assumption
theorem probe_1_115 : ¬ (fcTypeOfName% "Erdos14.erdos_14.parts.i") := by
  assumption
#print axioms probe_1_115

-- ATTACK fc-379fc029-parts-i-3c13034a0b-counterexample-v1 infer_instance
theorem probe_1_116 : ¬ (fcTypeOfName% "Erdos14.erdos_14.parts.i") := by
  infer_instance
#print axioms probe_1_116

-- ATTACK fc-379fc029-parts-i-3c13034a0b-counterexample-v1 contradiction
theorem probe_1_117 : ¬ (fcTypeOfName% "Erdos14.erdos_14.parts.i") := by
  contradiction
#print axioms probe_1_117

-- ATTACK fc-379fc029-parts-i-3c13034a0b-counterexample-v1 solve_by_elim
theorem probe_1_118 : ¬ (fcTypeOfName% "Erdos14.erdos_14.parts.i") := by
  solve_by_elim
#print axioms probe_1_118

-- ATTACK fc-379fc029-parts-i-3c13034a0b-counterexample-v1 first_order
theorem probe_1_119 : ¬ (fcTypeOfName% "Erdos14.erdos_14.parts.i") := by
  first_order
#print axioms probe_1_119

-- ATTACK fc-379fc029-parts-i-3c13034a0b-counterexample-v1 grind
theorem probe_1_120 : ¬ (fcTypeOfName% "Erdos14.erdos_14.parts.i") := by
  grind
#print axioms probe_1_120

-- ATTACK fc-379fc029-parts-i-3c13034a0b-counterexample-v1 exact_search
theorem probe_1_121 : ¬ (fcTypeOfName% "Erdos14.erdos_14.parts.i") := by
  exact?
#print axioms probe_1_121

-- ATTACK fc-379fc029-parts-i-3c13034a0b-counterexample-v1 apply_search
theorem probe_1_122 : ¬ (fcTypeOfName% "Erdos14.erdos_14.parts.i") := by
  apply?
#print axioms probe_1_122

-- ATTACK fc-379fc029-parts-i-3c13034a0b-counterexample-v1 library_search
theorem probe_1_123 : ¬ (fcTypeOfName% "Erdos14.erdos_14.parts.i") := by
  library_search
#print axioms probe_1_123

-- ATTACK fc-379fc029-parts-i-3c13034a0b-counterexample-v1 aesop_search
theorem probe_1_124 : ¬ (fcTypeOfName% "Erdos14.erdos_14.parts.i") := by
  aesop?
#print axioms probe_1_124

-- ATTACK fc-379fc029-parts-i-3c13034a0b-counterexample-v1 simp_search
theorem probe_1_125 : ¬ (fcTypeOfName% "Erdos14.erdos_14.parts.i") := by
  simp?
#print axioms probe_1_125

-- ATTACK fc-379fc029-erdos287-erdos-287-3d36036cec-counterexample-v1 simp
theorem probe_1_126 : ¬ (fcTypeOfName% "Erdos287.erdos_287") := by
  simp
#print axioms probe_1_126

-- ATTACK fc-379fc029-erdos287-erdos-287-3d36036cec-counterexample-v1 simpa
theorem probe_1_127 : ¬ (fcTypeOfName% "Erdos287.erdos_287") := by
  simpa
#print axioms probe_1_127

-- ATTACK fc-379fc029-erdos287-erdos-287-3d36036cec-counterexample-v1 simp_all
theorem probe_1_128 : ¬ (fcTypeOfName% "Erdos287.erdos_287") := by
  simp_all
#print axioms probe_1_128

-- ATTACK fc-379fc029-erdos287-erdos-287-3d36036cec-counterexample-v1 aesop
theorem probe_1_129 : ¬ (fcTypeOfName% "Erdos287.erdos_287") := by
  aesop
#print axioms probe_1_129

-- ATTACK fc-379fc029-erdos287-erdos-287-3d36036cec-counterexample-v1 omega
theorem probe_1_130 : ¬ (fcTypeOfName% "Erdos287.erdos_287") := by
  omega
#print axioms probe_1_130

-- ATTACK fc-379fc029-erdos287-erdos-287-3d36036cec-counterexample-v1 norm_num
theorem probe_1_131 : ¬ (fcTypeOfName% "Erdos287.erdos_287") := by
  norm_num
#print axioms probe_1_131

-- ATTACK fc-379fc029-erdos287-erdos-287-3d36036cec-counterexample-v1 decide
theorem probe_1_132 : ¬ (fcTypeOfName% "Erdos287.erdos_287") := by
  decide
#print axioms probe_1_132

-- ATTACK fc-379fc029-erdos287-erdos-287-3d36036cec-counterexample-v1 native_decide
theorem probe_1_133 : ¬ (fcTypeOfName% "Erdos287.erdos_287") := by
  native_decide
#print axioms probe_1_133

-- ATTACK fc-379fc029-erdos287-erdos-287-3d36036cec-counterexample-v1 true_intro
theorem probe_1_134 : ¬ (fcTypeOfName% "Erdos287.erdos_287") := by
  exact True.intro
#print axioms probe_1_134

-- ATTACK fc-379fc029-erdos287-erdos-287-3d36036cec-counterexample-v1 false_elim_simp
theorem probe_1_135 : ¬ (fcTypeOfName% "Erdos287.erdos_287") := by
  apply False.elim
  simp_all
#print axioms probe_1_135

-- ATTACK fc-379fc029-erdos287-erdos-287-3d36036cec-counterexample-v1 constructor
theorem probe_1_136 : ¬ (fcTypeOfName% "Erdos287.erdos_287") := by
  constructor
#print axioms probe_1_136

-- ATTACK fc-379fc029-erdos287-erdos-287-3d36036cec-counterexample-v1 constructor_simp
theorem probe_1_137 : ¬ (fcTypeOfName% "Erdos287.erdos_287") := by
  constructor <;> simp
#print axioms probe_1_137

-- ATTACK fc-379fc029-erdos287-erdos-287-3d36036cec-counterexample-v1 constructor_aesop
theorem probe_1_138 : ¬ (fcTypeOfName% "Erdos287.erdos_287") := by
  constructor <;> aesop
#print axioms probe_1_138

-- ATTACK fc-379fc029-erdos287-erdos-287-3d36036cec-counterexample-v1 rfl
theorem probe_1_139 : ¬ (fcTypeOfName% "Erdos287.erdos_287") := by
  rfl
#print axioms probe_1_139

-- ATTACK fc-379fc029-erdos287-erdos-287-3d36036cec-counterexample-v1 trivial
theorem probe_1_140 : ¬ (fcTypeOfName% "Erdos287.erdos_287") := by
  trivial
#print axioms probe_1_140

-- ATTACK fc-379fc029-erdos287-erdos-287-3d36036cec-counterexample-v1 tauto
theorem probe_1_141 : ¬ (fcTypeOfName% "Erdos287.erdos_287") := by
  tauto
#print axioms probe_1_141

-- ATTACK fc-379fc029-erdos287-erdos-287-3d36036cec-counterexample-v1 positivity
theorem probe_1_142 : ¬ (fcTypeOfName% "Erdos287.erdos_287") := by
  positivity
#print axioms probe_1_142

-- ATTACK fc-379fc029-erdos287-erdos-287-3d36036cec-counterexample-v1 linarith
theorem probe_1_143 : ¬ (fcTypeOfName% "Erdos287.erdos_287") := by
  linarith
#print axioms probe_1_143

-- ATTACK fc-379fc029-erdos287-erdos-287-3d36036cec-counterexample-v1 nlinarith
theorem probe_1_144 : ¬ (fcTypeOfName% "Erdos287.erdos_287") := by
  nlinarith
#print axioms probe_1_144

-- ATTACK fc-379fc029-erdos287-erdos-287-3d36036cec-counterexample-v1 intros_simp_all
theorem probe_1_145 : ¬ (fcTypeOfName% "Erdos287.erdos_287") := by
  intros
  simp_all
#print axioms probe_1_145

-- ATTACK fc-379fc029-erdos287-erdos-287-3d36036cec-counterexample-v1 intros_omega
theorem probe_1_146 : ¬ (fcTypeOfName% "Erdos287.erdos_287") := by
  intros
  omega
#print axioms probe_1_146

-- ATTACK fc-379fc029-erdos287-erdos-287-3d36036cec-counterexample-v1 intros_norm_num
theorem probe_1_147 : ¬ (fcTypeOfName% "Erdos287.erdos_287") := by
  intros
  norm_num at *
#print axioms probe_1_147

-- ATTACK fc-379fc029-erdos287-erdos-287-3d36036cec-counterexample-v1 intros_aesop
theorem probe_1_148 : ¬ (fcTypeOfName% "Erdos287.erdos_287") := by
  intros
  aesop
#print axioms probe_1_148

-- ATTACK fc-379fc029-erdos287-erdos-287-3d36036cec-counterexample-v1 by_contra_simp_all
theorem probe_1_149 : ¬ (fcTypeOfName% "Erdos287.erdos_287") := by
  by_contra h
  simp_all
#print axioms probe_1_149

-- ATTACK fc-379fc029-erdos287-erdos-287-3d36036cec-counterexample-v1 classical_simp_all
theorem probe_1_150 : ¬ (fcTypeOfName% "Erdos287.erdos_287") := by
  classical
  simp_all
#print axioms probe_1_150

-- ATTACK fc-379fc029-erdos287-erdos-287-3d36036cec-counterexample-v1 classical_aesop
theorem probe_1_151 : ¬ (fcTypeOfName% "Erdos287.erdos_287") := by
  classical
  aesop
#print axioms probe_1_151

-- ATTACK fc-379fc029-erdos287-erdos-287-3d36036cec-counterexample-v1 refine_pair_simp
theorem probe_1_152 : ¬ (fcTypeOfName% "Erdos287.erdos_287") := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_1_152

-- ATTACK fc-379fc029-erdos287-erdos-287-3d36036cec-counterexample-v1 refine_pair_aesop
theorem probe_1_153 : ¬ (fcTypeOfName% "Erdos287.erdos_287") := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_1_153

-- ATTACK fc-379fc029-erdos287-erdos-287-3d36036cec-counterexample-v1 use_zero_simp
theorem probe_1_154 : ¬ (fcTypeOfName% "Erdos287.erdos_287") := by
  use 0 <;> simp
#print axioms probe_1_154

-- ATTACK fc-379fc029-erdos287-erdos-287-3d36036cec-counterexample-v1 use_one_simp
theorem probe_1_155 : ¬ (fcTypeOfName% "Erdos287.erdos_287") := by
  use 1 <;> simp
#print axioms probe_1_155

-- ATTACK fc-379fc029-erdos287-erdos-287-3d36036cec-counterexample-v1 use_empty_simp
theorem probe_1_156 : ¬ (fcTypeOfName% "Erdos287.erdos_287") := by
  use ∅ <;> simp
#print axioms probe_1_156

-- ATTACK fc-379fc029-erdos287-erdos-287-3d36036cec-counterexample-v1 assumption
theorem probe_1_157 : ¬ (fcTypeOfName% "Erdos287.erdos_287") := by
  assumption
#print axioms probe_1_157

-- ATTACK fc-379fc029-erdos287-erdos-287-3d36036cec-counterexample-v1 infer_instance
theorem probe_1_158 : ¬ (fcTypeOfName% "Erdos287.erdos_287") := by
  infer_instance
#print axioms probe_1_158

-- ATTACK fc-379fc029-erdos287-erdos-287-3d36036cec-counterexample-v1 contradiction
theorem probe_1_159 : ¬ (fcTypeOfName% "Erdos287.erdos_287") := by
  contradiction
#print axioms probe_1_159

-- ATTACK fc-379fc029-erdos287-erdos-287-3d36036cec-counterexample-v1 solve_by_elim
theorem probe_1_160 : ¬ (fcTypeOfName% "Erdos287.erdos_287") := by
  solve_by_elim
#print axioms probe_1_160

-- ATTACK fc-379fc029-erdos287-erdos-287-3d36036cec-counterexample-v1 first_order
theorem probe_1_161 : ¬ (fcTypeOfName% "Erdos287.erdos_287") := by
  first_order
#print axioms probe_1_161

-- ATTACK fc-379fc029-erdos287-erdos-287-3d36036cec-counterexample-v1 grind
theorem probe_1_162 : ¬ (fcTypeOfName% "Erdos287.erdos_287") := by
  grind
#print axioms probe_1_162

-- ATTACK fc-379fc029-erdos287-erdos-287-3d36036cec-counterexample-v1 exact_search
theorem probe_1_163 : ¬ (fcTypeOfName% "Erdos287.erdos_287") := by
  exact?
#print axioms probe_1_163

-- ATTACK fc-379fc029-erdos287-erdos-287-3d36036cec-counterexample-v1 apply_search
theorem probe_1_164 : ¬ (fcTypeOfName% "Erdos287.erdos_287") := by
  apply?
#print axioms probe_1_164

-- ATTACK fc-379fc029-erdos287-erdos-287-3d36036cec-counterexample-v1 library_search
theorem probe_1_165 : ¬ (fcTypeOfName% "Erdos287.erdos_287") := by
  library_search
#print axioms probe_1_165

-- ATTACK fc-379fc029-erdos287-erdos-287-3d36036cec-counterexample-v1 aesop_search
theorem probe_1_166 : ¬ (fcTypeOfName% "Erdos287.erdos_287") := by
  aesop?
#print axioms probe_1_166

-- ATTACK fc-379fc029-erdos287-erdos-287-3d36036cec-counterexample-v1 simp_search
theorem probe_1_167 : ¬ (fcTypeOfName% "Erdos287.erdos_287") := by
  simp?
#print axioms probe_1_167

-- ATTACK fc-379fc029-erdos307-erdos-307-f292d53f02-counterexample-v1 simp
theorem probe_1_168 : ¬ (fcTypeOfName% "Erdos307.erdos_307") := by
  simp
#print axioms probe_1_168

-- ATTACK fc-379fc029-erdos307-erdos-307-f292d53f02-counterexample-v1 simpa
theorem probe_1_169 : ¬ (fcTypeOfName% "Erdos307.erdos_307") := by
  simpa
#print axioms probe_1_169

-- ATTACK fc-379fc029-erdos307-erdos-307-f292d53f02-counterexample-v1 simp_all
theorem probe_1_170 : ¬ (fcTypeOfName% "Erdos307.erdos_307") := by
  simp_all
#print axioms probe_1_170

-- ATTACK fc-379fc029-erdos307-erdos-307-f292d53f02-counterexample-v1 aesop
theorem probe_1_171 : ¬ (fcTypeOfName% "Erdos307.erdos_307") := by
  aesop
#print axioms probe_1_171

-- ATTACK fc-379fc029-erdos307-erdos-307-f292d53f02-counterexample-v1 omega
theorem probe_1_172 : ¬ (fcTypeOfName% "Erdos307.erdos_307") := by
  omega
#print axioms probe_1_172

-- ATTACK fc-379fc029-erdos307-erdos-307-f292d53f02-counterexample-v1 norm_num
theorem probe_1_173 : ¬ (fcTypeOfName% "Erdos307.erdos_307") := by
  norm_num
#print axioms probe_1_173

-- ATTACK fc-379fc029-erdos307-erdos-307-f292d53f02-counterexample-v1 decide
theorem probe_1_174 : ¬ (fcTypeOfName% "Erdos307.erdos_307") := by
  decide
#print axioms probe_1_174

-- ATTACK fc-379fc029-erdos307-erdos-307-f292d53f02-counterexample-v1 native_decide
theorem probe_1_175 : ¬ (fcTypeOfName% "Erdos307.erdos_307") := by
  native_decide
#print axioms probe_1_175

-- ATTACK fc-379fc029-erdos307-erdos-307-f292d53f02-counterexample-v1 true_intro
theorem probe_1_176 : ¬ (fcTypeOfName% "Erdos307.erdos_307") := by
  exact True.intro
#print axioms probe_1_176

-- ATTACK fc-379fc029-erdos307-erdos-307-f292d53f02-counterexample-v1 false_elim_simp
theorem probe_1_177 : ¬ (fcTypeOfName% "Erdos307.erdos_307") := by
  apply False.elim
  simp_all
#print axioms probe_1_177

-- ATTACK fc-379fc029-erdos307-erdos-307-f292d53f02-counterexample-v1 constructor
theorem probe_1_178 : ¬ (fcTypeOfName% "Erdos307.erdos_307") := by
  constructor
#print axioms probe_1_178

-- ATTACK fc-379fc029-erdos307-erdos-307-f292d53f02-counterexample-v1 constructor_simp
theorem probe_1_179 : ¬ (fcTypeOfName% "Erdos307.erdos_307") := by
  constructor <;> simp
#print axioms probe_1_179

-- ATTACK fc-379fc029-erdos307-erdos-307-f292d53f02-counterexample-v1 constructor_aesop
theorem probe_1_180 : ¬ (fcTypeOfName% "Erdos307.erdos_307") := by
  constructor <;> aesop
#print axioms probe_1_180

-- ATTACK fc-379fc029-erdos307-erdos-307-f292d53f02-counterexample-v1 rfl
theorem probe_1_181 : ¬ (fcTypeOfName% "Erdos307.erdos_307") := by
  rfl
#print axioms probe_1_181

-- ATTACK fc-379fc029-erdos307-erdos-307-f292d53f02-counterexample-v1 trivial
theorem probe_1_182 : ¬ (fcTypeOfName% "Erdos307.erdos_307") := by
  trivial
#print axioms probe_1_182

-- ATTACK fc-379fc029-erdos307-erdos-307-f292d53f02-counterexample-v1 tauto
theorem probe_1_183 : ¬ (fcTypeOfName% "Erdos307.erdos_307") := by
  tauto
#print axioms probe_1_183

-- ATTACK fc-379fc029-erdos307-erdos-307-f292d53f02-counterexample-v1 positivity
theorem probe_1_184 : ¬ (fcTypeOfName% "Erdos307.erdos_307") := by
  positivity
#print axioms probe_1_184

-- ATTACK fc-379fc029-erdos307-erdos-307-f292d53f02-counterexample-v1 linarith
theorem probe_1_185 : ¬ (fcTypeOfName% "Erdos307.erdos_307") := by
  linarith
#print axioms probe_1_185

-- ATTACK fc-379fc029-erdos307-erdos-307-f292d53f02-counterexample-v1 nlinarith
theorem probe_1_186 : ¬ (fcTypeOfName% "Erdos307.erdos_307") := by
  nlinarith
#print axioms probe_1_186

-- ATTACK fc-379fc029-erdos307-erdos-307-f292d53f02-counterexample-v1 intros_simp_all
theorem probe_1_187 : ¬ (fcTypeOfName% "Erdos307.erdos_307") := by
  intros
  simp_all
#print axioms probe_1_187

-- ATTACK fc-379fc029-erdos307-erdos-307-f292d53f02-counterexample-v1 intros_omega
theorem probe_1_188 : ¬ (fcTypeOfName% "Erdos307.erdos_307") := by
  intros
  omega
#print axioms probe_1_188

-- ATTACK fc-379fc029-erdos307-erdos-307-f292d53f02-counterexample-v1 intros_norm_num
theorem probe_1_189 : ¬ (fcTypeOfName% "Erdos307.erdos_307") := by
  intros
  norm_num at *
#print axioms probe_1_189

-- ATTACK fc-379fc029-erdos307-erdos-307-f292d53f02-counterexample-v1 intros_aesop
theorem probe_1_190 : ¬ (fcTypeOfName% "Erdos307.erdos_307") := by
  intros
  aesop
#print axioms probe_1_190

-- ATTACK fc-379fc029-erdos307-erdos-307-f292d53f02-counterexample-v1 by_contra_simp_all
theorem probe_1_191 : ¬ (fcTypeOfName% "Erdos307.erdos_307") := by
  by_contra h
  simp_all
#print axioms probe_1_191

-- ATTACK fc-379fc029-erdos307-erdos-307-f292d53f02-counterexample-v1 classical_simp_all
theorem probe_1_192 : ¬ (fcTypeOfName% "Erdos307.erdos_307") := by
  classical
  simp_all
#print axioms probe_1_192

-- ATTACK fc-379fc029-erdos307-erdos-307-f292d53f02-counterexample-v1 classical_aesop
theorem probe_1_193 : ¬ (fcTypeOfName% "Erdos307.erdos_307") := by
  classical
  aesop
#print axioms probe_1_193

-- ATTACK fc-379fc029-erdos307-erdos-307-f292d53f02-counterexample-v1 refine_pair_simp
theorem probe_1_194 : ¬ (fcTypeOfName% "Erdos307.erdos_307") := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_1_194

-- ATTACK fc-379fc029-erdos307-erdos-307-f292d53f02-counterexample-v1 refine_pair_aesop
theorem probe_1_195 : ¬ (fcTypeOfName% "Erdos307.erdos_307") := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_1_195

-- ATTACK fc-379fc029-erdos307-erdos-307-f292d53f02-counterexample-v1 use_zero_simp
theorem probe_1_196 : ¬ (fcTypeOfName% "Erdos307.erdos_307") := by
  use 0 <;> simp
#print axioms probe_1_196

-- ATTACK fc-379fc029-erdos307-erdos-307-f292d53f02-counterexample-v1 use_one_simp
theorem probe_1_197 : ¬ (fcTypeOfName% "Erdos307.erdos_307") := by
  use 1 <;> simp
#print axioms probe_1_197

-- ATTACK fc-379fc029-erdos307-erdos-307-f292d53f02-counterexample-v1 use_empty_simp
theorem probe_1_198 : ¬ (fcTypeOfName% "Erdos307.erdos_307") := by
  use ∅ <;> simp
#print axioms probe_1_198

-- ATTACK fc-379fc029-erdos307-erdos-307-f292d53f02-counterexample-v1 assumption
theorem probe_1_199 : ¬ (fcTypeOfName% "Erdos307.erdos_307") := by
  assumption
#print axioms probe_1_199

-- ATTACK fc-379fc029-erdos307-erdos-307-f292d53f02-counterexample-v1 infer_instance
theorem probe_1_200 : ¬ (fcTypeOfName% "Erdos307.erdos_307") := by
  infer_instance
#print axioms probe_1_200

-- ATTACK fc-379fc029-erdos307-erdos-307-f292d53f02-counterexample-v1 contradiction
theorem probe_1_201 : ¬ (fcTypeOfName% "Erdos307.erdos_307") := by
  contradiction
#print axioms probe_1_201

-- ATTACK fc-379fc029-erdos307-erdos-307-f292d53f02-counterexample-v1 solve_by_elim
theorem probe_1_202 : ¬ (fcTypeOfName% "Erdos307.erdos_307") := by
  solve_by_elim
#print axioms probe_1_202

-- ATTACK fc-379fc029-erdos307-erdos-307-f292d53f02-counterexample-v1 first_order
theorem probe_1_203 : ¬ (fcTypeOfName% "Erdos307.erdos_307") := by
  first_order
#print axioms probe_1_203

-- ATTACK fc-379fc029-erdos307-erdos-307-f292d53f02-counterexample-v1 grind
theorem probe_1_204 : ¬ (fcTypeOfName% "Erdos307.erdos_307") := by
  grind
#print axioms probe_1_204

-- ATTACK fc-379fc029-erdos307-erdos-307-f292d53f02-counterexample-v1 exact_search
theorem probe_1_205 : ¬ (fcTypeOfName% "Erdos307.erdos_307") := by
  exact?
#print axioms probe_1_205

-- ATTACK fc-379fc029-erdos307-erdos-307-f292d53f02-counterexample-v1 apply_search
theorem probe_1_206 : ¬ (fcTypeOfName% "Erdos307.erdos_307") := by
  apply?
#print axioms probe_1_206

-- ATTACK fc-379fc029-erdos307-erdos-307-f292d53f02-counterexample-v1 library_search
theorem probe_1_207 : ¬ (fcTypeOfName% "Erdos307.erdos_307") := by
  library_search
#print axioms probe_1_207

-- ATTACK fc-379fc029-erdos307-erdos-307-f292d53f02-counterexample-v1 aesop_search
theorem probe_1_208 : ¬ (fcTypeOfName% "Erdos307.erdos_307") := by
  aesop?
#print axioms probe_1_208

-- ATTACK fc-379fc029-erdos307-erdos-307-f292d53f02-counterexample-v1 simp_search
theorem probe_1_209 : ¬ (fcTypeOfName% "Erdos307.erdos_307") := by
  simp?
#print axioms probe_1_209

-- ATTACK fc-379fc029-parts-i-af44001ff7-counterexample-v1 simp
theorem probe_1_210 : ¬ (fcTypeOfName% "Erdos400.erdos_400.parts.i") := by
  simp
#print axioms probe_1_210

-- ATTACK fc-379fc029-parts-i-af44001ff7-counterexample-v1 simpa
theorem probe_1_211 : ¬ (fcTypeOfName% "Erdos400.erdos_400.parts.i") := by
  simpa
#print axioms probe_1_211

-- ATTACK fc-379fc029-parts-i-af44001ff7-counterexample-v1 simp_all
theorem probe_1_212 : ¬ (fcTypeOfName% "Erdos400.erdos_400.parts.i") := by
  simp_all
#print axioms probe_1_212

-- ATTACK fc-379fc029-parts-i-af44001ff7-counterexample-v1 aesop
theorem probe_1_213 : ¬ (fcTypeOfName% "Erdos400.erdos_400.parts.i") := by
  aesop
#print axioms probe_1_213

-- ATTACK fc-379fc029-parts-i-af44001ff7-counterexample-v1 omega
theorem probe_1_214 : ¬ (fcTypeOfName% "Erdos400.erdos_400.parts.i") := by
  omega
#print axioms probe_1_214

-- ATTACK fc-379fc029-parts-i-af44001ff7-counterexample-v1 norm_num
theorem probe_1_215 : ¬ (fcTypeOfName% "Erdos400.erdos_400.parts.i") := by
  norm_num
#print axioms probe_1_215

-- ATTACK fc-379fc029-parts-i-af44001ff7-counterexample-v1 decide
theorem probe_1_216 : ¬ (fcTypeOfName% "Erdos400.erdos_400.parts.i") := by
  decide
#print axioms probe_1_216

-- ATTACK fc-379fc029-parts-i-af44001ff7-counterexample-v1 native_decide
theorem probe_1_217 : ¬ (fcTypeOfName% "Erdos400.erdos_400.parts.i") := by
  native_decide
#print axioms probe_1_217

-- ATTACK fc-379fc029-parts-i-af44001ff7-counterexample-v1 true_intro
theorem probe_1_218 : ¬ (fcTypeOfName% "Erdos400.erdos_400.parts.i") := by
  exact True.intro
#print axioms probe_1_218

-- ATTACK fc-379fc029-parts-i-af44001ff7-counterexample-v1 false_elim_simp
theorem probe_1_219 : ¬ (fcTypeOfName% "Erdos400.erdos_400.parts.i") := by
  apply False.elim
  simp_all
#print axioms probe_1_219

-- ATTACK fc-379fc029-parts-i-af44001ff7-counterexample-v1 constructor
theorem probe_1_220 : ¬ (fcTypeOfName% "Erdos400.erdos_400.parts.i") := by
  constructor
#print axioms probe_1_220

-- ATTACK fc-379fc029-parts-i-af44001ff7-counterexample-v1 constructor_simp
theorem probe_1_221 : ¬ (fcTypeOfName% "Erdos400.erdos_400.parts.i") := by
  constructor <;> simp
#print axioms probe_1_221

-- ATTACK fc-379fc029-parts-i-af44001ff7-counterexample-v1 constructor_aesop
theorem probe_1_222 : ¬ (fcTypeOfName% "Erdos400.erdos_400.parts.i") := by
  constructor <;> aesop
#print axioms probe_1_222

-- ATTACK fc-379fc029-parts-i-af44001ff7-counterexample-v1 rfl
theorem probe_1_223 : ¬ (fcTypeOfName% "Erdos400.erdos_400.parts.i") := by
  rfl
#print axioms probe_1_223

-- ATTACK fc-379fc029-parts-i-af44001ff7-counterexample-v1 trivial
theorem probe_1_224 : ¬ (fcTypeOfName% "Erdos400.erdos_400.parts.i") := by
  trivial
#print axioms probe_1_224

-- ATTACK fc-379fc029-parts-i-af44001ff7-counterexample-v1 tauto
theorem probe_1_225 : ¬ (fcTypeOfName% "Erdos400.erdos_400.parts.i") := by
  tauto
#print axioms probe_1_225

-- ATTACK fc-379fc029-parts-i-af44001ff7-counterexample-v1 positivity
theorem probe_1_226 : ¬ (fcTypeOfName% "Erdos400.erdos_400.parts.i") := by
  positivity
#print axioms probe_1_226

-- ATTACK fc-379fc029-parts-i-af44001ff7-counterexample-v1 linarith
theorem probe_1_227 : ¬ (fcTypeOfName% "Erdos400.erdos_400.parts.i") := by
  linarith
#print axioms probe_1_227

-- ATTACK fc-379fc029-parts-i-af44001ff7-counterexample-v1 nlinarith
theorem probe_1_228 : ¬ (fcTypeOfName% "Erdos400.erdos_400.parts.i") := by
  nlinarith
#print axioms probe_1_228

-- ATTACK fc-379fc029-parts-i-af44001ff7-counterexample-v1 intros_simp_all
theorem probe_1_229 : ¬ (fcTypeOfName% "Erdos400.erdos_400.parts.i") := by
  intros
  simp_all
#print axioms probe_1_229

-- ATTACK fc-379fc029-parts-i-af44001ff7-counterexample-v1 intros_omega
theorem probe_1_230 : ¬ (fcTypeOfName% "Erdos400.erdos_400.parts.i") := by
  intros
  omega
#print axioms probe_1_230

-- ATTACK fc-379fc029-parts-i-af44001ff7-counterexample-v1 intros_norm_num
theorem probe_1_231 : ¬ (fcTypeOfName% "Erdos400.erdos_400.parts.i") := by
  intros
  norm_num at *
#print axioms probe_1_231

-- ATTACK fc-379fc029-parts-i-af44001ff7-counterexample-v1 intros_aesop
theorem probe_1_232 : ¬ (fcTypeOfName% "Erdos400.erdos_400.parts.i") := by
  intros
  aesop
#print axioms probe_1_232

-- ATTACK fc-379fc029-parts-i-af44001ff7-counterexample-v1 by_contra_simp_all
theorem probe_1_233 : ¬ (fcTypeOfName% "Erdos400.erdos_400.parts.i") := by
  by_contra h
  simp_all
#print axioms probe_1_233

-- ATTACK fc-379fc029-parts-i-af44001ff7-counterexample-v1 classical_simp_all
theorem probe_1_234 : ¬ (fcTypeOfName% "Erdos400.erdos_400.parts.i") := by
  classical
  simp_all
#print axioms probe_1_234

-- ATTACK fc-379fc029-parts-i-af44001ff7-counterexample-v1 classical_aesop
theorem probe_1_235 : ¬ (fcTypeOfName% "Erdos400.erdos_400.parts.i") := by
  classical
  aesop
#print axioms probe_1_235

-- ATTACK fc-379fc029-parts-i-af44001ff7-counterexample-v1 refine_pair_simp
theorem probe_1_236 : ¬ (fcTypeOfName% "Erdos400.erdos_400.parts.i") := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_1_236

-- ATTACK fc-379fc029-parts-i-af44001ff7-counterexample-v1 refine_pair_aesop
theorem probe_1_237 : ¬ (fcTypeOfName% "Erdos400.erdos_400.parts.i") := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_1_237

-- ATTACK fc-379fc029-parts-i-af44001ff7-counterexample-v1 use_zero_simp
theorem probe_1_238 : ¬ (fcTypeOfName% "Erdos400.erdos_400.parts.i") := by
  use 0 <;> simp
#print axioms probe_1_238

-- ATTACK fc-379fc029-parts-i-af44001ff7-counterexample-v1 use_one_simp
theorem probe_1_239 : ¬ (fcTypeOfName% "Erdos400.erdos_400.parts.i") := by
  use 1 <;> simp
#print axioms probe_1_239

-- ATTACK fc-379fc029-parts-i-af44001ff7-counterexample-v1 use_empty_simp
theorem probe_1_240 : ¬ (fcTypeOfName% "Erdos400.erdos_400.parts.i") := by
  use ∅ <;> simp
#print axioms probe_1_240

-- ATTACK fc-379fc029-parts-i-af44001ff7-counterexample-v1 assumption
theorem probe_1_241 : ¬ (fcTypeOfName% "Erdos400.erdos_400.parts.i") := by
  assumption
#print axioms probe_1_241

-- ATTACK fc-379fc029-parts-i-af44001ff7-counterexample-v1 infer_instance
theorem probe_1_242 : ¬ (fcTypeOfName% "Erdos400.erdos_400.parts.i") := by
  infer_instance
#print axioms probe_1_242

-- ATTACK fc-379fc029-parts-i-af44001ff7-counterexample-v1 contradiction
theorem probe_1_243 : ¬ (fcTypeOfName% "Erdos400.erdos_400.parts.i") := by
  contradiction
#print axioms probe_1_243

-- ATTACK fc-379fc029-parts-i-af44001ff7-counterexample-v1 solve_by_elim
theorem probe_1_244 : ¬ (fcTypeOfName% "Erdos400.erdos_400.parts.i") := by
  solve_by_elim
#print axioms probe_1_244

-- ATTACK fc-379fc029-parts-i-af44001ff7-counterexample-v1 first_order
theorem probe_1_245 : ¬ (fcTypeOfName% "Erdos400.erdos_400.parts.i") := by
  first_order
#print axioms probe_1_245

-- ATTACK fc-379fc029-parts-i-af44001ff7-counterexample-v1 grind
theorem probe_1_246 : ¬ (fcTypeOfName% "Erdos400.erdos_400.parts.i") := by
  grind
#print axioms probe_1_246

-- ATTACK fc-379fc029-parts-i-af44001ff7-counterexample-v1 exact_search
theorem probe_1_247 : ¬ (fcTypeOfName% "Erdos400.erdos_400.parts.i") := by
  exact?
#print axioms probe_1_247

-- ATTACK fc-379fc029-parts-i-af44001ff7-counterexample-v1 apply_search
theorem probe_1_248 : ¬ (fcTypeOfName% "Erdos400.erdos_400.parts.i") := by
  apply?
#print axioms probe_1_248

-- ATTACK fc-379fc029-parts-i-af44001ff7-counterexample-v1 library_search
theorem probe_1_249 : ¬ (fcTypeOfName% "Erdos400.erdos_400.parts.i") := by
  library_search
#print axioms probe_1_249

-- ATTACK fc-379fc029-parts-i-af44001ff7-counterexample-v1 aesop_search
theorem probe_1_250 : ¬ (fcTypeOfName% "Erdos400.erdos_400.parts.i") := by
  aesop?
#print axioms probe_1_250

-- ATTACK fc-379fc029-parts-i-af44001ff7-counterexample-v1 simp_search
theorem probe_1_251 : ¬ (fcTypeOfName% "Erdos400.erdos_400.parts.i") := by
  simp?
#print axioms probe_1_251

-- ATTACK fc-379fc029-erdos52-erdos-52-cebf46c084-counterexample-v1 simp
theorem probe_1_252 : ¬ (fcTypeOfName% "Erdos52.erdos_52") := by
  simp
#print axioms probe_1_252

-- ATTACK fc-379fc029-erdos52-erdos-52-cebf46c084-counterexample-v1 simpa
theorem probe_1_253 : ¬ (fcTypeOfName% "Erdos52.erdos_52") := by
  simpa
#print axioms probe_1_253

-- ATTACK fc-379fc029-erdos52-erdos-52-cebf46c084-counterexample-v1 simp_all
theorem probe_1_254 : ¬ (fcTypeOfName% "Erdos52.erdos_52") := by
  simp_all
#print axioms probe_1_254

-- ATTACK fc-379fc029-erdos52-erdos-52-cebf46c084-counterexample-v1 aesop
theorem probe_1_255 : ¬ (fcTypeOfName% "Erdos52.erdos_52") := by
  aesop
#print axioms probe_1_255

-- ATTACK fc-379fc029-erdos52-erdos-52-cebf46c084-counterexample-v1 omega
theorem probe_1_256 : ¬ (fcTypeOfName% "Erdos52.erdos_52") := by
  omega
#print axioms probe_1_256

-- ATTACK fc-379fc029-erdos52-erdos-52-cebf46c084-counterexample-v1 norm_num
theorem probe_1_257 : ¬ (fcTypeOfName% "Erdos52.erdos_52") := by
  norm_num
#print axioms probe_1_257

-- ATTACK fc-379fc029-erdos52-erdos-52-cebf46c084-counterexample-v1 decide
theorem probe_1_258 : ¬ (fcTypeOfName% "Erdos52.erdos_52") := by
  decide
#print axioms probe_1_258

-- ATTACK fc-379fc029-erdos52-erdos-52-cebf46c084-counterexample-v1 native_decide
theorem probe_1_259 : ¬ (fcTypeOfName% "Erdos52.erdos_52") := by
  native_decide
#print axioms probe_1_259

-- ATTACK fc-379fc029-erdos52-erdos-52-cebf46c084-counterexample-v1 true_intro
theorem probe_1_260 : ¬ (fcTypeOfName% "Erdos52.erdos_52") := by
  exact True.intro
#print axioms probe_1_260

-- ATTACK fc-379fc029-erdos52-erdos-52-cebf46c084-counterexample-v1 false_elim_simp
theorem probe_1_261 : ¬ (fcTypeOfName% "Erdos52.erdos_52") := by
  apply False.elim
  simp_all
#print axioms probe_1_261

-- ATTACK fc-379fc029-erdos52-erdos-52-cebf46c084-counterexample-v1 constructor
theorem probe_1_262 : ¬ (fcTypeOfName% "Erdos52.erdos_52") := by
  constructor
#print axioms probe_1_262

-- ATTACK fc-379fc029-erdos52-erdos-52-cebf46c084-counterexample-v1 constructor_simp
theorem probe_1_263 : ¬ (fcTypeOfName% "Erdos52.erdos_52") := by
  constructor <;> simp
#print axioms probe_1_263

-- ATTACK fc-379fc029-erdos52-erdos-52-cebf46c084-counterexample-v1 constructor_aesop
theorem probe_1_264 : ¬ (fcTypeOfName% "Erdos52.erdos_52") := by
  constructor <;> aesop
#print axioms probe_1_264

-- ATTACK fc-379fc029-erdos52-erdos-52-cebf46c084-counterexample-v1 rfl
theorem probe_1_265 : ¬ (fcTypeOfName% "Erdos52.erdos_52") := by
  rfl
#print axioms probe_1_265

-- ATTACK fc-379fc029-erdos52-erdos-52-cebf46c084-counterexample-v1 trivial
theorem probe_1_266 : ¬ (fcTypeOfName% "Erdos52.erdos_52") := by
  trivial
#print axioms probe_1_266

-- ATTACK fc-379fc029-erdos52-erdos-52-cebf46c084-counterexample-v1 tauto
theorem probe_1_267 : ¬ (fcTypeOfName% "Erdos52.erdos_52") := by
  tauto
#print axioms probe_1_267

-- ATTACK fc-379fc029-erdos52-erdos-52-cebf46c084-counterexample-v1 positivity
theorem probe_1_268 : ¬ (fcTypeOfName% "Erdos52.erdos_52") := by
  positivity
#print axioms probe_1_268

-- ATTACK fc-379fc029-erdos52-erdos-52-cebf46c084-counterexample-v1 linarith
theorem probe_1_269 : ¬ (fcTypeOfName% "Erdos52.erdos_52") := by
  linarith
#print axioms probe_1_269

-- ATTACK fc-379fc029-erdos52-erdos-52-cebf46c084-counterexample-v1 nlinarith
theorem probe_1_270 : ¬ (fcTypeOfName% "Erdos52.erdos_52") := by
  nlinarith
#print axioms probe_1_270

-- ATTACK fc-379fc029-erdos52-erdos-52-cebf46c084-counterexample-v1 intros_simp_all
theorem probe_1_271 : ¬ (fcTypeOfName% "Erdos52.erdos_52") := by
  intros
  simp_all
#print axioms probe_1_271

-- ATTACK fc-379fc029-erdos52-erdos-52-cebf46c084-counterexample-v1 intros_omega
theorem probe_1_272 : ¬ (fcTypeOfName% "Erdos52.erdos_52") := by
  intros
  omega
#print axioms probe_1_272

-- ATTACK fc-379fc029-erdos52-erdos-52-cebf46c084-counterexample-v1 intros_norm_num
theorem probe_1_273 : ¬ (fcTypeOfName% "Erdos52.erdos_52") := by
  intros
  norm_num at *
#print axioms probe_1_273

-- ATTACK fc-379fc029-erdos52-erdos-52-cebf46c084-counterexample-v1 intros_aesop
theorem probe_1_274 : ¬ (fcTypeOfName% "Erdos52.erdos_52") := by
  intros
  aesop
#print axioms probe_1_274

-- ATTACK fc-379fc029-erdos52-erdos-52-cebf46c084-counterexample-v1 by_contra_simp_all
theorem probe_1_275 : ¬ (fcTypeOfName% "Erdos52.erdos_52") := by
  by_contra h
  simp_all
#print axioms probe_1_275

-- ATTACK fc-379fc029-erdos52-erdos-52-cebf46c084-counterexample-v1 classical_simp_all
theorem probe_1_276 : ¬ (fcTypeOfName% "Erdos52.erdos_52") := by
  classical
  simp_all
#print axioms probe_1_276

-- ATTACK fc-379fc029-erdos52-erdos-52-cebf46c084-counterexample-v1 classical_aesop
theorem probe_1_277 : ¬ (fcTypeOfName% "Erdos52.erdos_52") := by
  classical
  aesop
#print axioms probe_1_277

-- ATTACK fc-379fc029-erdos52-erdos-52-cebf46c084-counterexample-v1 refine_pair_simp
theorem probe_1_278 : ¬ (fcTypeOfName% "Erdos52.erdos_52") := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_1_278

-- ATTACK fc-379fc029-erdos52-erdos-52-cebf46c084-counterexample-v1 refine_pair_aesop
theorem probe_1_279 : ¬ (fcTypeOfName% "Erdos52.erdos_52") := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_1_279

-- ATTACK fc-379fc029-erdos52-erdos-52-cebf46c084-counterexample-v1 use_zero_simp
theorem probe_1_280 : ¬ (fcTypeOfName% "Erdos52.erdos_52") := by
  use 0 <;> simp
#print axioms probe_1_280

-- ATTACK fc-379fc029-erdos52-erdos-52-cebf46c084-counterexample-v1 use_one_simp
theorem probe_1_281 : ¬ (fcTypeOfName% "Erdos52.erdos_52") := by
  use 1 <;> simp
#print axioms probe_1_281

-- ATTACK fc-379fc029-erdos52-erdos-52-cebf46c084-counterexample-v1 use_empty_simp
theorem probe_1_282 : ¬ (fcTypeOfName% "Erdos52.erdos_52") := by
  use ∅ <;> simp
#print axioms probe_1_282

-- ATTACK fc-379fc029-erdos52-erdos-52-cebf46c084-counterexample-v1 assumption
theorem probe_1_283 : ¬ (fcTypeOfName% "Erdos52.erdos_52") := by
  assumption
#print axioms probe_1_283

-- ATTACK fc-379fc029-erdos52-erdos-52-cebf46c084-counterexample-v1 infer_instance
theorem probe_1_284 : ¬ (fcTypeOfName% "Erdos52.erdos_52") := by
  infer_instance
#print axioms probe_1_284

-- ATTACK fc-379fc029-erdos52-erdos-52-cebf46c084-counterexample-v1 contradiction
theorem probe_1_285 : ¬ (fcTypeOfName% "Erdos52.erdos_52") := by
  contradiction
#print axioms probe_1_285

-- ATTACK fc-379fc029-erdos52-erdos-52-cebf46c084-counterexample-v1 solve_by_elim
theorem probe_1_286 : ¬ (fcTypeOfName% "Erdos52.erdos_52") := by
  solve_by_elim
#print axioms probe_1_286

-- ATTACK fc-379fc029-erdos52-erdos-52-cebf46c084-counterexample-v1 first_order
theorem probe_1_287 : ¬ (fcTypeOfName% "Erdos52.erdos_52") := by
  first_order
#print axioms probe_1_287

-- ATTACK fc-379fc029-erdos52-erdos-52-cebf46c084-counterexample-v1 grind
theorem probe_1_288 : ¬ (fcTypeOfName% "Erdos52.erdos_52") := by
  grind
#print axioms probe_1_288

-- ATTACK fc-379fc029-erdos52-erdos-52-cebf46c084-counterexample-v1 exact_search
theorem probe_1_289 : ¬ (fcTypeOfName% "Erdos52.erdos_52") := by
  exact?
#print axioms probe_1_289

-- ATTACK fc-379fc029-erdos52-erdos-52-cebf46c084-counterexample-v1 apply_search
theorem probe_1_290 : ¬ (fcTypeOfName% "Erdos52.erdos_52") := by
  apply?
#print axioms probe_1_290

-- ATTACK fc-379fc029-erdos52-erdos-52-cebf46c084-counterexample-v1 library_search
theorem probe_1_291 : ¬ (fcTypeOfName% "Erdos52.erdos_52") := by
  library_search
#print axioms probe_1_291

-- ATTACK fc-379fc029-erdos52-erdos-52-cebf46c084-counterexample-v1 aesop_search
theorem probe_1_292 : ¬ (fcTypeOfName% "Erdos52.erdos_52") := by
  aesop?
#print axioms probe_1_292

-- ATTACK fc-379fc029-erdos52-erdos-52-cebf46c084-counterexample-v1 simp_search
theorem probe_1_293 : ¬ (fcTypeOfName% "Erdos52.erdos_52") := by
  simp?
#print axioms probe_1_293

-- ATTACK fc-379fc029-variants-twenty-five-64509c04ff-counterexample-v1 simp
theorem probe_1_294 : ¬ (fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five") := by
  simp
#print axioms probe_1_294

-- ATTACK fc-379fc029-variants-twenty-five-64509c04ff-counterexample-v1 simpa
theorem probe_1_295 : ¬ (fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five") := by
  simpa
#print axioms probe_1_295

-- ATTACK fc-379fc029-variants-twenty-five-64509c04ff-counterexample-v1 simp_all
theorem probe_1_296 : ¬ (fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five") := by
  simp_all
#print axioms probe_1_296

-- ATTACK fc-379fc029-variants-twenty-five-64509c04ff-counterexample-v1 aesop
theorem probe_1_297 : ¬ (fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five") := by
  aesop
#print axioms probe_1_297

-- ATTACK fc-379fc029-variants-twenty-five-64509c04ff-counterexample-v1 omega
theorem probe_1_298 : ¬ (fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five") := by
  omega
#print axioms probe_1_298

-- ATTACK fc-379fc029-variants-twenty-five-64509c04ff-counterexample-v1 norm_num
theorem probe_1_299 : ¬ (fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five") := by
  norm_num
#print axioms probe_1_299

-- ATTACK fc-379fc029-variants-twenty-five-64509c04ff-counterexample-v1 decide
theorem probe_1_300 : ¬ (fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five") := by
  decide
#print axioms probe_1_300

-- ATTACK fc-379fc029-variants-twenty-five-64509c04ff-counterexample-v1 native_decide
theorem probe_1_301 : ¬ (fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five") := by
  native_decide
#print axioms probe_1_301

-- ATTACK fc-379fc029-variants-twenty-five-64509c04ff-counterexample-v1 true_intro
theorem probe_1_302 : ¬ (fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five") := by
  exact True.intro
#print axioms probe_1_302

-- ATTACK fc-379fc029-variants-twenty-five-64509c04ff-counterexample-v1 false_elim_simp
theorem probe_1_303 : ¬ (fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five") := by
  apply False.elim
  simp_all
#print axioms probe_1_303

-- ATTACK fc-379fc029-variants-twenty-five-64509c04ff-counterexample-v1 constructor
theorem probe_1_304 : ¬ (fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five") := by
  constructor
#print axioms probe_1_304

-- ATTACK fc-379fc029-variants-twenty-five-64509c04ff-counterexample-v1 constructor_simp
theorem probe_1_305 : ¬ (fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five") := by
  constructor <;> simp
#print axioms probe_1_305

-- ATTACK fc-379fc029-variants-twenty-five-64509c04ff-counterexample-v1 constructor_aesop
theorem probe_1_306 : ¬ (fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five") := by
  constructor <;> aesop
#print axioms probe_1_306

-- ATTACK fc-379fc029-variants-twenty-five-64509c04ff-counterexample-v1 rfl
theorem probe_1_307 : ¬ (fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five") := by
  rfl
#print axioms probe_1_307

-- ATTACK fc-379fc029-variants-twenty-five-64509c04ff-counterexample-v1 trivial
theorem probe_1_308 : ¬ (fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five") := by
  trivial
#print axioms probe_1_308

-- ATTACK fc-379fc029-variants-twenty-five-64509c04ff-counterexample-v1 tauto
theorem probe_1_309 : ¬ (fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five") := by
  tauto
#print axioms probe_1_309

-- ATTACK fc-379fc029-variants-twenty-five-64509c04ff-counterexample-v1 positivity
theorem probe_1_310 : ¬ (fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five") := by
  positivity
#print axioms probe_1_310

-- ATTACK fc-379fc029-variants-twenty-five-64509c04ff-counterexample-v1 linarith
theorem probe_1_311 : ¬ (fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five") := by
  linarith
#print axioms probe_1_311

-- ATTACK fc-379fc029-variants-twenty-five-64509c04ff-counterexample-v1 nlinarith
theorem probe_1_312 : ¬ (fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five") := by
  nlinarith
#print axioms probe_1_312

-- ATTACK fc-379fc029-variants-twenty-five-64509c04ff-counterexample-v1 intros_simp_all
theorem probe_1_313 : ¬ (fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five") := by
  intros
  simp_all
#print axioms probe_1_313

-- ATTACK fc-379fc029-variants-twenty-five-64509c04ff-counterexample-v1 intros_omega
theorem probe_1_314 : ¬ (fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five") := by
  intros
  omega
#print axioms probe_1_314

-- ATTACK fc-379fc029-variants-twenty-five-64509c04ff-counterexample-v1 intros_norm_num
theorem probe_1_315 : ¬ (fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five") := by
  intros
  norm_num at *
#print axioms probe_1_315

-- ATTACK fc-379fc029-variants-twenty-five-64509c04ff-counterexample-v1 intros_aesop
theorem probe_1_316 : ¬ (fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five") := by
  intros
  aesop
#print axioms probe_1_316

-- ATTACK fc-379fc029-variants-twenty-five-64509c04ff-counterexample-v1 by_contra_simp_all
theorem probe_1_317 : ¬ (fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five") := by
  by_contra h
  simp_all
#print axioms probe_1_317

-- ATTACK fc-379fc029-variants-twenty-five-64509c04ff-counterexample-v1 classical_simp_all
theorem probe_1_318 : ¬ (fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five") := by
  classical
  simp_all
#print axioms probe_1_318

-- ATTACK fc-379fc029-variants-twenty-five-64509c04ff-counterexample-v1 classical_aesop
theorem probe_1_319 : ¬ (fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five") := by
  classical
  aesop
#print axioms probe_1_319

-- ATTACK fc-379fc029-variants-twenty-five-64509c04ff-counterexample-v1 refine_pair_simp
theorem probe_1_320 : ¬ (fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five") := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_1_320

-- ATTACK fc-379fc029-variants-twenty-five-64509c04ff-counterexample-v1 refine_pair_aesop
theorem probe_1_321 : ¬ (fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five") := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_1_321

-- ATTACK fc-379fc029-variants-twenty-five-64509c04ff-counterexample-v1 use_zero_simp
theorem probe_1_322 : ¬ (fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five") := by
  use 0 <;> simp
#print axioms probe_1_322

-- ATTACK fc-379fc029-variants-twenty-five-64509c04ff-counterexample-v1 use_one_simp
theorem probe_1_323 : ¬ (fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five") := by
  use 1 <;> simp
#print axioms probe_1_323

-- ATTACK fc-379fc029-variants-twenty-five-64509c04ff-counterexample-v1 use_empty_simp
theorem probe_1_324 : ¬ (fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five") := by
  use ∅ <;> simp
#print axioms probe_1_324

-- ATTACK fc-379fc029-variants-twenty-five-64509c04ff-counterexample-v1 assumption
theorem probe_1_325 : ¬ (fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five") := by
  assumption
#print axioms probe_1_325

-- ATTACK fc-379fc029-variants-twenty-five-64509c04ff-counterexample-v1 infer_instance
theorem probe_1_326 : ¬ (fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five") := by
  infer_instance
#print axioms probe_1_326

-- ATTACK fc-379fc029-variants-twenty-five-64509c04ff-counterexample-v1 contradiction
theorem probe_1_327 : ¬ (fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five") := by
  contradiction
#print axioms probe_1_327

-- ATTACK fc-379fc029-variants-twenty-five-64509c04ff-counterexample-v1 solve_by_elim
theorem probe_1_328 : ¬ (fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five") := by
  solve_by_elim
#print axioms probe_1_328

-- ATTACK fc-379fc029-variants-twenty-five-64509c04ff-counterexample-v1 first_order
theorem probe_1_329 : ¬ (fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five") := by
  first_order
#print axioms probe_1_329

-- ATTACK fc-379fc029-variants-twenty-five-64509c04ff-counterexample-v1 grind
theorem probe_1_330 : ¬ (fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five") := by
  grind
#print axioms probe_1_330

-- ATTACK fc-379fc029-variants-twenty-five-64509c04ff-counterexample-v1 exact_search
theorem probe_1_331 : ¬ (fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five") := by
  exact?
#print axioms probe_1_331

-- ATTACK fc-379fc029-variants-twenty-five-64509c04ff-counterexample-v1 apply_search
theorem probe_1_332 : ¬ (fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five") := by
  apply?
#print axioms probe_1_332

-- ATTACK fc-379fc029-variants-twenty-five-64509c04ff-counterexample-v1 library_search
theorem probe_1_333 : ¬ (fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five") := by
  library_search
#print axioms probe_1_333

-- ATTACK fc-379fc029-variants-twenty-five-64509c04ff-counterexample-v1 aesop_search
theorem probe_1_334 : ¬ (fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five") := by
  aesop?
#print axioms probe_1_334

-- ATTACK fc-379fc029-variants-twenty-five-64509c04ff-counterexample-v1 simp_search
theorem probe_1_335 : ¬ (fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five") := by
  simp?
#print axioms probe_1_335

-- ATTACK fc-379fc029-parts-b-ae49ddddb4-counterexample-v1 simp
theorem probe_1_336 : ¬ (fcTypeOfName% "Erdos890.erdos_890.parts.b") := by
  simp
#print axioms probe_1_336

-- ATTACK fc-379fc029-parts-b-ae49ddddb4-counterexample-v1 simpa
theorem probe_1_337 : ¬ (fcTypeOfName% "Erdos890.erdos_890.parts.b") := by
  simpa
#print axioms probe_1_337

-- ATTACK fc-379fc029-parts-b-ae49ddddb4-counterexample-v1 simp_all
theorem probe_1_338 : ¬ (fcTypeOfName% "Erdos890.erdos_890.parts.b") := by
  simp_all
#print axioms probe_1_338

-- ATTACK fc-379fc029-parts-b-ae49ddddb4-counterexample-v1 aesop
theorem probe_1_339 : ¬ (fcTypeOfName% "Erdos890.erdos_890.parts.b") := by
  aesop
#print axioms probe_1_339

-- ATTACK fc-379fc029-parts-b-ae49ddddb4-counterexample-v1 omega
theorem probe_1_340 : ¬ (fcTypeOfName% "Erdos890.erdos_890.parts.b") := by
  omega
#print axioms probe_1_340

-- ATTACK fc-379fc029-parts-b-ae49ddddb4-counterexample-v1 norm_num
theorem probe_1_341 : ¬ (fcTypeOfName% "Erdos890.erdos_890.parts.b") := by
  norm_num
#print axioms probe_1_341

-- ATTACK fc-379fc029-parts-b-ae49ddddb4-counterexample-v1 decide
theorem probe_1_342 : ¬ (fcTypeOfName% "Erdos890.erdos_890.parts.b") := by
  decide
#print axioms probe_1_342

-- ATTACK fc-379fc029-parts-b-ae49ddddb4-counterexample-v1 native_decide
theorem probe_1_343 : ¬ (fcTypeOfName% "Erdos890.erdos_890.parts.b") := by
  native_decide
#print axioms probe_1_343

-- ATTACK fc-379fc029-parts-b-ae49ddddb4-counterexample-v1 true_intro
theorem probe_1_344 : ¬ (fcTypeOfName% "Erdos890.erdos_890.parts.b") := by
  exact True.intro
#print axioms probe_1_344

-- ATTACK fc-379fc029-parts-b-ae49ddddb4-counterexample-v1 false_elim_simp
theorem probe_1_345 : ¬ (fcTypeOfName% "Erdos890.erdos_890.parts.b") := by
  apply False.elim
  simp_all
#print axioms probe_1_345

-- ATTACK fc-379fc029-parts-b-ae49ddddb4-counterexample-v1 constructor
theorem probe_1_346 : ¬ (fcTypeOfName% "Erdos890.erdos_890.parts.b") := by
  constructor
#print axioms probe_1_346

-- ATTACK fc-379fc029-parts-b-ae49ddddb4-counterexample-v1 constructor_simp
theorem probe_1_347 : ¬ (fcTypeOfName% "Erdos890.erdos_890.parts.b") := by
  constructor <;> simp
#print axioms probe_1_347

-- ATTACK fc-379fc029-parts-b-ae49ddddb4-counterexample-v1 constructor_aesop
theorem probe_1_348 : ¬ (fcTypeOfName% "Erdos890.erdos_890.parts.b") := by
  constructor <;> aesop
#print axioms probe_1_348

-- ATTACK fc-379fc029-parts-b-ae49ddddb4-counterexample-v1 rfl
theorem probe_1_349 : ¬ (fcTypeOfName% "Erdos890.erdos_890.parts.b") := by
  rfl
#print axioms probe_1_349

-- ATTACK fc-379fc029-parts-b-ae49ddddb4-counterexample-v1 trivial
theorem probe_1_350 : ¬ (fcTypeOfName% "Erdos890.erdos_890.parts.b") := by
  trivial
#print axioms probe_1_350

-- ATTACK fc-379fc029-parts-b-ae49ddddb4-counterexample-v1 tauto
theorem probe_1_351 : ¬ (fcTypeOfName% "Erdos890.erdos_890.parts.b") := by
  tauto
#print axioms probe_1_351

-- ATTACK fc-379fc029-parts-b-ae49ddddb4-counterexample-v1 positivity
theorem probe_1_352 : ¬ (fcTypeOfName% "Erdos890.erdos_890.parts.b") := by
  positivity
#print axioms probe_1_352

-- ATTACK fc-379fc029-parts-b-ae49ddddb4-counterexample-v1 linarith
theorem probe_1_353 : ¬ (fcTypeOfName% "Erdos890.erdos_890.parts.b") := by
  linarith
#print axioms probe_1_353

-- ATTACK fc-379fc029-parts-b-ae49ddddb4-counterexample-v1 nlinarith
theorem probe_1_354 : ¬ (fcTypeOfName% "Erdos890.erdos_890.parts.b") := by
  nlinarith
#print axioms probe_1_354

-- ATTACK fc-379fc029-parts-b-ae49ddddb4-counterexample-v1 intros_simp_all
theorem probe_1_355 : ¬ (fcTypeOfName% "Erdos890.erdos_890.parts.b") := by
  intros
  simp_all
#print axioms probe_1_355

-- ATTACK fc-379fc029-parts-b-ae49ddddb4-counterexample-v1 intros_omega
theorem probe_1_356 : ¬ (fcTypeOfName% "Erdos890.erdos_890.parts.b") := by
  intros
  omega
#print axioms probe_1_356

-- ATTACK fc-379fc029-parts-b-ae49ddddb4-counterexample-v1 intros_norm_num
theorem probe_1_357 : ¬ (fcTypeOfName% "Erdos890.erdos_890.parts.b") := by
  intros
  norm_num at *
#print axioms probe_1_357

-- ATTACK fc-379fc029-parts-b-ae49ddddb4-counterexample-v1 intros_aesop
theorem probe_1_358 : ¬ (fcTypeOfName% "Erdos890.erdos_890.parts.b") := by
  intros
  aesop
#print axioms probe_1_358

-- ATTACK fc-379fc029-parts-b-ae49ddddb4-counterexample-v1 by_contra_simp_all
theorem probe_1_359 : ¬ (fcTypeOfName% "Erdos890.erdos_890.parts.b") := by
  by_contra h
  simp_all
#print axioms probe_1_359

-- ATTACK fc-379fc029-parts-b-ae49ddddb4-counterexample-v1 classical_simp_all
theorem probe_1_360 : ¬ (fcTypeOfName% "Erdos890.erdos_890.parts.b") := by
  classical
  simp_all
#print axioms probe_1_360

-- ATTACK fc-379fc029-parts-b-ae49ddddb4-counterexample-v1 classical_aesop
theorem probe_1_361 : ¬ (fcTypeOfName% "Erdos890.erdos_890.parts.b") := by
  classical
  aesop
#print axioms probe_1_361

-- ATTACK fc-379fc029-parts-b-ae49ddddb4-counterexample-v1 refine_pair_simp
theorem probe_1_362 : ¬ (fcTypeOfName% "Erdos890.erdos_890.parts.b") := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_1_362

-- ATTACK fc-379fc029-parts-b-ae49ddddb4-counterexample-v1 refine_pair_aesop
theorem probe_1_363 : ¬ (fcTypeOfName% "Erdos890.erdos_890.parts.b") := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_1_363

-- ATTACK fc-379fc029-parts-b-ae49ddddb4-counterexample-v1 use_zero_simp
theorem probe_1_364 : ¬ (fcTypeOfName% "Erdos890.erdos_890.parts.b") := by
  use 0 <;> simp
#print axioms probe_1_364

-- ATTACK fc-379fc029-parts-b-ae49ddddb4-counterexample-v1 use_one_simp
theorem probe_1_365 : ¬ (fcTypeOfName% "Erdos890.erdos_890.parts.b") := by
  use 1 <;> simp
#print axioms probe_1_365

-- ATTACK fc-379fc029-parts-b-ae49ddddb4-counterexample-v1 use_empty_simp
theorem probe_1_366 : ¬ (fcTypeOfName% "Erdos890.erdos_890.parts.b") := by
  use ∅ <;> simp
#print axioms probe_1_366

-- ATTACK fc-379fc029-parts-b-ae49ddddb4-counterexample-v1 assumption
theorem probe_1_367 : ¬ (fcTypeOfName% "Erdos890.erdos_890.parts.b") := by
  assumption
#print axioms probe_1_367

-- ATTACK fc-379fc029-parts-b-ae49ddddb4-counterexample-v1 infer_instance
theorem probe_1_368 : ¬ (fcTypeOfName% "Erdos890.erdos_890.parts.b") := by
  infer_instance
#print axioms probe_1_368

-- ATTACK fc-379fc029-parts-b-ae49ddddb4-counterexample-v1 contradiction
theorem probe_1_369 : ¬ (fcTypeOfName% "Erdos890.erdos_890.parts.b") := by
  contradiction
#print axioms probe_1_369

-- ATTACK fc-379fc029-parts-b-ae49ddddb4-counterexample-v1 solve_by_elim
theorem probe_1_370 : ¬ (fcTypeOfName% "Erdos890.erdos_890.parts.b") := by
  solve_by_elim
#print axioms probe_1_370

-- ATTACK fc-379fc029-parts-b-ae49ddddb4-counterexample-v1 first_order
theorem probe_1_371 : ¬ (fcTypeOfName% "Erdos890.erdos_890.parts.b") := by
  first_order
#print axioms probe_1_371

-- ATTACK fc-379fc029-parts-b-ae49ddddb4-counterexample-v1 grind
theorem probe_1_372 : ¬ (fcTypeOfName% "Erdos890.erdos_890.parts.b") := by
  grind
#print axioms probe_1_372

-- ATTACK fc-379fc029-parts-b-ae49ddddb4-counterexample-v1 exact_search
theorem probe_1_373 : ¬ (fcTypeOfName% "Erdos890.erdos_890.parts.b") := by
  exact?
#print axioms probe_1_373

-- ATTACK fc-379fc029-parts-b-ae49ddddb4-counterexample-v1 apply_search
theorem probe_1_374 : ¬ (fcTypeOfName% "Erdos890.erdos_890.parts.b") := by
  apply?
#print axioms probe_1_374

-- ATTACK fc-379fc029-parts-b-ae49ddddb4-counterexample-v1 library_search
theorem probe_1_375 : ¬ (fcTypeOfName% "Erdos890.erdos_890.parts.b") := by
  library_search
#print axioms probe_1_375

-- ATTACK fc-379fc029-parts-b-ae49ddddb4-counterexample-v1 aesop_search
theorem probe_1_376 : ¬ (fcTypeOfName% "Erdos890.erdos_890.parts.b") := by
  aesop?
#print axioms probe_1_376

-- ATTACK fc-379fc029-parts-b-ae49ddddb4-counterexample-v1 simp_search
theorem probe_1_377 : ¬ (fcTypeOfName% "Erdos890.erdos_890.parts.b") := by
  simp?
#print axioms probe_1_377

-- ATTACK fc-379fc029-variants-factorial-add-one-77e5207192-counterexample-v1 simp
theorem probe_1_378 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one") := by
  simp
#print axioms probe_1_378

-- ATTACK fc-379fc029-variants-factorial-add-one-77e5207192-counterexample-v1 simpa
theorem probe_1_379 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one") := by
  simpa
#print axioms probe_1_379

-- ATTACK fc-379fc029-variants-factorial-add-one-77e5207192-counterexample-v1 simp_all
theorem probe_1_380 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one") := by
  simp_all
#print axioms probe_1_380

-- ATTACK fc-379fc029-variants-factorial-add-one-77e5207192-counterexample-v1 aesop
theorem probe_1_381 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one") := by
  aesop
#print axioms probe_1_381

-- ATTACK fc-379fc029-variants-factorial-add-one-77e5207192-counterexample-v1 omega
theorem probe_1_382 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one") := by
  omega
#print axioms probe_1_382

-- ATTACK fc-379fc029-variants-factorial-add-one-77e5207192-counterexample-v1 norm_num
theorem probe_1_383 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one") := by
  norm_num
#print axioms probe_1_383

-- ATTACK fc-379fc029-variants-factorial-add-one-77e5207192-counterexample-v1 decide
theorem probe_1_384 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one") := by
  decide
#print axioms probe_1_384

-- ATTACK fc-379fc029-variants-factorial-add-one-77e5207192-counterexample-v1 native_decide
theorem probe_1_385 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one") := by
  native_decide
#print axioms probe_1_385

-- ATTACK fc-379fc029-variants-factorial-add-one-77e5207192-counterexample-v1 true_intro
theorem probe_1_386 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one") := by
  exact True.intro
#print axioms probe_1_386

-- ATTACK fc-379fc029-variants-factorial-add-one-77e5207192-counterexample-v1 false_elim_simp
theorem probe_1_387 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one") := by
  apply False.elim
  simp_all
#print axioms probe_1_387

-- ATTACK fc-379fc029-variants-factorial-add-one-77e5207192-counterexample-v1 constructor
theorem probe_1_388 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one") := by
  constructor
#print axioms probe_1_388

-- ATTACK fc-379fc029-variants-factorial-add-one-77e5207192-counterexample-v1 constructor_simp
theorem probe_1_389 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one") := by
  constructor <;> simp
#print axioms probe_1_389

-- ATTACK fc-379fc029-variants-factorial-add-one-77e5207192-counterexample-v1 constructor_aesop
theorem probe_1_390 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one") := by
  constructor <;> aesop
#print axioms probe_1_390

-- ATTACK fc-379fc029-variants-factorial-add-one-77e5207192-counterexample-v1 rfl
theorem probe_1_391 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one") := by
  rfl
#print axioms probe_1_391

-- ATTACK fc-379fc029-variants-factorial-add-one-77e5207192-counterexample-v1 trivial
theorem probe_1_392 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one") := by
  trivial
#print axioms probe_1_392

-- ATTACK fc-379fc029-variants-factorial-add-one-77e5207192-counterexample-v1 tauto
theorem probe_1_393 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one") := by
  tauto
#print axioms probe_1_393

-- ATTACK fc-379fc029-variants-factorial-add-one-77e5207192-counterexample-v1 positivity
theorem probe_1_394 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one") := by
  positivity
#print axioms probe_1_394

-- ATTACK fc-379fc029-variants-factorial-add-one-77e5207192-counterexample-v1 linarith
theorem probe_1_395 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one") := by
  linarith
#print axioms probe_1_395

-- ATTACK fc-379fc029-variants-factorial-add-one-77e5207192-counterexample-v1 nlinarith
theorem probe_1_396 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one") := by
  nlinarith
#print axioms probe_1_396

-- ATTACK fc-379fc029-variants-factorial-add-one-77e5207192-counterexample-v1 intros_simp_all
theorem probe_1_397 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one") := by
  intros
  simp_all
#print axioms probe_1_397

-- ATTACK fc-379fc029-variants-factorial-add-one-77e5207192-counterexample-v1 intros_omega
theorem probe_1_398 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one") := by
  intros
  omega
#print axioms probe_1_398

-- ATTACK fc-379fc029-variants-factorial-add-one-77e5207192-counterexample-v1 intros_norm_num
theorem probe_1_399 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one") := by
  intros
  norm_num at *
#print axioms probe_1_399

-- ATTACK fc-379fc029-variants-factorial-add-one-77e5207192-counterexample-v1 intros_aesop
theorem probe_1_400 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one") := by
  intros
  aesop
#print axioms probe_1_400

-- ATTACK fc-379fc029-variants-factorial-add-one-77e5207192-counterexample-v1 by_contra_simp_all
theorem probe_1_401 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one") := by
  by_contra h
  simp_all
#print axioms probe_1_401

-- ATTACK fc-379fc029-variants-factorial-add-one-77e5207192-counterexample-v1 classical_simp_all
theorem probe_1_402 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one") := by
  classical
  simp_all
#print axioms probe_1_402

-- ATTACK fc-379fc029-variants-factorial-add-one-77e5207192-counterexample-v1 classical_aesop
theorem probe_1_403 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one") := by
  classical
  aesop
#print axioms probe_1_403

-- ATTACK fc-379fc029-variants-factorial-add-one-77e5207192-counterexample-v1 refine_pair_simp
theorem probe_1_404 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one") := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_1_404

-- ATTACK fc-379fc029-variants-factorial-add-one-77e5207192-counterexample-v1 refine_pair_aesop
theorem probe_1_405 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one") := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_1_405

-- ATTACK fc-379fc029-variants-factorial-add-one-77e5207192-counterexample-v1 use_zero_simp
theorem probe_1_406 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one") := by
  use 0 <;> simp
#print axioms probe_1_406

-- ATTACK fc-379fc029-variants-factorial-add-one-77e5207192-counterexample-v1 use_one_simp
theorem probe_1_407 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one") := by
  use 1 <;> simp
#print axioms probe_1_407

-- ATTACK fc-379fc029-variants-factorial-add-one-77e5207192-counterexample-v1 use_empty_simp
theorem probe_1_408 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one") := by
  use ∅ <;> simp
#print axioms probe_1_408

-- ATTACK fc-379fc029-variants-factorial-add-one-77e5207192-counterexample-v1 assumption
theorem probe_1_409 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one") := by
  assumption
#print axioms probe_1_409

-- ATTACK fc-379fc029-variants-factorial-add-one-77e5207192-counterexample-v1 infer_instance
theorem probe_1_410 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one") := by
  infer_instance
#print axioms probe_1_410

-- ATTACK fc-379fc029-variants-factorial-add-one-77e5207192-counterexample-v1 contradiction
theorem probe_1_411 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one") := by
  contradiction
#print axioms probe_1_411

-- ATTACK fc-379fc029-variants-factorial-add-one-77e5207192-counterexample-v1 solve_by_elim
theorem probe_1_412 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one") := by
  solve_by_elim
#print axioms probe_1_412

-- ATTACK fc-379fc029-variants-factorial-add-one-77e5207192-counterexample-v1 first_order
theorem probe_1_413 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one") := by
  first_order
#print axioms probe_1_413

-- ATTACK fc-379fc029-variants-factorial-add-one-77e5207192-counterexample-v1 grind
theorem probe_1_414 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one") := by
  grind
#print axioms probe_1_414

-- ATTACK fc-379fc029-variants-factorial-add-one-77e5207192-counterexample-v1 exact_search
theorem probe_1_415 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one") := by
  exact?
#print axioms probe_1_415

-- ATTACK fc-379fc029-variants-factorial-add-one-77e5207192-counterexample-v1 apply_search
theorem probe_1_416 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one") := by
  apply?
#print axioms probe_1_416

-- ATTACK fc-379fc029-variants-factorial-add-one-77e5207192-counterexample-v1 library_search
theorem probe_1_417 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one") := by
  library_search
#print axioms probe_1_417

-- ATTACK fc-379fc029-variants-factorial-add-one-77e5207192-counterexample-v1 aesop_search
theorem probe_1_418 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one") := by
  aesop?
#print axioms probe_1_418

-- ATTACK fc-379fc029-variants-factorial-add-one-77e5207192-counterexample-v1 simp_search
theorem probe_1_419 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one") := by
  simp?
#print axioms probe_1_419

-- ATTACK fc-379fc029-parts-iii-0566f94b03-counterexample-v1 simp
theorem probe_1_420 : ¬ (fcTypeOfName% "Erdos950.erdos_950.parts.iii") := by
  simp
#print axioms probe_1_420

-- ATTACK fc-379fc029-parts-iii-0566f94b03-counterexample-v1 simpa
theorem probe_1_421 : ¬ (fcTypeOfName% "Erdos950.erdos_950.parts.iii") := by
  simpa
#print axioms probe_1_421

-- ATTACK fc-379fc029-parts-iii-0566f94b03-counterexample-v1 simp_all
theorem probe_1_422 : ¬ (fcTypeOfName% "Erdos950.erdos_950.parts.iii") := by
  simp_all
#print axioms probe_1_422

-- ATTACK fc-379fc029-parts-iii-0566f94b03-counterexample-v1 aesop
theorem probe_1_423 : ¬ (fcTypeOfName% "Erdos950.erdos_950.parts.iii") := by
  aesop
#print axioms probe_1_423

-- ATTACK fc-379fc029-parts-iii-0566f94b03-counterexample-v1 omega
theorem probe_1_424 : ¬ (fcTypeOfName% "Erdos950.erdos_950.parts.iii") := by
  omega
#print axioms probe_1_424

-- ATTACK fc-379fc029-parts-iii-0566f94b03-counterexample-v1 norm_num
theorem probe_1_425 : ¬ (fcTypeOfName% "Erdos950.erdos_950.parts.iii") := by
  norm_num
#print axioms probe_1_425

-- ATTACK fc-379fc029-parts-iii-0566f94b03-counterexample-v1 decide
theorem probe_1_426 : ¬ (fcTypeOfName% "Erdos950.erdos_950.parts.iii") := by
  decide
#print axioms probe_1_426

-- ATTACK fc-379fc029-parts-iii-0566f94b03-counterexample-v1 native_decide
theorem probe_1_427 : ¬ (fcTypeOfName% "Erdos950.erdos_950.parts.iii") := by
  native_decide
#print axioms probe_1_427

-- ATTACK fc-379fc029-parts-iii-0566f94b03-counterexample-v1 true_intro
theorem probe_1_428 : ¬ (fcTypeOfName% "Erdos950.erdos_950.parts.iii") := by
  exact True.intro
#print axioms probe_1_428

-- ATTACK fc-379fc029-parts-iii-0566f94b03-counterexample-v1 false_elim_simp
theorem probe_1_429 : ¬ (fcTypeOfName% "Erdos950.erdos_950.parts.iii") := by
  apply False.elim
  simp_all
#print axioms probe_1_429

-- ATTACK fc-379fc029-parts-iii-0566f94b03-counterexample-v1 constructor
theorem probe_1_430 : ¬ (fcTypeOfName% "Erdos950.erdos_950.parts.iii") := by
  constructor
#print axioms probe_1_430

-- ATTACK fc-379fc029-parts-iii-0566f94b03-counterexample-v1 constructor_simp
theorem probe_1_431 : ¬ (fcTypeOfName% "Erdos950.erdos_950.parts.iii") := by
  constructor <;> simp
#print axioms probe_1_431

-- ATTACK fc-379fc029-parts-iii-0566f94b03-counterexample-v1 constructor_aesop
theorem probe_1_432 : ¬ (fcTypeOfName% "Erdos950.erdos_950.parts.iii") := by
  constructor <;> aesop
#print axioms probe_1_432

-- ATTACK fc-379fc029-parts-iii-0566f94b03-counterexample-v1 rfl
theorem probe_1_433 : ¬ (fcTypeOfName% "Erdos950.erdos_950.parts.iii") := by
  rfl
#print axioms probe_1_433

-- ATTACK fc-379fc029-parts-iii-0566f94b03-counterexample-v1 trivial
theorem probe_1_434 : ¬ (fcTypeOfName% "Erdos950.erdos_950.parts.iii") := by
  trivial
#print axioms probe_1_434

-- ATTACK fc-379fc029-parts-iii-0566f94b03-counterexample-v1 tauto
theorem probe_1_435 : ¬ (fcTypeOfName% "Erdos950.erdos_950.parts.iii") := by
  tauto
#print axioms probe_1_435

-- ATTACK fc-379fc029-parts-iii-0566f94b03-counterexample-v1 positivity
theorem probe_1_436 : ¬ (fcTypeOfName% "Erdos950.erdos_950.parts.iii") := by
  positivity
#print axioms probe_1_436

-- ATTACK fc-379fc029-parts-iii-0566f94b03-counterexample-v1 linarith
theorem probe_1_437 : ¬ (fcTypeOfName% "Erdos950.erdos_950.parts.iii") := by
  linarith
#print axioms probe_1_437

-- ATTACK fc-379fc029-parts-iii-0566f94b03-counterexample-v1 nlinarith
theorem probe_1_438 : ¬ (fcTypeOfName% "Erdos950.erdos_950.parts.iii") := by
  nlinarith
#print axioms probe_1_438

-- ATTACK fc-379fc029-parts-iii-0566f94b03-counterexample-v1 intros_simp_all
theorem probe_1_439 : ¬ (fcTypeOfName% "Erdos950.erdos_950.parts.iii") := by
  intros
  simp_all
#print axioms probe_1_439

-- ATTACK fc-379fc029-parts-iii-0566f94b03-counterexample-v1 intros_omega
theorem probe_1_440 : ¬ (fcTypeOfName% "Erdos950.erdos_950.parts.iii") := by
  intros
  omega
#print axioms probe_1_440

-- ATTACK fc-379fc029-parts-iii-0566f94b03-counterexample-v1 intros_norm_num
theorem probe_1_441 : ¬ (fcTypeOfName% "Erdos950.erdos_950.parts.iii") := by
  intros
  norm_num at *
#print axioms probe_1_441

-- ATTACK fc-379fc029-parts-iii-0566f94b03-counterexample-v1 intros_aesop
theorem probe_1_442 : ¬ (fcTypeOfName% "Erdos950.erdos_950.parts.iii") := by
  intros
  aesop
#print axioms probe_1_442

-- ATTACK fc-379fc029-parts-iii-0566f94b03-counterexample-v1 by_contra_simp_all
theorem probe_1_443 : ¬ (fcTypeOfName% "Erdos950.erdos_950.parts.iii") := by
  by_contra h
  simp_all
#print axioms probe_1_443

-- ATTACK fc-379fc029-parts-iii-0566f94b03-counterexample-v1 classical_simp_all
theorem probe_1_444 : ¬ (fcTypeOfName% "Erdos950.erdos_950.parts.iii") := by
  classical
  simp_all
#print axioms probe_1_444

-- ATTACK fc-379fc029-parts-iii-0566f94b03-counterexample-v1 classical_aesop
theorem probe_1_445 : ¬ (fcTypeOfName% "Erdos950.erdos_950.parts.iii") := by
  classical
  aesop
#print axioms probe_1_445

-- ATTACK fc-379fc029-parts-iii-0566f94b03-counterexample-v1 refine_pair_simp
theorem probe_1_446 : ¬ (fcTypeOfName% "Erdos950.erdos_950.parts.iii") := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_1_446

-- ATTACK fc-379fc029-parts-iii-0566f94b03-counterexample-v1 refine_pair_aesop
theorem probe_1_447 : ¬ (fcTypeOfName% "Erdos950.erdos_950.parts.iii") := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_1_447

-- ATTACK fc-379fc029-parts-iii-0566f94b03-counterexample-v1 use_zero_simp
theorem probe_1_448 : ¬ (fcTypeOfName% "Erdos950.erdos_950.parts.iii") := by
  use 0 <;> simp
#print axioms probe_1_448

-- ATTACK fc-379fc029-parts-iii-0566f94b03-counterexample-v1 use_one_simp
theorem probe_1_449 : ¬ (fcTypeOfName% "Erdos950.erdos_950.parts.iii") := by
  use 1 <;> simp
#print axioms probe_1_449

-- ATTACK fc-379fc029-parts-iii-0566f94b03-counterexample-v1 use_empty_simp
theorem probe_1_450 : ¬ (fcTypeOfName% "Erdos950.erdos_950.parts.iii") := by
  use ∅ <;> simp
#print axioms probe_1_450

-- ATTACK fc-379fc029-parts-iii-0566f94b03-counterexample-v1 assumption
theorem probe_1_451 : ¬ (fcTypeOfName% "Erdos950.erdos_950.parts.iii") := by
  assumption
#print axioms probe_1_451

-- ATTACK fc-379fc029-parts-iii-0566f94b03-counterexample-v1 infer_instance
theorem probe_1_452 : ¬ (fcTypeOfName% "Erdos950.erdos_950.parts.iii") := by
  infer_instance
#print axioms probe_1_452

-- ATTACK fc-379fc029-parts-iii-0566f94b03-counterexample-v1 contradiction
theorem probe_1_453 : ¬ (fcTypeOfName% "Erdos950.erdos_950.parts.iii") := by
  contradiction
#print axioms probe_1_453

-- ATTACK fc-379fc029-parts-iii-0566f94b03-counterexample-v1 solve_by_elim
theorem probe_1_454 : ¬ (fcTypeOfName% "Erdos950.erdos_950.parts.iii") := by
  solve_by_elim
#print axioms probe_1_454

-- ATTACK fc-379fc029-parts-iii-0566f94b03-counterexample-v1 first_order
theorem probe_1_455 : ¬ (fcTypeOfName% "Erdos950.erdos_950.parts.iii") := by
  first_order
#print axioms probe_1_455

-- ATTACK fc-379fc029-parts-iii-0566f94b03-counterexample-v1 grind
theorem probe_1_456 : ¬ (fcTypeOfName% "Erdos950.erdos_950.parts.iii") := by
  grind
#print axioms probe_1_456

-- ATTACK fc-379fc029-parts-iii-0566f94b03-counterexample-v1 exact_search
theorem probe_1_457 : ¬ (fcTypeOfName% "Erdos950.erdos_950.parts.iii") := by
  exact?
#print axioms probe_1_457

-- ATTACK fc-379fc029-parts-iii-0566f94b03-counterexample-v1 apply_search
theorem probe_1_458 : ¬ (fcTypeOfName% "Erdos950.erdos_950.parts.iii") := by
  apply?
#print axioms probe_1_458

-- ATTACK fc-379fc029-parts-iii-0566f94b03-counterexample-v1 library_search
theorem probe_1_459 : ¬ (fcTypeOfName% "Erdos950.erdos_950.parts.iii") := by
  library_search
#print axioms probe_1_459

-- ATTACK fc-379fc029-parts-iii-0566f94b03-counterexample-v1 aesop_search
theorem probe_1_460 : ¬ (fcTypeOfName% "Erdos950.erdos_950.parts.iii") := by
  aesop?
#print axioms probe_1_460

-- ATTACK fc-379fc029-parts-iii-0566f94b03-counterexample-v1 simp_search
theorem probe_1_461 : ¬ (fcTypeOfName% "Erdos950.erdos_950.parts.iii") := by
  simp?
#print axioms probe_1_461

-- ATTACK fc-379fc029-variants-cks05-77e3c7c8f6-counterexample-v1 simp
theorem probe_1_462 : ¬ (fcTypeOfName% "Green36.green_36.variants.cks05") := by
  simp
#print axioms probe_1_462

-- ATTACK fc-379fc029-variants-cks05-77e3c7c8f6-counterexample-v1 simpa
theorem probe_1_463 : ¬ (fcTypeOfName% "Green36.green_36.variants.cks05") := by
  simpa
#print axioms probe_1_463

-- ATTACK fc-379fc029-variants-cks05-77e3c7c8f6-counterexample-v1 simp_all
theorem probe_1_464 : ¬ (fcTypeOfName% "Green36.green_36.variants.cks05") := by
  simp_all
#print axioms probe_1_464

-- ATTACK fc-379fc029-variants-cks05-77e3c7c8f6-counterexample-v1 aesop
theorem probe_1_465 : ¬ (fcTypeOfName% "Green36.green_36.variants.cks05") := by
  aesop
#print axioms probe_1_465

-- ATTACK fc-379fc029-variants-cks05-77e3c7c8f6-counterexample-v1 omega
theorem probe_1_466 : ¬ (fcTypeOfName% "Green36.green_36.variants.cks05") := by
  omega
#print axioms probe_1_466

-- ATTACK fc-379fc029-variants-cks05-77e3c7c8f6-counterexample-v1 norm_num
theorem probe_1_467 : ¬ (fcTypeOfName% "Green36.green_36.variants.cks05") := by
  norm_num
#print axioms probe_1_467

-- ATTACK fc-379fc029-variants-cks05-77e3c7c8f6-counterexample-v1 decide
theorem probe_1_468 : ¬ (fcTypeOfName% "Green36.green_36.variants.cks05") := by
  decide
#print axioms probe_1_468

-- ATTACK fc-379fc029-variants-cks05-77e3c7c8f6-counterexample-v1 native_decide
theorem probe_1_469 : ¬ (fcTypeOfName% "Green36.green_36.variants.cks05") := by
  native_decide
#print axioms probe_1_469

-- ATTACK fc-379fc029-variants-cks05-77e3c7c8f6-counterexample-v1 true_intro
theorem probe_1_470 : ¬ (fcTypeOfName% "Green36.green_36.variants.cks05") := by
  exact True.intro
#print axioms probe_1_470

-- ATTACK fc-379fc029-variants-cks05-77e3c7c8f6-counterexample-v1 false_elim_simp
theorem probe_1_471 : ¬ (fcTypeOfName% "Green36.green_36.variants.cks05") := by
  apply False.elim
  simp_all
#print axioms probe_1_471

-- ATTACK fc-379fc029-variants-cks05-77e3c7c8f6-counterexample-v1 constructor
theorem probe_1_472 : ¬ (fcTypeOfName% "Green36.green_36.variants.cks05") := by
  constructor
#print axioms probe_1_472

-- ATTACK fc-379fc029-variants-cks05-77e3c7c8f6-counterexample-v1 constructor_simp
theorem probe_1_473 : ¬ (fcTypeOfName% "Green36.green_36.variants.cks05") := by
  constructor <;> simp
#print axioms probe_1_473

-- ATTACK fc-379fc029-variants-cks05-77e3c7c8f6-counterexample-v1 constructor_aesop
theorem probe_1_474 : ¬ (fcTypeOfName% "Green36.green_36.variants.cks05") := by
  constructor <;> aesop
#print axioms probe_1_474

-- ATTACK fc-379fc029-variants-cks05-77e3c7c8f6-counterexample-v1 rfl
theorem probe_1_475 : ¬ (fcTypeOfName% "Green36.green_36.variants.cks05") := by
  rfl
#print axioms probe_1_475

-- ATTACK fc-379fc029-variants-cks05-77e3c7c8f6-counterexample-v1 trivial
theorem probe_1_476 : ¬ (fcTypeOfName% "Green36.green_36.variants.cks05") := by
  trivial
#print axioms probe_1_476

-- ATTACK fc-379fc029-variants-cks05-77e3c7c8f6-counterexample-v1 tauto
theorem probe_1_477 : ¬ (fcTypeOfName% "Green36.green_36.variants.cks05") := by
  tauto
#print axioms probe_1_477

-- ATTACK fc-379fc029-variants-cks05-77e3c7c8f6-counterexample-v1 positivity
theorem probe_1_478 : ¬ (fcTypeOfName% "Green36.green_36.variants.cks05") := by
  positivity
#print axioms probe_1_478

-- ATTACK fc-379fc029-variants-cks05-77e3c7c8f6-counterexample-v1 linarith
theorem probe_1_479 : ¬ (fcTypeOfName% "Green36.green_36.variants.cks05") := by
  linarith
#print axioms probe_1_479

-- ATTACK fc-379fc029-variants-cks05-77e3c7c8f6-counterexample-v1 nlinarith
theorem probe_1_480 : ¬ (fcTypeOfName% "Green36.green_36.variants.cks05") := by
  nlinarith
#print axioms probe_1_480

-- ATTACK fc-379fc029-variants-cks05-77e3c7c8f6-counterexample-v1 intros_simp_all
theorem probe_1_481 : ¬ (fcTypeOfName% "Green36.green_36.variants.cks05") := by
  intros
  simp_all
#print axioms probe_1_481

-- ATTACK fc-379fc029-variants-cks05-77e3c7c8f6-counterexample-v1 intros_omega
theorem probe_1_482 : ¬ (fcTypeOfName% "Green36.green_36.variants.cks05") := by
  intros
  omega
#print axioms probe_1_482

-- ATTACK fc-379fc029-variants-cks05-77e3c7c8f6-counterexample-v1 intros_norm_num
theorem probe_1_483 : ¬ (fcTypeOfName% "Green36.green_36.variants.cks05") := by
  intros
  norm_num at *
#print axioms probe_1_483

-- ATTACK fc-379fc029-variants-cks05-77e3c7c8f6-counterexample-v1 intros_aesop
theorem probe_1_484 : ¬ (fcTypeOfName% "Green36.green_36.variants.cks05") := by
  intros
  aesop
#print axioms probe_1_484

-- ATTACK fc-379fc029-variants-cks05-77e3c7c8f6-counterexample-v1 by_contra_simp_all
theorem probe_1_485 : ¬ (fcTypeOfName% "Green36.green_36.variants.cks05") := by
  by_contra h
  simp_all
#print axioms probe_1_485

-- ATTACK fc-379fc029-variants-cks05-77e3c7c8f6-counterexample-v1 classical_simp_all
theorem probe_1_486 : ¬ (fcTypeOfName% "Green36.green_36.variants.cks05") := by
  classical
  simp_all
#print axioms probe_1_486

-- ATTACK fc-379fc029-variants-cks05-77e3c7c8f6-counterexample-v1 classical_aesop
theorem probe_1_487 : ¬ (fcTypeOfName% "Green36.green_36.variants.cks05") := by
  classical
  aesop
#print axioms probe_1_487

-- ATTACK fc-379fc029-variants-cks05-77e3c7c8f6-counterexample-v1 refine_pair_simp
theorem probe_1_488 : ¬ (fcTypeOfName% "Green36.green_36.variants.cks05") := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_1_488

-- ATTACK fc-379fc029-variants-cks05-77e3c7c8f6-counterexample-v1 refine_pair_aesop
theorem probe_1_489 : ¬ (fcTypeOfName% "Green36.green_36.variants.cks05") := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_1_489

-- ATTACK fc-379fc029-variants-cks05-77e3c7c8f6-counterexample-v1 use_zero_simp
theorem probe_1_490 : ¬ (fcTypeOfName% "Green36.green_36.variants.cks05") := by
  use 0 <;> simp
#print axioms probe_1_490

-- ATTACK fc-379fc029-variants-cks05-77e3c7c8f6-counterexample-v1 use_one_simp
theorem probe_1_491 : ¬ (fcTypeOfName% "Green36.green_36.variants.cks05") := by
  use 1 <;> simp
#print axioms probe_1_491

-- ATTACK fc-379fc029-variants-cks05-77e3c7c8f6-counterexample-v1 use_empty_simp
theorem probe_1_492 : ¬ (fcTypeOfName% "Green36.green_36.variants.cks05") := by
  use ∅ <;> simp
#print axioms probe_1_492

-- ATTACK fc-379fc029-variants-cks05-77e3c7c8f6-counterexample-v1 assumption
theorem probe_1_493 : ¬ (fcTypeOfName% "Green36.green_36.variants.cks05") := by
  assumption
#print axioms probe_1_493

-- ATTACK fc-379fc029-variants-cks05-77e3c7c8f6-counterexample-v1 infer_instance
theorem probe_1_494 : ¬ (fcTypeOfName% "Green36.green_36.variants.cks05") := by
  infer_instance
#print axioms probe_1_494

-- ATTACK fc-379fc029-variants-cks05-77e3c7c8f6-counterexample-v1 contradiction
theorem probe_1_495 : ¬ (fcTypeOfName% "Green36.green_36.variants.cks05") := by
  contradiction
#print axioms probe_1_495

-- ATTACK fc-379fc029-variants-cks05-77e3c7c8f6-counterexample-v1 solve_by_elim
theorem probe_1_496 : ¬ (fcTypeOfName% "Green36.green_36.variants.cks05") := by
  solve_by_elim
#print axioms probe_1_496

-- ATTACK fc-379fc029-variants-cks05-77e3c7c8f6-counterexample-v1 first_order
theorem probe_1_497 : ¬ (fcTypeOfName% "Green36.green_36.variants.cks05") := by
  first_order
#print axioms probe_1_497

-- ATTACK fc-379fc029-variants-cks05-77e3c7c8f6-counterexample-v1 grind
theorem probe_1_498 : ¬ (fcTypeOfName% "Green36.green_36.variants.cks05") := by
  grind
#print axioms probe_1_498

-- ATTACK fc-379fc029-variants-cks05-77e3c7c8f6-counterexample-v1 exact_search
theorem probe_1_499 : ¬ (fcTypeOfName% "Green36.green_36.variants.cks05") := by
  exact?
#print axioms probe_1_499

-- ATTACK fc-379fc029-variants-cks05-77e3c7c8f6-counterexample-v1 apply_search
theorem probe_1_500 : ¬ (fcTypeOfName% "Green36.green_36.variants.cks05") := by
  apply?
#print axioms probe_1_500

-- ATTACK fc-379fc029-variants-cks05-77e3c7c8f6-counterexample-v1 library_search
theorem probe_1_501 : ¬ (fcTypeOfName% "Green36.green_36.variants.cks05") := by
  library_search
#print axioms probe_1_501

-- ATTACK fc-379fc029-variants-cks05-77e3c7c8f6-counterexample-v1 aesop_search
theorem probe_1_502 : ¬ (fcTypeOfName% "Green36.green_36.variants.cks05") := by
  aesop?
#print axioms probe_1_502

-- ATTACK fc-379fc029-variants-cks05-77e3c7c8f6-counterexample-v1 simp_search
theorem probe_1_503 : ¬ (fcTypeOfName% "Green36.green_36.variants.cks05") := by
  simp?
#print axioms probe_1_503

-- ATTACK fc-379fc029-green66-green-66-6948611506-counterexample-v1 simp
theorem probe_1_504 : ¬ (fcTypeOfName% "Green66.green_66") := by
  simp
#print axioms probe_1_504

-- ATTACK fc-379fc029-green66-green-66-6948611506-counterexample-v1 simpa
theorem probe_1_505 : ¬ (fcTypeOfName% "Green66.green_66") := by
  simpa
#print axioms probe_1_505

-- ATTACK fc-379fc029-green66-green-66-6948611506-counterexample-v1 simp_all
theorem probe_1_506 : ¬ (fcTypeOfName% "Green66.green_66") := by
  simp_all
#print axioms probe_1_506

-- ATTACK fc-379fc029-green66-green-66-6948611506-counterexample-v1 aesop
theorem probe_1_507 : ¬ (fcTypeOfName% "Green66.green_66") := by
  aesop
#print axioms probe_1_507

-- ATTACK fc-379fc029-green66-green-66-6948611506-counterexample-v1 omega
theorem probe_1_508 : ¬ (fcTypeOfName% "Green66.green_66") := by
  omega
#print axioms probe_1_508

-- ATTACK fc-379fc029-green66-green-66-6948611506-counterexample-v1 norm_num
theorem probe_1_509 : ¬ (fcTypeOfName% "Green66.green_66") := by
  norm_num
#print axioms probe_1_509

-- ATTACK fc-379fc029-green66-green-66-6948611506-counterexample-v1 decide
theorem probe_1_510 : ¬ (fcTypeOfName% "Green66.green_66") := by
  decide
#print axioms probe_1_510

-- ATTACK fc-379fc029-green66-green-66-6948611506-counterexample-v1 native_decide
theorem probe_1_511 : ¬ (fcTypeOfName% "Green66.green_66") := by
  native_decide
#print axioms probe_1_511

-- ATTACK fc-379fc029-green66-green-66-6948611506-counterexample-v1 true_intro
theorem probe_1_512 : ¬ (fcTypeOfName% "Green66.green_66") := by
  exact True.intro
#print axioms probe_1_512

-- ATTACK fc-379fc029-green66-green-66-6948611506-counterexample-v1 false_elim_simp
theorem probe_1_513 : ¬ (fcTypeOfName% "Green66.green_66") := by
  apply False.elim
  simp_all
#print axioms probe_1_513

-- ATTACK fc-379fc029-green66-green-66-6948611506-counterexample-v1 constructor
theorem probe_1_514 : ¬ (fcTypeOfName% "Green66.green_66") := by
  constructor
#print axioms probe_1_514

-- ATTACK fc-379fc029-green66-green-66-6948611506-counterexample-v1 constructor_simp
theorem probe_1_515 : ¬ (fcTypeOfName% "Green66.green_66") := by
  constructor <;> simp
#print axioms probe_1_515

-- ATTACK fc-379fc029-green66-green-66-6948611506-counterexample-v1 constructor_aesop
theorem probe_1_516 : ¬ (fcTypeOfName% "Green66.green_66") := by
  constructor <;> aesop
#print axioms probe_1_516

-- ATTACK fc-379fc029-green66-green-66-6948611506-counterexample-v1 rfl
theorem probe_1_517 : ¬ (fcTypeOfName% "Green66.green_66") := by
  rfl
#print axioms probe_1_517

-- ATTACK fc-379fc029-green66-green-66-6948611506-counterexample-v1 trivial
theorem probe_1_518 : ¬ (fcTypeOfName% "Green66.green_66") := by
  trivial
#print axioms probe_1_518

-- ATTACK fc-379fc029-green66-green-66-6948611506-counterexample-v1 tauto
theorem probe_1_519 : ¬ (fcTypeOfName% "Green66.green_66") := by
  tauto
#print axioms probe_1_519

-- ATTACK fc-379fc029-green66-green-66-6948611506-counterexample-v1 positivity
theorem probe_1_520 : ¬ (fcTypeOfName% "Green66.green_66") := by
  positivity
#print axioms probe_1_520

-- ATTACK fc-379fc029-green66-green-66-6948611506-counterexample-v1 linarith
theorem probe_1_521 : ¬ (fcTypeOfName% "Green66.green_66") := by
  linarith
#print axioms probe_1_521

-- ATTACK fc-379fc029-green66-green-66-6948611506-counterexample-v1 nlinarith
theorem probe_1_522 : ¬ (fcTypeOfName% "Green66.green_66") := by
  nlinarith
#print axioms probe_1_522

-- ATTACK fc-379fc029-green66-green-66-6948611506-counterexample-v1 intros_simp_all
theorem probe_1_523 : ¬ (fcTypeOfName% "Green66.green_66") := by
  intros
  simp_all
#print axioms probe_1_523

-- ATTACK fc-379fc029-green66-green-66-6948611506-counterexample-v1 intros_omega
theorem probe_1_524 : ¬ (fcTypeOfName% "Green66.green_66") := by
  intros
  omega
#print axioms probe_1_524

-- ATTACK fc-379fc029-green66-green-66-6948611506-counterexample-v1 intros_norm_num
theorem probe_1_525 : ¬ (fcTypeOfName% "Green66.green_66") := by
  intros
  norm_num at *
#print axioms probe_1_525

-- ATTACK fc-379fc029-green66-green-66-6948611506-counterexample-v1 intros_aesop
theorem probe_1_526 : ¬ (fcTypeOfName% "Green66.green_66") := by
  intros
  aesop
#print axioms probe_1_526

-- ATTACK fc-379fc029-green66-green-66-6948611506-counterexample-v1 by_contra_simp_all
theorem probe_1_527 : ¬ (fcTypeOfName% "Green66.green_66") := by
  by_contra h
  simp_all
#print axioms probe_1_527

-- ATTACK fc-379fc029-green66-green-66-6948611506-counterexample-v1 classical_simp_all
theorem probe_1_528 : ¬ (fcTypeOfName% "Green66.green_66") := by
  classical
  simp_all
#print axioms probe_1_528

-- ATTACK fc-379fc029-green66-green-66-6948611506-counterexample-v1 classical_aesop
theorem probe_1_529 : ¬ (fcTypeOfName% "Green66.green_66") := by
  classical
  aesop
#print axioms probe_1_529

-- ATTACK fc-379fc029-green66-green-66-6948611506-counterexample-v1 refine_pair_simp
theorem probe_1_530 : ¬ (fcTypeOfName% "Green66.green_66") := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_1_530

-- ATTACK fc-379fc029-green66-green-66-6948611506-counterexample-v1 refine_pair_aesop
theorem probe_1_531 : ¬ (fcTypeOfName% "Green66.green_66") := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_1_531

-- ATTACK fc-379fc029-green66-green-66-6948611506-counterexample-v1 use_zero_simp
theorem probe_1_532 : ¬ (fcTypeOfName% "Green66.green_66") := by
  use 0 <;> simp
#print axioms probe_1_532

-- ATTACK fc-379fc029-green66-green-66-6948611506-counterexample-v1 use_one_simp
theorem probe_1_533 : ¬ (fcTypeOfName% "Green66.green_66") := by
  use 1 <;> simp
#print axioms probe_1_533

-- ATTACK fc-379fc029-green66-green-66-6948611506-counterexample-v1 use_empty_simp
theorem probe_1_534 : ¬ (fcTypeOfName% "Green66.green_66") := by
  use ∅ <;> simp
#print axioms probe_1_534

-- ATTACK fc-379fc029-green66-green-66-6948611506-counterexample-v1 assumption
theorem probe_1_535 : ¬ (fcTypeOfName% "Green66.green_66") := by
  assumption
#print axioms probe_1_535

-- ATTACK fc-379fc029-green66-green-66-6948611506-counterexample-v1 infer_instance
theorem probe_1_536 : ¬ (fcTypeOfName% "Green66.green_66") := by
  infer_instance
#print axioms probe_1_536

-- ATTACK fc-379fc029-green66-green-66-6948611506-counterexample-v1 contradiction
theorem probe_1_537 : ¬ (fcTypeOfName% "Green66.green_66") := by
  contradiction
#print axioms probe_1_537

-- ATTACK fc-379fc029-green66-green-66-6948611506-counterexample-v1 solve_by_elim
theorem probe_1_538 : ¬ (fcTypeOfName% "Green66.green_66") := by
  solve_by_elim
#print axioms probe_1_538

-- ATTACK fc-379fc029-green66-green-66-6948611506-counterexample-v1 first_order
theorem probe_1_539 : ¬ (fcTypeOfName% "Green66.green_66") := by
  first_order
#print axioms probe_1_539

-- ATTACK fc-379fc029-green66-green-66-6948611506-counterexample-v1 grind
theorem probe_1_540 : ¬ (fcTypeOfName% "Green66.green_66") := by
  grind
#print axioms probe_1_540

-- ATTACK fc-379fc029-green66-green-66-6948611506-counterexample-v1 exact_search
theorem probe_1_541 : ¬ (fcTypeOfName% "Green66.green_66") := by
  exact?
#print axioms probe_1_541

-- ATTACK fc-379fc029-green66-green-66-6948611506-counterexample-v1 apply_search
theorem probe_1_542 : ¬ (fcTypeOfName% "Green66.green_66") := by
  apply?
#print axioms probe_1_542

-- ATTACK fc-379fc029-green66-green-66-6948611506-counterexample-v1 library_search
theorem probe_1_543 : ¬ (fcTypeOfName% "Green66.green_66") := by
  library_search
#print axioms probe_1_543

-- ATTACK fc-379fc029-green66-green-66-6948611506-counterexample-v1 aesop_search
theorem probe_1_544 : ¬ (fcTypeOfName% "Green66.green_66") := by
  aesop?
#print axioms probe_1_544

-- ATTACK fc-379fc029-green66-green-66-6948611506-counterexample-v1 simp_search
theorem probe_1_545 : ¬ (fcTypeOfName% "Green66.green_66") := by
  simp?
#print axioms probe_1_545

end AttackBattery
