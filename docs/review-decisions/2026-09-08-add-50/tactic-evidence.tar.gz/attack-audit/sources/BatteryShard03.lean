import FormalConjectures.ErdosProblems.«1062»
import FormalConjectures.ErdosProblems.«1175»
import FormalConjectures.ErdosProblems.«168»
import FormalConjectures.ErdosProblems.«291»
import FormalConjectures.ErdosProblems.«317»
import FormalConjectures.ErdosProblems.«410»
import FormalConjectures.ErdosProblems.«61»
import FormalConjectures.ErdosProblems.«749»
import FormalConjectures.ErdosProblems.«91»
import FormalConjectures.ErdosProblems.«936»
import FormalConjectures.ErdosProblems.«962»
import FormalConjectures.GreensOpenProblems.«39»
import FormalConjectures.GreensOpenProblems.«94»
import TaskSupport

set_option maxHeartbeats 20000
namespace AttackBattery

-- ATTACK fc-379fc029-parts-ii-056fb2fabb-counterexample-v1 simp
theorem probe_3_0 : ¬ (fcTypeOfName% "Erdos1062.erdos_1062.parts.ii") := by
  simp
#print axioms probe_3_0

-- ATTACK fc-379fc029-parts-ii-056fb2fabb-counterexample-v1 simpa
theorem probe_3_1 : ¬ (fcTypeOfName% "Erdos1062.erdos_1062.parts.ii") := by
  simpa
#print axioms probe_3_1

-- ATTACK fc-379fc029-parts-ii-056fb2fabb-counterexample-v1 simp_all
theorem probe_3_2 : ¬ (fcTypeOfName% "Erdos1062.erdos_1062.parts.ii") := by
  simp_all
#print axioms probe_3_2

-- ATTACK fc-379fc029-parts-ii-056fb2fabb-counterexample-v1 aesop
theorem probe_3_3 : ¬ (fcTypeOfName% "Erdos1062.erdos_1062.parts.ii") := by
  aesop
#print axioms probe_3_3

-- ATTACK fc-379fc029-parts-ii-056fb2fabb-counterexample-v1 omega
theorem probe_3_4 : ¬ (fcTypeOfName% "Erdos1062.erdos_1062.parts.ii") := by
  omega
#print axioms probe_3_4

-- ATTACK fc-379fc029-parts-ii-056fb2fabb-counterexample-v1 norm_num
theorem probe_3_5 : ¬ (fcTypeOfName% "Erdos1062.erdos_1062.parts.ii") := by
  norm_num
#print axioms probe_3_5

-- ATTACK fc-379fc029-parts-ii-056fb2fabb-counterexample-v1 decide
theorem probe_3_6 : ¬ (fcTypeOfName% "Erdos1062.erdos_1062.parts.ii") := by
  decide
#print axioms probe_3_6

-- ATTACK fc-379fc029-parts-ii-056fb2fabb-counterexample-v1 native_decide
theorem probe_3_7 : ¬ (fcTypeOfName% "Erdos1062.erdos_1062.parts.ii") := by
  native_decide
#print axioms probe_3_7

-- ATTACK fc-379fc029-parts-ii-056fb2fabb-counterexample-v1 true_intro
theorem probe_3_8 : ¬ (fcTypeOfName% "Erdos1062.erdos_1062.parts.ii") := by
  exact True.intro
#print axioms probe_3_8

-- ATTACK fc-379fc029-parts-ii-056fb2fabb-counterexample-v1 false_elim_simp
theorem probe_3_9 : ¬ (fcTypeOfName% "Erdos1062.erdos_1062.parts.ii") := by
  apply False.elim
  simp_all
#print axioms probe_3_9

-- ATTACK fc-379fc029-parts-ii-056fb2fabb-counterexample-v1 constructor
theorem probe_3_10 : ¬ (fcTypeOfName% "Erdos1062.erdos_1062.parts.ii") := by
  constructor
#print axioms probe_3_10

-- ATTACK fc-379fc029-parts-ii-056fb2fabb-counterexample-v1 constructor_simp
theorem probe_3_11 : ¬ (fcTypeOfName% "Erdos1062.erdos_1062.parts.ii") := by
  constructor <;> simp
#print axioms probe_3_11

-- ATTACK fc-379fc029-parts-ii-056fb2fabb-counterexample-v1 constructor_aesop
theorem probe_3_12 : ¬ (fcTypeOfName% "Erdos1062.erdos_1062.parts.ii") := by
  constructor <;> aesop
#print axioms probe_3_12

-- ATTACK fc-379fc029-parts-ii-056fb2fabb-counterexample-v1 rfl
theorem probe_3_13 : ¬ (fcTypeOfName% "Erdos1062.erdos_1062.parts.ii") := by
  rfl
#print axioms probe_3_13

-- ATTACK fc-379fc029-parts-ii-056fb2fabb-counterexample-v1 trivial
theorem probe_3_14 : ¬ (fcTypeOfName% "Erdos1062.erdos_1062.parts.ii") := by
  trivial
#print axioms probe_3_14

-- ATTACK fc-379fc029-parts-ii-056fb2fabb-counterexample-v1 tauto
theorem probe_3_15 : ¬ (fcTypeOfName% "Erdos1062.erdos_1062.parts.ii") := by
  tauto
#print axioms probe_3_15

-- ATTACK fc-379fc029-parts-ii-056fb2fabb-counterexample-v1 positivity
theorem probe_3_16 : ¬ (fcTypeOfName% "Erdos1062.erdos_1062.parts.ii") := by
  positivity
#print axioms probe_3_16

-- ATTACK fc-379fc029-parts-ii-056fb2fabb-counterexample-v1 linarith
theorem probe_3_17 : ¬ (fcTypeOfName% "Erdos1062.erdos_1062.parts.ii") := by
  linarith
#print axioms probe_3_17

-- ATTACK fc-379fc029-parts-ii-056fb2fabb-counterexample-v1 nlinarith
theorem probe_3_18 : ¬ (fcTypeOfName% "Erdos1062.erdos_1062.parts.ii") := by
  nlinarith
#print axioms probe_3_18

-- ATTACK fc-379fc029-parts-ii-056fb2fabb-counterexample-v1 intros_simp_all
theorem probe_3_19 : ¬ (fcTypeOfName% "Erdos1062.erdos_1062.parts.ii") := by
  intros
  simp_all
#print axioms probe_3_19

-- ATTACK fc-379fc029-parts-ii-056fb2fabb-counterexample-v1 intros_omega
theorem probe_3_20 : ¬ (fcTypeOfName% "Erdos1062.erdos_1062.parts.ii") := by
  intros
  omega
#print axioms probe_3_20

-- ATTACK fc-379fc029-parts-ii-056fb2fabb-counterexample-v1 intros_norm_num
theorem probe_3_21 : ¬ (fcTypeOfName% "Erdos1062.erdos_1062.parts.ii") := by
  intros
  norm_num at *
#print axioms probe_3_21

-- ATTACK fc-379fc029-parts-ii-056fb2fabb-counterexample-v1 intros_aesop
theorem probe_3_22 : ¬ (fcTypeOfName% "Erdos1062.erdos_1062.parts.ii") := by
  intros
  aesop
#print axioms probe_3_22

-- ATTACK fc-379fc029-parts-ii-056fb2fabb-counterexample-v1 by_contra_simp_all
theorem probe_3_23 : ¬ (fcTypeOfName% "Erdos1062.erdos_1062.parts.ii") := by
  by_contra h
  simp_all
#print axioms probe_3_23

-- ATTACK fc-379fc029-parts-ii-056fb2fabb-counterexample-v1 classical_simp_all
theorem probe_3_24 : ¬ (fcTypeOfName% "Erdos1062.erdos_1062.parts.ii") := by
  classical
  simp_all
#print axioms probe_3_24

-- ATTACK fc-379fc029-parts-ii-056fb2fabb-counterexample-v1 classical_aesop
theorem probe_3_25 : ¬ (fcTypeOfName% "Erdos1062.erdos_1062.parts.ii") := by
  classical
  aesop
#print axioms probe_3_25

-- ATTACK fc-379fc029-parts-ii-056fb2fabb-counterexample-v1 refine_pair_simp
theorem probe_3_26 : ¬ (fcTypeOfName% "Erdos1062.erdos_1062.parts.ii") := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_3_26

-- ATTACK fc-379fc029-parts-ii-056fb2fabb-counterexample-v1 refine_pair_aesop
theorem probe_3_27 : ¬ (fcTypeOfName% "Erdos1062.erdos_1062.parts.ii") := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_3_27

-- ATTACK fc-379fc029-parts-ii-056fb2fabb-counterexample-v1 use_zero_simp
theorem probe_3_28 : ¬ (fcTypeOfName% "Erdos1062.erdos_1062.parts.ii") := by
  use 0 <;> simp
#print axioms probe_3_28

-- ATTACK fc-379fc029-parts-ii-056fb2fabb-counterexample-v1 use_one_simp
theorem probe_3_29 : ¬ (fcTypeOfName% "Erdos1062.erdos_1062.parts.ii") := by
  use 1 <;> simp
#print axioms probe_3_29

-- ATTACK fc-379fc029-parts-ii-056fb2fabb-counterexample-v1 use_empty_simp
theorem probe_3_30 : ¬ (fcTypeOfName% "Erdos1062.erdos_1062.parts.ii") := by
  use ∅ <;> simp
#print axioms probe_3_30

-- ATTACK fc-379fc029-parts-ii-056fb2fabb-counterexample-v1 assumption
theorem probe_3_31 : ¬ (fcTypeOfName% "Erdos1062.erdos_1062.parts.ii") := by
  assumption
#print axioms probe_3_31

-- ATTACK fc-379fc029-parts-ii-056fb2fabb-counterexample-v1 infer_instance
theorem probe_3_32 : ¬ (fcTypeOfName% "Erdos1062.erdos_1062.parts.ii") := by
  infer_instance
#print axioms probe_3_32

-- ATTACK fc-379fc029-parts-ii-056fb2fabb-counterexample-v1 contradiction
theorem probe_3_33 : ¬ (fcTypeOfName% "Erdos1062.erdos_1062.parts.ii") := by
  contradiction
#print axioms probe_3_33

-- ATTACK fc-379fc029-parts-ii-056fb2fabb-counterexample-v1 solve_by_elim
theorem probe_3_34 : ¬ (fcTypeOfName% "Erdos1062.erdos_1062.parts.ii") := by
  solve_by_elim
#print axioms probe_3_34

-- ATTACK fc-379fc029-parts-ii-056fb2fabb-counterexample-v1 first_order
theorem probe_3_35 : ¬ (fcTypeOfName% "Erdos1062.erdos_1062.parts.ii") := by
  first_order
#print axioms probe_3_35

-- ATTACK fc-379fc029-parts-ii-056fb2fabb-counterexample-v1 grind
theorem probe_3_36 : ¬ (fcTypeOfName% "Erdos1062.erdos_1062.parts.ii") := by
  grind
#print axioms probe_3_36

-- ATTACK fc-379fc029-parts-ii-056fb2fabb-counterexample-v1 exact_search
theorem probe_3_37 : ¬ (fcTypeOfName% "Erdos1062.erdos_1062.parts.ii") := by
  exact?
#print axioms probe_3_37

-- ATTACK fc-379fc029-parts-ii-056fb2fabb-counterexample-v1 apply_search
theorem probe_3_38 : ¬ (fcTypeOfName% "Erdos1062.erdos_1062.parts.ii") := by
  apply?
#print axioms probe_3_38

-- ATTACK fc-379fc029-parts-ii-056fb2fabb-counterexample-v1 library_search
theorem probe_3_39 : ¬ (fcTypeOfName% "Erdos1062.erdos_1062.parts.ii") := by
  library_search
#print axioms probe_3_39

-- ATTACK fc-379fc029-parts-ii-056fb2fabb-counterexample-v1 aesop_search
theorem probe_3_40 : ¬ (fcTypeOfName% "Erdos1062.erdos_1062.parts.ii") := by
  aesop?
#print axioms probe_3_40

-- ATTACK fc-379fc029-parts-ii-056fb2fabb-counterexample-v1 simp_search
theorem probe_3_41 : ¬ (fcTypeOfName% "Erdos1062.erdos_1062.parts.ii") := by
  simp?
#print axioms probe_3_41

-- ATTACK fc-379fc029-erdos1175-erdos-1175-905c25dcc6-counterexample-v1 simp
theorem probe_3_42 : ¬ (fcTypeOfName% "Erdos1175.erdos_1175") := by
  simp
#print axioms probe_3_42

-- ATTACK fc-379fc029-erdos1175-erdos-1175-905c25dcc6-counterexample-v1 simpa
theorem probe_3_43 : ¬ (fcTypeOfName% "Erdos1175.erdos_1175") := by
  simpa
#print axioms probe_3_43

-- ATTACK fc-379fc029-erdos1175-erdos-1175-905c25dcc6-counterexample-v1 simp_all
theorem probe_3_44 : ¬ (fcTypeOfName% "Erdos1175.erdos_1175") := by
  simp_all
#print axioms probe_3_44

-- ATTACK fc-379fc029-erdos1175-erdos-1175-905c25dcc6-counterexample-v1 aesop
theorem probe_3_45 : ¬ (fcTypeOfName% "Erdos1175.erdos_1175") := by
  aesop
#print axioms probe_3_45

-- ATTACK fc-379fc029-erdos1175-erdos-1175-905c25dcc6-counterexample-v1 omega
theorem probe_3_46 : ¬ (fcTypeOfName% "Erdos1175.erdos_1175") := by
  omega
#print axioms probe_3_46

-- ATTACK fc-379fc029-erdos1175-erdos-1175-905c25dcc6-counterexample-v1 norm_num
theorem probe_3_47 : ¬ (fcTypeOfName% "Erdos1175.erdos_1175") := by
  norm_num
#print axioms probe_3_47

-- ATTACK fc-379fc029-erdos1175-erdos-1175-905c25dcc6-counterexample-v1 decide
theorem probe_3_48 : ¬ (fcTypeOfName% "Erdos1175.erdos_1175") := by
  decide
#print axioms probe_3_48

-- ATTACK fc-379fc029-erdos1175-erdos-1175-905c25dcc6-counterexample-v1 native_decide
theorem probe_3_49 : ¬ (fcTypeOfName% "Erdos1175.erdos_1175") := by
  native_decide
#print axioms probe_3_49

-- ATTACK fc-379fc029-erdos1175-erdos-1175-905c25dcc6-counterexample-v1 true_intro
theorem probe_3_50 : ¬ (fcTypeOfName% "Erdos1175.erdos_1175") := by
  exact True.intro
#print axioms probe_3_50

-- ATTACK fc-379fc029-erdos1175-erdos-1175-905c25dcc6-counterexample-v1 false_elim_simp
theorem probe_3_51 : ¬ (fcTypeOfName% "Erdos1175.erdos_1175") := by
  apply False.elim
  simp_all
#print axioms probe_3_51

-- ATTACK fc-379fc029-erdos1175-erdos-1175-905c25dcc6-counterexample-v1 constructor
theorem probe_3_52 : ¬ (fcTypeOfName% "Erdos1175.erdos_1175") := by
  constructor
#print axioms probe_3_52

-- ATTACK fc-379fc029-erdos1175-erdos-1175-905c25dcc6-counterexample-v1 constructor_simp
theorem probe_3_53 : ¬ (fcTypeOfName% "Erdos1175.erdos_1175") := by
  constructor <;> simp
#print axioms probe_3_53

-- ATTACK fc-379fc029-erdos1175-erdos-1175-905c25dcc6-counterexample-v1 constructor_aesop
theorem probe_3_54 : ¬ (fcTypeOfName% "Erdos1175.erdos_1175") := by
  constructor <;> aesop
#print axioms probe_3_54

-- ATTACK fc-379fc029-erdos1175-erdos-1175-905c25dcc6-counterexample-v1 rfl
theorem probe_3_55 : ¬ (fcTypeOfName% "Erdos1175.erdos_1175") := by
  rfl
#print axioms probe_3_55

-- ATTACK fc-379fc029-erdos1175-erdos-1175-905c25dcc6-counterexample-v1 trivial
theorem probe_3_56 : ¬ (fcTypeOfName% "Erdos1175.erdos_1175") := by
  trivial
#print axioms probe_3_56

-- ATTACK fc-379fc029-erdos1175-erdos-1175-905c25dcc6-counterexample-v1 tauto
theorem probe_3_57 : ¬ (fcTypeOfName% "Erdos1175.erdos_1175") := by
  tauto
#print axioms probe_3_57

-- ATTACK fc-379fc029-erdos1175-erdos-1175-905c25dcc6-counterexample-v1 positivity
theorem probe_3_58 : ¬ (fcTypeOfName% "Erdos1175.erdos_1175") := by
  positivity
#print axioms probe_3_58

-- ATTACK fc-379fc029-erdos1175-erdos-1175-905c25dcc6-counterexample-v1 linarith
theorem probe_3_59 : ¬ (fcTypeOfName% "Erdos1175.erdos_1175") := by
  linarith
#print axioms probe_3_59

-- ATTACK fc-379fc029-erdos1175-erdos-1175-905c25dcc6-counterexample-v1 nlinarith
theorem probe_3_60 : ¬ (fcTypeOfName% "Erdos1175.erdos_1175") := by
  nlinarith
#print axioms probe_3_60

-- ATTACK fc-379fc029-erdos1175-erdos-1175-905c25dcc6-counterexample-v1 intros_simp_all
theorem probe_3_61 : ¬ (fcTypeOfName% "Erdos1175.erdos_1175") := by
  intros
  simp_all
#print axioms probe_3_61

-- ATTACK fc-379fc029-erdos1175-erdos-1175-905c25dcc6-counterexample-v1 intros_omega
theorem probe_3_62 : ¬ (fcTypeOfName% "Erdos1175.erdos_1175") := by
  intros
  omega
#print axioms probe_3_62

-- ATTACK fc-379fc029-erdos1175-erdos-1175-905c25dcc6-counterexample-v1 intros_norm_num
theorem probe_3_63 : ¬ (fcTypeOfName% "Erdos1175.erdos_1175") := by
  intros
  norm_num at *
#print axioms probe_3_63

-- ATTACK fc-379fc029-erdos1175-erdos-1175-905c25dcc6-counterexample-v1 intros_aesop
theorem probe_3_64 : ¬ (fcTypeOfName% "Erdos1175.erdos_1175") := by
  intros
  aesop
#print axioms probe_3_64

-- ATTACK fc-379fc029-erdos1175-erdos-1175-905c25dcc6-counterexample-v1 by_contra_simp_all
theorem probe_3_65 : ¬ (fcTypeOfName% "Erdos1175.erdos_1175") := by
  by_contra h
  simp_all
#print axioms probe_3_65

-- ATTACK fc-379fc029-erdos1175-erdos-1175-905c25dcc6-counterexample-v1 classical_simp_all
theorem probe_3_66 : ¬ (fcTypeOfName% "Erdos1175.erdos_1175") := by
  classical
  simp_all
#print axioms probe_3_66

-- ATTACK fc-379fc029-erdos1175-erdos-1175-905c25dcc6-counterexample-v1 classical_aesop
theorem probe_3_67 : ¬ (fcTypeOfName% "Erdos1175.erdos_1175") := by
  classical
  aesop
#print axioms probe_3_67

-- ATTACK fc-379fc029-erdos1175-erdos-1175-905c25dcc6-counterexample-v1 refine_pair_simp
theorem probe_3_68 : ¬ (fcTypeOfName% "Erdos1175.erdos_1175") := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_3_68

-- ATTACK fc-379fc029-erdos1175-erdos-1175-905c25dcc6-counterexample-v1 refine_pair_aesop
theorem probe_3_69 : ¬ (fcTypeOfName% "Erdos1175.erdos_1175") := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_3_69

-- ATTACK fc-379fc029-erdos1175-erdos-1175-905c25dcc6-counterexample-v1 use_zero_simp
theorem probe_3_70 : ¬ (fcTypeOfName% "Erdos1175.erdos_1175") := by
  use 0 <;> simp
#print axioms probe_3_70

-- ATTACK fc-379fc029-erdos1175-erdos-1175-905c25dcc6-counterexample-v1 use_one_simp
theorem probe_3_71 : ¬ (fcTypeOfName% "Erdos1175.erdos_1175") := by
  use 1 <;> simp
#print axioms probe_3_71

-- ATTACK fc-379fc029-erdos1175-erdos-1175-905c25dcc6-counterexample-v1 use_empty_simp
theorem probe_3_72 : ¬ (fcTypeOfName% "Erdos1175.erdos_1175") := by
  use ∅ <;> simp
#print axioms probe_3_72

-- ATTACK fc-379fc029-erdos1175-erdos-1175-905c25dcc6-counterexample-v1 assumption
theorem probe_3_73 : ¬ (fcTypeOfName% "Erdos1175.erdos_1175") := by
  assumption
#print axioms probe_3_73

-- ATTACK fc-379fc029-erdos1175-erdos-1175-905c25dcc6-counterexample-v1 infer_instance
theorem probe_3_74 : ¬ (fcTypeOfName% "Erdos1175.erdos_1175") := by
  infer_instance
#print axioms probe_3_74

-- ATTACK fc-379fc029-erdos1175-erdos-1175-905c25dcc6-counterexample-v1 contradiction
theorem probe_3_75 : ¬ (fcTypeOfName% "Erdos1175.erdos_1175") := by
  contradiction
#print axioms probe_3_75

-- ATTACK fc-379fc029-erdos1175-erdos-1175-905c25dcc6-counterexample-v1 solve_by_elim
theorem probe_3_76 : ¬ (fcTypeOfName% "Erdos1175.erdos_1175") := by
  solve_by_elim
#print axioms probe_3_76

-- ATTACK fc-379fc029-erdos1175-erdos-1175-905c25dcc6-counterexample-v1 first_order
theorem probe_3_77 : ¬ (fcTypeOfName% "Erdos1175.erdos_1175") := by
  first_order
#print axioms probe_3_77

-- ATTACK fc-379fc029-erdos1175-erdos-1175-905c25dcc6-counterexample-v1 grind
theorem probe_3_78 : ¬ (fcTypeOfName% "Erdos1175.erdos_1175") := by
  grind
#print axioms probe_3_78

-- ATTACK fc-379fc029-erdos1175-erdos-1175-905c25dcc6-counterexample-v1 exact_search
theorem probe_3_79 : ¬ (fcTypeOfName% "Erdos1175.erdos_1175") := by
  exact?
#print axioms probe_3_79

-- ATTACK fc-379fc029-erdos1175-erdos-1175-905c25dcc6-counterexample-v1 apply_search
theorem probe_3_80 : ¬ (fcTypeOfName% "Erdos1175.erdos_1175") := by
  apply?
#print axioms probe_3_80

-- ATTACK fc-379fc029-erdos1175-erdos-1175-905c25dcc6-counterexample-v1 library_search
theorem probe_3_81 : ¬ (fcTypeOfName% "Erdos1175.erdos_1175") := by
  library_search
#print axioms probe_3_81

-- ATTACK fc-379fc029-erdos1175-erdos-1175-905c25dcc6-counterexample-v1 aesop_search
theorem probe_3_82 : ¬ (fcTypeOfName% "Erdos1175.erdos_1175") := by
  aesop?
#print axioms probe_3_82

-- ATTACK fc-379fc029-erdos1175-erdos-1175-905c25dcc6-counterexample-v1 simp_search
theorem probe_3_83 : ¬ (fcTypeOfName% "Erdos1175.erdos_1175") := by
  simp?
#print axioms probe_3_83

-- ATTACK fc-379fc029-parts-ii-547b5f5606-counterexample-v1 simp
theorem probe_3_84 : ¬ (fcTypeOfName% "Erdos168.erdos_168.parts.ii") := by
  simp
#print axioms probe_3_84

-- ATTACK fc-379fc029-parts-ii-547b5f5606-counterexample-v1 simpa
theorem probe_3_85 : ¬ (fcTypeOfName% "Erdos168.erdos_168.parts.ii") := by
  simpa
#print axioms probe_3_85

-- ATTACK fc-379fc029-parts-ii-547b5f5606-counterexample-v1 simp_all
theorem probe_3_86 : ¬ (fcTypeOfName% "Erdos168.erdos_168.parts.ii") := by
  simp_all
#print axioms probe_3_86

-- ATTACK fc-379fc029-parts-ii-547b5f5606-counterexample-v1 aesop
theorem probe_3_87 : ¬ (fcTypeOfName% "Erdos168.erdos_168.parts.ii") := by
  aesop
#print axioms probe_3_87

-- ATTACK fc-379fc029-parts-ii-547b5f5606-counterexample-v1 omega
theorem probe_3_88 : ¬ (fcTypeOfName% "Erdos168.erdos_168.parts.ii") := by
  omega
#print axioms probe_3_88

-- ATTACK fc-379fc029-parts-ii-547b5f5606-counterexample-v1 norm_num
theorem probe_3_89 : ¬ (fcTypeOfName% "Erdos168.erdos_168.parts.ii") := by
  norm_num
#print axioms probe_3_89

-- ATTACK fc-379fc029-parts-ii-547b5f5606-counterexample-v1 decide
theorem probe_3_90 : ¬ (fcTypeOfName% "Erdos168.erdos_168.parts.ii") := by
  decide
#print axioms probe_3_90

-- ATTACK fc-379fc029-parts-ii-547b5f5606-counterexample-v1 native_decide
theorem probe_3_91 : ¬ (fcTypeOfName% "Erdos168.erdos_168.parts.ii") := by
  native_decide
#print axioms probe_3_91

-- ATTACK fc-379fc029-parts-ii-547b5f5606-counterexample-v1 true_intro
theorem probe_3_92 : ¬ (fcTypeOfName% "Erdos168.erdos_168.parts.ii") := by
  exact True.intro
#print axioms probe_3_92

-- ATTACK fc-379fc029-parts-ii-547b5f5606-counterexample-v1 false_elim_simp
theorem probe_3_93 : ¬ (fcTypeOfName% "Erdos168.erdos_168.parts.ii") := by
  apply False.elim
  simp_all
#print axioms probe_3_93

-- ATTACK fc-379fc029-parts-ii-547b5f5606-counterexample-v1 constructor
theorem probe_3_94 : ¬ (fcTypeOfName% "Erdos168.erdos_168.parts.ii") := by
  constructor
#print axioms probe_3_94

-- ATTACK fc-379fc029-parts-ii-547b5f5606-counterexample-v1 constructor_simp
theorem probe_3_95 : ¬ (fcTypeOfName% "Erdos168.erdos_168.parts.ii") := by
  constructor <;> simp
#print axioms probe_3_95

-- ATTACK fc-379fc029-parts-ii-547b5f5606-counterexample-v1 constructor_aesop
theorem probe_3_96 : ¬ (fcTypeOfName% "Erdos168.erdos_168.parts.ii") := by
  constructor <;> aesop
#print axioms probe_3_96

-- ATTACK fc-379fc029-parts-ii-547b5f5606-counterexample-v1 rfl
theorem probe_3_97 : ¬ (fcTypeOfName% "Erdos168.erdos_168.parts.ii") := by
  rfl
#print axioms probe_3_97

-- ATTACK fc-379fc029-parts-ii-547b5f5606-counterexample-v1 trivial
theorem probe_3_98 : ¬ (fcTypeOfName% "Erdos168.erdos_168.parts.ii") := by
  trivial
#print axioms probe_3_98

-- ATTACK fc-379fc029-parts-ii-547b5f5606-counterexample-v1 tauto
theorem probe_3_99 : ¬ (fcTypeOfName% "Erdos168.erdos_168.parts.ii") := by
  tauto
#print axioms probe_3_99

-- ATTACK fc-379fc029-parts-ii-547b5f5606-counterexample-v1 positivity
theorem probe_3_100 : ¬ (fcTypeOfName% "Erdos168.erdos_168.parts.ii") := by
  positivity
#print axioms probe_3_100

-- ATTACK fc-379fc029-parts-ii-547b5f5606-counterexample-v1 linarith
theorem probe_3_101 : ¬ (fcTypeOfName% "Erdos168.erdos_168.parts.ii") := by
  linarith
#print axioms probe_3_101

-- ATTACK fc-379fc029-parts-ii-547b5f5606-counterexample-v1 nlinarith
theorem probe_3_102 : ¬ (fcTypeOfName% "Erdos168.erdos_168.parts.ii") := by
  nlinarith
#print axioms probe_3_102

-- ATTACK fc-379fc029-parts-ii-547b5f5606-counterexample-v1 intros_simp_all
theorem probe_3_103 : ¬ (fcTypeOfName% "Erdos168.erdos_168.parts.ii") := by
  intros
  simp_all
#print axioms probe_3_103

-- ATTACK fc-379fc029-parts-ii-547b5f5606-counterexample-v1 intros_omega
theorem probe_3_104 : ¬ (fcTypeOfName% "Erdos168.erdos_168.parts.ii") := by
  intros
  omega
#print axioms probe_3_104

-- ATTACK fc-379fc029-parts-ii-547b5f5606-counterexample-v1 intros_norm_num
theorem probe_3_105 : ¬ (fcTypeOfName% "Erdos168.erdos_168.parts.ii") := by
  intros
  norm_num at *
#print axioms probe_3_105

-- ATTACK fc-379fc029-parts-ii-547b5f5606-counterexample-v1 intros_aesop
theorem probe_3_106 : ¬ (fcTypeOfName% "Erdos168.erdos_168.parts.ii") := by
  intros
  aesop
#print axioms probe_3_106

-- ATTACK fc-379fc029-parts-ii-547b5f5606-counterexample-v1 by_contra_simp_all
theorem probe_3_107 : ¬ (fcTypeOfName% "Erdos168.erdos_168.parts.ii") := by
  by_contra h
  simp_all
#print axioms probe_3_107

-- ATTACK fc-379fc029-parts-ii-547b5f5606-counterexample-v1 classical_simp_all
theorem probe_3_108 : ¬ (fcTypeOfName% "Erdos168.erdos_168.parts.ii") := by
  classical
  simp_all
#print axioms probe_3_108

-- ATTACK fc-379fc029-parts-ii-547b5f5606-counterexample-v1 classical_aesop
theorem probe_3_109 : ¬ (fcTypeOfName% "Erdos168.erdos_168.parts.ii") := by
  classical
  aesop
#print axioms probe_3_109

-- ATTACK fc-379fc029-parts-ii-547b5f5606-counterexample-v1 refine_pair_simp
theorem probe_3_110 : ¬ (fcTypeOfName% "Erdos168.erdos_168.parts.ii") := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_3_110

-- ATTACK fc-379fc029-parts-ii-547b5f5606-counterexample-v1 refine_pair_aesop
theorem probe_3_111 : ¬ (fcTypeOfName% "Erdos168.erdos_168.parts.ii") := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_3_111

-- ATTACK fc-379fc029-parts-ii-547b5f5606-counterexample-v1 use_zero_simp
theorem probe_3_112 : ¬ (fcTypeOfName% "Erdos168.erdos_168.parts.ii") := by
  use 0 <;> simp
#print axioms probe_3_112

-- ATTACK fc-379fc029-parts-ii-547b5f5606-counterexample-v1 use_one_simp
theorem probe_3_113 : ¬ (fcTypeOfName% "Erdos168.erdos_168.parts.ii") := by
  use 1 <;> simp
#print axioms probe_3_113

-- ATTACK fc-379fc029-parts-ii-547b5f5606-counterexample-v1 use_empty_simp
theorem probe_3_114 : ¬ (fcTypeOfName% "Erdos168.erdos_168.parts.ii") := by
  use ∅ <;> simp
#print axioms probe_3_114

-- ATTACK fc-379fc029-parts-ii-547b5f5606-counterexample-v1 assumption
theorem probe_3_115 : ¬ (fcTypeOfName% "Erdos168.erdos_168.parts.ii") := by
  assumption
#print axioms probe_3_115

-- ATTACK fc-379fc029-parts-ii-547b5f5606-counterexample-v1 infer_instance
theorem probe_3_116 : ¬ (fcTypeOfName% "Erdos168.erdos_168.parts.ii") := by
  infer_instance
#print axioms probe_3_116

-- ATTACK fc-379fc029-parts-ii-547b5f5606-counterexample-v1 contradiction
theorem probe_3_117 : ¬ (fcTypeOfName% "Erdos168.erdos_168.parts.ii") := by
  contradiction
#print axioms probe_3_117

-- ATTACK fc-379fc029-parts-ii-547b5f5606-counterexample-v1 solve_by_elim
theorem probe_3_118 : ¬ (fcTypeOfName% "Erdos168.erdos_168.parts.ii") := by
  solve_by_elim
#print axioms probe_3_118

-- ATTACK fc-379fc029-parts-ii-547b5f5606-counterexample-v1 first_order
theorem probe_3_119 : ¬ (fcTypeOfName% "Erdos168.erdos_168.parts.ii") := by
  first_order
#print axioms probe_3_119

-- ATTACK fc-379fc029-parts-ii-547b5f5606-counterexample-v1 grind
theorem probe_3_120 : ¬ (fcTypeOfName% "Erdos168.erdos_168.parts.ii") := by
  grind
#print axioms probe_3_120

-- ATTACK fc-379fc029-parts-ii-547b5f5606-counterexample-v1 exact_search
theorem probe_3_121 : ¬ (fcTypeOfName% "Erdos168.erdos_168.parts.ii") := by
  exact?
#print axioms probe_3_121

-- ATTACK fc-379fc029-parts-ii-547b5f5606-counterexample-v1 apply_search
theorem probe_3_122 : ¬ (fcTypeOfName% "Erdos168.erdos_168.parts.ii") := by
  apply?
#print axioms probe_3_122

-- ATTACK fc-379fc029-parts-ii-547b5f5606-counterexample-v1 library_search
theorem probe_3_123 : ¬ (fcTypeOfName% "Erdos168.erdos_168.parts.ii") := by
  library_search
#print axioms probe_3_123

-- ATTACK fc-379fc029-parts-ii-547b5f5606-counterexample-v1 aesop_search
theorem probe_3_124 : ¬ (fcTypeOfName% "Erdos168.erdos_168.parts.ii") := by
  aesop?
#print axioms probe_3_124

-- ATTACK fc-379fc029-parts-ii-547b5f5606-counterexample-v1 simp_search
theorem probe_3_125 : ¬ (fcTypeOfName% "Erdos168.erdos_168.parts.ii") := by
  simp?
#print axioms probe_3_125

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-fd6912fb6a-counterexample-v1 simp
theorem probe_3_126 : ¬ (fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero") := by
  simp
#print axioms probe_3_126

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-fd6912fb6a-counterexample-v1 simpa
theorem probe_3_127 : ¬ (fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero") := by
  simpa
#print axioms probe_3_127

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-fd6912fb6a-counterexample-v1 simp_all
theorem probe_3_128 : ¬ (fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero") := by
  simp_all
#print axioms probe_3_128

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-fd6912fb6a-counterexample-v1 aesop
theorem probe_3_129 : ¬ (fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero") := by
  aesop
#print axioms probe_3_129

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-fd6912fb6a-counterexample-v1 omega
theorem probe_3_130 : ¬ (fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero") := by
  omega
#print axioms probe_3_130

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-fd6912fb6a-counterexample-v1 norm_num
theorem probe_3_131 : ¬ (fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero") := by
  norm_num
#print axioms probe_3_131

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-fd6912fb6a-counterexample-v1 decide
theorem probe_3_132 : ¬ (fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero") := by
  decide
#print axioms probe_3_132

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-fd6912fb6a-counterexample-v1 native_decide
theorem probe_3_133 : ¬ (fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero") := by
  native_decide
#print axioms probe_3_133

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-fd6912fb6a-counterexample-v1 true_intro
theorem probe_3_134 : ¬ (fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero") := by
  exact True.intro
#print axioms probe_3_134

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-fd6912fb6a-counterexample-v1 false_elim_simp
theorem probe_3_135 : ¬ (fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero") := by
  apply False.elim
  simp_all
#print axioms probe_3_135

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-fd6912fb6a-counterexample-v1 constructor
theorem probe_3_136 : ¬ (fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero") := by
  constructor
#print axioms probe_3_136

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-fd6912fb6a-counterexample-v1 constructor_simp
theorem probe_3_137 : ¬ (fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero") := by
  constructor <;> simp
#print axioms probe_3_137

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-fd6912fb6a-counterexample-v1 constructor_aesop
theorem probe_3_138 : ¬ (fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero") := by
  constructor <;> aesop
#print axioms probe_3_138

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-fd6912fb6a-counterexample-v1 rfl
theorem probe_3_139 : ¬ (fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero") := by
  rfl
#print axioms probe_3_139

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-fd6912fb6a-counterexample-v1 trivial
theorem probe_3_140 : ¬ (fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero") := by
  trivial
#print axioms probe_3_140

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-fd6912fb6a-counterexample-v1 tauto
theorem probe_3_141 : ¬ (fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero") := by
  tauto
#print axioms probe_3_141

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-fd6912fb6a-counterexample-v1 positivity
theorem probe_3_142 : ¬ (fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero") := by
  positivity
#print axioms probe_3_142

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-fd6912fb6a-counterexample-v1 linarith
theorem probe_3_143 : ¬ (fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero") := by
  linarith
#print axioms probe_3_143

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-fd6912fb6a-counterexample-v1 nlinarith
theorem probe_3_144 : ¬ (fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero") := by
  nlinarith
#print axioms probe_3_144

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-fd6912fb6a-counterexample-v1 intros_simp_all
theorem probe_3_145 : ¬ (fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero") := by
  intros
  simp_all
#print axioms probe_3_145

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-fd6912fb6a-counterexample-v1 intros_omega
theorem probe_3_146 : ¬ (fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero") := by
  intros
  omega
#print axioms probe_3_146

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-fd6912fb6a-counterexample-v1 intros_norm_num
theorem probe_3_147 : ¬ (fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero") := by
  intros
  norm_num at *
#print axioms probe_3_147

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-fd6912fb6a-counterexample-v1 intros_aesop
theorem probe_3_148 : ¬ (fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero") := by
  intros
  aesop
#print axioms probe_3_148

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-fd6912fb6a-counterexample-v1 by_contra_simp_all
theorem probe_3_149 : ¬ (fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero") := by
  by_contra h
  simp_all
#print axioms probe_3_149

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-fd6912fb6a-counterexample-v1 classical_simp_all
theorem probe_3_150 : ¬ (fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero") := by
  classical
  simp_all
#print axioms probe_3_150

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-fd6912fb6a-counterexample-v1 classical_aesop
theorem probe_3_151 : ¬ (fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero") := by
  classical
  aesop
#print axioms probe_3_151

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-fd6912fb6a-counterexample-v1 refine_pair_simp
theorem probe_3_152 : ¬ (fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero") := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_3_152

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-fd6912fb6a-counterexample-v1 refine_pair_aesop
theorem probe_3_153 : ¬ (fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero") := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_3_153

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-fd6912fb6a-counterexample-v1 use_zero_simp
theorem probe_3_154 : ¬ (fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero") := by
  use 0 <;> simp
#print axioms probe_3_154

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-fd6912fb6a-counterexample-v1 use_one_simp
theorem probe_3_155 : ¬ (fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero") := by
  use 1 <;> simp
#print axioms probe_3_155

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-fd6912fb6a-counterexample-v1 use_empty_simp
theorem probe_3_156 : ¬ (fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero") := by
  use ∅ <;> simp
#print axioms probe_3_156

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-fd6912fb6a-counterexample-v1 assumption
theorem probe_3_157 : ¬ (fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero") := by
  assumption
#print axioms probe_3_157

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-fd6912fb6a-counterexample-v1 infer_instance
theorem probe_3_158 : ¬ (fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero") := by
  infer_instance
#print axioms probe_3_158

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-fd6912fb6a-counterexample-v1 contradiction
theorem probe_3_159 : ¬ (fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero") := by
  contradiction
#print axioms probe_3_159

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-fd6912fb6a-counterexample-v1 solve_by_elim
theorem probe_3_160 : ¬ (fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero") := by
  solve_by_elim
#print axioms probe_3_160

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-fd6912fb6a-counterexample-v1 first_order
theorem probe_3_161 : ¬ (fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero") := by
  first_order
#print axioms probe_3_161

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-fd6912fb6a-counterexample-v1 grind
theorem probe_3_162 : ¬ (fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero") := by
  grind
#print axioms probe_3_162

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-fd6912fb6a-counterexample-v1 exact_search
theorem probe_3_163 : ¬ (fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero") := by
  exact?
#print axioms probe_3_163

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-fd6912fb6a-counterexample-v1 apply_search
theorem probe_3_164 : ¬ (fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero") := by
  apply?
#print axioms probe_3_164

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-fd6912fb6a-counterexample-v1 library_search
theorem probe_3_165 : ¬ (fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero") := by
  library_search
#print axioms probe_3_165

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-fd6912fb6a-counterexample-v1 aesop_search
theorem probe_3_166 : ¬ (fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero") := by
  aesop?
#print axioms probe_3_166

-- ATTACK fc-379fc029-variants-shiu-heuristic-density-zero-fd6912fb6a-counterexample-v1 simp_search
theorem probe_3_167 : ¬ (fcTypeOfName% "Erdos291.erdos_291.variants.shiu_heuristic_density_zero") := by
  simp?
#print axioms probe_3_167

-- ATTACK fc-379fc029-variants-claim2-2f3f1c57a6-counterexample-v1 simp
theorem probe_3_168 : ¬ (fcTypeOfName% "Erdos317.erdos_317.variants.claim2") := by
  simp
#print axioms probe_3_168

-- ATTACK fc-379fc029-variants-claim2-2f3f1c57a6-counterexample-v1 simpa
theorem probe_3_169 : ¬ (fcTypeOfName% "Erdos317.erdos_317.variants.claim2") := by
  simpa
#print axioms probe_3_169

-- ATTACK fc-379fc029-variants-claim2-2f3f1c57a6-counterexample-v1 simp_all
theorem probe_3_170 : ¬ (fcTypeOfName% "Erdos317.erdos_317.variants.claim2") := by
  simp_all
#print axioms probe_3_170

-- ATTACK fc-379fc029-variants-claim2-2f3f1c57a6-counterexample-v1 aesop
theorem probe_3_171 : ¬ (fcTypeOfName% "Erdos317.erdos_317.variants.claim2") := by
  aesop
#print axioms probe_3_171

-- ATTACK fc-379fc029-variants-claim2-2f3f1c57a6-counterexample-v1 omega
theorem probe_3_172 : ¬ (fcTypeOfName% "Erdos317.erdos_317.variants.claim2") := by
  omega
#print axioms probe_3_172

-- ATTACK fc-379fc029-variants-claim2-2f3f1c57a6-counterexample-v1 norm_num
theorem probe_3_173 : ¬ (fcTypeOfName% "Erdos317.erdos_317.variants.claim2") := by
  norm_num
#print axioms probe_3_173

-- ATTACK fc-379fc029-variants-claim2-2f3f1c57a6-counterexample-v1 decide
theorem probe_3_174 : ¬ (fcTypeOfName% "Erdos317.erdos_317.variants.claim2") := by
  decide
#print axioms probe_3_174

-- ATTACK fc-379fc029-variants-claim2-2f3f1c57a6-counterexample-v1 native_decide
theorem probe_3_175 : ¬ (fcTypeOfName% "Erdos317.erdos_317.variants.claim2") := by
  native_decide
#print axioms probe_3_175

-- ATTACK fc-379fc029-variants-claim2-2f3f1c57a6-counterexample-v1 true_intro
theorem probe_3_176 : ¬ (fcTypeOfName% "Erdos317.erdos_317.variants.claim2") := by
  exact True.intro
#print axioms probe_3_176

-- ATTACK fc-379fc029-variants-claim2-2f3f1c57a6-counterexample-v1 false_elim_simp
theorem probe_3_177 : ¬ (fcTypeOfName% "Erdos317.erdos_317.variants.claim2") := by
  apply False.elim
  simp_all
#print axioms probe_3_177

-- ATTACK fc-379fc029-variants-claim2-2f3f1c57a6-counterexample-v1 constructor
theorem probe_3_178 : ¬ (fcTypeOfName% "Erdos317.erdos_317.variants.claim2") := by
  constructor
#print axioms probe_3_178

-- ATTACK fc-379fc029-variants-claim2-2f3f1c57a6-counterexample-v1 constructor_simp
theorem probe_3_179 : ¬ (fcTypeOfName% "Erdos317.erdos_317.variants.claim2") := by
  constructor <;> simp
#print axioms probe_3_179

-- ATTACK fc-379fc029-variants-claim2-2f3f1c57a6-counterexample-v1 constructor_aesop
theorem probe_3_180 : ¬ (fcTypeOfName% "Erdos317.erdos_317.variants.claim2") := by
  constructor <;> aesop
#print axioms probe_3_180

-- ATTACK fc-379fc029-variants-claim2-2f3f1c57a6-counterexample-v1 rfl
theorem probe_3_181 : ¬ (fcTypeOfName% "Erdos317.erdos_317.variants.claim2") := by
  rfl
#print axioms probe_3_181

-- ATTACK fc-379fc029-variants-claim2-2f3f1c57a6-counterexample-v1 trivial
theorem probe_3_182 : ¬ (fcTypeOfName% "Erdos317.erdos_317.variants.claim2") := by
  trivial
#print axioms probe_3_182

-- ATTACK fc-379fc029-variants-claim2-2f3f1c57a6-counterexample-v1 tauto
theorem probe_3_183 : ¬ (fcTypeOfName% "Erdos317.erdos_317.variants.claim2") := by
  tauto
#print axioms probe_3_183

-- ATTACK fc-379fc029-variants-claim2-2f3f1c57a6-counterexample-v1 positivity
theorem probe_3_184 : ¬ (fcTypeOfName% "Erdos317.erdos_317.variants.claim2") := by
  positivity
#print axioms probe_3_184

-- ATTACK fc-379fc029-variants-claim2-2f3f1c57a6-counterexample-v1 linarith
theorem probe_3_185 : ¬ (fcTypeOfName% "Erdos317.erdos_317.variants.claim2") := by
  linarith
#print axioms probe_3_185

-- ATTACK fc-379fc029-variants-claim2-2f3f1c57a6-counterexample-v1 nlinarith
theorem probe_3_186 : ¬ (fcTypeOfName% "Erdos317.erdos_317.variants.claim2") := by
  nlinarith
#print axioms probe_3_186

-- ATTACK fc-379fc029-variants-claim2-2f3f1c57a6-counterexample-v1 intros_simp_all
theorem probe_3_187 : ¬ (fcTypeOfName% "Erdos317.erdos_317.variants.claim2") := by
  intros
  simp_all
#print axioms probe_3_187

-- ATTACK fc-379fc029-variants-claim2-2f3f1c57a6-counterexample-v1 intros_omega
theorem probe_3_188 : ¬ (fcTypeOfName% "Erdos317.erdos_317.variants.claim2") := by
  intros
  omega
#print axioms probe_3_188

-- ATTACK fc-379fc029-variants-claim2-2f3f1c57a6-counterexample-v1 intros_norm_num
theorem probe_3_189 : ¬ (fcTypeOfName% "Erdos317.erdos_317.variants.claim2") := by
  intros
  norm_num at *
#print axioms probe_3_189

-- ATTACK fc-379fc029-variants-claim2-2f3f1c57a6-counterexample-v1 intros_aesop
theorem probe_3_190 : ¬ (fcTypeOfName% "Erdos317.erdos_317.variants.claim2") := by
  intros
  aesop
#print axioms probe_3_190

-- ATTACK fc-379fc029-variants-claim2-2f3f1c57a6-counterexample-v1 by_contra_simp_all
theorem probe_3_191 : ¬ (fcTypeOfName% "Erdos317.erdos_317.variants.claim2") := by
  by_contra h
  simp_all
#print axioms probe_3_191

-- ATTACK fc-379fc029-variants-claim2-2f3f1c57a6-counterexample-v1 classical_simp_all
theorem probe_3_192 : ¬ (fcTypeOfName% "Erdos317.erdos_317.variants.claim2") := by
  classical
  simp_all
#print axioms probe_3_192

-- ATTACK fc-379fc029-variants-claim2-2f3f1c57a6-counterexample-v1 classical_aesop
theorem probe_3_193 : ¬ (fcTypeOfName% "Erdos317.erdos_317.variants.claim2") := by
  classical
  aesop
#print axioms probe_3_193

-- ATTACK fc-379fc029-variants-claim2-2f3f1c57a6-counterexample-v1 refine_pair_simp
theorem probe_3_194 : ¬ (fcTypeOfName% "Erdos317.erdos_317.variants.claim2") := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_3_194

-- ATTACK fc-379fc029-variants-claim2-2f3f1c57a6-counterexample-v1 refine_pair_aesop
theorem probe_3_195 : ¬ (fcTypeOfName% "Erdos317.erdos_317.variants.claim2") := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_3_195

-- ATTACK fc-379fc029-variants-claim2-2f3f1c57a6-counterexample-v1 use_zero_simp
theorem probe_3_196 : ¬ (fcTypeOfName% "Erdos317.erdos_317.variants.claim2") := by
  use 0 <;> simp
#print axioms probe_3_196

-- ATTACK fc-379fc029-variants-claim2-2f3f1c57a6-counterexample-v1 use_one_simp
theorem probe_3_197 : ¬ (fcTypeOfName% "Erdos317.erdos_317.variants.claim2") := by
  use 1 <;> simp
#print axioms probe_3_197

-- ATTACK fc-379fc029-variants-claim2-2f3f1c57a6-counterexample-v1 use_empty_simp
theorem probe_3_198 : ¬ (fcTypeOfName% "Erdos317.erdos_317.variants.claim2") := by
  use ∅ <;> simp
#print axioms probe_3_198

-- ATTACK fc-379fc029-variants-claim2-2f3f1c57a6-counterexample-v1 assumption
theorem probe_3_199 : ¬ (fcTypeOfName% "Erdos317.erdos_317.variants.claim2") := by
  assumption
#print axioms probe_3_199

-- ATTACK fc-379fc029-variants-claim2-2f3f1c57a6-counterexample-v1 infer_instance
theorem probe_3_200 : ¬ (fcTypeOfName% "Erdos317.erdos_317.variants.claim2") := by
  infer_instance
#print axioms probe_3_200

-- ATTACK fc-379fc029-variants-claim2-2f3f1c57a6-counterexample-v1 contradiction
theorem probe_3_201 : ¬ (fcTypeOfName% "Erdos317.erdos_317.variants.claim2") := by
  contradiction
#print axioms probe_3_201

-- ATTACK fc-379fc029-variants-claim2-2f3f1c57a6-counterexample-v1 solve_by_elim
theorem probe_3_202 : ¬ (fcTypeOfName% "Erdos317.erdos_317.variants.claim2") := by
  solve_by_elim
#print axioms probe_3_202

-- ATTACK fc-379fc029-variants-claim2-2f3f1c57a6-counterexample-v1 first_order
theorem probe_3_203 : ¬ (fcTypeOfName% "Erdos317.erdos_317.variants.claim2") := by
  first_order
#print axioms probe_3_203

-- ATTACK fc-379fc029-variants-claim2-2f3f1c57a6-counterexample-v1 grind
theorem probe_3_204 : ¬ (fcTypeOfName% "Erdos317.erdos_317.variants.claim2") := by
  grind
#print axioms probe_3_204

-- ATTACK fc-379fc029-variants-claim2-2f3f1c57a6-counterexample-v1 exact_search
theorem probe_3_205 : ¬ (fcTypeOfName% "Erdos317.erdos_317.variants.claim2") := by
  exact?
#print axioms probe_3_205

-- ATTACK fc-379fc029-variants-claim2-2f3f1c57a6-counterexample-v1 apply_search
theorem probe_3_206 : ¬ (fcTypeOfName% "Erdos317.erdos_317.variants.claim2") := by
  apply?
#print axioms probe_3_206

-- ATTACK fc-379fc029-variants-claim2-2f3f1c57a6-counterexample-v1 library_search
theorem probe_3_207 : ¬ (fcTypeOfName% "Erdos317.erdos_317.variants.claim2") := by
  library_search
#print axioms probe_3_207

-- ATTACK fc-379fc029-variants-claim2-2f3f1c57a6-counterexample-v1 aesop_search
theorem probe_3_208 : ¬ (fcTypeOfName% "Erdos317.erdos_317.variants.claim2") := by
  aesop?
#print axioms probe_3_208

-- ATTACK fc-379fc029-variants-claim2-2f3f1c57a6-counterexample-v1 simp_search
theorem probe_3_209 : ¬ (fcTypeOfName% "Erdos317.erdos_317.variants.claim2") := by
  simp?
#print axioms probe_3_209

-- ATTACK fc-379fc029-erdos410-erdos-410-532b819af6-counterexample-v1 simp
theorem probe_3_210 : ¬ (fcTypeOfName% "Erdos410.erdos_410") := by
  simp
#print axioms probe_3_210

-- ATTACK fc-379fc029-erdos410-erdos-410-532b819af6-counterexample-v1 simpa
theorem probe_3_211 : ¬ (fcTypeOfName% "Erdos410.erdos_410") := by
  simpa
#print axioms probe_3_211

-- ATTACK fc-379fc029-erdos410-erdos-410-532b819af6-counterexample-v1 simp_all
theorem probe_3_212 : ¬ (fcTypeOfName% "Erdos410.erdos_410") := by
  simp_all
#print axioms probe_3_212

-- ATTACK fc-379fc029-erdos410-erdos-410-532b819af6-counterexample-v1 aesop
theorem probe_3_213 : ¬ (fcTypeOfName% "Erdos410.erdos_410") := by
  aesop
#print axioms probe_3_213

-- ATTACK fc-379fc029-erdos410-erdos-410-532b819af6-counterexample-v1 omega
theorem probe_3_214 : ¬ (fcTypeOfName% "Erdos410.erdos_410") := by
  omega
#print axioms probe_3_214

-- ATTACK fc-379fc029-erdos410-erdos-410-532b819af6-counterexample-v1 norm_num
theorem probe_3_215 : ¬ (fcTypeOfName% "Erdos410.erdos_410") := by
  norm_num
#print axioms probe_3_215

-- ATTACK fc-379fc029-erdos410-erdos-410-532b819af6-counterexample-v1 decide
theorem probe_3_216 : ¬ (fcTypeOfName% "Erdos410.erdos_410") := by
  decide
#print axioms probe_3_216

-- ATTACK fc-379fc029-erdos410-erdos-410-532b819af6-counterexample-v1 native_decide
theorem probe_3_217 : ¬ (fcTypeOfName% "Erdos410.erdos_410") := by
  native_decide
#print axioms probe_3_217

-- ATTACK fc-379fc029-erdos410-erdos-410-532b819af6-counterexample-v1 true_intro
theorem probe_3_218 : ¬ (fcTypeOfName% "Erdos410.erdos_410") := by
  exact True.intro
#print axioms probe_3_218

-- ATTACK fc-379fc029-erdos410-erdos-410-532b819af6-counterexample-v1 false_elim_simp
theorem probe_3_219 : ¬ (fcTypeOfName% "Erdos410.erdos_410") := by
  apply False.elim
  simp_all
#print axioms probe_3_219

-- ATTACK fc-379fc029-erdos410-erdos-410-532b819af6-counterexample-v1 constructor
theorem probe_3_220 : ¬ (fcTypeOfName% "Erdos410.erdos_410") := by
  constructor
#print axioms probe_3_220

-- ATTACK fc-379fc029-erdos410-erdos-410-532b819af6-counterexample-v1 constructor_simp
theorem probe_3_221 : ¬ (fcTypeOfName% "Erdos410.erdos_410") := by
  constructor <;> simp
#print axioms probe_3_221

-- ATTACK fc-379fc029-erdos410-erdos-410-532b819af6-counterexample-v1 constructor_aesop
theorem probe_3_222 : ¬ (fcTypeOfName% "Erdos410.erdos_410") := by
  constructor <;> aesop
#print axioms probe_3_222

-- ATTACK fc-379fc029-erdos410-erdos-410-532b819af6-counterexample-v1 rfl
theorem probe_3_223 : ¬ (fcTypeOfName% "Erdos410.erdos_410") := by
  rfl
#print axioms probe_3_223

-- ATTACK fc-379fc029-erdos410-erdos-410-532b819af6-counterexample-v1 trivial
theorem probe_3_224 : ¬ (fcTypeOfName% "Erdos410.erdos_410") := by
  trivial
#print axioms probe_3_224

-- ATTACK fc-379fc029-erdos410-erdos-410-532b819af6-counterexample-v1 tauto
theorem probe_3_225 : ¬ (fcTypeOfName% "Erdos410.erdos_410") := by
  tauto
#print axioms probe_3_225

-- ATTACK fc-379fc029-erdos410-erdos-410-532b819af6-counterexample-v1 positivity
theorem probe_3_226 : ¬ (fcTypeOfName% "Erdos410.erdos_410") := by
  positivity
#print axioms probe_3_226

-- ATTACK fc-379fc029-erdos410-erdos-410-532b819af6-counterexample-v1 linarith
theorem probe_3_227 : ¬ (fcTypeOfName% "Erdos410.erdos_410") := by
  linarith
#print axioms probe_3_227

-- ATTACK fc-379fc029-erdos410-erdos-410-532b819af6-counterexample-v1 nlinarith
theorem probe_3_228 : ¬ (fcTypeOfName% "Erdos410.erdos_410") := by
  nlinarith
#print axioms probe_3_228

-- ATTACK fc-379fc029-erdos410-erdos-410-532b819af6-counterexample-v1 intros_simp_all
theorem probe_3_229 : ¬ (fcTypeOfName% "Erdos410.erdos_410") := by
  intros
  simp_all
#print axioms probe_3_229

-- ATTACK fc-379fc029-erdos410-erdos-410-532b819af6-counterexample-v1 intros_omega
theorem probe_3_230 : ¬ (fcTypeOfName% "Erdos410.erdos_410") := by
  intros
  omega
#print axioms probe_3_230

-- ATTACK fc-379fc029-erdos410-erdos-410-532b819af6-counterexample-v1 intros_norm_num
theorem probe_3_231 : ¬ (fcTypeOfName% "Erdos410.erdos_410") := by
  intros
  norm_num at *
#print axioms probe_3_231

-- ATTACK fc-379fc029-erdos410-erdos-410-532b819af6-counterexample-v1 intros_aesop
theorem probe_3_232 : ¬ (fcTypeOfName% "Erdos410.erdos_410") := by
  intros
  aesop
#print axioms probe_3_232

-- ATTACK fc-379fc029-erdos410-erdos-410-532b819af6-counterexample-v1 by_contra_simp_all
theorem probe_3_233 : ¬ (fcTypeOfName% "Erdos410.erdos_410") := by
  by_contra h
  simp_all
#print axioms probe_3_233

-- ATTACK fc-379fc029-erdos410-erdos-410-532b819af6-counterexample-v1 classical_simp_all
theorem probe_3_234 : ¬ (fcTypeOfName% "Erdos410.erdos_410") := by
  classical
  simp_all
#print axioms probe_3_234

-- ATTACK fc-379fc029-erdos410-erdos-410-532b819af6-counterexample-v1 classical_aesop
theorem probe_3_235 : ¬ (fcTypeOfName% "Erdos410.erdos_410") := by
  classical
  aesop
#print axioms probe_3_235

-- ATTACK fc-379fc029-erdos410-erdos-410-532b819af6-counterexample-v1 refine_pair_simp
theorem probe_3_236 : ¬ (fcTypeOfName% "Erdos410.erdos_410") := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_3_236

-- ATTACK fc-379fc029-erdos410-erdos-410-532b819af6-counterexample-v1 refine_pair_aesop
theorem probe_3_237 : ¬ (fcTypeOfName% "Erdos410.erdos_410") := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_3_237

-- ATTACK fc-379fc029-erdos410-erdos-410-532b819af6-counterexample-v1 use_zero_simp
theorem probe_3_238 : ¬ (fcTypeOfName% "Erdos410.erdos_410") := by
  use 0 <;> simp
#print axioms probe_3_238

-- ATTACK fc-379fc029-erdos410-erdos-410-532b819af6-counterexample-v1 use_one_simp
theorem probe_3_239 : ¬ (fcTypeOfName% "Erdos410.erdos_410") := by
  use 1 <;> simp
#print axioms probe_3_239

-- ATTACK fc-379fc029-erdos410-erdos-410-532b819af6-counterexample-v1 use_empty_simp
theorem probe_3_240 : ¬ (fcTypeOfName% "Erdos410.erdos_410") := by
  use ∅ <;> simp
#print axioms probe_3_240

-- ATTACK fc-379fc029-erdos410-erdos-410-532b819af6-counterexample-v1 assumption
theorem probe_3_241 : ¬ (fcTypeOfName% "Erdos410.erdos_410") := by
  assumption
#print axioms probe_3_241

-- ATTACK fc-379fc029-erdos410-erdos-410-532b819af6-counterexample-v1 infer_instance
theorem probe_3_242 : ¬ (fcTypeOfName% "Erdos410.erdos_410") := by
  infer_instance
#print axioms probe_3_242

-- ATTACK fc-379fc029-erdos410-erdos-410-532b819af6-counterexample-v1 contradiction
theorem probe_3_243 : ¬ (fcTypeOfName% "Erdos410.erdos_410") := by
  contradiction
#print axioms probe_3_243

-- ATTACK fc-379fc029-erdos410-erdos-410-532b819af6-counterexample-v1 solve_by_elim
theorem probe_3_244 : ¬ (fcTypeOfName% "Erdos410.erdos_410") := by
  solve_by_elim
#print axioms probe_3_244

-- ATTACK fc-379fc029-erdos410-erdos-410-532b819af6-counterexample-v1 first_order
theorem probe_3_245 : ¬ (fcTypeOfName% "Erdos410.erdos_410") := by
  first_order
#print axioms probe_3_245

-- ATTACK fc-379fc029-erdos410-erdos-410-532b819af6-counterexample-v1 grind
theorem probe_3_246 : ¬ (fcTypeOfName% "Erdos410.erdos_410") := by
  grind
#print axioms probe_3_246

-- ATTACK fc-379fc029-erdos410-erdos-410-532b819af6-counterexample-v1 exact_search
theorem probe_3_247 : ¬ (fcTypeOfName% "Erdos410.erdos_410") := by
  exact?
#print axioms probe_3_247

-- ATTACK fc-379fc029-erdos410-erdos-410-532b819af6-counterexample-v1 apply_search
theorem probe_3_248 : ¬ (fcTypeOfName% "Erdos410.erdos_410") := by
  apply?
#print axioms probe_3_248

-- ATTACK fc-379fc029-erdos410-erdos-410-532b819af6-counterexample-v1 library_search
theorem probe_3_249 : ¬ (fcTypeOfName% "Erdos410.erdos_410") := by
  library_search
#print axioms probe_3_249

-- ATTACK fc-379fc029-erdos410-erdos-410-532b819af6-counterexample-v1 aesop_search
theorem probe_3_250 : ¬ (fcTypeOfName% "Erdos410.erdos_410") := by
  aesop?
#print axioms probe_3_250

-- ATTACK fc-379fc029-erdos410-erdos-410-532b819af6-counterexample-v1 simp_search
theorem probe_3_251 : ¬ (fcTypeOfName% "Erdos410.erdos_410") := by
  simp?
#print axioms probe_3_251

-- ATTACK fc-379fc029-erdos61-erdos-61-356adde5de-counterexample-v1 simp
theorem probe_3_252 : ¬ (fcTypeOfName% "Erdos61.erdos_61") := by
  simp
#print axioms probe_3_252

-- ATTACK fc-379fc029-erdos61-erdos-61-356adde5de-counterexample-v1 simpa
theorem probe_3_253 : ¬ (fcTypeOfName% "Erdos61.erdos_61") := by
  simpa
#print axioms probe_3_253

-- ATTACK fc-379fc029-erdos61-erdos-61-356adde5de-counterexample-v1 simp_all
theorem probe_3_254 : ¬ (fcTypeOfName% "Erdos61.erdos_61") := by
  simp_all
#print axioms probe_3_254

-- ATTACK fc-379fc029-erdos61-erdos-61-356adde5de-counterexample-v1 aesop
theorem probe_3_255 : ¬ (fcTypeOfName% "Erdos61.erdos_61") := by
  aesop
#print axioms probe_3_255

-- ATTACK fc-379fc029-erdos61-erdos-61-356adde5de-counterexample-v1 omega
theorem probe_3_256 : ¬ (fcTypeOfName% "Erdos61.erdos_61") := by
  omega
#print axioms probe_3_256

-- ATTACK fc-379fc029-erdos61-erdos-61-356adde5de-counterexample-v1 norm_num
theorem probe_3_257 : ¬ (fcTypeOfName% "Erdos61.erdos_61") := by
  norm_num
#print axioms probe_3_257

-- ATTACK fc-379fc029-erdos61-erdos-61-356adde5de-counterexample-v1 decide
theorem probe_3_258 : ¬ (fcTypeOfName% "Erdos61.erdos_61") := by
  decide
#print axioms probe_3_258

-- ATTACK fc-379fc029-erdos61-erdos-61-356adde5de-counterexample-v1 native_decide
theorem probe_3_259 : ¬ (fcTypeOfName% "Erdos61.erdos_61") := by
  native_decide
#print axioms probe_3_259

-- ATTACK fc-379fc029-erdos61-erdos-61-356adde5de-counterexample-v1 true_intro
theorem probe_3_260 : ¬ (fcTypeOfName% "Erdos61.erdos_61") := by
  exact True.intro
#print axioms probe_3_260

-- ATTACK fc-379fc029-erdos61-erdos-61-356adde5de-counterexample-v1 false_elim_simp
theorem probe_3_261 : ¬ (fcTypeOfName% "Erdos61.erdos_61") := by
  apply False.elim
  simp_all
#print axioms probe_3_261

-- ATTACK fc-379fc029-erdos61-erdos-61-356adde5de-counterexample-v1 constructor
theorem probe_3_262 : ¬ (fcTypeOfName% "Erdos61.erdos_61") := by
  constructor
#print axioms probe_3_262

-- ATTACK fc-379fc029-erdos61-erdos-61-356adde5de-counterexample-v1 constructor_simp
theorem probe_3_263 : ¬ (fcTypeOfName% "Erdos61.erdos_61") := by
  constructor <;> simp
#print axioms probe_3_263

-- ATTACK fc-379fc029-erdos61-erdos-61-356adde5de-counterexample-v1 constructor_aesop
theorem probe_3_264 : ¬ (fcTypeOfName% "Erdos61.erdos_61") := by
  constructor <;> aesop
#print axioms probe_3_264

-- ATTACK fc-379fc029-erdos61-erdos-61-356adde5de-counterexample-v1 rfl
theorem probe_3_265 : ¬ (fcTypeOfName% "Erdos61.erdos_61") := by
  rfl
#print axioms probe_3_265

-- ATTACK fc-379fc029-erdos61-erdos-61-356adde5de-counterexample-v1 trivial
theorem probe_3_266 : ¬ (fcTypeOfName% "Erdos61.erdos_61") := by
  trivial
#print axioms probe_3_266

-- ATTACK fc-379fc029-erdos61-erdos-61-356adde5de-counterexample-v1 tauto
theorem probe_3_267 : ¬ (fcTypeOfName% "Erdos61.erdos_61") := by
  tauto
#print axioms probe_3_267

-- ATTACK fc-379fc029-erdos61-erdos-61-356adde5de-counterexample-v1 positivity
theorem probe_3_268 : ¬ (fcTypeOfName% "Erdos61.erdos_61") := by
  positivity
#print axioms probe_3_268

-- ATTACK fc-379fc029-erdos61-erdos-61-356adde5de-counterexample-v1 linarith
theorem probe_3_269 : ¬ (fcTypeOfName% "Erdos61.erdos_61") := by
  linarith
#print axioms probe_3_269

-- ATTACK fc-379fc029-erdos61-erdos-61-356adde5de-counterexample-v1 nlinarith
theorem probe_3_270 : ¬ (fcTypeOfName% "Erdos61.erdos_61") := by
  nlinarith
#print axioms probe_3_270

-- ATTACK fc-379fc029-erdos61-erdos-61-356adde5de-counterexample-v1 intros_simp_all
theorem probe_3_271 : ¬ (fcTypeOfName% "Erdos61.erdos_61") := by
  intros
  simp_all
#print axioms probe_3_271

-- ATTACK fc-379fc029-erdos61-erdos-61-356adde5de-counterexample-v1 intros_omega
theorem probe_3_272 : ¬ (fcTypeOfName% "Erdos61.erdos_61") := by
  intros
  omega
#print axioms probe_3_272

-- ATTACK fc-379fc029-erdos61-erdos-61-356adde5de-counterexample-v1 intros_norm_num
theorem probe_3_273 : ¬ (fcTypeOfName% "Erdos61.erdos_61") := by
  intros
  norm_num at *
#print axioms probe_3_273

-- ATTACK fc-379fc029-erdos61-erdos-61-356adde5de-counterexample-v1 intros_aesop
theorem probe_3_274 : ¬ (fcTypeOfName% "Erdos61.erdos_61") := by
  intros
  aesop
#print axioms probe_3_274

-- ATTACK fc-379fc029-erdos61-erdos-61-356adde5de-counterexample-v1 by_contra_simp_all
theorem probe_3_275 : ¬ (fcTypeOfName% "Erdos61.erdos_61") := by
  by_contra h
  simp_all
#print axioms probe_3_275

-- ATTACK fc-379fc029-erdos61-erdos-61-356adde5de-counterexample-v1 classical_simp_all
theorem probe_3_276 : ¬ (fcTypeOfName% "Erdos61.erdos_61") := by
  classical
  simp_all
#print axioms probe_3_276

-- ATTACK fc-379fc029-erdos61-erdos-61-356adde5de-counterexample-v1 classical_aesop
theorem probe_3_277 : ¬ (fcTypeOfName% "Erdos61.erdos_61") := by
  classical
  aesop
#print axioms probe_3_277

-- ATTACK fc-379fc029-erdos61-erdos-61-356adde5de-counterexample-v1 refine_pair_simp
theorem probe_3_278 : ¬ (fcTypeOfName% "Erdos61.erdos_61") := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_3_278

-- ATTACK fc-379fc029-erdos61-erdos-61-356adde5de-counterexample-v1 refine_pair_aesop
theorem probe_3_279 : ¬ (fcTypeOfName% "Erdos61.erdos_61") := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_3_279

-- ATTACK fc-379fc029-erdos61-erdos-61-356adde5de-counterexample-v1 use_zero_simp
theorem probe_3_280 : ¬ (fcTypeOfName% "Erdos61.erdos_61") := by
  use 0 <;> simp
#print axioms probe_3_280

-- ATTACK fc-379fc029-erdos61-erdos-61-356adde5de-counterexample-v1 use_one_simp
theorem probe_3_281 : ¬ (fcTypeOfName% "Erdos61.erdos_61") := by
  use 1 <;> simp
#print axioms probe_3_281

-- ATTACK fc-379fc029-erdos61-erdos-61-356adde5de-counterexample-v1 use_empty_simp
theorem probe_3_282 : ¬ (fcTypeOfName% "Erdos61.erdos_61") := by
  use ∅ <;> simp
#print axioms probe_3_282

-- ATTACK fc-379fc029-erdos61-erdos-61-356adde5de-counterexample-v1 assumption
theorem probe_3_283 : ¬ (fcTypeOfName% "Erdos61.erdos_61") := by
  assumption
#print axioms probe_3_283

-- ATTACK fc-379fc029-erdos61-erdos-61-356adde5de-counterexample-v1 infer_instance
theorem probe_3_284 : ¬ (fcTypeOfName% "Erdos61.erdos_61") := by
  infer_instance
#print axioms probe_3_284

-- ATTACK fc-379fc029-erdos61-erdos-61-356adde5de-counterexample-v1 contradiction
theorem probe_3_285 : ¬ (fcTypeOfName% "Erdos61.erdos_61") := by
  contradiction
#print axioms probe_3_285

-- ATTACK fc-379fc029-erdos61-erdos-61-356adde5de-counterexample-v1 solve_by_elim
theorem probe_3_286 : ¬ (fcTypeOfName% "Erdos61.erdos_61") := by
  solve_by_elim
#print axioms probe_3_286

-- ATTACK fc-379fc029-erdos61-erdos-61-356adde5de-counterexample-v1 first_order
theorem probe_3_287 : ¬ (fcTypeOfName% "Erdos61.erdos_61") := by
  first_order
#print axioms probe_3_287

-- ATTACK fc-379fc029-erdos61-erdos-61-356adde5de-counterexample-v1 grind
theorem probe_3_288 : ¬ (fcTypeOfName% "Erdos61.erdos_61") := by
  grind
#print axioms probe_3_288

-- ATTACK fc-379fc029-erdos61-erdos-61-356adde5de-counterexample-v1 exact_search
theorem probe_3_289 : ¬ (fcTypeOfName% "Erdos61.erdos_61") := by
  exact?
#print axioms probe_3_289

-- ATTACK fc-379fc029-erdos61-erdos-61-356adde5de-counterexample-v1 apply_search
theorem probe_3_290 : ¬ (fcTypeOfName% "Erdos61.erdos_61") := by
  apply?
#print axioms probe_3_290

-- ATTACK fc-379fc029-erdos61-erdos-61-356adde5de-counterexample-v1 library_search
theorem probe_3_291 : ¬ (fcTypeOfName% "Erdos61.erdos_61") := by
  library_search
#print axioms probe_3_291

-- ATTACK fc-379fc029-erdos61-erdos-61-356adde5de-counterexample-v1 aesop_search
theorem probe_3_292 : ¬ (fcTypeOfName% "Erdos61.erdos_61") := by
  aesop?
#print axioms probe_3_292

-- ATTACK fc-379fc029-erdos61-erdos-61-356adde5de-counterexample-v1 simp_search
theorem probe_3_293 : ¬ (fcTypeOfName% "Erdos61.erdos_61") := by
  simp?
#print axioms probe_3_293

-- ATTACK fc-379fc029-erdos749-erdos-749-988e2c14c3-counterexample-v1 simp
theorem probe_3_294 : ¬ (fcTypeOfName% "Erdos749.erdos_749") := by
  simp
#print axioms probe_3_294

-- ATTACK fc-379fc029-erdos749-erdos-749-988e2c14c3-counterexample-v1 simpa
theorem probe_3_295 : ¬ (fcTypeOfName% "Erdos749.erdos_749") := by
  simpa
#print axioms probe_3_295

-- ATTACK fc-379fc029-erdos749-erdos-749-988e2c14c3-counterexample-v1 simp_all
theorem probe_3_296 : ¬ (fcTypeOfName% "Erdos749.erdos_749") := by
  simp_all
#print axioms probe_3_296

-- ATTACK fc-379fc029-erdos749-erdos-749-988e2c14c3-counterexample-v1 aesop
theorem probe_3_297 : ¬ (fcTypeOfName% "Erdos749.erdos_749") := by
  aesop
#print axioms probe_3_297

-- ATTACK fc-379fc029-erdos749-erdos-749-988e2c14c3-counterexample-v1 omega
theorem probe_3_298 : ¬ (fcTypeOfName% "Erdos749.erdos_749") := by
  omega
#print axioms probe_3_298

-- ATTACK fc-379fc029-erdos749-erdos-749-988e2c14c3-counterexample-v1 norm_num
theorem probe_3_299 : ¬ (fcTypeOfName% "Erdos749.erdos_749") := by
  norm_num
#print axioms probe_3_299

-- ATTACK fc-379fc029-erdos749-erdos-749-988e2c14c3-counterexample-v1 decide
theorem probe_3_300 : ¬ (fcTypeOfName% "Erdos749.erdos_749") := by
  decide
#print axioms probe_3_300

-- ATTACK fc-379fc029-erdos749-erdos-749-988e2c14c3-counterexample-v1 native_decide
theorem probe_3_301 : ¬ (fcTypeOfName% "Erdos749.erdos_749") := by
  native_decide
#print axioms probe_3_301

-- ATTACK fc-379fc029-erdos749-erdos-749-988e2c14c3-counterexample-v1 true_intro
theorem probe_3_302 : ¬ (fcTypeOfName% "Erdos749.erdos_749") := by
  exact True.intro
#print axioms probe_3_302

-- ATTACK fc-379fc029-erdos749-erdos-749-988e2c14c3-counterexample-v1 false_elim_simp
theorem probe_3_303 : ¬ (fcTypeOfName% "Erdos749.erdos_749") := by
  apply False.elim
  simp_all
#print axioms probe_3_303

-- ATTACK fc-379fc029-erdos749-erdos-749-988e2c14c3-counterexample-v1 constructor
theorem probe_3_304 : ¬ (fcTypeOfName% "Erdos749.erdos_749") := by
  constructor
#print axioms probe_3_304

-- ATTACK fc-379fc029-erdos749-erdos-749-988e2c14c3-counterexample-v1 constructor_simp
theorem probe_3_305 : ¬ (fcTypeOfName% "Erdos749.erdos_749") := by
  constructor <;> simp
#print axioms probe_3_305

-- ATTACK fc-379fc029-erdos749-erdos-749-988e2c14c3-counterexample-v1 constructor_aesop
theorem probe_3_306 : ¬ (fcTypeOfName% "Erdos749.erdos_749") := by
  constructor <;> aesop
#print axioms probe_3_306

-- ATTACK fc-379fc029-erdos749-erdos-749-988e2c14c3-counterexample-v1 rfl
theorem probe_3_307 : ¬ (fcTypeOfName% "Erdos749.erdos_749") := by
  rfl
#print axioms probe_3_307

-- ATTACK fc-379fc029-erdos749-erdos-749-988e2c14c3-counterexample-v1 trivial
theorem probe_3_308 : ¬ (fcTypeOfName% "Erdos749.erdos_749") := by
  trivial
#print axioms probe_3_308

-- ATTACK fc-379fc029-erdos749-erdos-749-988e2c14c3-counterexample-v1 tauto
theorem probe_3_309 : ¬ (fcTypeOfName% "Erdos749.erdos_749") := by
  tauto
#print axioms probe_3_309

-- ATTACK fc-379fc029-erdos749-erdos-749-988e2c14c3-counterexample-v1 positivity
theorem probe_3_310 : ¬ (fcTypeOfName% "Erdos749.erdos_749") := by
  positivity
#print axioms probe_3_310

-- ATTACK fc-379fc029-erdos749-erdos-749-988e2c14c3-counterexample-v1 linarith
theorem probe_3_311 : ¬ (fcTypeOfName% "Erdos749.erdos_749") := by
  linarith
#print axioms probe_3_311

-- ATTACK fc-379fc029-erdos749-erdos-749-988e2c14c3-counterexample-v1 nlinarith
theorem probe_3_312 : ¬ (fcTypeOfName% "Erdos749.erdos_749") := by
  nlinarith
#print axioms probe_3_312

-- ATTACK fc-379fc029-erdos749-erdos-749-988e2c14c3-counterexample-v1 intros_simp_all
theorem probe_3_313 : ¬ (fcTypeOfName% "Erdos749.erdos_749") := by
  intros
  simp_all
#print axioms probe_3_313

-- ATTACK fc-379fc029-erdos749-erdos-749-988e2c14c3-counterexample-v1 intros_omega
theorem probe_3_314 : ¬ (fcTypeOfName% "Erdos749.erdos_749") := by
  intros
  omega
#print axioms probe_3_314

-- ATTACK fc-379fc029-erdos749-erdos-749-988e2c14c3-counterexample-v1 intros_norm_num
theorem probe_3_315 : ¬ (fcTypeOfName% "Erdos749.erdos_749") := by
  intros
  norm_num at *
#print axioms probe_3_315

-- ATTACK fc-379fc029-erdos749-erdos-749-988e2c14c3-counterexample-v1 intros_aesop
theorem probe_3_316 : ¬ (fcTypeOfName% "Erdos749.erdos_749") := by
  intros
  aesop
#print axioms probe_3_316

-- ATTACK fc-379fc029-erdos749-erdos-749-988e2c14c3-counterexample-v1 by_contra_simp_all
theorem probe_3_317 : ¬ (fcTypeOfName% "Erdos749.erdos_749") := by
  by_contra h
  simp_all
#print axioms probe_3_317

-- ATTACK fc-379fc029-erdos749-erdos-749-988e2c14c3-counterexample-v1 classical_simp_all
theorem probe_3_318 : ¬ (fcTypeOfName% "Erdos749.erdos_749") := by
  classical
  simp_all
#print axioms probe_3_318

-- ATTACK fc-379fc029-erdos749-erdos-749-988e2c14c3-counterexample-v1 classical_aesop
theorem probe_3_319 : ¬ (fcTypeOfName% "Erdos749.erdos_749") := by
  classical
  aesop
#print axioms probe_3_319

-- ATTACK fc-379fc029-erdos749-erdos-749-988e2c14c3-counterexample-v1 refine_pair_simp
theorem probe_3_320 : ¬ (fcTypeOfName% "Erdos749.erdos_749") := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_3_320

-- ATTACK fc-379fc029-erdos749-erdos-749-988e2c14c3-counterexample-v1 refine_pair_aesop
theorem probe_3_321 : ¬ (fcTypeOfName% "Erdos749.erdos_749") := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_3_321

-- ATTACK fc-379fc029-erdos749-erdos-749-988e2c14c3-counterexample-v1 use_zero_simp
theorem probe_3_322 : ¬ (fcTypeOfName% "Erdos749.erdos_749") := by
  use 0 <;> simp
#print axioms probe_3_322

-- ATTACK fc-379fc029-erdos749-erdos-749-988e2c14c3-counterexample-v1 use_one_simp
theorem probe_3_323 : ¬ (fcTypeOfName% "Erdos749.erdos_749") := by
  use 1 <;> simp
#print axioms probe_3_323

-- ATTACK fc-379fc029-erdos749-erdos-749-988e2c14c3-counterexample-v1 use_empty_simp
theorem probe_3_324 : ¬ (fcTypeOfName% "Erdos749.erdos_749") := by
  use ∅ <;> simp
#print axioms probe_3_324

-- ATTACK fc-379fc029-erdos749-erdos-749-988e2c14c3-counterexample-v1 assumption
theorem probe_3_325 : ¬ (fcTypeOfName% "Erdos749.erdos_749") := by
  assumption
#print axioms probe_3_325

-- ATTACK fc-379fc029-erdos749-erdos-749-988e2c14c3-counterexample-v1 infer_instance
theorem probe_3_326 : ¬ (fcTypeOfName% "Erdos749.erdos_749") := by
  infer_instance
#print axioms probe_3_326

-- ATTACK fc-379fc029-erdos749-erdos-749-988e2c14c3-counterexample-v1 contradiction
theorem probe_3_327 : ¬ (fcTypeOfName% "Erdos749.erdos_749") := by
  contradiction
#print axioms probe_3_327

-- ATTACK fc-379fc029-erdos749-erdos-749-988e2c14c3-counterexample-v1 solve_by_elim
theorem probe_3_328 : ¬ (fcTypeOfName% "Erdos749.erdos_749") := by
  solve_by_elim
#print axioms probe_3_328

-- ATTACK fc-379fc029-erdos749-erdos-749-988e2c14c3-counterexample-v1 first_order
theorem probe_3_329 : ¬ (fcTypeOfName% "Erdos749.erdos_749") := by
  first_order
#print axioms probe_3_329

-- ATTACK fc-379fc029-erdos749-erdos-749-988e2c14c3-counterexample-v1 grind
theorem probe_3_330 : ¬ (fcTypeOfName% "Erdos749.erdos_749") := by
  grind
#print axioms probe_3_330

-- ATTACK fc-379fc029-erdos749-erdos-749-988e2c14c3-counterexample-v1 exact_search
theorem probe_3_331 : ¬ (fcTypeOfName% "Erdos749.erdos_749") := by
  exact?
#print axioms probe_3_331

-- ATTACK fc-379fc029-erdos749-erdos-749-988e2c14c3-counterexample-v1 apply_search
theorem probe_3_332 : ¬ (fcTypeOfName% "Erdos749.erdos_749") := by
  apply?
#print axioms probe_3_332

-- ATTACK fc-379fc029-erdos749-erdos-749-988e2c14c3-counterexample-v1 library_search
theorem probe_3_333 : ¬ (fcTypeOfName% "Erdos749.erdos_749") := by
  library_search
#print axioms probe_3_333

-- ATTACK fc-379fc029-erdos749-erdos-749-988e2c14c3-counterexample-v1 aesop_search
theorem probe_3_334 : ¬ (fcTypeOfName% "Erdos749.erdos_749") := by
  aesop?
#print axioms probe_3_334

-- ATTACK fc-379fc029-erdos749-erdos-749-988e2c14c3-counterexample-v1 simp_search
theorem probe_3_335 : ¬ (fcTypeOfName% "Erdos749.erdos_749") := by
  simp?
#print axioms probe_3_335

-- ATTACK fc-379fc029-erdos91-erdos-91-9928cf1dc7-counterexample-v1 simp
theorem probe_3_336 : ¬ (fcTypeOfName% "Erdos91.erdos_91") := by
  simp
#print axioms probe_3_336

-- ATTACK fc-379fc029-erdos91-erdos-91-9928cf1dc7-counterexample-v1 simpa
theorem probe_3_337 : ¬ (fcTypeOfName% "Erdos91.erdos_91") := by
  simpa
#print axioms probe_3_337

-- ATTACK fc-379fc029-erdos91-erdos-91-9928cf1dc7-counterexample-v1 simp_all
theorem probe_3_338 : ¬ (fcTypeOfName% "Erdos91.erdos_91") := by
  simp_all
#print axioms probe_3_338

-- ATTACK fc-379fc029-erdos91-erdos-91-9928cf1dc7-counterexample-v1 aesop
theorem probe_3_339 : ¬ (fcTypeOfName% "Erdos91.erdos_91") := by
  aesop
#print axioms probe_3_339

-- ATTACK fc-379fc029-erdos91-erdos-91-9928cf1dc7-counterexample-v1 omega
theorem probe_3_340 : ¬ (fcTypeOfName% "Erdos91.erdos_91") := by
  omega
#print axioms probe_3_340

-- ATTACK fc-379fc029-erdos91-erdos-91-9928cf1dc7-counterexample-v1 norm_num
theorem probe_3_341 : ¬ (fcTypeOfName% "Erdos91.erdos_91") := by
  norm_num
#print axioms probe_3_341

-- ATTACK fc-379fc029-erdos91-erdos-91-9928cf1dc7-counterexample-v1 decide
theorem probe_3_342 : ¬ (fcTypeOfName% "Erdos91.erdos_91") := by
  decide
#print axioms probe_3_342

-- ATTACK fc-379fc029-erdos91-erdos-91-9928cf1dc7-counterexample-v1 native_decide
theorem probe_3_343 : ¬ (fcTypeOfName% "Erdos91.erdos_91") := by
  native_decide
#print axioms probe_3_343

-- ATTACK fc-379fc029-erdos91-erdos-91-9928cf1dc7-counterexample-v1 true_intro
theorem probe_3_344 : ¬ (fcTypeOfName% "Erdos91.erdos_91") := by
  exact True.intro
#print axioms probe_3_344

-- ATTACK fc-379fc029-erdos91-erdos-91-9928cf1dc7-counterexample-v1 false_elim_simp
theorem probe_3_345 : ¬ (fcTypeOfName% "Erdos91.erdos_91") := by
  apply False.elim
  simp_all
#print axioms probe_3_345

-- ATTACK fc-379fc029-erdos91-erdos-91-9928cf1dc7-counterexample-v1 constructor
theorem probe_3_346 : ¬ (fcTypeOfName% "Erdos91.erdos_91") := by
  constructor
#print axioms probe_3_346

-- ATTACK fc-379fc029-erdos91-erdos-91-9928cf1dc7-counterexample-v1 constructor_simp
theorem probe_3_347 : ¬ (fcTypeOfName% "Erdos91.erdos_91") := by
  constructor <;> simp
#print axioms probe_3_347

-- ATTACK fc-379fc029-erdos91-erdos-91-9928cf1dc7-counterexample-v1 constructor_aesop
theorem probe_3_348 : ¬ (fcTypeOfName% "Erdos91.erdos_91") := by
  constructor <;> aesop
#print axioms probe_3_348

-- ATTACK fc-379fc029-erdos91-erdos-91-9928cf1dc7-counterexample-v1 rfl
theorem probe_3_349 : ¬ (fcTypeOfName% "Erdos91.erdos_91") := by
  rfl
#print axioms probe_3_349

-- ATTACK fc-379fc029-erdos91-erdos-91-9928cf1dc7-counterexample-v1 trivial
theorem probe_3_350 : ¬ (fcTypeOfName% "Erdos91.erdos_91") := by
  trivial
#print axioms probe_3_350

-- ATTACK fc-379fc029-erdos91-erdos-91-9928cf1dc7-counterexample-v1 tauto
theorem probe_3_351 : ¬ (fcTypeOfName% "Erdos91.erdos_91") := by
  tauto
#print axioms probe_3_351

-- ATTACK fc-379fc029-erdos91-erdos-91-9928cf1dc7-counterexample-v1 positivity
theorem probe_3_352 : ¬ (fcTypeOfName% "Erdos91.erdos_91") := by
  positivity
#print axioms probe_3_352

-- ATTACK fc-379fc029-erdos91-erdos-91-9928cf1dc7-counterexample-v1 linarith
theorem probe_3_353 : ¬ (fcTypeOfName% "Erdos91.erdos_91") := by
  linarith
#print axioms probe_3_353

-- ATTACK fc-379fc029-erdos91-erdos-91-9928cf1dc7-counterexample-v1 nlinarith
theorem probe_3_354 : ¬ (fcTypeOfName% "Erdos91.erdos_91") := by
  nlinarith
#print axioms probe_3_354

-- ATTACK fc-379fc029-erdos91-erdos-91-9928cf1dc7-counterexample-v1 intros_simp_all
theorem probe_3_355 : ¬ (fcTypeOfName% "Erdos91.erdos_91") := by
  intros
  simp_all
#print axioms probe_3_355

-- ATTACK fc-379fc029-erdos91-erdos-91-9928cf1dc7-counterexample-v1 intros_omega
theorem probe_3_356 : ¬ (fcTypeOfName% "Erdos91.erdos_91") := by
  intros
  omega
#print axioms probe_3_356

-- ATTACK fc-379fc029-erdos91-erdos-91-9928cf1dc7-counterexample-v1 intros_norm_num
theorem probe_3_357 : ¬ (fcTypeOfName% "Erdos91.erdos_91") := by
  intros
  norm_num at *
#print axioms probe_3_357

-- ATTACK fc-379fc029-erdos91-erdos-91-9928cf1dc7-counterexample-v1 intros_aesop
theorem probe_3_358 : ¬ (fcTypeOfName% "Erdos91.erdos_91") := by
  intros
  aesop
#print axioms probe_3_358

-- ATTACK fc-379fc029-erdos91-erdos-91-9928cf1dc7-counterexample-v1 by_contra_simp_all
theorem probe_3_359 : ¬ (fcTypeOfName% "Erdos91.erdos_91") := by
  by_contra h
  simp_all
#print axioms probe_3_359

-- ATTACK fc-379fc029-erdos91-erdos-91-9928cf1dc7-counterexample-v1 classical_simp_all
theorem probe_3_360 : ¬ (fcTypeOfName% "Erdos91.erdos_91") := by
  classical
  simp_all
#print axioms probe_3_360

-- ATTACK fc-379fc029-erdos91-erdos-91-9928cf1dc7-counterexample-v1 classical_aesop
theorem probe_3_361 : ¬ (fcTypeOfName% "Erdos91.erdos_91") := by
  classical
  aesop
#print axioms probe_3_361

-- ATTACK fc-379fc029-erdos91-erdos-91-9928cf1dc7-counterexample-v1 refine_pair_simp
theorem probe_3_362 : ¬ (fcTypeOfName% "Erdos91.erdos_91") := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_3_362

-- ATTACK fc-379fc029-erdos91-erdos-91-9928cf1dc7-counterexample-v1 refine_pair_aesop
theorem probe_3_363 : ¬ (fcTypeOfName% "Erdos91.erdos_91") := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_3_363

-- ATTACK fc-379fc029-erdos91-erdos-91-9928cf1dc7-counterexample-v1 use_zero_simp
theorem probe_3_364 : ¬ (fcTypeOfName% "Erdos91.erdos_91") := by
  use 0 <;> simp
#print axioms probe_3_364

-- ATTACK fc-379fc029-erdos91-erdos-91-9928cf1dc7-counterexample-v1 use_one_simp
theorem probe_3_365 : ¬ (fcTypeOfName% "Erdos91.erdos_91") := by
  use 1 <;> simp
#print axioms probe_3_365

-- ATTACK fc-379fc029-erdos91-erdos-91-9928cf1dc7-counterexample-v1 use_empty_simp
theorem probe_3_366 : ¬ (fcTypeOfName% "Erdos91.erdos_91") := by
  use ∅ <;> simp
#print axioms probe_3_366

-- ATTACK fc-379fc029-erdos91-erdos-91-9928cf1dc7-counterexample-v1 assumption
theorem probe_3_367 : ¬ (fcTypeOfName% "Erdos91.erdos_91") := by
  assumption
#print axioms probe_3_367

-- ATTACK fc-379fc029-erdos91-erdos-91-9928cf1dc7-counterexample-v1 infer_instance
theorem probe_3_368 : ¬ (fcTypeOfName% "Erdos91.erdos_91") := by
  infer_instance
#print axioms probe_3_368

-- ATTACK fc-379fc029-erdos91-erdos-91-9928cf1dc7-counterexample-v1 contradiction
theorem probe_3_369 : ¬ (fcTypeOfName% "Erdos91.erdos_91") := by
  contradiction
#print axioms probe_3_369

-- ATTACK fc-379fc029-erdos91-erdos-91-9928cf1dc7-counterexample-v1 solve_by_elim
theorem probe_3_370 : ¬ (fcTypeOfName% "Erdos91.erdos_91") := by
  solve_by_elim
#print axioms probe_3_370

-- ATTACK fc-379fc029-erdos91-erdos-91-9928cf1dc7-counterexample-v1 first_order
theorem probe_3_371 : ¬ (fcTypeOfName% "Erdos91.erdos_91") := by
  first_order
#print axioms probe_3_371

-- ATTACK fc-379fc029-erdos91-erdos-91-9928cf1dc7-counterexample-v1 grind
theorem probe_3_372 : ¬ (fcTypeOfName% "Erdos91.erdos_91") := by
  grind
#print axioms probe_3_372

-- ATTACK fc-379fc029-erdos91-erdos-91-9928cf1dc7-counterexample-v1 exact_search
theorem probe_3_373 : ¬ (fcTypeOfName% "Erdos91.erdos_91") := by
  exact?
#print axioms probe_3_373

-- ATTACK fc-379fc029-erdos91-erdos-91-9928cf1dc7-counterexample-v1 apply_search
theorem probe_3_374 : ¬ (fcTypeOfName% "Erdos91.erdos_91") := by
  apply?
#print axioms probe_3_374

-- ATTACK fc-379fc029-erdos91-erdos-91-9928cf1dc7-counterexample-v1 library_search
theorem probe_3_375 : ¬ (fcTypeOfName% "Erdos91.erdos_91") := by
  library_search
#print axioms probe_3_375

-- ATTACK fc-379fc029-erdos91-erdos-91-9928cf1dc7-counterexample-v1 aesop_search
theorem probe_3_376 : ¬ (fcTypeOfName% "Erdos91.erdos_91") := by
  aesop?
#print axioms probe_3_376

-- ATTACK fc-379fc029-erdos91-erdos-91-9928cf1dc7-counterexample-v1 simp_search
theorem probe_3_377 : ¬ (fcTypeOfName% "Erdos91.erdos_91") := by
  simp?
#print axioms probe_3_377

-- ATTACK fc-379fc029-variants-factorial-sub-one-1ac728555f-counterexample-v1 simp
theorem probe_3_378 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one") := by
  simp
#print axioms probe_3_378

-- ATTACK fc-379fc029-variants-factorial-sub-one-1ac728555f-counterexample-v1 simpa
theorem probe_3_379 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one") := by
  simpa
#print axioms probe_3_379

-- ATTACK fc-379fc029-variants-factorial-sub-one-1ac728555f-counterexample-v1 simp_all
theorem probe_3_380 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one") := by
  simp_all
#print axioms probe_3_380

-- ATTACK fc-379fc029-variants-factorial-sub-one-1ac728555f-counterexample-v1 aesop
theorem probe_3_381 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one") := by
  aesop
#print axioms probe_3_381

-- ATTACK fc-379fc029-variants-factorial-sub-one-1ac728555f-counterexample-v1 omega
theorem probe_3_382 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one") := by
  omega
#print axioms probe_3_382

-- ATTACK fc-379fc029-variants-factorial-sub-one-1ac728555f-counterexample-v1 norm_num
theorem probe_3_383 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one") := by
  norm_num
#print axioms probe_3_383

-- ATTACK fc-379fc029-variants-factorial-sub-one-1ac728555f-counterexample-v1 decide
theorem probe_3_384 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one") := by
  decide
#print axioms probe_3_384

-- ATTACK fc-379fc029-variants-factorial-sub-one-1ac728555f-counterexample-v1 native_decide
theorem probe_3_385 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one") := by
  native_decide
#print axioms probe_3_385

-- ATTACK fc-379fc029-variants-factorial-sub-one-1ac728555f-counterexample-v1 true_intro
theorem probe_3_386 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one") := by
  exact True.intro
#print axioms probe_3_386

-- ATTACK fc-379fc029-variants-factorial-sub-one-1ac728555f-counterexample-v1 false_elim_simp
theorem probe_3_387 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one") := by
  apply False.elim
  simp_all
#print axioms probe_3_387

-- ATTACK fc-379fc029-variants-factorial-sub-one-1ac728555f-counterexample-v1 constructor
theorem probe_3_388 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one") := by
  constructor
#print axioms probe_3_388

-- ATTACK fc-379fc029-variants-factorial-sub-one-1ac728555f-counterexample-v1 constructor_simp
theorem probe_3_389 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one") := by
  constructor <;> simp
#print axioms probe_3_389

-- ATTACK fc-379fc029-variants-factorial-sub-one-1ac728555f-counterexample-v1 constructor_aesop
theorem probe_3_390 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one") := by
  constructor <;> aesop
#print axioms probe_3_390

-- ATTACK fc-379fc029-variants-factorial-sub-one-1ac728555f-counterexample-v1 rfl
theorem probe_3_391 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one") := by
  rfl
#print axioms probe_3_391

-- ATTACK fc-379fc029-variants-factorial-sub-one-1ac728555f-counterexample-v1 trivial
theorem probe_3_392 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one") := by
  trivial
#print axioms probe_3_392

-- ATTACK fc-379fc029-variants-factorial-sub-one-1ac728555f-counterexample-v1 tauto
theorem probe_3_393 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one") := by
  tauto
#print axioms probe_3_393

-- ATTACK fc-379fc029-variants-factorial-sub-one-1ac728555f-counterexample-v1 positivity
theorem probe_3_394 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one") := by
  positivity
#print axioms probe_3_394

-- ATTACK fc-379fc029-variants-factorial-sub-one-1ac728555f-counterexample-v1 linarith
theorem probe_3_395 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one") := by
  linarith
#print axioms probe_3_395

-- ATTACK fc-379fc029-variants-factorial-sub-one-1ac728555f-counterexample-v1 nlinarith
theorem probe_3_396 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one") := by
  nlinarith
#print axioms probe_3_396

-- ATTACK fc-379fc029-variants-factorial-sub-one-1ac728555f-counterexample-v1 intros_simp_all
theorem probe_3_397 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one") := by
  intros
  simp_all
#print axioms probe_3_397

-- ATTACK fc-379fc029-variants-factorial-sub-one-1ac728555f-counterexample-v1 intros_omega
theorem probe_3_398 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one") := by
  intros
  omega
#print axioms probe_3_398

-- ATTACK fc-379fc029-variants-factorial-sub-one-1ac728555f-counterexample-v1 intros_norm_num
theorem probe_3_399 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one") := by
  intros
  norm_num at *
#print axioms probe_3_399

-- ATTACK fc-379fc029-variants-factorial-sub-one-1ac728555f-counterexample-v1 intros_aesop
theorem probe_3_400 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one") := by
  intros
  aesop
#print axioms probe_3_400

-- ATTACK fc-379fc029-variants-factorial-sub-one-1ac728555f-counterexample-v1 by_contra_simp_all
theorem probe_3_401 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one") := by
  by_contra h
  simp_all
#print axioms probe_3_401

-- ATTACK fc-379fc029-variants-factorial-sub-one-1ac728555f-counterexample-v1 classical_simp_all
theorem probe_3_402 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one") := by
  classical
  simp_all
#print axioms probe_3_402

-- ATTACK fc-379fc029-variants-factorial-sub-one-1ac728555f-counterexample-v1 classical_aesop
theorem probe_3_403 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one") := by
  classical
  aesop
#print axioms probe_3_403

-- ATTACK fc-379fc029-variants-factorial-sub-one-1ac728555f-counterexample-v1 refine_pair_simp
theorem probe_3_404 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one") := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_3_404

-- ATTACK fc-379fc029-variants-factorial-sub-one-1ac728555f-counterexample-v1 refine_pair_aesop
theorem probe_3_405 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one") := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_3_405

-- ATTACK fc-379fc029-variants-factorial-sub-one-1ac728555f-counterexample-v1 use_zero_simp
theorem probe_3_406 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one") := by
  use 0 <;> simp
#print axioms probe_3_406

-- ATTACK fc-379fc029-variants-factorial-sub-one-1ac728555f-counterexample-v1 use_one_simp
theorem probe_3_407 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one") := by
  use 1 <;> simp
#print axioms probe_3_407

-- ATTACK fc-379fc029-variants-factorial-sub-one-1ac728555f-counterexample-v1 use_empty_simp
theorem probe_3_408 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one") := by
  use ∅ <;> simp
#print axioms probe_3_408

-- ATTACK fc-379fc029-variants-factorial-sub-one-1ac728555f-counterexample-v1 assumption
theorem probe_3_409 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one") := by
  assumption
#print axioms probe_3_409

-- ATTACK fc-379fc029-variants-factorial-sub-one-1ac728555f-counterexample-v1 infer_instance
theorem probe_3_410 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one") := by
  infer_instance
#print axioms probe_3_410

-- ATTACK fc-379fc029-variants-factorial-sub-one-1ac728555f-counterexample-v1 contradiction
theorem probe_3_411 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one") := by
  contradiction
#print axioms probe_3_411

-- ATTACK fc-379fc029-variants-factorial-sub-one-1ac728555f-counterexample-v1 solve_by_elim
theorem probe_3_412 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one") := by
  solve_by_elim
#print axioms probe_3_412

-- ATTACK fc-379fc029-variants-factorial-sub-one-1ac728555f-counterexample-v1 first_order
theorem probe_3_413 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one") := by
  first_order
#print axioms probe_3_413

-- ATTACK fc-379fc029-variants-factorial-sub-one-1ac728555f-counterexample-v1 grind
theorem probe_3_414 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one") := by
  grind
#print axioms probe_3_414

-- ATTACK fc-379fc029-variants-factorial-sub-one-1ac728555f-counterexample-v1 exact_search
theorem probe_3_415 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one") := by
  exact?
#print axioms probe_3_415

-- ATTACK fc-379fc029-variants-factorial-sub-one-1ac728555f-counterexample-v1 apply_search
theorem probe_3_416 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one") := by
  apply?
#print axioms probe_3_416

-- ATTACK fc-379fc029-variants-factorial-sub-one-1ac728555f-counterexample-v1 library_search
theorem probe_3_417 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one") := by
  library_search
#print axioms probe_3_417

-- ATTACK fc-379fc029-variants-factorial-sub-one-1ac728555f-counterexample-v1 aesop_search
theorem probe_3_418 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one") := by
  aesop?
#print axioms probe_3_418

-- ATTACK fc-379fc029-variants-factorial-sub-one-1ac728555f-counterexample-v1 simp_search
theorem probe_3_419 : ¬ (fcTypeOfName% "Erdos936.erdos_936.variants.factorial_sub_one") := by
  simp?
#print axioms probe_3_419

-- ATTACK fc-379fc029-erdos962-erdos-962-9458b60a0e-counterexample-v1 simp
theorem probe_3_420 : ¬ (fcTypeOfName% "Erdos962.erdos_962") := by
  simp
#print axioms probe_3_420

-- ATTACK fc-379fc029-erdos962-erdos-962-9458b60a0e-counterexample-v1 simpa
theorem probe_3_421 : ¬ (fcTypeOfName% "Erdos962.erdos_962") := by
  simpa
#print axioms probe_3_421

-- ATTACK fc-379fc029-erdos962-erdos-962-9458b60a0e-counterexample-v1 simp_all
theorem probe_3_422 : ¬ (fcTypeOfName% "Erdos962.erdos_962") := by
  simp_all
#print axioms probe_3_422

-- ATTACK fc-379fc029-erdos962-erdos-962-9458b60a0e-counterexample-v1 aesop
theorem probe_3_423 : ¬ (fcTypeOfName% "Erdos962.erdos_962") := by
  aesop
#print axioms probe_3_423

-- ATTACK fc-379fc029-erdos962-erdos-962-9458b60a0e-counterexample-v1 omega
theorem probe_3_424 : ¬ (fcTypeOfName% "Erdos962.erdos_962") := by
  omega
#print axioms probe_3_424

-- ATTACK fc-379fc029-erdos962-erdos-962-9458b60a0e-counterexample-v1 norm_num
theorem probe_3_425 : ¬ (fcTypeOfName% "Erdos962.erdos_962") := by
  norm_num
#print axioms probe_3_425

-- ATTACK fc-379fc029-erdos962-erdos-962-9458b60a0e-counterexample-v1 decide
theorem probe_3_426 : ¬ (fcTypeOfName% "Erdos962.erdos_962") := by
  decide
#print axioms probe_3_426

-- ATTACK fc-379fc029-erdos962-erdos-962-9458b60a0e-counterexample-v1 native_decide
theorem probe_3_427 : ¬ (fcTypeOfName% "Erdos962.erdos_962") := by
  native_decide
#print axioms probe_3_427

-- ATTACK fc-379fc029-erdos962-erdos-962-9458b60a0e-counterexample-v1 true_intro
theorem probe_3_428 : ¬ (fcTypeOfName% "Erdos962.erdos_962") := by
  exact True.intro
#print axioms probe_3_428

-- ATTACK fc-379fc029-erdos962-erdos-962-9458b60a0e-counterexample-v1 false_elim_simp
theorem probe_3_429 : ¬ (fcTypeOfName% "Erdos962.erdos_962") := by
  apply False.elim
  simp_all
#print axioms probe_3_429

-- ATTACK fc-379fc029-erdos962-erdos-962-9458b60a0e-counterexample-v1 constructor
theorem probe_3_430 : ¬ (fcTypeOfName% "Erdos962.erdos_962") := by
  constructor
#print axioms probe_3_430

-- ATTACK fc-379fc029-erdos962-erdos-962-9458b60a0e-counterexample-v1 constructor_simp
theorem probe_3_431 : ¬ (fcTypeOfName% "Erdos962.erdos_962") := by
  constructor <;> simp
#print axioms probe_3_431

-- ATTACK fc-379fc029-erdos962-erdos-962-9458b60a0e-counterexample-v1 constructor_aesop
theorem probe_3_432 : ¬ (fcTypeOfName% "Erdos962.erdos_962") := by
  constructor <;> aesop
#print axioms probe_3_432

-- ATTACK fc-379fc029-erdos962-erdos-962-9458b60a0e-counterexample-v1 rfl
theorem probe_3_433 : ¬ (fcTypeOfName% "Erdos962.erdos_962") := by
  rfl
#print axioms probe_3_433

-- ATTACK fc-379fc029-erdos962-erdos-962-9458b60a0e-counterexample-v1 trivial
theorem probe_3_434 : ¬ (fcTypeOfName% "Erdos962.erdos_962") := by
  trivial
#print axioms probe_3_434

-- ATTACK fc-379fc029-erdos962-erdos-962-9458b60a0e-counterexample-v1 tauto
theorem probe_3_435 : ¬ (fcTypeOfName% "Erdos962.erdos_962") := by
  tauto
#print axioms probe_3_435

-- ATTACK fc-379fc029-erdos962-erdos-962-9458b60a0e-counterexample-v1 positivity
theorem probe_3_436 : ¬ (fcTypeOfName% "Erdos962.erdos_962") := by
  positivity
#print axioms probe_3_436

-- ATTACK fc-379fc029-erdos962-erdos-962-9458b60a0e-counterexample-v1 linarith
theorem probe_3_437 : ¬ (fcTypeOfName% "Erdos962.erdos_962") := by
  linarith
#print axioms probe_3_437

-- ATTACK fc-379fc029-erdos962-erdos-962-9458b60a0e-counterexample-v1 nlinarith
theorem probe_3_438 : ¬ (fcTypeOfName% "Erdos962.erdos_962") := by
  nlinarith
#print axioms probe_3_438

-- ATTACK fc-379fc029-erdos962-erdos-962-9458b60a0e-counterexample-v1 intros_simp_all
theorem probe_3_439 : ¬ (fcTypeOfName% "Erdos962.erdos_962") := by
  intros
  simp_all
#print axioms probe_3_439

-- ATTACK fc-379fc029-erdos962-erdos-962-9458b60a0e-counterexample-v1 intros_omega
theorem probe_3_440 : ¬ (fcTypeOfName% "Erdos962.erdos_962") := by
  intros
  omega
#print axioms probe_3_440

-- ATTACK fc-379fc029-erdos962-erdos-962-9458b60a0e-counterexample-v1 intros_norm_num
theorem probe_3_441 : ¬ (fcTypeOfName% "Erdos962.erdos_962") := by
  intros
  norm_num at *
#print axioms probe_3_441

-- ATTACK fc-379fc029-erdos962-erdos-962-9458b60a0e-counterexample-v1 intros_aesop
theorem probe_3_442 : ¬ (fcTypeOfName% "Erdos962.erdos_962") := by
  intros
  aesop
#print axioms probe_3_442

-- ATTACK fc-379fc029-erdos962-erdos-962-9458b60a0e-counterexample-v1 by_contra_simp_all
theorem probe_3_443 : ¬ (fcTypeOfName% "Erdos962.erdos_962") := by
  by_contra h
  simp_all
#print axioms probe_3_443

-- ATTACK fc-379fc029-erdos962-erdos-962-9458b60a0e-counterexample-v1 classical_simp_all
theorem probe_3_444 : ¬ (fcTypeOfName% "Erdos962.erdos_962") := by
  classical
  simp_all
#print axioms probe_3_444

-- ATTACK fc-379fc029-erdos962-erdos-962-9458b60a0e-counterexample-v1 classical_aesop
theorem probe_3_445 : ¬ (fcTypeOfName% "Erdos962.erdos_962") := by
  classical
  aesop
#print axioms probe_3_445

-- ATTACK fc-379fc029-erdos962-erdos-962-9458b60a0e-counterexample-v1 refine_pair_simp
theorem probe_3_446 : ¬ (fcTypeOfName% "Erdos962.erdos_962") := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_3_446

-- ATTACK fc-379fc029-erdos962-erdos-962-9458b60a0e-counterexample-v1 refine_pair_aesop
theorem probe_3_447 : ¬ (fcTypeOfName% "Erdos962.erdos_962") := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_3_447

-- ATTACK fc-379fc029-erdos962-erdos-962-9458b60a0e-counterexample-v1 use_zero_simp
theorem probe_3_448 : ¬ (fcTypeOfName% "Erdos962.erdos_962") := by
  use 0 <;> simp
#print axioms probe_3_448

-- ATTACK fc-379fc029-erdos962-erdos-962-9458b60a0e-counterexample-v1 use_one_simp
theorem probe_3_449 : ¬ (fcTypeOfName% "Erdos962.erdos_962") := by
  use 1 <;> simp
#print axioms probe_3_449

-- ATTACK fc-379fc029-erdos962-erdos-962-9458b60a0e-counterexample-v1 use_empty_simp
theorem probe_3_450 : ¬ (fcTypeOfName% "Erdos962.erdos_962") := by
  use ∅ <;> simp
#print axioms probe_3_450

-- ATTACK fc-379fc029-erdos962-erdos-962-9458b60a0e-counterexample-v1 assumption
theorem probe_3_451 : ¬ (fcTypeOfName% "Erdos962.erdos_962") := by
  assumption
#print axioms probe_3_451

-- ATTACK fc-379fc029-erdos962-erdos-962-9458b60a0e-counterexample-v1 infer_instance
theorem probe_3_452 : ¬ (fcTypeOfName% "Erdos962.erdos_962") := by
  infer_instance
#print axioms probe_3_452

-- ATTACK fc-379fc029-erdos962-erdos-962-9458b60a0e-counterexample-v1 contradiction
theorem probe_3_453 : ¬ (fcTypeOfName% "Erdos962.erdos_962") := by
  contradiction
#print axioms probe_3_453

-- ATTACK fc-379fc029-erdos962-erdos-962-9458b60a0e-counterexample-v1 solve_by_elim
theorem probe_3_454 : ¬ (fcTypeOfName% "Erdos962.erdos_962") := by
  solve_by_elim
#print axioms probe_3_454

-- ATTACK fc-379fc029-erdos962-erdos-962-9458b60a0e-counterexample-v1 first_order
theorem probe_3_455 : ¬ (fcTypeOfName% "Erdos962.erdos_962") := by
  first_order
#print axioms probe_3_455

-- ATTACK fc-379fc029-erdos962-erdos-962-9458b60a0e-counterexample-v1 grind
theorem probe_3_456 : ¬ (fcTypeOfName% "Erdos962.erdos_962") := by
  grind
#print axioms probe_3_456

-- ATTACK fc-379fc029-erdos962-erdos-962-9458b60a0e-counterexample-v1 exact_search
theorem probe_3_457 : ¬ (fcTypeOfName% "Erdos962.erdos_962") := by
  exact?
#print axioms probe_3_457

-- ATTACK fc-379fc029-erdos962-erdos-962-9458b60a0e-counterexample-v1 apply_search
theorem probe_3_458 : ¬ (fcTypeOfName% "Erdos962.erdos_962") := by
  apply?
#print axioms probe_3_458

-- ATTACK fc-379fc029-erdos962-erdos-962-9458b60a0e-counterexample-v1 library_search
theorem probe_3_459 : ¬ (fcTypeOfName% "Erdos962.erdos_962") := by
  library_search
#print axioms probe_3_459

-- ATTACK fc-379fc029-erdos962-erdos-962-9458b60a0e-counterexample-v1 aesop_search
theorem probe_3_460 : ¬ (fcTypeOfName% "Erdos962.erdos_962") := by
  aesop?
#print axioms probe_3_460

-- ATTACK fc-379fc029-erdos962-erdos-962-9458b60a0e-counterexample-v1 simp_search
theorem probe_3_461 : ¬ (fcTypeOfName% "Erdos962.erdos_962") := by
  simp?
#print axioms probe_3_461

-- ATTACK fc-379fc029-green39-green-39-bb5279a986-counterexample-v1 simp
theorem probe_3_462 : ¬ (fcTypeOfName% "Green39.green_39") := by
  simp
#print axioms probe_3_462

-- ATTACK fc-379fc029-green39-green-39-bb5279a986-counterexample-v1 simpa
theorem probe_3_463 : ¬ (fcTypeOfName% "Green39.green_39") := by
  simpa
#print axioms probe_3_463

-- ATTACK fc-379fc029-green39-green-39-bb5279a986-counterexample-v1 simp_all
theorem probe_3_464 : ¬ (fcTypeOfName% "Green39.green_39") := by
  simp_all
#print axioms probe_3_464

-- ATTACK fc-379fc029-green39-green-39-bb5279a986-counterexample-v1 aesop
theorem probe_3_465 : ¬ (fcTypeOfName% "Green39.green_39") := by
  aesop
#print axioms probe_3_465

-- ATTACK fc-379fc029-green39-green-39-bb5279a986-counterexample-v1 omega
theorem probe_3_466 : ¬ (fcTypeOfName% "Green39.green_39") := by
  omega
#print axioms probe_3_466

-- ATTACK fc-379fc029-green39-green-39-bb5279a986-counterexample-v1 norm_num
theorem probe_3_467 : ¬ (fcTypeOfName% "Green39.green_39") := by
  norm_num
#print axioms probe_3_467

-- ATTACK fc-379fc029-green39-green-39-bb5279a986-counterexample-v1 decide
theorem probe_3_468 : ¬ (fcTypeOfName% "Green39.green_39") := by
  decide
#print axioms probe_3_468

-- ATTACK fc-379fc029-green39-green-39-bb5279a986-counterexample-v1 native_decide
theorem probe_3_469 : ¬ (fcTypeOfName% "Green39.green_39") := by
  native_decide
#print axioms probe_3_469

-- ATTACK fc-379fc029-green39-green-39-bb5279a986-counterexample-v1 true_intro
theorem probe_3_470 : ¬ (fcTypeOfName% "Green39.green_39") := by
  exact True.intro
#print axioms probe_3_470

-- ATTACK fc-379fc029-green39-green-39-bb5279a986-counterexample-v1 false_elim_simp
theorem probe_3_471 : ¬ (fcTypeOfName% "Green39.green_39") := by
  apply False.elim
  simp_all
#print axioms probe_3_471

-- ATTACK fc-379fc029-green39-green-39-bb5279a986-counterexample-v1 constructor
theorem probe_3_472 : ¬ (fcTypeOfName% "Green39.green_39") := by
  constructor
#print axioms probe_3_472

-- ATTACK fc-379fc029-green39-green-39-bb5279a986-counterexample-v1 constructor_simp
theorem probe_3_473 : ¬ (fcTypeOfName% "Green39.green_39") := by
  constructor <;> simp
#print axioms probe_3_473

-- ATTACK fc-379fc029-green39-green-39-bb5279a986-counterexample-v1 constructor_aesop
theorem probe_3_474 : ¬ (fcTypeOfName% "Green39.green_39") := by
  constructor <;> aesop
#print axioms probe_3_474

-- ATTACK fc-379fc029-green39-green-39-bb5279a986-counterexample-v1 rfl
theorem probe_3_475 : ¬ (fcTypeOfName% "Green39.green_39") := by
  rfl
#print axioms probe_3_475

-- ATTACK fc-379fc029-green39-green-39-bb5279a986-counterexample-v1 trivial
theorem probe_3_476 : ¬ (fcTypeOfName% "Green39.green_39") := by
  trivial
#print axioms probe_3_476

-- ATTACK fc-379fc029-green39-green-39-bb5279a986-counterexample-v1 tauto
theorem probe_3_477 : ¬ (fcTypeOfName% "Green39.green_39") := by
  tauto
#print axioms probe_3_477

-- ATTACK fc-379fc029-green39-green-39-bb5279a986-counterexample-v1 positivity
theorem probe_3_478 : ¬ (fcTypeOfName% "Green39.green_39") := by
  positivity
#print axioms probe_3_478

-- ATTACK fc-379fc029-green39-green-39-bb5279a986-counterexample-v1 linarith
theorem probe_3_479 : ¬ (fcTypeOfName% "Green39.green_39") := by
  linarith
#print axioms probe_3_479

-- ATTACK fc-379fc029-green39-green-39-bb5279a986-counterexample-v1 nlinarith
theorem probe_3_480 : ¬ (fcTypeOfName% "Green39.green_39") := by
  nlinarith
#print axioms probe_3_480

-- ATTACK fc-379fc029-green39-green-39-bb5279a986-counterexample-v1 intros_simp_all
theorem probe_3_481 : ¬ (fcTypeOfName% "Green39.green_39") := by
  intros
  simp_all
#print axioms probe_3_481

-- ATTACK fc-379fc029-green39-green-39-bb5279a986-counterexample-v1 intros_omega
theorem probe_3_482 : ¬ (fcTypeOfName% "Green39.green_39") := by
  intros
  omega
#print axioms probe_3_482

-- ATTACK fc-379fc029-green39-green-39-bb5279a986-counterexample-v1 intros_norm_num
theorem probe_3_483 : ¬ (fcTypeOfName% "Green39.green_39") := by
  intros
  norm_num at *
#print axioms probe_3_483

-- ATTACK fc-379fc029-green39-green-39-bb5279a986-counterexample-v1 intros_aesop
theorem probe_3_484 : ¬ (fcTypeOfName% "Green39.green_39") := by
  intros
  aesop
#print axioms probe_3_484

-- ATTACK fc-379fc029-green39-green-39-bb5279a986-counterexample-v1 by_contra_simp_all
theorem probe_3_485 : ¬ (fcTypeOfName% "Green39.green_39") := by
  by_contra h
  simp_all
#print axioms probe_3_485

-- ATTACK fc-379fc029-green39-green-39-bb5279a986-counterexample-v1 classical_simp_all
theorem probe_3_486 : ¬ (fcTypeOfName% "Green39.green_39") := by
  classical
  simp_all
#print axioms probe_3_486

-- ATTACK fc-379fc029-green39-green-39-bb5279a986-counterexample-v1 classical_aesop
theorem probe_3_487 : ¬ (fcTypeOfName% "Green39.green_39") := by
  classical
  aesop
#print axioms probe_3_487

-- ATTACK fc-379fc029-green39-green-39-bb5279a986-counterexample-v1 refine_pair_simp
theorem probe_3_488 : ¬ (fcTypeOfName% "Green39.green_39") := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_3_488

-- ATTACK fc-379fc029-green39-green-39-bb5279a986-counterexample-v1 refine_pair_aesop
theorem probe_3_489 : ¬ (fcTypeOfName% "Green39.green_39") := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_3_489

-- ATTACK fc-379fc029-green39-green-39-bb5279a986-counterexample-v1 use_zero_simp
theorem probe_3_490 : ¬ (fcTypeOfName% "Green39.green_39") := by
  use 0 <;> simp
#print axioms probe_3_490

-- ATTACK fc-379fc029-green39-green-39-bb5279a986-counterexample-v1 use_one_simp
theorem probe_3_491 : ¬ (fcTypeOfName% "Green39.green_39") := by
  use 1 <;> simp
#print axioms probe_3_491

-- ATTACK fc-379fc029-green39-green-39-bb5279a986-counterexample-v1 use_empty_simp
theorem probe_3_492 : ¬ (fcTypeOfName% "Green39.green_39") := by
  use ∅ <;> simp
#print axioms probe_3_492

-- ATTACK fc-379fc029-green39-green-39-bb5279a986-counterexample-v1 assumption
theorem probe_3_493 : ¬ (fcTypeOfName% "Green39.green_39") := by
  assumption
#print axioms probe_3_493

-- ATTACK fc-379fc029-green39-green-39-bb5279a986-counterexample-v1 infer_instance
theorem probe_3_494 : ¬ (fcTypeOfName% "Green39.green_39") := by
  infer_instance
#print axioms probe_3_494

-- ATTACK fc-379fc029-green39-green-39-bb5279a986-counterexample-v1 contradiction
theorem probe_3_495 : ¬ (fcTypeOfName% "Green39.green_39") := by
  contradiction
#print axioms probe_3_495

-- ATTACK fc-379fc029-green39-green-39-bb5279a986-counterexample-v1 solve_by_elim
theorem probe_3_496 : ¬ (fcTypeOfName% "Green39.green_39") := by
  solve_by_elim
#print axioms probe_3_496

-- ATTACK fc-379fc029-green39-green-39-bb5279a986-counterexample-v1 first_order
theorem probe_3_497 : ¬ (fcTypeOfName% "Green39.green_39") := by
  first_order
#print axioms probe_3_497

-- ATTACK fc-379fc029-green39-green-39-bb5279a986-counterexample-v1 grind
theorem probe_3_498 : ¬ (fcTypeOfName% "Green39.green_39") := by
  grind
#print axioms probe_3_498

-- ATTACK fc-379fc029-green39-green-39-bb5279a986-counterexample-v1 exact_search
theorem probe_3_499 : ¬ (fcTypeOfName% "Green39.green_39") := by
  exact?
#print axioms probe_3_499

-- ATTACK fc-379fc029-green39-green-39-bb5279a986-counterexample-v1 apply_search
theorem probe_3_500 : ¬ (fcTypeOfName% "Green39.green_39") := by
  apply?
#print axioms probe_3_500

-- ATTACK fc-379fc029-green39-green-39-bb5279a986-counterexample-v1 library_search
theorem probe_3_501 : ¬ (fcTypeOfName% "Green39.green_39") := by
  library_search
#print axioms probe_3_501

-- ATTACK fc-379fc029-green39-green-39-bb5279a986-counterexample-v1 aesop_search
theorem probe_3_502 : ¬ (fcTypeOfName% "Green39.green_39") := by
  aesop?
#print axioms probe_3_502

-- ATTACK fc-379fc029-green39-green-39-bb5279a986-counterexample-v1 simp_search
theorem probe_3_503 : ¬ (fcTypeOfName% "Green39.green_39") := by
  simp?
#print axioms probe_3_503

-- ATTACK fc-379fc029-green94-green-94-317f482903-counterexample-v1 simp
theorem probe_3_504 : ¬ (fcTypeOfName% "Green94.green_94") := by
  simp
#print axioms probe_3_504

-- ATTACK fc-379fc029-green94-green-94-317f482903-counterexample-v1 simpa
theorem probe_3_505 : ¬ (fcTypeOfName% "Green94.green_94") := by
  simpa
#print axioms probe_3_505

-- ATTACK fc-379fc029-green94-green-94-317f482903-counterexample-v1 simp_all
theorem probe_3_506 : ¬ (fcTypeOfName% "Green94.green_94") := by
  simp_all
#print axioms probe_3_506

-- ATTACK fc-379fc029-green94-green-94-317f482903-counterexample-v1 aesop
theorem probe_3_507 : ¬ (fcTypeOfName% "Green94.green_94") := by
  aesop
#print axioms probe_3_507

-- ATTACK fc-379fc029-green94-green-94-317f482903-counterexample-v1 omega
theorem probe_3_508 : ¬ (fcTypeOfName% "Green94.green_94") := by
  omega
#print axioms probe_3_508

-- ATTACK fc-379fc029-green94-green-94-317f482903-counterexample-v1 norm_num
theorem probe_3_509 : ¬ (fcTypeOfName% "Green94.green_94") := by
  norm_num
#print axioms probe_3_509

-- ATTACK fc-379fc029-green94-green-94-317f482903-counterexample-v1 decide
theorem probe_3_510 : ¬ (fcTypeOfName% "Green94.green_94") := by
  decide
#print axioms probe_3_510

-- ATTACK fc-379fc029-green94-green-94-317f482903-counterexample-v1 native_decide
theorem probe_3_511 : ¬ (fcTypeOfName% "Green94.green_94") := by
  native_decide
#print axioms probe_3_511

-- ATTACK fc-379fc029-green94-green-94-317f482903-counterexample-v1 true_intro
theorem probe_3_512 : ¬ (fcTypeOfName% "Green94.green_94") := by
  exact True.intro
#print axioms probe_3_512

-- ATTACK fc-379fc029-green94-green-94-317f482903-counterexample-v1 false_elim_simp
theorem probe_3_513 : ¬ (fcTypeOfName% "Green94.green_94") := by
  apply False.elim
  simp_all
#print axioms probe_3_513

-- ATTACK fc-379fc029-green94-green-94-317f482903-counterexample-v1 constructor
theorem probe_3_514 : ¬ (fcTypeOfName% "Green94.green_94") := by
  constructor
#print axioms probe_3_514

-- ATTACK fc-379fc029-green94-green-94-317f482903-counterexample-v1 constructor_simp
theorem probe_3_515 : ¬ (fcTypeOfName% "Green94.green_94") := by
  constructor <;> simp
#print axioms probe_3_515

-- ATTACK fc-379fc029-green94-green-94-317f482903-counterexample-v1 constructor_aesop
theorem probe_3_516 : ¬ (fcTypeOfName% "Green94.green_94") := by
  constructor <;> aesop
#print axioms probe_3_516

-- ATTACK fc-379fc029-green94-green-94-317f482903-counterexample-v1 rfl
theorem probe_3_517 : ¬ (fcTypeOfName% "Green94.green_94") := by
  rfl
#print axioms probe_3_517

-- ATTACK fc-379fc029-green94-green-94-317f482903-counterexample-v1 trivial
theorem probe_3_518 : ¬ (fcTypeOfName% "Green94.green_94") := by
  trivial
#print axioms probe_3_518

-- ATTACK fc-379fc029-green94-green-94-317f482903-counterexample-v1 tauto
theorem probe_3_519 : ¬ (fcTypeOfName% "Green94.green_94") := by
  tauto
#print axioms probe_3_519

-- ATTACK fc-379fc029-green94-green-94-317f482903-counterexample-v1 positivity
theorem probe_3_520 : ¬ (fcTypeOfName% "Green94.green_94") := by
  positivity
#print axioms probe_3_520

-- ATTACK fc-379fc029-green94-green-94-317f482903-counterexample-v1 linarith
theorem probe_3_521 : ¬ (fcTypeOfName% "Green94.green_94") := by
  linarith
#print axioms probe_3_521

-- ATTACK fc-379fc029-green94-green-94-317f482903-counterexample-v1 nlinarith
theorem probe_3_522 : ¬ (fcTypeOfName% "Green94.green_94") := by
  nlinarith
#print axioms probe_3_522

-- ATTACK fc-379fc029-green94-green-94-317f482903-counterexample-v1 intros_simp_all
theorem probe_3_523 : ¬ (fcTypeOfName% "Green94.green_94") := by
  intros
  simp_all
#print axioms probe_3_523

-- ATTACK fc-379fc029-green94-green-94-317f482903-counterexample-v1 intros_omega
theorem probe_3_524 : ¬ (fcTypeOfName% "Green94.green_94") := by
  intros
  omega
#print axioms probe_3_524

-- ATTACK fc-379fc029-green94-green-94-317f482903-counterexample-v1 intros_norm_num
theorem probe_3_525 : ¬ (fcTypeOfName% "Green94.green_94") := by
  intros
  norm_num at *
#print axioms probe_3_525

-- ATTACK fc-379fc029-green94-green-94-317f482903-counterexample-v1 intros_aesop
theorem probe_3_526 : ¬ (fcTypeOfName% "Green94.green_94") := by
  intros
  aesop
#print axioms probe_3_526

-- ATTACK fc-379fc029-green94-green-94-317f482903-counterexample-v1 by_contra_simp_all
theorem probe_3_527 : ¬ (fcTypeOfName% "Green94.green_94") := by
  by_contra h
  simp_all
#print axioms probe_3_527

-- ATTACK fc-379fc029-green94-green-94-317f482903-counterexample-v1 classical_simp_all
theorem probe_3_528 : ¬ (fcTypeOfName% "Green94.green_94") := by
  classical
  simp_all
#print axioms probe_3_528

-- ATTACK fc-379fc029-green94-green-94-317f482903-counterexample-v1 classical_aesop
theorem probe_3_529 : ¬ (fcTypeOfName% "Green94.green_94") := by
  classical
  aesop
#print axioms probe_3_529

-- ATTACK fc-379fc029-green94-green-94-317f482903-counterexample-v1 refine_pair_simp
theorem probe_3_530 : ¬ (fcTypeOfName% "Green94.green_94") := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_3_530

-- ATTACK fc-379fc029-green94-green-94-317f482903-counterexample-v1 refine_pair_aesop
theorem probe_3_531 : ¬ (fcTypeOfName% "Green94.green_94") := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_3_531

-- ATTACK fc-379fc029-green94-green-94-317f482903-counterexample-v1 use_zero_simp
theorem probe_3_532 : ¬ (fcTypeOfName% "Green94.green_94") := by
  use 0 <;> simp
#print axioms probe_3_532

-- ATTACK fc-379fc029-green94-green-94-317f482903-counterexample-v1 use_one_simp
theorem probe_3_533 : ¬ (fcTypeOfName% "Green94.green_94") := by
  use 1 <;> simp
#print axioms probe_3_533

-- ATTACK fc-379fc029-green94-green-94-317f482903-counterexample-v1 use_empty_simp
theorem probe_3_534 : ¬ (fcTypeOfName% "Green94.green_94") := by
  use ∅ <;> simp
#print axioms probe_3_534

-- ATTACK fc-379fc029-green94-green-94-317f482903-counterexample-v1 assumption
theorem probe_3_535 : ¬ (fcTypeOfName% "Green94.green_94") := by
  assumption
#print axioms probe_3_535

-- ATTACK fc-379fc029-green94-green-94-317f482903-counterexample-v1 infer_instance
theorem probe_3_536 : ¬ (fcTypeOfName% "Green94.green_94") := by
  infer_instance
#print axioms probe_3_536

-- ATTACK fc-379fc029-green94-green-94-317f482903-counterexample-v1 contradiction
theorem probe_3_537 : ¬ (fcTypeOfName% "Green94.green_94") := by
  contradiction
#print axioms probe_3_537

-- ATTACK fc-379fc029-green94-green-94-317f482903-counterexample-v1 solve_by_elim
theorem probe_3_538 : ¬ (fcTypeOfName% "Green94.green_94") := by
  solve_by_elim
#print axioms probe_3_538

-- ATTACK fc-379fc029-green94-green-94-317f482903-counterexample-v1 first_order
theorem probe_3_539 : ¬ (fcTypeOfName% "Green94.green_94") := by
  first_order
#print axioms probe_3_539

-- ATTACK fc-379fc029-green94-green-94-317f482903-counterexample-v1 grind
theorem probe_3_540 : ¬ (fcTypeOfName% "Green94.green_94") := by
  grind
#print axioms probe_3_540

-- ATTACK fc-379fc029-green94-green-94-317f482903-counterexample-v1 exact_search
theorem probe_3_541 : ¬ (fcTypeOfName% "Green94.green_94") := by
  exact?
#print axioms probe_3_541

-- ATTACK fc-379fc029-green94-green-94-317f482903-counterexample-v1 apply_search
theorem probe_3_542 : ¬ (fcTypeOfName% "Green94.green_94") := by
  apply?
#print axioms probe_3_542

-- ATTACK fc-379fc029-green94-green-94-317f482903-counterexample-v1 library_search
theorem probe_3_543 : ¬ (fcTypeOfName% "Green94.green_94") := by
  library_search
#print axioms probe_3_543

-- ATTACK fc-379fc029-green94-green-94-317f482903-counterexample-v1 aesop_search
theorem probe_3_544 : ¬ (fcTypeOfName% "Green94.green_94") := by
  aesop?
#print axioms probe_3_544

-- ATTACK fc-379fc029-green94-green-94-317f482903-counterexample-v1 simp_search
theorem probe_3_545 : ¬ (fcTypeOfName% "Green94.green_94") := by
  simp?
#print axioms probe_3_545

end AttackBattery
