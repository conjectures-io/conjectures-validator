import FormalConjectures.ErdosProblems.«1056»
import FormalConjectures.ErdosProblems.«1113»
import FormalConjectures.ErdosProblems.«14»
import FormalConjectures.ErdosProblems.«287»
import FormalConjectures.ErdosProblems.«307»
import FormalConjectures.ErdosProblems.«400»
import FormalConjectures.ErdosProblems.«52»
import FormalConjectures.ErdosProblems.«686»
import FormalConjectures.ErdosProblems.«890»
import FormalConjectures.ErdosProblems.«936»
import FormalConjectures.ErdosProblems.«950»
import FormalConjectures.GreensOpenProblems.«36»
import FormalConjectures.GreensOpenProblems.«66»
import TaskSupport

set_option maxHeartbeats 20000
namespace AttackBattery

-- ATTACK fc-379fc029-erdos1056-erdos-1056-47d3f33f00-formalized-v1 simp
theorem probe_2_0 : fcTypeOfName% "Erdos1056.erdos_1056" := by
  simp
#print axioms probe_2_0

-- ATTACK fc-379fc029-erdos1056-erdos-1056-47d3f33f00-formalized-v1 simpa
theorem probe_2_1 : fcTypeOfName% "Erdos1056.erdos_1056" := by
  simpa
#print axioms probe_2_1

-- ATTACK fc-379fc029-erdos1056-erdos-1056-47d3f33f00-formalized-v1 simp_all
theorem probe_2_2 : fcTypeOfName% "Erdos1056.erdos_1056" := by
  simp_all
#print axioms probe_2_2

-- ATTACK fc-379fc029-erdos1056-erdos-1056-47d3f33f00-formalized-v1 aesop
theorem probe_2_3 : fcTypeOfName% "Erdos1056.erdos_1056" := by
  aesop
#print axioms probe_2_3

-- ATTACK fc-379fc029-erdos1056-erdos-1056-47d3f33f00-formalized-v1 omega
theorem probe_2_4 : fcTypeOfName% "Erdos1056.erdos_1056" := by
  omega
#print axioms probe_2_4

-- ATTACK fc-379fc029-erdos1056-erdos-1056-47d3f33f00-formalized-v1 norm_num
theorem probe_2_5 : fcTypeOfName% "Erdos1056.erdos_1056" := by
  norm_num
#print axioms probe_2_5

-- ATTACK fc-379fc029-erdos1056-erdos-1056-47d3f33f00-formalized-v1 decide
theorem probe_2_6 : fcTypeOfName% "Erdos1056.erdos_1056" := by
  decide
#print axioms probe_2_6

-- ATTACK fc-379fc029-erdos1056-erdos-1056-47d3f33f00-formalized-v1 native_decide
theorem probe_2_7 : fcTypeOfName% "Erdos1056.erdos_1056" := by
  native_decide
#print axioms probe_2_7

-- ATTACK fc-379fc029-erdos1056-erdos-1056-47d3f33f00-formalized-v1 true_intro
theorem probe_2_8 : fcTypeOfName% "Erdos1056.erdos_1056" := by
  exact True.intro
#print axioms probe_2_8

-- ATTACK fc-379fc029-erdos1056-erdos-1056-47d3f33f00-formalized-v1 false_elim_simp
theorem probe_2_9 : fcTypeOfName% "Erdos1056.erdos_1056" := by
  apply False.elim
  simp_all
#print axioms probe_2_9

-- ATTACK fc-379fc029-erdos1056-erdos-1056-47d3f33f00-formalized-v1 constructor
theorem probe_2_10 : fcTypeOfName% "Erdos1056.erdos_1056" := by
  constructor
#print axioms probe_2_10

-- ATTACK fc-379fc029-erdos1056-erdos-1056-47d3f33f00-formalized-v1 constructor_simp
theorem probe_2_11 : fcTypeOfName% "Erdos1056.erdos_1056" := by
  constructor <;> simp
#print axioms probe_2_11

-- ATTACK fc-379fc029-erdos1056-erdos-1056-47d3f33f00-formalized-v1 constructor_aesop
theorem probe_2_12 : fcTypeOfName% "Erdos1056.erdos_1056" := by
  constructor <;> aesop
#print axioms probe_2_12

-- ATTACK fc-379fc029-erdos1056-erdos-1056-47d3f33f00-formalized-v1 rfl
theorem probe_2_13 : fcTypeOfName% "Erdos1056.erdos_1056" := by
  rfl
#print axioms probe_2_13

-- ATTACK fc-379fc029-erdos1056-erdos-1056-47d3f33f00-formalized-v1 trivial
theorem probe_2_14 : fcTypeOfName% "Erdos1056.erdos_1056" := by
  trivial
#print axioms probe_2_14

-- ATTACK fc-379fc029-erdos1056-erdos-1056-47d3f33f00-formalized-v1 tauto
theorem probe_2_15 : fcTypeOfName% "Erdos1056.erdos_1056" := by
  tauto
#print axioms probe_2_15

-- ATTACK fc-379fc029-erdos1056-erdos-1056-47d3f33f00-formalized-v1 positivity
theorem probe_2_16 : fcTypeOfName% "Erdos1056.erdos_1056" := by
  positivity
#print axioms probe_2_16

-- ATTACK fc-379fc029-erdos1056-erdos-1056-47d3f33f00-formalized-v1 linarith
theorem probe_2_17 : fcTypeOfName% "Erdos1056.erdos_1056" := by
  linarith
#print axioms probe_2_17

-- ATTACK fc-379fc029-erdos1056-erdos-1056-47d3f33f00-formalized-v1 nlinarith
theorem probe_2_18 : fcTypeOfName% "Erdos1056.erdos_1056" := by
  nlinarith
#print axioms probe_2_18

-- ATTACK fc-379fc029-erdos1056-erdos-1056-47d3f33f00-formalized-v1 intros_simp_all
theorem probe_2_19 : fcTypeOfName% "Erdos1056.erdos_1056" := by
  intros
  simp_all
#print axioms probe_2_19

-- ATTACK fc-379fc029-erdos1056-erdos-1056-47d3f33f00-formalized-v1 intros_omega
theorem probe_2_20 : fcTypeOfName% "Erdos1056.erdos_1056" := by
  intros
  omega
#print axioms probe_2_20

-- ATTACK fc-379fc029-erdos1056-erdos-1056-47d3f33f00-formalized-v1 intros_norm_num
theorem probe_2_21 : fcTypeOfName% "Erdos1056.erdos_1056" := by
  intros
  norm_num at *
#print axioms probe_2_21

-- ATTACK fc-379fc029-erdos1056-erdos-1056-47d3f33f00-formalized-v1 intros_aesop
theorem probe_2_22 : fcTypeOfName% "Erdos1056.erdos_1056" := by
  intros
  aesop
#print axioms probe_2_22

-- ATTACK fc-379fc029-erdos1056-erdos-1056-47d3f33f00-formalized-v1 by_contra_simp_all
theorem probe_2_23 : fcTypeOfName% "Erdos1056.erdos_1056" := by
  by_contra h
  simp_all
#print axioms probe_2_23

-- ATTACK fc-379fc029-erdos1056-erdos-1056-47d3f33f00-formalized-v1 classical_simp_all
theorem probe_2_24 : fcTypeOfName% "Erdos1056.erdos_1056" := by
  classical
  simp_all
#print axioms probe_2_24

-- ATTACK fc-379fc029-erdos1056-erdos-1056-47d3f33f00-formalized-v1 classical_aesop
theorem probe_2_25 : fcTypeOfName% "Erdos1056.erdos_1056" := by
  classical
  aesop
#print axioms probe_2_25

-- ATTACK fc-379fc029-erdos1056-erdos-1056-47d3f33f00-formalized-v1 refine_pair_simp
theorem probe_2_26 : fcTypeOfName% "Erdos1056.erdos_1056" := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_2_26

-- ATTACK fc-379fc029-erdos1056-erdos-1056-47d3f33f00-formalized-v1 refine_pair_aesop
theorem probe_2_27 : fcTypeOfName% "Erdos1056.erdos_1056" := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_2_27

-- ATTACK fc-379fc029-erdos1056-erdos-1056-47d3f33f00-formalized-v1 use_zero_simp
theorem probe_2_28 : fcTypeOfName% "Erdos1056.erdos_1056" := by
  use 0 <;> simp
#print axioms probe_2_28

-- ATTACK fc-379fc029-erdos1056-erdos-1056-47d3f33f00-formalized-v1 use_one_simp
theorem probe_2_29 : fcTypeOfName% "Erdos1056.erdos_1056" := by
  use 1 <;> simp
#print axioms probe_2_29

-- ATTACK fc-379fc029-erdos1056-erdos-1056-47d3f33f00-formalized-v1 use_empty_simp
theorem probe_2_30 : fcTypeOfName% "Erdos1056.erdos_1056" := by
  use ∅ <;> simp
#print axioms probe_2_30

-- ATTACK fc-379fc029-erdos1056-erdos-1056-47d3f33f00-formalized-v1 assumption
theorem probe_2_31 : fcTypeOfName% "Erdos1056.erdos_1056" := by
  assumption
#print axioms probe_2_31

-- ATTACK fc-379fc029-erdos1056-erdos-1056-47d3f33f00-formalized-v1 infer_instance
theorem probe_2_32 : fcTypeOfName% "Erdos1056.erdos_1056" := by
  infer_instance
#print axioms probe_2_32

-- ATTACK fc-379fc029-erdos1056-erdos-1056-47d3f33f00-formalized-v1 contradiction
theorem probe_2_33 : fcTypeOfName% "Erdos1056.erdos_1056" := by
  contradiction
#print axioms probe_2_33

-- ATTACK fc-379fc029-erdos1056-erdos-1056-47d3f33f00-formalized-v1 solve_by_elim
theorem probe_2_34 : fcTypeOfName% "Erdos1056.erdos_1056" := by
  solve_by_elim
#print axioms probe_2_34

-- ATTACK fc-379fc029-erdos1056-erdos-1056-47d3f33f00-formalized-v1 first_order
theorem probe_2_35 : fcTypeOfName% "Erdos1056.erdos_1056" := by
  first_order
#print axioms probe_2_35

-- ATTACK fc-379fc029-erdos1056-erdos-1056-47d3f33f00-formalized-v1 grind
theorem probe_2_36 : fcTypeOfName% "Erdos1056.erdos_1056" := by
  grind
#print axioms probe_2_36

-- ATTACK fc-379fc029-erdos1056-erdos-1056-47d3f33f00-formalized-v1 exact_search
theorem probe_2_37 : fcTypeOfName% "Erdos1056.erdos_1056" := by
  exact?
#print axioms probe_2_37

-- ATTACK fc-379fc029-erdos1056-erdos-1056-47d3f33f00-formalized-v1 apply_search
theorem probe_2_38 : fcTypeOfName% "Erdos1056.erdos_1056" := by
  apply?
#print axioms probe_2_38

-- ATTACK fc-379fc029-erdos1056-erdos-1056-47d3f33f00-formalized-v1 library_search
theorem probe_2_39 : fcTypeOfName% "Erdos1056.erdos_1056" := by
  library_search
#print axioms probe_2_39

-- ATTACK fc-379fc029-erdos1056-erdos-1056-47d3f33f00-formalized-v1 aesop_search
theorem probe_2_40 : fcTypeOfName% "Erdos1056.erdos_1056" := by
  aesop?
#print axioms probe_2_40

-- ATTACK fc-379fc029-erdos1056-erdos-1056-47d3f33f00-formalized-v1 simp_search
theorem probe_2_41 : fcTypeOfName% "Erdos1056.erdos_1056" := by
  simp?
#print axioms probe_2_41

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-3f5c424901-formalized-v1 simp
theorem probe_2_42 : fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek" := by
  simp
#print axioms probe_2_42

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-3f5c424901-formalized-v1 simpa
theorem probe_2_43 : fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek" := by
  simpa
#print axioms probe_2_43

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-3f5c424901-formalized-v1 simp_all
theorem probe_2_44 : fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek" := by
  simp_all
#print axioms probe_2_44

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-3f5c424901-formalized-v1 aesop
theorem probe_2_45 : fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek" := by
  aesop
#print axioms probe_2_45

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-3f5c424901-formalized-v1 omega
theorem probe_2_46 : fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek" := by
  omega
#print axioms probe_2_46

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-3f5c424901-formalized-v1 norm_num
theorem probe_2_47 : fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek" := by
  norm_num
#print axioms probe_2_47

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-3f5c424901-formalized-v1 decide
theorem probe_2_48 : fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek" := by
  decide
#print axioms probe_2_48

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-3f5c424901-formalized-v1 native_decide
theorem probe_2_49 : fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek" := by
  native_decide
#print axioms probe_2_49

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-3f5c424901-formalized-v1 true_intro
theorem probe_2_50 : fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek" := by
  exact True.intro
#print axioms probe_2_50

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-3f5c424901-formalized-v1 false_elim_simp
theorem probe_2_51 : fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek" := by
  apply False.elim
  simp_all
#print axioms probe_2_51

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-3f5c424901-formalized-v1 constructor
theorem probe_2_52 : fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek" := by
  constructor
#print axioms probe_2_52

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-3f5c424901-formalized-v1 constructor_simp
theorem probe_2_53 : fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek" := by
  constructor <;> simp
#print axioms probe_2_53

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-3f5c424901-formalized-v1 constructor_aesop
theorem probe_2_54 : fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek" := by
  constructor <;> aesop
#print axioms probe_2_54

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-3f5c424901-formalized-v1 rfl
theorem probe_2_55 : fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek" := by
  rfl
#print axioms probe_2_55

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-3f5c424901-formalized-v1 trivial
theorem probe_2_56 : fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek" := by
  trivial
#print axioms probe_2_56

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-3f5c424901-formalized-v1 tauto
theorem probe_2_57 : fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek" := by
  tauto
#print axioms probe_2_57

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-3f5c424901-formalized-v1 positivity
theorem probe_2_58 : fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek" := by
  positivity
#print axioms probe_2_58

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-3f5c424901-formalized-v1 linarith
theorem probe_2_59 : fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek" := by
  linarith
#print axioms probe_2_59

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-3f5c424901-formalized-v1 nlinarith
theorem probe_2_60 : fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek" := by
  nlinarith
#print axioms probe_2_60

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-3f5c424901-formalized-v1 intros_simp_all
theorem probe_2_61 : fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek" := by
  intros
  simp_all
#print axioms probe_2_61

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-3f5c424901-formalized-v1 intros_omega
theorem probe_2_62 : fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek" := by
  intros
  omega
#print axioms probe_2_62

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-3f5c424901-formalized-v1 intros_norm_num
theorem probe_2_63 : fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek" := by
  intros
  norm_num at *
#print axioms probe_2_63

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-3f5c424901-formalized-v1 intros_aesop
theorem probe_2_64 : fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek" := by
  intros
  aesop
#print axioms probe_2_64

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-3f5c424901-formalized-v1 by_contra_simp_all
theorem probe_2_65 : fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek" := by
  by_contra h
  simp_all
#print axioms probe_2_65

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-3f5c424901-formalized-v1 classical_simp_all
theorem probe_2_66 : fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek" := by
  classical
  simp_all
#print axioms probe_2_66

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-3f5c424901-formalized-v1 classical_aesop
theorem probe_2_67 : fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek" := by
  classical
  aesop
#print axioms probe_2_67

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-3f5c424901-formalized-v1 refine_pair_simp
theorem probe_2_68 : fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek" := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_2_68

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-3f5c424901-formalized-v1 refine_pair_aesop
theorem probe_2_69 : fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek" := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_2_69

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-3f5c424901-formalized-v1 use_zero_simp
theorem probe_2_70 : fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek" := by
  use 0 <;> simp
#print axioms probe_2_70

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-3f5c424901-formalized-v1 use_one_simp
theorem probe_2_71 : fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek" := by
  use 1 <;> simp
#print axioms probe_2_71

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-3f5c424901-formalized-v1 use_empty_simp
theorem probe_2_72 : fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek" := by
  use ∅ <;> simp
#print axioms probe_2_72

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-3f5c424901-formalized-v1 assumption
theorem probe_2_73 : fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek" := by
  assumption
#print axioms probe_2_73

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-3f5c424901-formalized-v1 infer_instance
theorem probe_2_74 : fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek" := by
  infer_instance
#print axioms probe_2_74

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-3f5c424901-formalized-v1 contradiction
theorem probe_2_75 : fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek" := by
  contradiction
#print axioms probe_2_75

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-3f5c424901-formalized-v1 solve_by_elim
theorem probe_2_76 : fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek" := by
  solve_by_elim
#print axioms probe_2_76

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-3f5c424901-formalized-v1 first_order
theorem probe_2_77 : fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek" := by
  first_order
#print axioms probe_2_77

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-3f5c424901-formalized-v1 grind
theorem probe_2_78 : fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek" := by
  grind
#print axioms probe_2_78

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-3f5c424901-formalized-v1 exact_search
theorem probe_2_79 : fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek" := by
  exact?
#print axioms probe_2_79

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-3f5c424901-formalized-v1 apply_search
theorem probe_2_80 : fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek" := by
  apply?
#print axioms probe_2_80

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-3f5c424901-formalized-v1 library_search
theorem probe_2_81 : fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek" := by
  library_search
#print axioms probe_2_81

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-3f5c424901-formalized-v1 aesop_search
theorem probe_2_82 : fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek" := by
  aesop?
#print axioms probe_2_82

-- ATTACK fc-379fc029-variants-filaseta-finch-kozek-3f5c424901-formalized-v1 simp_search
theorem probe_2_83 : fcTypeOfName% "Erdos1113.erdos_1113.variants.filaseta_finch_kozek" := by
  simp?
#print axioms probe_2_83

-- ATTACK fc-379fc029-parts-i-5d0824f34f-formalized-v1 simp
theorem probe_2_84 : fcTypeOfName% "Erdos14.erdos_14.parts.i" := by
  simp
#print axioms probe_2_84

-- ATTACK fc-379fc029-parts-i-5d0824f34f-formalized-v1 simpa
theorem probe_2_85 : fcTypeOfName% "Erdos14.erdos_14.parts.i" := by
  simpa
#print axioms probe_2_85

-- ATTACK fc-379fc029-parts-i-5d0824f34f-formalized-v1 simp_all
theorem probe_2_86 : fcTypeOfName% "Erdos14.erdos_14.parts.i" := by
  simp_all
#print axioms probe_2_86

-- ATTACK fc-379fc029-parts-i-5d0824f34f-formalized-v1 aesop
theorem probe_2_87 : fcTypeOfName% "Erdos14.erdos_14.parts.i" := by
  aesop
#print axioms probe_2_87

-- ATTACK fc-379fc029-parts-i-5d0824f34f-formalized-v1 omega
theorem probe_2_88 : fcTypeOfName% "Erdos14.erdos_14.parts.i" := by
  omega
#print axioms probe_2_88

-- ATTACK fc-379fc029-parts-i-5d0824f34f-formalized-v1 norm_num
theorem probe_2_89 : fcTypeOfName% "Erdos14.erdos_14.parts.i" := by
  norm_num
#print axioms probe_2_89

-- ATTACK fc-379fc029-parts-i-5d0824f34f-formalized-v1 decide
theorem probe_2_90 : fcTypeOfName% "Erdos14.erdos_14.parts.i" := by
  decide
#print axioms probe_2_90

-- ATTACK fc-379fc029-parts-i-5d0824f34f-formalized-v1 native_decide
theorem probe_2_91 : fcTypeOfName% "Erdos14.erdos_14.parts.i" := by
  native_decide
#print axioms probe_2_91

-- ATTACK fc-379fc029-parts-i-5d0824f34f-formalized-v1 true_intro
theorem probe_2_92 : fcTypeOfName% "Erdos14.erdos_14.parts.i" := by
  exact True.intro
#print axioms probe_2_92

-- ATTACK fc-379fc029-parts-i-5d0824f34f-formalized-v1 false_elim_simp
theorem probe_2_93 : fcTypeOfName% "Erdos14.erdos_14.parts.i" := by
  apply False.elim
  simp_all
#print axioms probe_2_93

-- ATTACK fc-379fc029-parts-i-5d0824f34f-formalized-v1 constructor
theorem probe_2_94 : fcTypeOfName% "Erdos14.erdos_14.parts.i" := by
  constructor
#print axioms probe_2_94

-- ATTACK fc-379fc029-parts-i-5d0824f34f-formalized-v1 constructor_simp
theorem probe_2_95 : fcTypeOfName% "Erdos14.erdos_14.parts.i" := by
  constructor <;> simp
#print axioms probe_2_95

-- ATTACK fc-379fc029-parts-i-5d0824f34f-formalized-v1 constructor_aesop
theorem probe_2_96 : fcTypeOfName% "Erdos14.erdos_14.parts.i" := by
  constructor <;> aesop
#print axioms probe_2_96

-- ATTACK fc-379fc029-parts-i-5d0824f34f-formalized-v1 rfl
theorem probe_2_97 : fcTypeOfName% "Erdos14.erdos_14.parts.i" := by
  rfl
#print axioms probe_2_97

-- ATTACK fc-379fc029-parts-i-5d0824f34f-formalized-v1 trivial
theorem probe_2_98 : fcTypeOfName% "Erdos14.erdos_14.parts.i" := by
  trivial
#print axioms probe_2_98

-- ATTACK fc-379fc029-parts-i-5d0824f34f-formalized-v1 tauto
theorem probe_2_99 : fcTypeOfName% "Erdos14.erdos_14.parts.i" := by
  tauto
#print axioms probe_2_99

-- ATTACK fc-379fc029-parts-i-5d0824f34f-formalized-v1 positivity
theorem probe_2_100 : fcTypeOfName% "Erdos14.erdos_14.parts.i" := by
  positivity
#print axioms probe_2_100

-- ATTACK fc-379fc029-parts-i-5d0824f34f-formalized-v1 linarith
theorem probe_2_101 : fcTypeOfName% "Erdos14.erdos_14.parts.i" := by
  linarith
#print axioms probe_2_101

-- ATTACK fc-379fc029-parts-i-5d0824f34f-formalized-v1 nlinarith
theorem probe_2_102 : fcTypeOfName% "Erdos14.erdos_14.parts.i" := by
  nlinarith
#print axioms probe_2_102

-- ATTACK fc-379fc029-parts-i-5d0824f34f-formalized-v1 intros_simp_all
theorem probe_2_103 : fcTypeOfName% "Erdos14.erdos_14.parts.i" := by
  intros
  simp_all
#print axioms probe_2_103

-- ATTACK fc-379fc029-parts-i-5d0824f34f-formalized-v1 intros_omega
theorem probe_2_104 : fcTypeOfName% "Erdos14.erdos_14.parts.i" := by
  intros
  omega
#print axioms probe_2_104

-- ATTACK fc-379fc029-parts-i-5d0824f34f-formalized-v1 intros_norm_num
theorem probe_2_105 : fcTypeOfName% "Erdos14.erdos_14.parts.i" := by
  intros
  norm_num at *
#print axioms probe_2_105

-- ATTACK fc-379fc029-parts-i-5d0824f34f-formalized-v1 intros_aesop
theorem probe_2_106 : fcTypeOfName% "Erdos14.erdos_14.parts.i" := by
  intros
  aesop
#print axioms probe_2_106

-- ATTACK fc-379fc029-parts-i-5d0824f34f-formalized-v1 by_contra_simp_all
theorem probe_2_107 : fcTypeOfName% "Erdos14.erdos_14.parts.i" := by
  by_contra h
  simp_all
#print axioms probe_2_107

-- ATTACK fc-379fc029-parts-i-5d0824f34f-formalized-v1 classical_simp_all
theorem probe_2_108 : fcTypeOfName% "Erdos14.erdos_14.parts.i" := by
  classical
  simp_all
#print axioms probe_2_108

-- ATTACK fc-379fc029-parts-i-5d0824f34f-formalized-v1 classical_aesop
theorem probe_2_109 : fcTypeOfName% "Erdos14.erdos_14.parts.i" := by
  classical
  aesop
#print axioms probe_2_109

-- ATTACK fc-379fc029-parts-i-5d0824f34f-formalized-v1 refine_pair_simp
theorem probe_2_110 : fcTypeOfName% "Erdos14.erdos_14.parts.i" := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_2_110

-- ATTACK fc-379fc029-parts-i-5d0824f34f-formalized-v1 refine_pair_aesop
theorem probe_2_111 : fcTypeOfName% "Erdos14.erdos_14.parts.i" := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_2_111

-- ATTACK fc-379fc029-parts-i-5d0824f34f-formalized-v1 use_zero_simp
theorem probe_2_112 : fcTypeOfName% "Erdos14.erdos_14.parts.i" := by
  use 0 <;> simp
#print axioms probe_2_112

-- ATTACK fc-379fc029-parts-i-5d0824f34f-formalized-v1 use_one_simp
theorem probe_2_113 : fcTypeOfName% "Erdos14.erdos_14.parts.i" := by
  use 1 <;> simp
#print axioms probe_2_113

-- ATTACK fc-379fc029-parts-i-5d0824f34f-formalized-v1 use_empty_simp
theorem probe_2_114 : fcTypeOfName% "Erdos14.erdos_14.parts.i" := by
  use ∅ <;> simp
#print axioms probe_2_114

-- ATTACK fc-379fc029-parts-i-5d0824f34f-formalized-v1 assumption
theorem probe_2_115 : fcTypeOfName% "Erdos14.erdos_14.parts.i" := by
  assumption
#print axioms probe_2_115

-- ATTACK fc-379fc029-parts-i-5d0824f34f-formalized-v1 infer_instance
theorem probe_2_116 : fcTypeOfName% "Erdos14.erdos_14.parts.i" := by
  infer_instance
#print axioms probe_2_116

-- ATTACK fc-379fc029-parts-i-5d0824f34f-formalized-v1 contradiction
theorem probe_2_117 : fcTypeOfName% "Erdos14.erdos_14.parts.i" := by
  contradiction
#print axioms probe_2_117

-- ATTACK fc-379fc029-parts-i-5d0824f34f-formalized-v1 solve_by_elim
theorem probe_2_118 : fcTypeOfName% "Erdos14.erdos_14.parts.i" := by
  solve_by_elim
#print axioms probe_2_118

-- ATTACK fc-379fc029-parts-i-5d0824f34f-formalized-v1 first_order
theorem probe_2_119 : fcTypeOfName% "Erdos14.erdos_14.parts.i" := by
  first_order
#print axioms probe_2_119

-- ATTACK fc-379fc029-parts-i-5d0824f34f-formalized-v1 grind
theorem probe_2_120 : fcTypeOfName% "Erdos14.erdos_14.parts.i" := by
  grind
#print axioms probe_2_120

-- ATTACK fc-379fc029-parts-i-5d0824f34f-formalized-v1 exact_search
theorem probe_2_121 : fcTypeOfName% "Erdos14.erdos_14.parts.i" := by
  exact?
#print axioms probe_2_121

-- ATTACK fc-379fc029-parts-i-5d0824f34f-formalized-v1 apply_search
theorem probe_2_122 : fcTypeOfName% "Erdos14.erdos_14.parts.i" := by
  apply?
#print axioms probe_2_122

-- ATTACK fc-379fc029-parts-i-5d0824f34f-formalized-v1 library_search
theorem probe_2_123 : fcTypeOfName% "Erdos14.erdos_14.parts.i" := by
  library_search
#print axioms probe_2_123

-- ATTACK fc-379fc029-parts-i-5d0824f34f-formalized-v1 aesop_search
theorem probe_2_124 : fcTypeOfName% "Erdos14.erdos_14.parts.i" := by
  aesop?
#print axioms probe_2_124

-- ATTACK fc-379fc029-parts-i-5d0824f34f-formalized-v1 simp_search
theorem probe_2_125 : fcTypeOfName% "Erdos14.erdos_14.parts.i" := by
  simp?
#print axioms probe_2_125

-- ATTACK fc-379fc029-erdos287-erdos-287-4a2e3952cd-formalized-v1 simp
theorem probe_2_126 : fcTypeOfName% "Erdos287.erdos_287" := by
  simp
#print axioms probe_2_126

-- ATTACK fc-379fc029-erdos287-erdos-287-4a2e3952cd-formalized-v1 simpa
theorem probe_2_127 : fcTypeOfName% "Erdos287.erdos_287" := by
  simpa
#print axioms probe_2_127

-- ATTACK fc-379fc029-erdos287-erdos-287-4a2e3952cd-formalized-v1 simp_all
theorem probe_2_128 : fcTypeOfName% "Erdos287.erdos_287" := by
  simp_all
#print axioms probe_2_128

-- ATTACK fc-379fc029-erdos287-erdos-287-4a2e3952cd-formalized-v1 aesop
theorem probe_2_129 : fcTypeOfName% "Erdos287.erdos_287" := by
  aesop
#print axioms probe_2_129

-- ATTACK fc-379fc029-erdos287-erdos-287-4a2e3952cd-formalized-v1 omega
theorem probe_2_130 : fcTypeOfName% "Erdos287.erdos_287" := by
  omega
#print axioms probe_2_130

-- ATTACK fc-379fc029-erdos287-erdos-287-4a2e3952cd-formalized-v1 norm_num
theorem probe_2_131 : fcTypeOfName% "Erdos287.erdos_287" := by
  norm_num
#print axioms probe_2_131

-- ATTACK fc-379fc029-erdos287-erdos-287-4a2e3952cd-formalized-v1 decide
theorem probe_2_132 : fcTypeOfName% "Erdos287.erdos_287" := by
  decide
#print axioms probe_2_132

-- ATTACK fc-379fc029-erdos287-erdos-287-4a2e3952cd-formalized-v1 native_decide
theorem probe_2_133 : fcTypeOfName% "Erdos287.erdos_287" := by
  native_decide
#print axioms probe_2_133

-- ATTACK fc-379fc029-erdos287-erdos-287-4a2e3952cd-formalized-v1 true_intro
theorem probe_2_134 : fcTypeOfName% "Erdos287.erdos_287" := by
  exact True.intro
#print axioms probe_2_134

-- ATTACK fc-379fc029-erdos287-erdos-287-4a2e3952cd-formalized-v1 false_elim_simp
theorem probe_2_135 : fcTypeOfName% "Erdos287.erdos_287" := by
  apply False.elim
  simp_all
#print axioms probe_2_135

-- ATTACK fc-379fc029-erdos287-erdos-287-4a2e3952cd-formalized-v1 constructor
theorem probe_2_136 : fcTypeOfName% "Erdos287.erdos_287" := by
  constructor
#print axioms probe_2_136

-- ATTACK fc-379fc029-erdos287-erdos-287-4a2e3952cd-formalized-v1 constructor_simp
theorem probe_2_137 : fcTypeOfName% "Erdos287.erdos_287" := by
  constructor <;> simp
#print axioms probe_2_137

-- ATTACK fc-379fc029-erdos287-erdos-287-4a2e3952cd-formalized-v1 constructor_aesop
theorem probe_2_138 : fcTypeOfName% "Erdos287.erdos_287" := by
  constructor <;> aesop
#print axioms probe_2_138

-- ATTACK fc-379fc029-erdos287-erdos-287-4a2e3952cd-formalized-v1 rfl
theorem probe_2_139 : fcTypeOfName% "Erdos287.erdos_287" := by
  rfl
#print axioms probe_2_139

-- ATTACK fc-379fc029-erdos287-erdos-287-4a2e3952cd-formalized-v1 trivial
theorem probe_2_140 : fcTypeOfName% "Erdos287.erdos_287" := by
  trivial
#print axioms probe_2_140

-- ATTACK fc-379fc029-erdos287-erdos-287-4a2e3952cd-formalized-v1 tauto
theorem probe_2_141 : fcTypeOfName% "Erdos287.erdos_287" := by
  tauto
#print axioms probe_2_141

-- ATTACK fc-379fc029-erdos287-erdos-287-4a2e3952cd-formalized-v1 positivity
theorem probe_2_142 : fcTypeOfName% "Erdos287.erdos_287" := by
  positivity
#print axioms probe_2_142

-- ATTACK fc-379fc029-erdos287-erdos-287-4a2e3952cd-formalized-v1 linarith
theorem probe_2_143 : fcTypeOfName% "Erdos287.erdos_287" := by
  linarith
#print axioms probe_2_143

-- ATTACK fc-379fc029-erdos287-erdos-287-4a2e3952cd-formalized-v1 nlinarith
theorem probe_2_144 : fcTypeOfName% "Erdos287.erdos_287" := by
  nlinarith
#print axioms probe_2_144

-- ATTACK fc-379fc029-erdos287-erdos-287-4a2e3952cd-formalized-v1 intros_simp_all
theorem probe_2_145 : fcTypeOfName% "Erdos287.erdos_287" := by
  intros
  simp_all
#print axioms probe_2_145

-- ATTACK fc-379fc029-erdos287-erdos-287-4a2e3952cd-formalized-v1 intros_omega
theorem probe_2_146 : fcTypeOfName% "Erdos287.erdos_287" := by
  intros
  omega
#print axioms probe_2_146

-- ATTACK fc-379fc029-erdos287-erdos-287-4a2e3952cd-formalized-v1 intros_norm_num
theorem probe_2_147 : fcTypeOfName% "Erdos287.erdos_287" := by
  intros
  norm_num at *
#print axioms probe_2_147

-- ATTACK fc-379fc029-erdos287-erdos-287-4a2e3952cd-formalized-v1 intros_aesop
theorem probe_2_148 : fcTypeOfName% "Erdos287.erdos_287" := by
  intros
  aesop
#print axioms probe_2_148

-- ATTACK fc-379fc029-erdos287-erdos-287-4a2e3952cd-formalized-v1 by_contra_simp_all
theorem probe_2_149 : fcTypeOfName% "Erdos287.erdos_287" := by
  by_contra h
  simp_all
#print axioms probe_2_149

-- ATTACK fc-379fc029-erdos287-erdos-287-4a2e3952cd-formalized-v1 classical_simp_all
theorem probe_2_150 : fcTypeOfName% "Erdos287.erdos_287" := by
  classical
  simp_all
#print axioms probe_2_150

-- ATTACK fc-379fc029-erdos287-erdos-287-4a2e3952cd-formalized-v1 classical_aesop
theorem probe_2_151 : fcTypeOfName% "Erdos287.erdos_287" := by
  classical
  aesop
#print axioms probe_2_151

-- ATTACK fc-379fc029-erdos287-erdos-287-4a2e3952cd-formalized-v1 refine_pair_simp
theorem probe_2_152 : fcTypeOfName% "Erdos287.erdos_287" := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_2_152

-- ATTACK fc-379fc029-erdos287-erdos-287-4a2e3952cd-formalized-v1 refine_pair_aesop
theorem probe_2_153 : fcTypeOfName% "Erdos287.erdos_287" := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_2_153

-- ATTACK fc-379fc029-erdos287-erdos-287-4a2e3952cd-formalized-v1 use_zero_simp
theorem probe_2_154 : fcTypeOfName% "Erdos287.erdos_287" := by
  use 0 <;> simp
#print axioms probe_2_154

-- ATTACK fc-379fc029-erdos287-erdos-287-4a2e3952cd-formalized-v1 use_one_simp
theorem probe_2_155 : fcTypeOfName% "Erdos287.erdos_287" := by
  use 1 <;> simp
#print axioms probe_2_155

-- ATTACK fc-379fc029-erdos287-erdos-287-4a2e3952cd-formalized-v1 use_empty_simp
theorem probe_2_156 : fcTypeOfName% "Erdos287.erdos_287" := by
  use ∅ <;> simp
#print axioms probe_2_156

-- ATTACK fc-379fc029-erdos287-erdos-287-4a2e3952cd-formalized-v1 assumption
theorem probe_2_157 : fcTypeOfName% "Erdos287.erdos_287" := by
  assumption
#print axioms probe_2_157

-- ATTACK fc-379fc029-erdos287-erdos-287-4a2e3952cd-formalized-v1 infer_instance
theorem probe_2_158 : fcTypeOfName% "Erdos287.erdos_287" := by
  infer_instance
#print axioms probe_2_158

-- ATTACK fc-379fc029-erdos287-erdos-287-4a2e3952cd-formalized-v1 contradiction
theorem probe_2_159 : fcTypeOfName% "Erdos287.erdos_287" := by
  contradiction
#print axioms probe_2_159

-- ATTACK fc-379fc029-erdos287-erdos-287-4a2e3952cd-formalized-v1 solve_by_elim
theorem probe_2_160 : fcTypeOfName% "Erdos287.erdos_287" := by
  solve_by_elim
#print axioms probe_2_160

-- ATTACK fc-379fc029-erdos287-erdos-287-4a2e3952cd-formalized-v1 first_order
theorem probe_2_161 : fcTypeOfName% "Erdos287.erdos_287" := by
  first_order
#print axioms probe_2_161

-- ATTACK fc-379fc029-erdos287-erdos-287-4a2e3952cd-formalized-v1 grind
theorem probe_2_162 : fcTypeOfName% "Erdos287.erdos_287" := by
  grind
#print axioms probe_2_162

-- ATTACK fc-379fc029-erdos287-erdos-287-4a2e3952cd-formalized-v1 exact_search
theorem probe_2_163 : fcTypeOfName% "Erdos287.erdos_287" := by
  exact?
#print axioms probe_2_163

-- ATTACK fc-379fc029-erdos287-erdos-287-4a2e3952cd-formalized-v1 apply_search
theorem probe_2_164 : fcTypeOfName% "Erdos287.erdos_287" := by
  apply?
#print axioms probe_2_164

-- ATTACK fc-379fc029-erdos287-erdos-287-4a2e3952cd-formalized-v1 library_search
theorem probe_2_165 : fcTypeOfName% "Erdos287.erdos_287" := by
  library_search
#print axioms probe_2_165

-- ATTACK fc-379fc029-erdos287-erdos-287-4a2e3952cd-formalized-v1 aesop_search
theorem probe_2_166 : fcTypeOfName% "Erdos287.erdos_287" := by
  aesop?
#print axioms probe_2_166

-- ATTACK fc-379fc029-erdos287-erdos-287-4a2e3952cd-formalized-v1 simp_search
theorem probe_2_167 : fcTypeOfName% "Erdos287.erdos_287" := by
  simp?
#print axioms probe_2_167

-- ATTACK fc-379fc029-erdos307-erdos-307-d63acee527-formalized-v1 simp
theorem probe_2_168 : fcTypeOfName% "Erdos307.erdos_307" := by
  simp
#print axioms probe_2_168

-- ATTACK fc-379fc029-erdos307-erdos-307-d63acee527-formalized-v1 simpa
theorem probe_2_169 : fcTypeOfName% "Erdos307.erdos_307" := by
  simpa
#print axioms probe_2_169

-- ATTACK fc-379fc029-erdos307-erdos-307-d63acee527-formalized-v1 simp_all
theorem probe_2_170 : fcTypeOfName% "Erdos307.erdos_307" := by
  simp_all
#print axioms probe_2_170

-- ATTACK fc-379fc029-erdos307-erdos-307-d63acee527-formalized-v1 aesop
theorem probe_2_171 : fcTypeOfName% "Erdos307.erdos_307" := by
  aesop
#print axioms probe_2_171

-- ATTACK fc-379fc029-erdos307-erdos-307-d63acee527-formalized-v1 omega
theorem probe_2_172 : fcTypeOfName% "Erdos307.erdos_307" := by
  omega
#print axioms probe_2_172

-- ATTACK fc-379fc029-erdos307-erdos-307-d63acee527-formalized-v1 norm_num
theorem probe_2_173 : fcTypeOfName% "Erdos307.erdos_307" := by
  norm_num
#print axioms probe_2_173

-- ATTACK fc-379fc029-erdos307-erdos-307-d63acee527-formalized-v1 decide
theorem probe_2_174 : fcTypeOfName% "Erdos307.erdos_307" := by
  decide
#print axioms probe_2_174

-- ATTACK fc-379fc029-erdos307-erdos-307-d63acee527-formalized-v1 native_decide
theorem probe_2_175 : fcTypeOfName% "Erdos307.erdos_307" := by
  native_decide
#print axioms probe_2_175

-- ATTACK fc-379fc029-erdos307-erdos-307-d63acee527-formalized-v1 true_intro
theorem probe_2_176 : fcTypeOfName% "Erdos307.erdos_307" := by
  exact True.intro
#print axioms probe_2_176

-- ATTACK fc-379fc029-erdos307-erdos-307-d63acee527-formalized-v1 false_elim_simp
theorem probe_2_177 : fcTypeOfName% "Erdos307.erdos_307" := by
  apply False.elim
  simp_all
#print axioms probe_2_177

-- ATTACK fc-379fc029-erdos307-erdos-307-d63acee527-formalized-v1 constructor
theorem probe_2_178 : fcTypeOfName% "Erdos307.erdos_307" := by
  constructor
#print axioms probe_2_178

-- ATTACK fc-379fc029-erdos307-erdos-307-d63acee527-formalized-v1 constructor_simp
theorem probe_2_179 : fcTypeOfName% "Erdos307.erdos_307" := by
  constructor <;> simp
#print axioms probe_2_179

-- ATTACK fc-379fc029-erdos307-erdos-307-d63acee527-formalized-v1 constructor_aesop
theorem probe_2_180 : fcTypeOfName% "Erdos307.erdos_307" := by
  constructor <;> aesop
#print axioms probe_2_180

-- ATTACK fc-379fc029-erdos307-erdos-307-d63acee527-formalized-v1 rfl
theorem probe_2_181 : fcTypeOfName% "Erdos307.erdos_307" := by
  rfl
#print axioms probe_2_181

-- ATTACK fc-379fc029-erdos307-erdos-307-d63acee527-formalized-v1 trivial
theorem probe_2_182 : fcTypeOfName% "Erdos307.erdos_307" := by
  trivial
#print axioms probe_2_182

-- ATTACK fc-379fc029-erdos307-erdos-307-d63acee527-formalized-v1 tauto
theorem probe_2_183 : fcTypeOfName% "Erdos307.erdos_307" := by
  tauto
#print axioms probe_2_183

-- ATTACK fc-379fc029-erdos307-erdos-307-d63acee527-formalized-v1 positivity
theorem probe_2_184 : fcTypeOfName% "Erdos307.erdos_307" := by
  positivity
#print axioms probe_2_184

-- ATTACK fc-379fc029-erdos307-erdos-307-d63acee527-formalized-v1 linarith
theorem probe_2_185 : fcTypeOfName% "Erdos307.erdos_307" := by
  linarith
#print axioms probe_2_185

-- ATTACK fc-379fc029-erdos307-erdos-307-d63acee527-formalized-v1 nlinarith
theorem probe_2_186 : fcTypeOfName% "Erdos307.erdos_307" := by
  nlinarith
#print axioms probe_2_186

-- ATTACK fc-379fc029-erdos307-erdos-307-d63acee527-formalized-v1 intros_simp_all
theorem probe_2_187 : fcTypeOfName% "Erdos307.erdos_307" := by
  intros
  simp_all
#print axioms probe_2_187

-- ATTACK fc-379fc029-erdos307-erdos-307-d63acee527-formalized-v1 intros_omega
theorem probe_2_188 : fcTypeOfName% "Erdos307.erdos_307" := by
  intros
  omega
#print axioms probe_2_188

-- ATTACK fc-379fc029-erdos307-erdos-307-d63acee527-formalized-v1 intros_norm_num
theorem probe_2_189 : fcTypeOfName% "Erdos307.erdos_307" := by
  intros
  norm_num at *
#print axioms probe_2_189

-- ATTACK fc-379fc029-erdos307-erdos-307-d63acee527-formalized-v1 intros_aesop
theorem probe_2_190 : fcTypeOfName% "Erdos307.erdos_307" := by
  intros
  aesop
#print axioms probe_2_190

-- ATTACK fc-379fc029-erdos307-erdos-307-d63acee527-formalized-v1 by_contra_simp_all
theorem probe_2_191 : fcTypeOfName% "Erdos307.erdos_307" := by
  by_contra h
  simp_all
#print axioms probe_2_191

-- ATTACK fc-379fc029-erdos307-erdos-307-d63acee527-formalized-v1 classical_simp_all
theorem probe_2_192 : fcTypeOfName% "Erdos307.erdos_307" := by
  classical
  simp_all
#print axioms probe_2_192

-- ATTACK fc-379fc029-erdos307-erdos-307-d63acee527-formalized-v1 classical_aesop
theorem probe_2_193 : fcTypeOfName% "Erdos307.erdos_307" := by
  classical
  aesop
#print axioms probe_2_193

-- ATTACK fc-379fc029-erdos307-erdos-307-d63acee527-formalized-v1 refine_pair_simp
theorem probe_2_194 : fcTypeOfName% "Erdos307.erdos_307" := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_2_194

-- ATTACK fc-379fc029-erdos307-erdos-307-d63acee527-formalized-v1 refine_pair_aesop
theorem probe_2_195 : fcTypeOfName% "Erdos307.erdos_307" := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_2_195

-- ATTACK fc-379fc029-erdos307-erdos-307-d63acee527-formalized-v1 use_zero_simp
theorem probe_2_196 : fcTypeOfName% "Erdos307.erdos_307" := by
  use 0 <;> simp
#print axioms probe_2_196

-- ATTACK fc-379fc029-erdos307-erdos-307-d63acee527-formalized-v1 use_one_simp
theorem probe_2_197 : fcTypeOfName% "Erdos307.erdos_307" := by
  use 1 <;> simp
#print axioms probe_2_197

-- ATTACK fc-379fc029-erdos307-erdos-307-d63acee527-formalized-v1 use_empty_simp
theorem probe_2_198 : fcTypeOfName% "Erdos307.erdos_307" := by
  use ∅ <;> simp
#print axioms probe_2_198

-- ATTACK fc-379fc029-erdos307-erdos-307-d63acee527-formalized-v1 assumption
theorem probe_2_199 : fcTypeOfName% "Erdos307.erdos_307" := by
  assumption
#print axioms probe_2_199

-- ATTACK fc-379fc029-erdos307-erdos-307-d63acee527-formalized-v1 infer_instance
theorem probe_2_200 : fcTypeOfName% "Erdos307.erdos_307" := by
  infer_instance
#print axioms probe_2_200

-- ATTACK fc-379fc029-erdos307-erdos-307-d63acee527-formalized-v1 contradiction
theorem probe_2_201 : fcTypeOfName% "Erdos307.erdos_307" := by
  contradiction
#print axioms probe_2_201

-- ATTACK fc-379fc029-erdos307-erdos-307-d63acee527-formalized-v1 solve_by_elim
theorem probe_2_202 : fcTypeOfName% "Erdos307.erdos_307" := by
  solve_by_elim
#print axioms probe_2_202

-- ATTACK fc-379fc029-erdos307-erdos-307-d63acee527-formalized-v1 first_order
theorem probe_2_203 : fcTypeOfName% "Erdos307.erdos_307" := by
  first_order
#print axioms probe_2_203

-- ATTACK fc-379fc029-erdos307-erdos-307-d63acee527-formalized-v1 grind
theorem probe_2_204 : fcTypeOfName% "Erdos307.erdos_307" := by
  grind
#print axioms probe_2_204

-- ATTACK fc-379fc029-erdos307-erdos-307-d63acee527-formalized-v1 exact_search
theorem probe_2_205 : fcTypeOfName% "Erdos307.erdos_307" := by
  exact?
#print axioms probe_2_205

-- ATTACK fc-379fc029-erdos307-erdos-307-d63acee527-formalized-v1 apply_search
theorem probe_2_206 : fcTypeOfName% "Erdos307.erdos_307" := by
  apply?
#print axioms probe_2_206

-- ATTACK fc-379fc029-erdos307-erdos-307-d63acee527-formalized-v1 library_search
theorem probe_2_207 : fcTypeOfName% "Erdos307.erdos_307" := by
  library_search
#print axioms probe_2_207

-- ATTACK fc-379fc029-erdos307-erdos-307-d63acee527-formalized-v1 aesop_search
theorem probe_2_208 : fcTypeOfName% "Erdos307.erdos_307" := by
  aesop?
#print axioms probe_2_208

-- ATTACK fc-379fc029-erdos307-erdos-307-d63acee527-formalized-v1 simp_search
theorem probe_2_209 : fcTypeOfName% "Erdos307.erdos_307" := by
  simp?
#print axioms probe_2_209

-- ATTACK fc-379fc029-parts-i-1986289467-formalized-v1 simp
theorem probe_2_210 : fcTypeOfName% "Erdos400.erdos_400.parts.i" := by
  simp
#print axioms probe_2_210

-- ATTACK fc-379fc029-parts-i-1986289467-formalized-v1 simpa
theorem probe_2_211 : fcTypeOfName% "Erdos400.erdos_400.parts.i" := by
  simpa
#print axioms probe_2_211

-- ATTACK fc-379fc029-parts-i-1986289467-formalized-v1 simp_all
theorem probe_2_212 : fcTypeOfName% "Erdos400.erdos_400.parts.i" := by
  simp_all
#print axioms probe_2_212

-- ATTACK fc-379fc029-parts-i-1986289467-formalized-v1 aesop
theorem probe_2_213 : fcTypeOfName% "Erdos400.erdos_400.parts.i" := by
  aesop
#print axioms probe_2_213

-- ATTACK fc-379fc029-parts-i-1986289467-formalized-v1 omega
theorem probe_2_214 : fcTypeOfName% "Erdos400.erdos_400.parts.i" := by
  omega
#print axioms probe_2_214

-- ATTACK fc-379fc029-parts-i-1986289467-formalized-v1 norm_num
theorem probe_2_215 : fcTypeOfName% "Erdos400.erdos_400.parts.i" := by
  norm_num
#print axioms probe_2_215

-- ATTACK fc-379fc029-parts-i-1986289467-formalized-v1 decide
theorem probe_2_216 : fcTypeOfName% "Erdos400.erdos_400.parts.i" := by
  decide
#print axioms probe_2_216

-- ATTACK fc-379fc029-parts-i-1986289467-formalized-v1 native_decide
theorem probe_2_217 : fcTypeOfName% "Erdos400.erdos_400.parts.i" := by
  native_decide
#print axioms probe_2_217

-- ATTACK fc-379fc029-parts-i-1986289467-formalized-v1 true_intro
theorem probe_2_218 : fcTypeOfName% "Erdos400.erdos_400.parts.i" := by
  exact True.intro
#print axioms probe_2_218

-- ATTACK fc-379fc029-parts-i-1986289467-formalized-v1 false_elim_simp
theorem probe_2_219 : fcTypeOfName% "Erdos400.erdos_400.parts.i" := by
  apply False.elim
  simp_all
#print axioms probe_2_219

-- ATTACK fc-379fc029-parts-i-1986289467-formalized-v1 constructor
theorem probe_2_220 : fcTypeOfName% "Erdos400.erdos_400.parts.i" := by
  constructor
#print axioms probe_2_220

-- ATTACK fc-379fc029-parts-i-1986289467-formalized-v1 constructor_simp
theorem probe_2_221 : fcTypeOfName% "Erdos400.erdos_400.parts.i" := by
  constructor <;> simp
#print axioms probe_2_221

-- ATTACK fc-379fc029-parts-i-1986289467-formalized-v1 constructor_aesop
theorem probe_2_222 : fcTypeOfName% "Erdos400.erdos_400.parts.i" := by
  constructor <;> aesop
#print axioms probe_2_222

-- ATTACK fc-379fc029-parts-i-1986289467-formalized-v1 rfl
theorem probe_2_223 : fcTypeOfName% "Erdos400.erdos_400.parts.i" := by
  rfl
#print axioms probe_2_223

-- ATTACK fc-379fc029-parts-i-1986289467-formalized-v1 trivial
theorem probe_2_224 : fcTypeOfName% "Erdos400.erdos_400.parts.i" := by
  trivial
#print axioms probe_2_224

-- ATTACK fc-379fc029-parts-i-1986289467-formalized-v1 tauto
theorem probe_2_225 : fcTypeOfName% "Erdos400.erdos_400.parts.i" := by
  tauto
#print axioms probe_2_225

-- ATTACK fc-379fc029-parts-i-1986289467-formalized-v1 positivity
theorem probe_2_226 : fcTypeOfName% "Erdos400.erdos_400.parts.i" := by
  positivity
#print axioms probe_2_226

-- ATTACK fc-379fc029-parts-i-1986289467-formalized-v1 linarith
theorem probe_2_227 : fcTypeOfName% "Erdos400.erdos_400.parts.i" := by
  linarith
#print axioms probe_2_227

-- ATTACK fc-379fc029-parts-i-1986289467-formalized-v1 nlinarith
theorem probe_2_228 : fcTypeOfName% "Erdos400.erdos_400.parts.i" := by
  nlinarith
#print axioms probe_2_228

-- ATTACK fc-379fc029-parts-i-1986289467-formalized-v1 intros_simp_all
theorem probe_2_229 : fcTypeOfName% "Erdos400.erdos_400.parts.i" := by
  intros
  simp_all
#print axioms probe_2_229

-- ATTACK fc-379fc029-parts-i-1986289467-formalized-v1 intros_omega
theorem probe_2_230 : fcTypeOfName% "Erdos400.erdos_400.parts.i" := by
  intros
  omega
#print axioms probe_2_230

-- ATTACK fc-379fc029-parts-i-1986289467-formalized-v1 intros_norm_num
theorem probe_2_231 : fcTypeOfName% "Erdos400.erdos_400.parts.i" := by
  intros
  norm_num at *
#print axioms probe_2_231

-- ATTACK fc-379fc029-parts-i-1986289467-formalized-v1 intros_aesop
theorem probe_2_232 : fcTypeOfName% "Erdos400.erdos_400.parts.i" := by
  intros
  aesop
#print axioms probe_2_232

-- ATTACK fc-379fc029-parts-i-1986289467-formalized-v1 by_contra_simp_all
theorem probe_2_233 : fcTypeOfName% "Erdos400.erdos_400.parts.i" := by
  by_contra h
  simp_all
#print axioms probe_2_233

-- ATTACK fc-379fc029-parts-i-1986289467-formalized-v1 classical_simp_all
theorem probe_2_234 : fcTypeOfName% "Erdos400.erdos_400.parts.i" := by
  classical
  simp_all
#print axioms probe_2_234

-- ATTACK fc-379fc029-parts-i-1986289467-formalized-v1 classical_aesop
theorem probe_2_235 : fcTypeOfName% "Erdos400.erdos_400.parts.i" := by
  classical
  aesop
#print axioms probe_2_235

-- ATTACK fc-379fc029-parts-i-1986289467-formalized-v1 refine_pair_simp
theorem probe_2_236 : fcTypeOfName% "Erdos400.erdos_400.parts.i" := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_2_236

-- ATTACK fc-379fc029-parts-i-1986289467-formalized-v1 refine_pair_aesop
theorem probe_2_237 : fcTypeOfName% "Erdos400.erdos_400.parts.i" := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_2_237

-- ATTACK fc-379fc029-parts-i-1986289467-formalized-v1 use_zero_simp
theorem probe_2_238 : fcTypeOfName% "Erdos400.erdos_400.parts.i" := by
  use 0 <;> simp
#print axioms probe_2_238

-- ATTACK fc-379fc029-parts-i-1986289467-formalized-v1 use_one_simp
theorem probe_2_239 : fcTypeOfName% "Erdos400.erdos_400.parts.i" := by
  use 1 <;> simp
#print axioms probe_2_239

-- ATTACK fc-379fc029-parts-i-1986289467-formalized-v1 use_empty_simp
theorem probe_2_240 : fcTypeOfName% "Erdos400.erdos_400.parts.i" := by
  use ∅ <;> simp
#print axioms probe_2_240

-- ATTACK fc-379fc029-parts-i-1986289467-formalized-v1 assumption
theorem probe_2_241 : fcTypeOfName% "Erdos400.erdos_400.parts.i" := by
  assumption
#print axioms probe_2_241

-- ATTACK fc-379fc029-parts-i-1986289467-formalized-v1 infer_instance
theorem probe_2_242 : fcTypeOfName% "Erdos400.erdos_400.parts.i" := by
  infer_instance
#print axioms probe_2_242

-- ATTACK fc-379fc029-parts-i-1986289467-formalized-v1 contradiction
theorem probe_2_243 : fcTypeOfName% "Erdos400.erdos_400.parts.i" := by
  contradiction
#print axioms probe_2_243

-- ATTACK fc-379fc029-parts-i-1986289467-formalized-v1 solve_by_elim
theorem probe_2_244 : fcTypeOfName% "Erdos400.erdos_400.parts.i" := by
  solve_by_elim
#print axioms probe_2_244

-- ATTACK fc-379fc029-parts-i-1986289467-formalized-v1 first_order
theorem probe_2_245 : fcTypeOfName% "Erdos400.erdos_400.parts.i" := by
  first_order
#print axioms probe_2_245

-- ATTACK fc-379fc029-parts-i-1986289467-formalized-v1 grind
theorem probe_2_246 : fcTypeOfName% "Erdos400.erdos_400.parts.i" := by
  grind
#print axioms probe_2_246

-- ATTACK fc-379fc029-parts-i-1986289467-formalized-v1 exact_search
theorem probe_2_247 : fcTypeOfName% "Erdos400.erdos_400.parts.i" := by
  exact?
#print axioms probe_2_247

-- ATTACK fc-379fc029-parts-i-1986289467-formalized-v1 apply_search
theorem probe_2_248 : fcTypeOfName% "Erdos400.erdos_400.parts.i" := by
  apply?
#print axioms probe_2_248

-- ATTACK fc-379fc029-parts-i-1986289467-formalized-v1 library_search
theorem probe_2_249 : fcTypeOfName% "Erdos400.erdos_400.parts.i" := by
  library_search
#print axioms probe_2_249

-- ATTACK fc-379fc029-parts-i-1986289467-formalized-v1 aesop_search
theorem probe_2_250 : fcTypeOfName% "Erdos400.erdos_400.parts.i" := by
  aesop?
#print axioms probe_2_250

-- ATTACK fc-379fc029-parts-i-1986289467-formalized-v1 simp_search
theorem probe_2_251 : fcTypeOfName% "Erdos400.erdos_400.parts.i" := by
  simp?
#print axioms probe_2_251

-- ATTACK fc-379fc029-erdos52-erdos-52-27d6bd442b-formalized-v1 simp
theorem probe_2_252 : fcTypeOfName% "Erdos52.erdos_52" := by
  simp
#print axioms probe_2_252

-- ATTACK fc-379fc029-erdos52-erdos-52-27d6bd442b-formalized-v1 simpa
theorem probe_2_253 : fcTypeOfName% "Erdos52.erdos_52" := by
  simpa
#print axioms probe_2_253

-- ATTACK fc-379fc029-erdos52-erdos-52-27d6bd442b-formalized-v1 simp_all
theorem probe_2_254 : fcTypeOfName% "Erdos52.erdos_52" := by
  simp_all
#print axioms probe_2_254

-- ATTACK fc-379fc029-erdos52-erdos-52-27d6bd442b-formalized-v1 aesop
theorem probe_2_255 : fcTypeOfName% "Erdos52.erdos_52" := by
  aesop
#print axioms probe_2_255

-- ATTACK fc-379fc029-erdos52-erdos-52-27d6bd442b-formalized-v1 omega
theorem probe_2_256 : fcTypeOfName% "Erdos52.erdos_52" := by
  omega
#print axioms probe_2_256

-- ATTACK fc-379fc029-erdos52-erdos-52-27d6bd442b-formalized-v1 norm_num
theorem probe_2_257 : fcTypeOfName% "Erdos52.erdos_52" := by
  norm_num
#print axioms probe_2_257

-- ATTACK fc-379fc029-erdos52-erdos-52-27d6bd442b-formalized-v1 decide
theorem probe_2_258 : fcTypeOfName% "Erdos52.erdos_52" := by
  decide
#print axioms probe_2_258

-- ATTACK fc-379fc029-erdos52-erdos-52-27d6bd442b-formalized-v1 native_decide
theorem probe_2_259 : fcTypeOfName% "Erdos52.erdos_52" := by
  native_decide
#print axioms probe_2_259

-- ATTACK fc-379fc029-erdos52-erdos-52-27d6bd442b-formalized-v1 true_intro
theorem probe_2_260 : fcTypeOfName% "Erdos52.erdos_52" := by
  exact True.intro
#print axioms probe_2_260

-- ATTACK fc-379fc029-erdos52-erdos-52-27d6bd442b-formalized-v1 false_elim_simp
theorem probe_2_261 : fcTypeOfName% "Erdos52.erdos_52" := by
  apply False.elim
  simp_all
#print axioms probe_2_261

-- ATTACK fc-379fc029-erdos52-erdos-52-27d6bd442b-formalized-v1 constructor
theorem probe_2_262 : fcTypeOfName% "Erdos52.erdos_52" := by
  constructor
#print axioms probe_2_262

-- ATTACK fc-379fc029-erdos52-erdos-52-27d6bd442b-formalized-v1 constructor_simp
theorem probe_2_263 : fcTypeOfName% "Erdos52.erdos_52" := by
  constructor <;> simp
#print axioms probe_2_263

-- ATTACK fc-379fc029-erdos52-erdos-52-27d6bd442b-formalized-v1 constructor_aesop
theorem probe_2_264 : fcTypeOfName% "Erdos52.erdos_52" := by
  constructor <;> aesop
#print axioms probe_2_264

-- ATTACK fc-379fc029-erdos52-erdos-52-27d6bd442b-formalized-v1 rfl
theorem probe_2_265 : fcTypeOfName% "Erdos52.erdos_52" := by
  rfl
#print axioms probe_2_265

-- ATTACK fc-379fc029-erdos52-erdos-52-27d6bd442b-formalized-v1 trivial
theorem probe_2_266 : fcTypeOfName% "Erdos52.erdos_52" := by
  trivial
#print axioms probe_2_266

-- ATTACK fc-379fc029-erdos52-erdos-52-27d6bd442b-formalized-v1 tauto
theorem probe_2_267 : fcTypeOfName% "Erdos52.erdos_52" := by
  tauto
#print axioms probe_2_267

-- ATTACK fc-379fc029-erdos52-erdos-52-27d6bd442b-formalized-v1 positivity
theorem probe_2_268 : fcTypeOfName% "Erdos52.erdos_52" := by
  positivity
#print axioms probe_2_268

-- ATTACK fc-379fc029-erdos52-erdos-52-27d6bd442b-formalized-v1 linarith
theorem probe_2_269 : fcTypeOfName% "Erdos52.erdos_52" := by
  linarith
#print axioms probe_2_269

-- ATTACK fc-379fc029-erdos52-erdos-52-27d6bd442b-formalized-v1 nlinarith
theorem probe_2_270 : fcTypeOfName% "Erdos52.erdos_52" := by
  nlinarith
#print axioms probe_2_270

-- ATTACK fc-379fc029-erdos52-erdos-52-27d6bd442b-formalized-v1 intros_simp_all
theorem probe_2_271 : fcTypeOfName% "Erdos52.erdos_52" := by
  intros
  simp_all
#print axioms probe_2_271

-- ATTACK fc-379fc029-erdos52-erdos-52-27d6bd442b-formalized-v1 intros_omega
theorem probe_2_272 : fcTypeOfName% "Erdos52.erdos_52" := by
  intros
  omega
#print axioms probe_2_272

-- ATTACK fc-379fc029-erdos52-erdos-52-27d6bd442b-formalized-v1 intros_norm_num
theorem probe_2_273 : fcTypeOfName% "Erdos52.erdos_52" := by
  intros
  norm_num at *
#print axioms probe_2_273

-- ATTACK fc-379fc029-erdos52-erdos-52-27d6bd442b-formalized-v1 intros_aesop
theorem probe_2_274 : fcTypeOfName% "Erdos52.erdos_52" := by
  intros
  aesop
#print axioms probe_2_274

-- ATTACK fc-379fc029-erdos52-erdos-52-27d6bd442b-formalized-v1 by_contra_simp_all
theorem probe_2_275 : fcTypeOfName% "Erdos52.erdos_52" := by
  by_contra h
  simp_all
#print axioms probe_2_275

-- ATTACK fc-379fc029-erdos52-erdos-52-27d6bd442b-formalized-v1 classical_simp_all
theorem probe_2_276 : fcTypeOfName% "Erdos52.erdos_52" := by
  classical
  simp_all
#print axioms probe_2_276

-- ATTACK fc-379fc029-erdos52-erdos-52-27d6bd442b-formalized-v1 classical_aesop
theorem probe_2_277 : fcTypeOfName% "Erdos52.erdos_52" := by
  classical
  aesop
#print axioms probe_2_277

-- ATTACK fc-379fc029-erdos52-erdos-52-27d6bd442b-formalized-v1 refine_pair_simp
theorem probe_2_278 : fcTypeOfName% "Erdos52.erdos_52" := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_2_278

-- ATTACK fc-379fc029-erdos52-erdos-52-27d6bd442b-formalized-v1 refine_pair_aesop
theorem probe_2_279 : fcTypeOfName% "Erdos52.erdos_52" := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_2_279

-- ATTACK fc-379fc029-erdos52-erdos-52-27d6bd442b-formalized-v1 use_zero_simp
theorem probe_2_280 : fcTypeOfName% "Erdos52.erdos_52" := by
  use 0 <;> simp
#print axioms probe_2_280

-- ATTACK fc-379fc029-erdos52-erdos-52-27d6bd442b-formalized-v1 use_one_simp
theorem probe_2_281 : fcTypeOfName% "Erdos52.erdos_52" := by
  use 1 <;> simp
#print axioms probe_2_281

-- ATTACK fc-379fc029-erdos52-erdos-52-27d6bd442b-formalized-v1 use_empty_simp
theorem probe_2_282 : fcTypeOfName% "Erdos52.erdos_52" := by
  use ∅ <;> simp
#print axioms probe_2_282

-- ATTACK fc-379fc029-erdos52-erdos-52-27d6bd442b-formalized-v1 assumption
theorem probe_2_283 : fcTypeOfName% "Erdos52.erdos_52" := by
  assumption
#print axioms probe_2_283

-- ATTACK fc-379fc029-erdos52-erdos-52-27d6bd442b-formalized-v1 infer_instance
theorem probe_2_284 : fcTypeOfName% "Erdos52.erdos_52" := by
  infer_instance
#print axioms probe_2_284

-- ATTACK fc-379fc029-erdos52-erdos-52-27d6bd442b-formalized-v1 contradiction
theorem probe_2_285 : fcTypeOfName% "Erdos52.erdos_52" := by
  contradiction
#print axioms probe_2_285

-- ATTACK fc-379fc029-erdos52-erdos-52-27d6bd442b-formalized-v1 solve_by_elim
theorem probe_2_286 : fcTypeOfName% "Erdos52.erdos_52" := by
  solve_by_elim
#print axioms probe_2_286

-- ATTACK fc-379fc029-erdos52-erdos-52-27d6bd442b-formalized-v1 first_order
theorem probe_2_287 : fcTypeOfName% "Erdos52.erdos_52" := by
  first_order
#print axioms probe_2_287

-- ATTACK fc-379fc029-erdos52-erdos-52-27d6bd442b-formalized-v1 grind
theorem probe_2_288 : fcTypeOfName% "Erdos52.erdos_52" := by
  grind
#print axioms probe_2_288

-- ATTACK fc-379fc029-erdos52-erdos-52-27d6bd442b-formalized-v1 exact_search
theorem probe_2_289 : fcTypeOfName% "Erdos52.erdos_52" := by
  exact?
#print axioms probe_2_289

-- ATTACK fc-379fc029-erdos52-erdos-52-27d6bd442b-formalized-v1 apply_search
theorem probe_2_290 : fcTypeOfName% "Erdos52.erdos_52" := by
  apply?
#print axioms probe_2_290

-- ATTACK fc-379fc029-erdos52-erdos-52-27d6bd442b-formalized-v1 library_search
theorem probe_2_291 : fcTypeOfName% "Erdos52.erdos_52" := by
  library_search
#print axioms probe_2_291

-- ATTACK fc-379fc029-erdos52-erdos-52-27d6bd442b-formalized-v1 aesop_search
theorem probe_2_292 : fcTypeOfName% "Erdos52.erdos_52" := by
  aesop?
#print axioms probe_2_292

-- ATTACK fc-379fc029-erdos52-erdos-52-27d6bd442b-formalized-v1 simp_search
theorem probe_2_293 : fcTypeOfName% "Erdos52.erdos_52" := by
  simp?
#print axioms probe_2_293

-- ATTACK fc-379fc029-variants-twenty-five-8707374236-formalized-v1 simp
theorem probe_2_294 : fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five" := by
  simp
#print axioms probe_2_294

-- ATTACK fc-379fc029-variants-twenty-five-8707374236-formalized-v1 simpa
theorem probe_2_295 : fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five" := by
  simpa
#print axioms probe_2_295

-- ATTACK fc-379fc029-variants-twenty-five-8707374236-formalized-v1 simp_all
theorem probe_2_296 : fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five" := by
  simp_all
#print axioms probe_2_296

-- ATTACK fc-379fc029-variants-twenty-five-8707374236-formalized-v1 aesop
theorem probe_2_297 : fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five" := by
  aesop
#print axioms probe_2_297

-- ATTACK fc-379fc029-variants-twenty-five-8707374236-formalized-v1 omega
theorem probe_2_298 : fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five" := by
  omega
#print axioms probe_2_298

-- ATTACK fc-379fc029-variants-twenty-five-8707374236-formalized-v1 norm_num
theorem probe_2_299 : fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five" := by
  norm_num
#print axioms probe_2_299

-- ATTACK fc-379fc029-variants-twenty-five-8707374236-formalized-v1 decide
theorem probe_2_300 : fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five" := by
  decide
#print axioms probe_2_300

-- ATTACK fc-379fc029-variants-twenty-five-8707374236-formalized-v1 native_decide
theorem probe_2_301 : fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five" := by
  native_decide
#print axioms probe_2_301

-- ATTACK fc-379fc029-variants-twenty-five-8707374236-formalized-v1 true_intro
theorem probe_2_302 : fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five" := by
  exact True.intro
#print axioms probe_2_302

-- ATTACK fc-379fc029-variants-twenty-five-8707374236-formalized-v1 false_elim_simp
theorem probe_2_303 : fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five" := by
  apply False.elim
  simp_all
#print axioms probe_2_303

-- ATTACK fc-379fc029-variants-twenty-five-8707374236-formalized-v1 constructor
theorem probe_2_304 : fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five" := by
  constructor
#print axioms probe_2_304

-- ATTACK fc-379fc029-variants-twenty-five-8707374236-formalized-v1 constructor_simp
theorem probe_2_305 : fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five" := by
  constructor <;> simp
#print axioms probe_2_305

-- ATTACK fc-379fc029-variants-twenty-five-8707374236-formalized-v1 constructor_aesop
theorem probe_2_306 : fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five" := by
  constructor <;> aesop
#print axioms probe_2_306

-- ATTACK fc-379fc029-variants-twenty-five-8707374236-formalized-v1 rfl
theorem probe_2_307 : fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five" := by
  rfl
#print axioms probe_2_307

-- ATTACK fc-379fc029-variants-twenty-five-8707374236-formalized-v1 trivial
theorem probe_2_308 : fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five" := by
  trivial
#print axioms probe_2_308

-- ATTACK fc-379fc029-variants-twenty-five-8707374236-formalized-v1 tauto
theorem probe_2_309 : fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five" := by
  tauto
#print axioms probe_2_309

-- ATTACK fc-379fc029-variants-twenty-five-8707374236-formalized-v1 positivity
theorem probe_2_310 : fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five" := by
  positivity
#print axioms probe_2_310

-- ATTACK fc-379fc029-variants-twenty-five-8707374236-formalized-v1 linarith
theorem probe_2_311 : fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five" := by
  linarith
#print axioms probe_2_311

-- ATTACK fc-379fc029-variants-twenty-five-8707374236-formalized-v1 nlinarith
theorem probe_2_312 : fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five" := by
  nlinarith
#print axioms probe_2_312

-- ATTACK fc-379fc029-variants-twenty-five-8707374236-formalized-v1 intros_simp_all
theorem probe_2_313 : fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five" := by
  intros
  simp_all
#print axioms probe_2_313

-- ATTACK fc-379fc029-variants-twenty-five-8707374236-formalized-v1 intros_omega
theorem probe_2_314 : fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five" := by
  intros
  omega
#print axioms probe_2_314

-- ATTACK fc-379fc029-variants-twenty-five-8707374236-formalized-v1 intros_norm_num
theorem probe_2_315 : fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five" := by
  intros
  norm_num at *
#print axioms probe_2_315

-- ATTACK fc-379fc029-variants-twenty-five-8707374236-formalized-v1 intros_aesop
theorem probe_2_316 : fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five" := by
  intros
  aesop
#print axioms probe_2_316

-- ATTACK fc-379fc029-variants-twenty-five-8707374236-formalized-v1 by_contra_simp_all
theorem probe_2_317 : fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five" := by
  by_contra h
  simp_all
#print axioms probe_2_317

-- ATTACK fc-379fc029-variants-twenty-five-8707374236-formalized-v1 classical_simp_all
theorem probe_2_318 : fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five" := by
  classical
  simp_all
#print axioms probe_2_318

-- ATTACK fc-379fc029-variants-twenty-five-8707374236-formalized-v1 classical_aesop
theorem probe_2_319 : fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five" := by
  classical
  aesop
#print axioms probe_2_319

-- ATTACK fc-379fc029-variants-twenty-five-8707374236-formalized-v1 refine_pair_simp
theorem probe_2_320 : fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five" := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_2_320

-- ATTACK fc-379fc029-variants-twenty-five-8707374236-formalized-v1 refine_pair_aesop
theorem probe_2_321 : fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five" := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_2_321

-- ATTACK fc-379fc029-variants-twenty-five-8707374236-formalized-v1 use_zero_simp
theorem probe_2_322 : fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five" := by
  use 0 <;> simp
#print axioms probe_2_322

-- ATTACK fc-379fc029-variants-twenty-five-8707374236-formalized-v1 use_one_simp
theorem probe_2_323 : fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five" := by
  use 1 <;> simp
#print axioms probe_2_323

-- ATTACK fc-379fc029-variants-twenty-five-8707374236-formalized-v1 use_empty_simp
theorem probe_2_324 : fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five" := by
  use ∅ <;> simp
#print axioms probe_2_324

-- ATTACK fc-379fc029-variants-twenty-five-8707374236-formalized-v1 assumption
theorem probe_2_325 : fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five" := by
  assumption
#print axioms probe_2_325

-- ATTACK fc-379fc029-variants-twenty-five-8707374236-formalized-v1 infer_instance
theorem probe_2_326 : fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five" := by
  infer_instance
#print axioms probe_2_326

-- ATTACK fc-379fc029-variants-twenty-five-8707374236-formalized-v1 contradiction
theorem probe_2_327 : fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five" := by
  contradiction
#print axioms probe_2_327

-- ATTACK fc-379fc029-variants-twenty-five-8707374236-formalized-v1 solve_by_elim
theorem probe_2_328 : fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five" := by
  solve_by_elim
#print axioms probe_2_328

-- ATTACK fc-379fc029-variants-twenty-five-8707374236-formalized-v1 first_order
theorem probe_2_329 : fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five" := by
  first_order
#print axioms probe_2_329

-- ATTACK fc-379fc029-variants-twenty-five-8707374236-formalized-v1 grind
theorem probe_2_330 : fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five" := by
  grind
#print axioms probe_2_330

-- ATTACK fc-379fc029-variants-twenty-five-8707374236-formalized-v1 exact_search
theorem probe_2_331 : fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five" := by
  exact?
#print axioms probe_2_331

-- ATTACK fc-379fc029-variants-twenty-five-8707374236-formalized-v1 apply_search
theorem probe_2_332 : fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five" := by
  apply?
#print axioms probe_2_332

-- ATTACK fc-379fc029-variants-twenty-five-8707374236-formalized-v1 library_search
theorem probe_2_333 : fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five" := by
  library_search
#print axioms probe_2_333

-- ATTACK fc-379fc029-variants-twenty-five-8707374236-formalized-v1 aesop_search
theorem probe_2_334 : fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five" := by
  aesop?
#print axioms probe_2_334

-- ATTACK fc-379fc029-variants-twenty-five-8707374236-formalized-v1 simp_search
theorem probe_2_335 : fcTypeOfName% "Erdos686.erdos_686.variants.twenty_five" := by
  simp?
#print axioms probe_2_335

-- ATTACK fc-379fc029-parts-b-fbe08c9411-formalized-v1 simp
theorem probe_2_336 : fcTypeOfName% "Erdos890.erdos_890.parts.b" := by
  simp
#print axioms probe_2_336

-- ATTACK fc-379fc029-parts-b-fbe08c9411-formalized-v1 simpa
theorem probe_2_337 : fcTypeOfName% "Erdos890.erdos_890.parts.b" := by
  simpa
#print axioms probe_2_337

-- ATTACK fc-379fc029-parts-b-fbe08c9411-formalized-v1 simp_all
theorem probe_2_338 : fcTypeOfName% "Erdos890.erdos_890.parts.b" := by
  simp_all
#print axioms probe_2_338

-- ATTACK fc-379fc029-parts-b-fbe08c9411-formalized-v1 aesop
theorem probe_2_339 : fcTypeOfName% "Erdos890.erdos_890.parts.b" := by
  aesop
#print axioms probe_2_339

-- ATTACK fc-379fc029-parts-b-fbe08c9411-formalized-v1 omega
theorem probe_2_340 : fcTypeOfName% "Erdos890.erdos_890.parts.b" := by
  omega
#print axioms probe_2_340

-- ATTACK fc-379fc029-parts-b-fbe08c9411-formalized-v1 norm_num
theorem probe_2_341 : fcTypeOfName% "Erdos890.erdos_890.parts.b" := by
  norm_num
#print axioms probe_2_341

-- ATTACK fc-379fc029-parts-b-fbe08c9411-formalized-v1 decide
theorem probe_2_342 : fcTypeOfName% "Erdos890.erdos_890.parts.b" := by
  decide
#print axioms probe_2_342

-- ATTACK fc-379fc029-parts-b-fbe08c9411-formalized-v1 native_decide
theorem probe_2_343 : fcTypeOfName% "Erdos890.erdos_890.parts.b" := by
  native_decide
#print axioms probe_2_343

-- ATTACK fc-379fc029-parts-b-fbe08c9411-formalized-v1 true_intro
theorem probe_2_344 : fcTypeOfName% "Erdos890.erdos_890.parts.b" := by
  exact True.intro
#print axioms probe_2_344

-- ATTACK fc-379fc029-parts-b-fbe08c9411-formalized-v1 false_elim_simp
theorem probe_2_345 : fcTypeOfName% "Erdos890.erdos_890.parts.b" := by
  apply False.elim
  simp_all
#print axioms probe_2_345

-- ATTACK fc-379fc029-parts-b-fbe08c9411-formalized-v1 constructor
theorem probe_2_346 : fcTypeOfName% "Erdos890.erdos_890.parts.b" := by
  constructor
#print axioms probe_2_346

-- ATTACK fc-379fc029-parts-b-fbe08c9411-formalized-v1 constructor_simp
theorem probe_2_347 : fcTypeOfName% "Erdos890.erdos_890.parts.b" := by
  constructor <;> simp
#print axioms probe_2_347

-- ATTACK fc-379fc029-parts-b-fbe08c9411-formalized-v1 constructor_aesop
theorem probe_2_348 : fcTypeOfName% "Erdos890.erdos_890.parts.b" := by
  constructor <;> aesop
#print axioms probe_2_348

-- ATTACK fc-379fc029-parts-b-fbe08c9411-formalized-v1 rfl
theorem probe_2_349 : fcTypeOfName% "Erdos890.erdos_890.parts.b" := by
  rfl
#print axioms probe_2_349

-- ATTACK fc-379fc029-parts-b-fbe08c9411-formalized-v1 trivial
theorem probe_2_350 : fcTypeOfName% "Erdos890.erdos_890.parts.b" := by
  trivial
#print axioms probe_2_350

-- ATTACK fc-379fc029-parts-b-fbe08c9411-formalized-v1 tauto
theorem probe_2_351 : fcTypeOfName% "Erdos890.erdos_890.parts.b" := by
  tauto
#print axioms probe_2_351

-- ATTACK fc-379fc029-parts-b-fbe08c9411-formalized-v1 positivity
theorem probe_2_352 : fcTypeOfName% "Erdos890.erdos_890.parts.b" := by
  positivity
#print axioms probe_2_352

-- ATTACK fc-379fc029-parts-b-fbe08c9411-formalized-v1 linarith
theorem probe_2_353 : fcTypeOfName% "Erdos890.erdos_890.parts.b" := by
  linarith
#print axioms probe_2_353

-- ATTACK fc-379fc029-parts-b-fbe08c9411-formalized-v1 nlinarith
theorem probe_2_354 : fcTypeOfName% "Erdos890.erdos_890.parts.b" := by
  nlinarith
#print axioms probe_2_354

-- ATTACK fc-379fc029-parts-b-fbe08c9411-formalized-v1 intros_simp_all
theorem probe_2_355 : fcTypeOfName% "Erdos890.erdos_890.parts.b" := by
  intros
  simp_all
#print axioms probe_2_355

-- ATTACK fc-379fc029-parts-b-fbe08c9411-formalized-v1 intros_omega
theorem probe_2_356 : fcTypeOfName% "Erdos890.erdos_890.parts.b" := by
  intros
  omega
#print axioms probe_2_356

-- ATTACK fc-379fc029-parts-b-fbe08c9411-formalized-v1 intros_norm_num
theorem probe_2_357 : fcTypeOfName% "Erdos890.erdos_890.parts.b" := by
  intros
  norm_num at *
#print axioms probe_2_357

-- ATTACK fc-379fc029-parts-b-fbe08c9411-formalized-v1 intros_aesop
theorem probe_2_358 : fcTypeOfName% "Erdos890.erdos_890.parts.b" := by
  intros
  aesop
#print axioms probe_2_358

-- ATTACK fc-379fc029-parts-b-fbe08c9411-formalized-v1 by_contra_simp_all
theorem probe_2_359 : fcTypeOfName% "Erdos890.erdos_890.parts.b" := by
  by_contra h
  simp_all
#print axioms probe_2_359

-- ATTACK fc-379fc029-parts-b-fbe08c9411-formalized-v1 classical_simp_all
theorem probe_2_360 : fcTypeOfName% "Erdos890.erdos_890.parts.b" := by
  classical
  simp_all
#print axioms probe_2_360

-- ATTACK fc-379fc029-parts-b-fbe08c9411-formalized-v1 classical_aesop
theorem probe_2_361 : fcTypeOfName% "Erdos890.erdos_890.parts.b" := by
  classical
  aesop
#print axioms probe_2_361

-- ATTACK fc-379fc029-parts-b-fbe08c9411-formalized-v1 refine_pair_simp
theorem probe_2_362 : fcTypeOfName% "Erdos890.erdos_890.parts.b" := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_2_362

-- ATTACK fc-379fc029-parts-b-fbe08c9411-formalized-v1 refine_pair_aesop
theorem probe_2_363 : fcTypeOfName% "Erdos890.erdos_890.parts.b" := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_2_363

-- ATTACK fc-379fc029-parts-b-fbe08c9411-formalized-v1 use_zero_simp
theorem probe_2_364 : fcTypeOfName% "Erdos890.erdos_890.parts.b" := by
  use 0 <;> simp
#print axioms probe_2_364

-- ATTACK fc-379fc029-parts-b-fbe08c9411-formalized-v1 use_one_simp
theorem probe_2_365 : fcTypeOfName% "Erdos890.erdos_890.parts.b" := by
  use 1 <;> simp
#print axioms probe_2_365

-- ATTACK fc-379fc029-parts-b-fbe08c9411-formalized-v1 use_empty_simp
theorem probe_2_366 : fcTypeOfName% "Erdos890.erdos_890.parts.b" := by
  use ∅ <;> simp
#print axioms probe_2_366

-- ATTACK fc-379fc029-parts-b-fbe08c9411-formalized-v1 assumption
theorem probe_2_367 : fcTypeOfName% "Erdos890.erdos_890.parts.b" := by
  assumption
#print axioms probe_2_367

-- ATTACK fc-379fc029-parts-b-fbe08c9411-formalized-v1 infer_instance
theorem probe_2_368 : fcTypeOfName% "Erdos890.erdos_890.parts.b" := by
  infer_instance
#print axioms probe_2_368

-- ATTACK fc-379fc029-parts-b-fbe08c9411-formalized-v1 contradiction
theorem probe_2_369 : fcTypeOfName% "Erdos890.erdos_890.parts.b" := by
  contradiction
#print axioms probe_2_369

-- ATTACK fc-379fc029-parts-b-fbe08c9411-formalized-v1 solve_by_elim
theorem probe_2_370 : fcTypeOfName% "Erdos890.erdos_890.parts.b" := by
  solve_by_elim
#print axioms probe_2_370

-- ATTACK fc-379fc029-parts-b-fbe08c9411-formalized-v1 first_order
theorem probe_2_371 : fcTypeOfName% "Erdos890.erdos_890.parts.b" := by
  first_order
#print axioms probe_2_371

-- ATTACK fc-379fc029-parts-b-fbe08c9411-formalized-v1 grind
theorem probe_2_372 : fcTypeOfName% "Erdos890.erdos_890.parts.b" := by
  grind
#print axioms probe_2_372

-- ATTACK fc-379fc029-parts-b-fbe08c9411-formalized-v1 exact_search
theorem probe_2_373 : fcTypeOfName% "Erdos890.erdos_890.parts.b" := by
  exact?
#print axioms probe_2_373

-- ATTACK fc-379fc029-parts-b-fbe08c9411-formalized-v1 apply_search
theorem probe_2_374 : fcTypeOfName% "Erdos890.erdos_890.parts.b" := by
  apply?
#print axioms probe_2_374

-- ATTACK fc-379fc029-parts-b-fbe08c9411-formalized-v1 library_search
theorem probe_2_375 : fcTypeOfName% "Erdos890.erdos_890.parts.b" := by
  library_search
#print axioms probe_2_375

-- ATTACK fc-379fc029-parts-b-fbe08c9411-formalized-v1 aesop_search
theorem probe_2_376 : fcTypeOfName% "Erdos890.erdos_890.parts.b" := by
  aesop?
#print axioms probe_2_376

-- ATTACK fc-379fc029-parts-b-fbe08c9411-formalized-v1 simp_search
theorem probe_2_377 : fcTypeOfName% "Erdos890.erdos_890.parts.b" := by
  simp?
#print axioms probe_2_377

-- ATTACK fc-379fc029-variants-factorial-add-one-6c719496c0-formalized-v1 simp
theorem probe_2_378 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one" := by
  simp
#print axioms probe_2_378

-- ATTACK fc-379fc029-variants-factorial-add-one-6c719496c0-formalized-v1 simpa
theorem probe_2_379 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one" := by
  simpa
#print axioms probe_2_379

-- ATTACK fc-379fc029-variants-factorial-add-one-6c719496c0-formalized-v1 simp_all
theorem probe_2_380 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one" := by
  simp_all
#print axioms probe_2_380

-- ATTACK fc-379fc029-variants-factorial-add-one-6c719496c0-formalized-v1 aesop
theorem probe_2_381 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one" := by
  aesop
#print axioms probe_2_381

-- ATTACK fc-379fc029-variants-factorial-add-one-6c719496c0-formalized-v1 omega
theorem probe_2_382 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one" := by
  omega
#print axioms probe_2_382

-- ATTACK fc-379fc029-variants-factorial-add-one-6c719496c0-formalized-v1 norm_num
theorem probe_2_383 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one" := by
  norm_num
#print axioms probe_2_383

-- ATTACK fc-379fc029-variants-factorial-add-one-6c719496c0-formalized-v1 decide
theorem probe_2_384 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one" := by
  decide
#print axioms probe_2_384

-- ATTACK fc-379fc029-variants-factorial-add-one-6c719496c0-formalized-v1 native_decide
theorem probe_2_385 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one" := by
  native_decide
#print axioms probe_2_385

-- ATTACK fc-379fc029-variants-factorial-add-one-6c719496c0-formalized-v1 true_intro
theorem probe_2_386 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one" := by
  exact True.intro
#print axioms probe_2_386

-- ATTACK fc-379fc029-variants-factorial-add-one-6c719496c0-formalized-v1 false_elim_simp
theorem probe_2_387 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one" := by
  apply False.elim
  simp_all
#print axioms probe_2_387

-- ATTACK fc-379fc029-variants-factorial-add-one-6c719496c0-formalized-v1 constructor
theorem probe_2_388 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one" := by
  constructor
#print axioms probe_2_388

-- ATTACK fc-379fc029-variants-factorial-add-one-6c719496c0-formalized-v1 constructor_simp
theorem probe_2_389 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one" := by
  constructor <;> simp
#print axioms probe_2_389

-- ATTACK fc-379fc029-variants-factorial-add-one-6c719496c0-formalized-v1 constructor_aesop
theorem probe_2_390 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one" := by
  constructor <;> aesop
#print axioms probe_2_390

-- ATTACK fc-379fc029-variants-factorial-add-one-6c719496c0-formalized-v1 rfl
theorem probe_2_391 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one" := by
  rfl
#print axioms probe_2_391

-- ATTACK fc-379fc029-variants-factorial-add-one-6c719496c0-formalized-v1 trivial
theorem probe_2_392 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one" := by
  trivial
#print axioms probe_2_392

-- ATTACK fc-379fc029-variants-factorial-add-one-6c719496c0-formalized-v1 tauto
theorem probe_2_393 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one" := by
  tauto
#print axioms probe_2_393

-- ATTACK fc-379fc029-variants-factorial-add-one-6c719496c0-formalized-v1 positivity
theorem probe_2_394 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one" := by
  positivity
#print axioms probe_2_394

-- ATTACK fc-379fc029-variants-factorial-add-one-6c719496c0-formalized-v1 linarith
theorem probe_2_395 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one" := by
  linarith
#print axioms probe_2_395

-- ATTACK fc-379fc029-variants-factorial-add-one-6c719496c0-formalized-v1 nlinarith
theorem probe_2_396 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one" := by
  nlinarith
#print axioms probe_2_396

-- ATTACK fc-379fc029-variants-factorial-add-one-6c719496c0-formalized-v1 intros_simp_all
theorem probe_2_397 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one" := by
  intros
  simp_all
#print axioms probe_2_397

-- ATTACK fc-379fc029-variants-factorial-add-one-6c719496c0-formalized-v1 intros_omega
theorem probe_2_398 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one" := by
  intros
  omega
#print axioms probe_2_398

-- ATTACK fc-379fc029-variants-factorial-add-one-6c719496c0-formalized-v1 intros_norm_num
theorem probe_2_399 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one" := by
  intros
  norm_num at *
#print axioms probe_2_399

-- ATTACK fc-379fc029-variants-factorial-add-one-6c719496c0-formalized-v1 intros_aesop
theorem probe_2_400 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one" := by
  intros
  aesop
#print axioms probe_2_400

-- ATTACK fc-379fc029-variants-factorial-add-one-6c719496c0-formalized-v1 by_contra_simp_all
theorem probe_2_401 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one" := by
  by_contra h
  simp_all
#print axioms probe_2_401

-- ATTACK fc-379fc029-variants-factorial-add-one-6c719496c0-formalized-v1 classical_simp_all
theorem probe_2_402 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one" := by
  classical
  simp_all
#print axioms probe_2_402

-- ATTACK fc-379fc029-variants-factorial-add-one-6c719496c0-formalized-v1 classical_aesop
theorem probe_2_403 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one" := by
  classical
  aesop
#print axioms probe_2_403

-- ATTACK fc-379fc029-variants-factorial-add-one-6c719496c0-formalized-v1 refine_pair_simp
theorem probe_2_404 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one" := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_2_404

-- ATTACK fc-379fc029-variants-factorial-add-one-6c719496c0-formalized-v1 refine_pair_aesop
theorem probe_2_405 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one" := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_2_405

-- ATTACK fc-379fc029-variants-factorial-add-one-6c719496c0-formalized-v1 use_zero_simp
theorem probe_2_406 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one" := by
  use 0 <;> simp
#print axioms probe_2_406

-- ATTACK fc-379fc029-variants-factorial-add-one-6c719496c0-formalized-v1 use_one_simp
theorem probe_2_407 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one" := by
  use 1 <;> simp
#print axioms probe_2_407

-- ATTACK fc-379fc029-variants-factorial-add-one-6c719496c0-formalized-v1 use_empty_simp
theorem probe_2_408 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one" := by
  use ∅ <;> simp
#print axioms probe_2_408

-- ATTACK fc-379fc029-variants-factorial-add-one-6c719496c0-formalized-v1 assumption
theorem probe_2_409 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one" := by
  assumption
#print axioms probe_2_409

-- ATTACK fc-379fc029-variants-factorial-add-one-6c719496c0-formalized-v1 infer_instance
theorem probe_2_410 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one" := by
  infer_instance
#print axioms probe_2_410

-- ATTACK fc-379fc029-variants-factorial-add-one-6c719496c0-formalized-v1 contradiction
theorem probe_2_411 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one" := by
  contradiction
#print axioms probe_2_411

-- ATTACK fc-379fc029-variants-factorial-add-one-6c719496c0-formalized-v1 solve_by_elim
theorem probe_2_412 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one" := by
  solve_by_elim
#print axioms probe_2_412

-- ATTACK fc-379fc029-variants-factorial-add-one-6c719496c0-formalized-v1 first_order
theorem probe_2_413 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one" := by
  first_order
#print axioms probe_2_413

-- ATTACK fc-379fc029-variants-factorial-add-one-6c719496c0-formalized-v1 grind
theorem probe_2_414 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one" := by
  grind
#print axioms probe_2_414

-- ATTACK fc-379fc029-variants-factorial-add-one-6c719496c0-formalized-v1 exact_search
theorem probe_2_415 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one" := by
  exact?
#print axioms probe_2_415

-- ATTACK fc-379fc029-variants-factorial-add-one-6c719496c0-formalized-v1 apply_search
theorem probe_2_416 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one" := by
  apply?
#print axioms probe_2_416

-- ATTACK fc-379fc029-variants-factorial-add-one-6c719496c0-formalized-v1 library_search
theorem probe_2_417 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one" := by
  library_search
#print axioms probe_2_417

-- ATTACK fc-379fc029-variants-factorial-add-one-6c719496c0-formalized-v1 aesop_search
theorem probe_2_418 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one" := by
  aesop?
#print axioms probe_2_418

-- ATTACK fc-379fc029-variants-factorial-add-one-6c719496c0-formalized-v1 simp_search
theorem probe_2_419 : fcTypeOfName% "Erdos936.erdos_936.variants.factorial_add_one" := by
  simp?
#print axioms probe_2_419

-- ATTACK fc-379fc029-parts-iii-9c28846a1d-formalized-v1 simp
theorem probe_2_420 : fcTypeOfName% "Erdos950.erdos_950.parts.iii" := by
  simp
#print axioms probe_2_420

-- ATTACK fc-379fc029-parts-iii-9c28846a1d-formalized-v1 simpa
theorem probe_2_421 : fcTypeOfName% "Erdos950.erdos_950.parts.iii" := by
  simpa
#print axioms probe_2_421

-- ATTACK fc-379fc029-parts-iii-9c28846a1d-formalized-v1 simp_all
theorem probe_2_422 : fcTypeOfName% "Erdos950.erdos_950.parts.iii" := by
  simp_all
#print axioms probe_2_422

-- ATTACK fc-379fc029-parts-iii-9c28846a1d-formalized-v1 aesop
theorem probe_2_423 : fcTypeOfName% "Erdos950.erdos_950.parts.iii" := by
  aesop
#print axioms probe_2_423

-- ATTACK fc-379fc029-parts-iii-9c28846a1d-formalized-v1 omega
theorem probe_2_424 : fcTypeOfName% "Erdos950.erdos_950.parts.iii" := by
  omega
#print axioms probe_2_424

-- ATTACK fc-379fc029-parts-iii-9c28846a1d-formalized-v1 norm_num
theorem probe_2_425 : fcTypeOfName% "Erdos950.erdos_950.parts.iii" := by
  norm_num
#print axioms probe_2_425

-- ATTACK fc-379fc029-parts-iii-9c28846a1d-formalized-v1 decide
theorem probe_2_426 : fcTypeOfName% "Erdos950.erdos_950.parts.iii" := by
  decide
#print axioms probe_2_426

-- ATTACK fc-379fc029-parts-iii-9c28846a1d-formalized-v1 native_decide
theorem probe_2_427 : fcTypeOfName% "Erdos950.erdos_950.parts.iii" := by
  native_decide
#print axioms probe_2_427

-- ATTACK fc-379fc029-parts-iii-9c28846a1d-formalized-v1 true_intro
theorem probe_2_428 : fcTypeOfName% "Erdos950.erdos_950.parts.iii" := by
  exact True.intro
#print axioms probe_2_428

-- ATTACK fc-379fc029-parts-iii-9c28846a1d-formalized-v1 false_elim_simp
theorem probe_2_429 : fcTypeOfName% "Erdos950.erdos_950.parts.iii" := by
  apply False.elim
  simp_all
#print axioms probe_2_429

-- ATTACK fc-379fc029-parts-iii-9c28846a1d-formalized-v1 constructor
theorem probe_2_430 : fcTypeOfName% "Erdos950.erdos_950.parts.iii" := by
  constructor
#print axioms probe_2_430

-- ATTACK fc-379fc029-parts-iii-9c28846a1d-formalized-v1 constructor_simp
theorem probe_2_431 : fcTypeOfName% "Erdos950.erdos_950.parts.iii" := by
  constructor <;> simp
#print axioms probe_2_431

-- ATTACK fc-379fc029-parts-iii-9c28846a1d-formalized-v1 constructor_aesop
theorem probe_2_432 : fcTypeOfName% "Erdos950.erdos_950.parts.iii" := by
  constructor <;> aesop
#print axioms probe_2_432

-- ATTACK fc-379fc029-parts-iii-9c28846a1d-formalized-v1 rfl
theorem probe_2_433 : fcTypeOfName% "Erdos950.erdos_950.parts.iii" := by
  rfl
#print axioms probe_2_433

-- ATTACK fc-379fc029-parts-iii-9c28846a1d-formalized-v1 trivial
theorem probe_2_434 : fcTypeOfName% "Erdos950.erdos_950.parts.iii" := by
  trivial
#print axioms probe_2_434

-- ATTACK fc-379fc029-parts-iii-9c28846a1d-formalized-v1 tauto
theorem probe_2_435 : fcTypeOfName% "Erdos950.erdos_950.parts.iii" := by
  tauto
#print axioms probe_2_435

-- ATTACK fc-379fc029-parts-iii-9c28846a1d-formalized-v1 positivity
theorem probe_2_436 : fcTypeOfName% "Erdos950.erdos_950.parts.iii" := by
  positivity
#print axioms probe_2_436

-- ATTACK fc-379fc029-parts-iii-9c28846a1d-formalized-v1 linarith
theorem probe_2_437 : fcTypeOfName% "Erdos950.erdos_950.parts.iii" := by
  linarith
#print axioms probe_2_437

-- ATTACK fc-379fc029-parts-iii-9c28846a1d-formalized-v1 nlinarith
theorem probe_2_438 : fcTypeOfName% "Erdos950.erdos_950.parts.iii" := by
  nlinarith
#print axioms probe_2_438

-- ATTACK fc-379fc029-parts-iii-9c28846a1d-formalized-v1 intros_simp_all
theorem probe_2_439 : fcTypeOfName% "Erdos950.erdos_950.parts.iii" := by
  intros
  simp_all
#print axioms probe_2_439

-- ATTACK fc-379fc029-parts-iii-9c28846a1d-formalized-v1 intros_omega
theorem probe_2_440 : fcTypeOfName% "Erdos950.erdos_950.parts.iii" := by
  intros
  omega
#print axioms probe_2_440

-- ATTACK fc-379fc029-parts-iii-9c28846a1d-formalized-v1 intros_norm_num
theorem probe_2_441 : fcTypeOfName% "Erdos950.erdos_950.parts.iii" := by
  intros
  norm_num at *
#print axioms probe_2_441

-- ATTACK fc-379fc029-parts-iii-9c28846a1d-formalized-v1 intros_aesop
theorem probe_2_442 : fcTypeOfName% "Erdos950.erdos_950.parts.iii" := by
  intros
  aesop
#print axioms probe_2_442

-- ATTACK fc-379fc029-parts-iii-9c28846a1d-formalized-v1 by_contra_simp_all
theorem probe_2_443 : fcTypeOfName% "Erdos950.erdos_950.parts.iii" := by
  by_contra h
  simp_all
#print axioms probe_2_443

-- ATTACK fc-379fc029-parts-iii-9c28846a1d-formalized-v1 classical_simp_all
theorem probe_2_444 : fcTypeOfName% "Erdos950.erdos_950.parts.iii" := by
  classical
  simp_all
#print axioms probe_2_444

-- ATTACK fc-379fc029-parts-iii-9c28846a1d-formalized-v1 classical_aesop
theorem probe_2_445 : fcTypeOfName% "Erdos950.erdos_950.parts.iii" := by
  classical
  aesop
#print axioms probe_2_445

-- ATTACK fc-379fc029-parts-iii-9c28846a1d-formalized-v1 refine_pair_simp
theorem probe_2_446 : fcTypeOfName% "Erdos950.erdos_950.parts.iii" := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_2_446

-- ATTACK fc-379fc029-parts-iii-9c28846a1d-formalized-v1 refine_pair_aesop
theorem probe_2_447 : fcTypeOfName% "Erdos950.erdos_950.parts.iii" := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_2_447

-- ATTACK fc-379fc029-parts-iii-9c28846a1d-formalized-v1 use_zero_simp
theorem probe_2_448 : fcTypeOfName% "Erdos950.erdos_950.parts.iii" := by
  use 0 <;> simp
#print axioms probe_2_448

-- ATTACK fc-379fc029-parts-iii-9c28846a1d-formalized-v1 use_one_simp
theorem probe_2_449 : fcTypeOfName% "Erdos950.erdos_950.parts.iii" := by
  use 1 <;> simp
#print axioms probe_2_449

-- ATTACK fc-379fc029-parts-iii-9c28846a1d-formalized-v1 use_empty_simp
theorem probe_2_450 : fcTypeOfName% "Erdos950.erdos_950.parts.iii" := by
  use ∅ <;> simp
#print axioms probe_2_450

-- ATTACK fc-379fc029-parts-iii-9c28846a1d-formalized-v1 assumption
theorem probe_2_451 : fcTypeOfName% "Erdos950.erdos_950.parts.iii" := by
  assumption
#print axioms probe_2_451

-- ATTACK fc-379fc029-parts-iii-9c28846a1d-formalized-v1 infer_instance
theorem probe_2_452 : fcTypeOfName% "Erdos950.erdos_950.parts.iii" := by
  infer_instance
#print axioms probe_2_452

-- ATTACK fc-379fc029-parts-iii-9c28846a1d-formalized-v1 contradiction
theorem probe_2_453 : fcTypeOfName% "Erdos950.erdos_950.parts.iii" := by
  contradiction
#print axioms probe_2_453

-- ATTACK fc-379fc029-parts-iii-9c28846a1d-formalized-v1 solve_by_elim
theorem probe_2_454 : fcTypeOfName% "Erdos950.erdos_950.parts.iii" := by
  solve_by_elim
#print axioms probe_2_454

-- ATTACK fc-379fc029-parts-iii-9c28846a1d-formalized-v1 first_order
theorem probe_2_455 : fcTypeOfName% "Erdos950.erdos_950.parts.iii" := by
  first_order
#print axioms probe_2_455

-- ATTACK fc-379fc029-parts-iii-9c28846a1d-formalized-v1 grind
theorem probe_2_456 : fcTypeOfName% "Erdos950.erdos_950.parts.iii" := by
  grind
#print axioms probe_2_456

-- ATTACK fc-379fc029-parts-iii-9c28846a1d-formalized-v1 exact_search
theorem probe_2_457 : fcTypeOfName% "Erdos950.erdos_950.parts.iii" := by
  exact?
#print axioms probe_2_457

-- ATTACK fc-379fc029-parts-iii-9c28846a1d-formalized-v1 apply_search
theorem probe_2_458 : fcTypeOfName% "Erdos950.erdos_950.parts.iii" := by
  apply?
#print axioms probe_2_458

-- ATTACK fc-379fc029-parts-iii-9c28846a1d-formalized-v1 library_search
theorem probe_2_459 : fcTypeOfName% "Erdos950.erdos_950.parts.iii" := by
  library_search
#print axioms probe_2_459

-- ATTACK fc-379fc029-parts-iii-9c28846a1d-formalized-v1 aesop_search
theorem probe_2_460 : fcTypeOfName% "Erdos950.erdos_950.parts.iii" := by
  aesop?
#print axioms probe_2_460

-- ATTACK fc-379fc029-parts-iii-9c28846a1d-formalized-v1 simp_search
theorem probe_2_461 : fcTypeOfName% "Erdos950.erdos_950.parts.iii" := by
  simp?
#print axioms probe_2_461

-- ATTACK fc-379fc029-variants-cks05-c2fe0b09f9-formalized-v1 simp
theorem probe_2_462 : fcTypeOfName% "Green36.green_36.variants.cks05" := by
  simp
#print axioms probe_2_462

-- ATTACK fc-379fc029-variants-cks05-c2fe0b09f9-formalized-v1 simpa
theorem probe_2_463 : fcTypeOfName% "Green36.green_36.variants.cks05" := by
  simpa
#print axioms probe_2_463

-- ATTACK fc-379fc029-variants-cks05-c2fe0b09f9-formalized-v1 simp_all
theorem probe_2_464 : fcTypeOfName% "Green36.green_36.variants.cks05" := by
  simp_all
#print axioms probe_2_464

-- ATTACK fc-379fc029-variants-cks05-c2fe0b09f9-formalized-v1 aesop
theorem probe_2_465 : fcTypeOfName% "Green36.green_36.variants.cks05" := by
  aesop
#print axioms probe_2_465

-- ATTACK fc-379fc029-variants-cks05-c2fe0b09f9-formalized-v1 omega
theorem probe_2_466 : fcTypeOfName% "Green36.green_36.variants.cks05" := by
  omega
#print axioms probe_2_466

-- ATTACK fc-379fc029-variants-cks05-c2fe0b09f9-formalized-v1 norm_num
theorem probe_2_467 : fcTypeOfName% "Green36.green_36.variants.cks05" := by
  norm_num
#print axioms probe_2_467

-- ATTACK fc-379fc029-variants-cks05-c2fe0b09f9-formalized-v1 decide
theorem probe_2_468 : fcTypeOfName% "Green36.green_36.variants.cks05" := by
  decide
#print axioms probe_2_468

-- ATTACK fc-379fc029-variants-cks05-c2fe0b09f9-formalized-v1 native_decide
theorem probe_2_469 : fcTypeOfName% "Green36.green_36.variants.cks05" := by
  native_decide
#print axioms probe_2_469

-- ATTACK fc-379fc029-variants-cks05-c2fe0b09f9-formalized-v1 true_intro
theorem probe_2_470 : fcTypeOfName% "Green36.green_36.variants.cks05" := by
  exact True.intro
#print axioms probe_2_470

-- ATTACK fc-379fc029-variants-cks05-c2fe0b09f9-formalized-v1 false_elim_simp
theorem probe_2_471 : fcTypeOfName% "Green36.green_36.variants.cks05" := by
  apply False.elim
  simp_all
#print axioms probe_2_471

-- ATTACK fc-379fc029-variants-cks05-c2fe0b09f9-formalized-v1 constructor
theorem probe_2_472 : fcTypeOfName% "Green36.green_36.variants.cks05" := by
  constructor
#print axioms probe_2_472

-- ATTACK fc-379fc029-variants-cks05-c2fe0b09f9-formalized-v1 constructor_simp
theorem probe_2_473 : fcTypeOfName% "Green36.green_36.variants.cks05" := by
  constructor <;> simp
#print axioms probe_2_473

-- ATTACK fc-379fc029-variants-cks05-c2fe0b09f9-formalized-v1 constructor_aesop
theorem probe_2_474 : fcTypeOfName% "Green36.green_36.variants.cks05" := by
  constructor <;> aesop
#print axioms probe_2_474

-- ATTACK fc-379fc029-variants-cks05-c2fe0b09f9-formalized-v1 rfl
theorem probe_2_475 : fcTypeOfName% "Green36.green_36.variants.cks05" := by
  rfl
#print axioms probe_2_475

-- ATTACK fc-379fc029-variants-cks05-c2fe0b09f9-formalized-v1 trivial
theorem probe_2_476 : fcTypeOfName% "Green36.green_36.variants.cks05" := by
  trivial
#print axioms probe_2_476

-- ATTACK fc-379fc029-variants-cks05-c2fe0b09f9-formalized-v1 tauto
theorem probe_2_477 : fcTypeOfName% "Green36.green_36.variants.cks05" := by
  tauto
#print axioms probe_2_477

-- ATTACK fc-379fc029-variants-cks05-c2fe0b09f9-formalized-v1 positivity
theorem probe_2_478 : fcTypeOfName% "Green36.green_36.variants.cks05" := by
  positivity
#print axioms probe_2_478

-- ATTACK fc-379fc029-variants-cks05-c2fe0b09f9-formalized-v1 linarith
theorem probe_2_479 : fcTypeOfName% "Green36.green_36.variants.cks05" := by
  linarith
#print axioms probe_2_479

-- ATTACK fc-379fc029-variants-cks05-c2fe0b09f9-formalized-v1 nlinarith
theorem probe_2_480 : fcTypeOfName% "Green36.green_36.variants.cks05" := by
  nlinarith
#print axioms probe_2_480

-- ATTACK fc-379fc029-variants-cks05-c2fe0b09f9-formalized-v1 intros_simp_all
theorem probe_2_481 : fcTypeOfName% "Green36.green_36.variants.cks05" := by
  intros
  simp_all
#print axioms probe_2_481

-- ATTACK fc-379fc029-variants-cks05-c2fe0b09f9-formalized-v1 intros_omega
theorem probe_2_482 : fcTypeOfName% "Green36.green_36.variants.cks05" := by
  intros
  omega
#print axioms probe_2_482

-- ATTACK fc-379fc029-variants-cks05-c2fe0b09f9-formalized-v1 intros_norm_num
theorem probe_2_483 : fcTypeOfName% "Green36.green_36.variants.cks05" := by
  intros
  norm_num at *
#print axioms probe_2_483

-- ATTACK fc-379fc029-variants-cks05-c2fe0b09f9-formalized-v1 intros_aesop
theorem probe_2_484 : fcTypeOfName% "Green36.green_36.variants.cks05" := by
  intros
  aesop
#print axioms probe_2_484

-- ATTACK fc-379fc029-variants-cks05-c2fe0b09f9-formalized-v1 by_contra_simp_all
theorem probe_2_485 : fcTypeOfName% "Green36.green_36.variants.cks05" := by
  by_contra h
  simp_all
#print axioms probe_2_485

-- ATTACK fc-379fc029-variants-cks05-c2fe0b09f9-formalized-v1 classical_simp_all
theorem probe_2_486 : fcTypeOfName% "Green36.green_36.variants.cks05" := by
  classical
  simp_all
#print axioms probe_2_486

-- ATTACK fc-379fc029-variants-cks05-c2fe0b09f9-formalized-v1 classical_aesop
theorem probe_2_487 : fcTypeOfName% "Green36.green_36.variants.cks05" := by
  classical
  aesop
#print axioms probe_2_487

-- ATTACK fc-379fc029-variants-cks05-c2fe0b09f9-formalized-v1 refine_pair_simp
theorem probe_2_488 : fcTypeOfName% "Green36.green_36.variants.cks05" := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_2_488

-- ATTACK fc-379fc029-variants-cks05-c2fe0b09f9-formalized-v1 refine_pair_aesop
theorem probe_2_489 : fcTypeOfName% "Green36.green_36.variants.cks05" := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_2_489

-- ATTACK fc-379fc029-variants-cks05-c2fe0b09f9-formalized-v1 use_zero_simp
theorem probe_2_490 : fcTypeOfName% "Green36.green_36.variants.cks05" := by
  use 0 <;> simp
#print axioms probe_2_490

-- ATTACK fc-379fc029-variants-cks05-c2fe0b09f9-formalized-v1 use_one_simp
theorem probe_2_491 : fcTypeOfName% "Green36.green_36.variants.cks05" := by
  use 1 <;> simp
#print axioms probe_2_491

-- ATTACK fc-379fc029-variants-cks05-c2fe0b09f9-formalized-v1 use_empty_simp
theorem probe_2_492 : fcTypeOfName% "Green36.green_36.variants.cks05" := by
  use ∅ <;> simp
#print axioms probe_2_492

-- ATTACK fc-379fc029-variants-cks05-c2fe0b09f9-formalized-v1 assumption
theorem probe_2_493 : fcTypeOfName% "Green36.green_36.variants.cks05" := by
  assumption
#print axioms probe_2_493

-- ATTACK fc-379fc029-variants-cks05-c2fe0b09f9-formalized-v1 infer_instance
theorem probe_2_494 : fcTypeOfName% "Green36.green_36.variants.cks05" := by
  infer_instance
#print axioms probe_2_494

-- ATTACK fc-379fc029-variants-cks05-c2fe0b09f9-formalized-v1 contradiction
theorem probe_2_495 : fcTypeOfName% "Green36.green_36.variants.cks05" := by
  contradiction
#print axioms probe_2_495

-- ATTACK fc-379fc029-variants-cks05-c2fe0b09f9-formalized-v1 solve_by_elim
theorem probe_2_496 : fcTypeOfName% "Green36.green_36.variants.cks05" := by
  solve_by_elim
#print axioms probe_2_496

-- ATTACK fc-379fc029-variants-cks05-c2fe0b09f9-formalized-v1 first_order
theorem probe_2_497 : fcTypeOfName% "Green36.green_36.variants.cks05" := by
  first_order
#print axioms probe_2_497

-- ATTACK fc-379fc029-variants-cks05-c2fe0b09f9-formalized-v1 grind
theorem probe_2_498 : fcTypeOfName% "Green36.green_36.variants.cks05" := by
  grind
#print axioms probe_2_498

-- ATTACK fc-379fc029-variants-cks05-c2fe0b09f9-formalized-v1 exact_search
theorem probe_2_499 : fcTypeOfName% "Green36.green_36.variants.cks05" := by
  exact?
#print axioms probe_2_499

-- ATTACK fc-379fc029-variants-cks05-c2fe0b09f9-formalized-v1 apply_search
theorem probe_2_500 : fcTypeOfName% "Green36.green_36.variants.cks05" := by
  apply?
#print axioms probe_2_500

-- ATTACK fc-379fc029-variants-cks05-c2fe0b09f9-formalized-v1 library_search
theorem probe_2_501 : fcTypeOfName% "Green36.green_36.variants.cks05" := by
  library_search
#print axioms probe_2_501

-- ATTACK fc-379fc029-variants-cks05-c2fe0b09f9-formalized-v1 aesop_search
theorem probe_2_502 : fcTypeOfName% "Green36.green_36.variants.cks05" := by
  aesop?
#print axioms probe_2_502

-- ATTACK fc-379fc029-variants-cks05-c2fe0b09f9-formalized-v1 simp_search
theorem probe_2_503 : fcTypeOfName% "Green36.green_36.variants.cks05" := by
  simp?
#print axioms probe_2_503

-- ATTACK fc-379fc029-green66-green-66-69595f6e77-formalized-v1 simp
theorem probe_2_504 : fcTypeOfName% "Green66.green_66" := by
  simp
#print axioms probe_2_504

-- ATTACK fc-379fc029-green66-green-66-69595f6e77-formalized-v1 simpa
theorem probe_2_505 : fcTypeOfName% "Green66.green_66" := by
  simpa
#print axioms probe_2_505

-- ATTACK fc-379fc029-green66-green-66-69595f6e77-formalized-v1 simp_all
theorem probe_2_506 : fcTypeOfName% "Green66.green_66" := by
  simp_all
#print axioms probe_2_506

-- ATTACK fc-379fc029-green66-green-66-69595f6e77-formalized-v1 aesop
theorem probe_2_507 : fcTypeOfName% "Green66.green_66" := by
  aesop
#print axioms probe_2_507

-- ATTACK fc-379fc029-green66-green-66-69595f6e77-formalized-v1 omega
theorem probe_2_508 : fcTypeOfName% "Green66.green_66" := by
  omega
#print axioms probe_2_508

-- ATTACK fc-379fc029-green66-green-66-69595f6e77-formalized-v1 norm_num
theorem probe_2_509 : fcTypeOfName% "Green66.green_66" := by
  norm_num
#print axioms probe_2_509

-- ATTACK fc-379fc029-green66-green-66-69595f6e77-formalized-v1 decide
theorem probe_2_510 : fcTypeOfName% "Green66.green_66" := by
  decide
#print axioms probe_2_510

-- ATTACK fc-379fc029-green66-green-66-69595f6e77-formalized-v1 native_decide
theorem probe_2_511 : fcTypeOfName% "Green66.green_66" := by
  native_decide
#print axioms probe_2_511

-- ATTACK fc-379fc029-green66-green-66-69595f6e77-formalized-v1 true_intro
theorem probe_2_512 : fcTypeOfName% "Green66.green_66" := by
  exact True.intro
#print axioms probe_2_512

-- ATTACK fc-379fc029-green66-green-66-69595f6e77-formalized-v1 false_elim_simp
theorem probe_2_513 : fcTypeOfName% "Green66.green_66" := by
  apply False.elim
  simp_all
#print axioms probe_2_513

-- ATTACK fc-379fc029-green66-green-66-69595f6e77-formalized-v1 constructor
theorem probe_2_514 : fcTypeOfName% "Green66.green_66" := by
  constructor
#print axioms probe_2_514

-- ATTACK fc-379fc029-green66-green-66-69595f6e77-formalized-v1 constructor_simp
theorem probe_2_515 : fcTypeOfName% "Green66.green_66" := by
  constructor <;> simp
#print axioms probe_2_515

-- ATTACK fc-379fc029-green66-green-66-69595f6e77-formalized-v1 constructor_aesop
theorem probe_2_516 : fcTypeOfName% "Green66.green_66" := by
  constructor <;> aesop
#print axioms probe_2_516

-- ATTACK fc-379fc029-green66-green-66-69595f6e77-formalized-v1 rfl
theorem probe_2_517 : fcTypeOfName% "Green66.green_66" := by
  rfl
#print axioms probe_2_517

-- ATTACK fc-379fc029-green66-green-66-69595f6e77-formalized-v1 trivial
theorem probe_2_518 : fcTypeOfName% "Green66.green_66" := by
  trivial
#print axioms probe_2_518

-- ATTACK fc-379fc029-green66-green-66-69595f6e77-formalized-v1 tauto
theorem probe_2_519 : fcTypeOfName% "Green66.green_66" := by
  tauto
#print axioms probe_2_519

-- ATTACK fc-379fc029-green66-green-66-69595f6e77-formalized-v1 positivity
theorem probe_2_520 : fcTypeOfName% "Green66.green_66" := by
  positivity
#print axioms probe_2_520

-- ATTACK fc-379fc029-green66-green-66-69595f6e77-formalized-v1 linarith
theorem probe_2_521 : fcTypeOfName% "Green66.green_66" := by
  linarith
#print axioms probe_2_521

-- ATTACK fc-379fc029-green66-green-66-69595f6e77-formalized-v1 nlinarith
theorem probe_2_522 : fcTypeOfName% "Green66.green_66" := by
  nlinarith
#print axioms probe_2_522

-- ATTACK fc-379fc029-green66-green-66-69595f6e77-formalized-v1 intros_simp_all
theorem probe_2_523 : fcTypeOfName% "Green66.green_66" := by
  intros
  simp_all
#print axioms probe_2_523

-- ATTACK fc-379fc029-green66-green-66-69595f6e77-formalized-v1 intros_omega
theorem probe_2_524 : fcTypeOfName% "Green66.green_66" := by
  intros
  omega
#print axioms probe_2_524

-- ATTACK fc-379fc029-green66-green-66-69595f6e77-formalized-v1 intros_norm_num
theorem probe_2_525 : fcTypeOfName% "Green66.green_66" := by
  intros
  norm_num at *
#print axioms probe_2_525

-- ATTACK fc-379fc029-green66-green-66-69595f6e77-formalized-v1 intros_aesop
theorem probe_2_526 : fcTypeOfName% "Green66.green_66" := by
  intros
  aesop
#print axioms probe_2_526

-- ATTACK fc-379fc029-green66-green-66-69595f6e77-formalized-v1 by_contra_simp_all
theorem probe_2_527 : fcTypeOfName% "Green66.green_66" := by
  by_contra h
  simp_all
#print axioms probe_2_527

-- ATTACK fc-379fc029-green66-green-66-69595f6e77-formalized-v1 classical_simp_all
theorem probe_2_528 : fcTypeOfName% "Green66.green_66" := by
  classical
  simp_all
#print axioms probe_2_528

-- ATTACK fc-379fc029-green66-green-66-69595f6e77-formalized-v1 classical_aesop
theorem probe_2_529 : fcTypeOfName% "Green66.green_66" := by
  classical
  aesop
#print axioms probe_2_529

-- ATTACK fc-379fc029-green66-green-66-69595f6e77-formalized-v1 refine_pair_simp
theorem probe_2_530 : fcTypeOfName% "Green66.green_66" := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_2_530

-- ATTACK fc-379fc029-green66-green-66-69595f6e77-formalized-v1 refine_pair_aesop
theorem probe_2_531 : fcTypeOfName% "Green66.green_66" := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_2_531

-- ATTACK fc-379fc029-green66-green-66-69595f6e77-formalized-v1 use_zero_simp
theorem probe_2_532 : fcTypeOfName% "Green66.green_66" := by
  use 0 <;> simp
#print axioms probe_2_532

-- ATTACK fc-379fc029-green66-green-66-69595f6e77-formalized-v1 use_one_simp
theorem probe_2_533 : fcTypeOfName% "Green66.green_66" := by
  use 1 <;> simp
#print axioms probe_2_533

-- ATTACK fc-379fc029-green66-green-66-69595f6e77-formalized-v1 use_empty_simp
theorem probe_2_534 : fcTypeOfName% "Green66.green_66" := by
  use ∅ <;> simp
#print axioms probe_2_534

-- ATTACK fc-379fc029-green66-green-66-69595f6e77-formalized-v1 assumption
theorem probe_2_535 : fcTypeOfName% "Green66.green_66" := by
  assumption
#print axioms probe_2_535

-- ATTACK fc-379fc029-green66-green-66-69595f6e77-formalized-v1 infer_instance
theorem probe_2_536 : fcTypeOfName% "Green66.green_66" := by
  infer_instance
#print axioms probe_2_536

-- ATTACK fc-379fc029-green66-green-66-69595f6e77-formalized-v1 contradiction
theorem probe_2_537 : fcTypeOfName% "Green66.green_66" := by
  contradiction
#print axioms probe_2_537

-- ATTACK fc-379fc029-green66-green-66-69595f6e77-formalized-v1 solve_by_elim
theorem probe_2_538 : fcTypeOfName% "Green66.green_66" := by
  solve_by_elim
#print axioms probe_2_538

-- ATTACK fc-379fc029-green66-green-66-69595f6e77-formalized-v1 first_order
theorem probe_2_539 : fcTypeOfName% "Green66.green_66" := by
  first_order
#print axioms probe_2_539

-- ATTACK fc-379fc029-green66-green-66-69595f6e77-formalized-v1 grind
theorem probe_2_540 : fcTypeOfName% "Green66.green_66" := by
  grind
#print axioms probe_2_540

-- ATTACK fc-379fc029-green66-green-66-69595f6e77-formalized-v1 exact_search
theorem probe_2_541 : fcTypeOfName% "Green66.green_66" := by
  exact?
#print axioms probe_2_541

-- ATTACK fc-379fc029-green66-green-66-69595f6e77-formalized-v1 apply_search
theorem probe_2_542 : fcTypeOfName% "Green66.green_66" := by
  apply?
#print axioms probe_2_542

-- ATTACK fc-379fc029-green66-green-66-69595f6e77-formalized-v1 library_search
theorem probe_2_543 : fcTypeOfName% "Green66.green_66" := by
  library_search
#print axioms probe_2_543

-- ATTACK fc-379fc029-green66-green-66-69595f6e77-formalized-v1 aesop_search
theorem probe_2_544 : fcTypeOfName% "Green66.green_66" := by
  aesop?
#print axioms probe_2_544

-- ATTACK fc-379fc029-green66-green-66-69595f6e77-formalized-v1 simp_search
theorem probe_2_545 : fcTypeOfName% "Green66.green_66" := by
  simp?
#print axioms probe_2_545

end AttackBattery
