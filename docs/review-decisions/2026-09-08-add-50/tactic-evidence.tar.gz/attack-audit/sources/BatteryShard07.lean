import FormalConjectures.ErdosProblems.«1101»
import FormalConjectures.ErdosProblems.«138»
import FormalConjectures.ErdosProblems.«25»
import FormalConjectures.ErdosProblems.«304»
import FormalConjectures.ErdosProblems.«323»
import FormalConjectures.ErdosProblems.«495»
import FormalConjectures.ErdosProblems.«681»
import FormalConjectures.ErdosProblems.«886»
import FormalConjectures.ErdosProblems.«933»
import FormalConjectures.ErdosProblems.«949»
import FormalConjectures.ErdosProblems.«98»
import FormalConjectures.GreensOpenProblems.«47»
import TaskSupport

set_option maxHeartbeats 20000
namespace AttackBattery

-- ATTACK fc-379fc029-parts-i-e0c9538a46-counterexample-v1 simp
theorem probe_7_0 : ¬ (fcTypeOfName% "Erdos1101.erdos_1101.parts.i") := by
  simp
#print axioms probe_7_0

-- ATTACK fc-379fc029-parts-i-e0c9538a46-counterexample-v1 simpa
theorem probe_7_1 : ¬ (fcTypeOfName% "Erdos1101.erdos_1101.parts.i") := by
  simpa
#print axioms probe_7_1

-- ATTACK fc-379fc029-parts-i-e0c9538a46-counterexample-v1 simp_all
theorem probe_7_2 : ¬ (fcTypeOfName% "Erdos1101.erdos_1101.parts.i") := by
  simp_all
#print axioms probe_7_2

-- ATTACK fc-379fc029-parts-i-e0c9538a46-counterexample-v1 aesop
theorem probe_7_3 : ¬ (fcTypeOfName% "Erdos1101.erdos_1101.parts.i") := by
  aesop
#print axioms probe_7_3

-- ATTACK fc-379fc029-parts-i-e0c9538a46-counterexample-v1 omega
theorem probe_7_4 : ¬ (fcTypeOfName% "Erdos1101.erdos_1101.parts.i") := by
  omega
#print axioms probe_7_4

-- ATTACK fc-379fc029-parts-i-e0c9538a46-counterexample-v1 norm_num
theorem probe_7_5 : ¬ (fcTypeOfName% "Erdos1101.erdos_1101.parts.i") := by
  norm_num
#print axioms probe_7_5

-- ATTACK fc-379fc029-parts-i-e0c9538a46-counterexample-v1 decide
theorem probe_7_6 : ¬ (fcTypeOfName% "Erdos1101.erdos_1101.parts.i") := by
  decide
#print axioms probe_7_6

-- ATTACK fc-379fc029-parts-i-e0c9538a46-counterexample-v1 native_decide
theorem probe_7_7 : ¬ (fcTypeOfName% "Erdos1101.erdos_1101.parts.i") := by
  native_decide
#print axioms probe_7_7

-- ATTACK fc-379fc029-parts-i-e0c9538a46-counterexample-v1 true_intro
theorem probe_7_8 : ¬ (fcTypeOfName% "Erdos1101.erdos_1101.parts.i") := by
  exact True.intro
#print axioms probe_7_8

-- ATTACK fc-379fc029-parts-i-e0c9538a46-counterexample-v1 false_elim_simp
theorem probe_7_9 : ¬ (fcTypeOfName% "Erdos1101.erdos_1101.parts.i") := by
  apply False.elim
  simp_all
#print axioms probe_7_9

-- ATTACK fc-379fc029-parts-i-e0c9538a46-counterexample-v1 constructor
theorem probe_7_10 : ¬ (fcTypeOfName% "Erdos1101.erdos_1101.parts.i") := by
  constructor
#print axioms probe_7_10

-- ATTACK fc-379fc029-parts-i-e0c9538a46-counterexample-v1 constructor_simp
theorem probe_7_11 : ¬ (fcTypeOfName% "Erdos1101.erdos_1101.parts.i") := by
  constructor <;> simp
#print axioms probe_7_11

-- ATTACK fc-379fc029-parts-i-e0c9538a46-counterexample-v1 constructor_aesop
theorem probe_7_12 : ¬ (fcTypeOfName% "Erdos1101.erdos_1101.parts.i") := by
  constructor <;> aesop
#print axioms probe_7_12

-- ATTACK fc-379fc029-parts-i-e0c9538a46-counterexample-v1 rfl
theorem probe_7_13 : ¬ (fcTypeOfName% "Erdos1101.erdos_1101.parts.i") := by
  rfl
#print axioms probe_7_13

-- ATTACK fc-379fc029-parts-i-e0c9538a46-counterexample-v1 trivial
theorem probe_7_14 : ¬ (fcTypeOfName% "Erdos1101.erdos_1101.parts.i") := by
  trivial
#print axioms probe_7_14

-- ATTACK fc-379fc029-parts-i-e0c9538a46-counterexample-v1 tauto
theorem probe_7_15 : ¬ (fcTypeOfName% "Erdos1101.erdos_1101.parts.i") := by
  tauto
#print axioms probe_7_15

-- ATTACK fc-379fc029-parts-i-e0c9538a46-counterexample-v1 positivity
theorem probe_7_16 : ¬ (fcTypeOfName% "Erdos1101.erdos_1101.parts.i") := by
  positivity
#print axioms probe_7_16

-- ATTACK fc-379fc029-parts-i-e0c9538a46-counterexample-v1 linarith
theorem probe_7_17 : ¬ (fcTypeOfName% "Erdos1101.erdos_1101.parts.i") := by
  linarith
#print axioms probe_7_17

-- ATTACK fc-379fc029-parts-i-e0c9538a46-counterexample-v1 nlinarith
theorem probe_7_18 : ¬ (fcTypeOfName% "Erdos1101.erdos_1101.parts.i") := by
  nlinarith
#print axioms probe_7_18

-- ATTACK fc-379fc029-parts-i-e0c9538a46-counterexample-v1 intros_simp_all
theorem probe_7_19 : ¬ (fcTypeOfName% "Erdos1101.erdos_1101.parts.i") := by
  intros
  simp_all
#print axioms probe_7_19

-- ATTACK fc-379fc029-parts-i-e0c9538a46-counterexample-v1 intros_omega
theorem probe_7_20 : ¬ (fcTypeOfName% "Erdos1101.erdos_1101.parts.i") := by
  intros
  omega
#print axioms probe_7_20

-- ATTACK fc-379fc029-parts-i-e0c9538a46-counterexample-v1 intros_norm_num
theorem probe_7_21 : ¬ (fcTypeOfName% "Erdos1101.erdos_1101.parts.i") := by
  intros
  norm_num at *
#print axioms probe_7_21

-- ATTACK fc-379fc029-parts-i-e0c9538a46-counterexample-v1 intros_aesop
theorem probe_7_22 : ¬ (fcTypeOfName% "Erdos1101.erdos_1101.parts.i") := by
  intros
  aesop
#print axioms probe_7_22

-- ATTACK fc-379fc029-parts-i-e0c9538a46-counterexample-v1 by_contra_simp_all
theorem probe_7_23 : ¬ (fcTypeOfName% "Erdos1101.erdos_1101.parts.i") := by
  by_contra h
  simp_all
#print axioms probe_7_23

-- ATTACK fc-379fc029-parts-i-e0c9538a46-counterexample-v1 classical_simp_all
theorem probe_7_24 : ¬ (fcTypeOfName% "Erdos1101.erdos_1101.parts.i") := by
  classical
  simp_all
#print axioms probe_7_24

-- ATTACK fc-379fc029-parts-i-e0c9538a46-counterexample-v1 classical_aesop
theorem probe_7_25 : ¬ (fcTypeOfName% "Erdos1101.erdos_1101.parts.i") := by
  classical
  aesop
#print axioms probe_7_25

-- ATTACK fc-379fc029-parts-i-e0c9538a46-counterexample-v1 refine_pair_simp
theorem probe_7_26 : ¬ (fcTypeOfName% "Erdos1101.erdos_1101.parts.i") := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_7_26

-- ATTACK fc-379fc029-parts-i-e0c9538a46-counterexample-v1 refine_pair_aesop
theorem probe_7_27 : ¬ (fcTypeOfName% "Erdos1101.erdos_1101.parts.i") := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_7_27

-- ATTACK fc-379fc029-parts-i-e0c9538a46-counterexample-v1 use_zero_simp
theorem probe_7_28 : ¬ (fcTypeOfName% "Erdos1101.erdos_1101.parts.i") := by
  use 0 <;> simp
#print axioms probe_7_28

-- ATTACK fc-379fc029-parts-i-e0c9538a46-counterexample-v1 use_one_simp
theorem probe_7_29 : ¬ (fcTypeOfName% "Erdos1101.erdos_1101.parts.i") := by
  use 1 <;> simp
#print axioms probe_7_29

-- ATTACK fc-379fc029-parts-i-e0c9538a46-counterexample-v1 use_empty_simp
theorem probe_7_30 : ¬ (fcTypeOfName% "Erdos1101.erdos_1101.parts.i") := by
  use ∅ <;> simp
#print axioms probe_7_30

-- ATTACK fc-379fc029-parts-i-e0c9538a46-counterexample-v1 assumption
theorem probe_7_31 : ¬ (fcTypeOfName% "Erdos1101.erdos_1101.parts.i") := by
  assumption
#print axioms probe_7_31

-- ATTACK fc-379fc029-parts-i-e0c9538a46-counterexample-v1 infer_instance
theorem probe_7_32 : ¬ (fcTypeOfName% "Erdos1101.erdos_1101.parts.i") := by
  infer_instance
#print axioms probe_7_32

-- ATTACK fc-379fc029-parts-i-e0c9538a46-counterexample-v1 contradiction
theorem probe_7_33 : ¬ (fcTypeOfName% "Erdos1101.erdos_1101.parts.i") := by
  contradiction
#print axioms probe_7_33

-- ATTACK fc-379fc029-parts-i-e0c9538a46-counterexample-v1 solve_by_elim
theorem probe_7_34 : ¬ (fcTypeOfName% "Erdos1101.erdos_1101.parts.i") := by
  solve_by_elim
#print axioms probe_7_34

-- ATTACK fc-379fc029-parts-i-e0c9538a46-counterexample-v1 first_order
theorem probe_7_35 : ¬ (fcTypeOfName% "Erdos1101.erdos_1101.parts.i") := by
  first_order
#print axioms probe_7_35

-- ATTACK fc-379fc029-parts-i-e0c9538a46-counterexample-v1 grind
theorem probe_7_36 : ¬ (fcTypeOfName% "Erdos1101.erdos_1101.parts.i") := by
  grind
#print axioms probe_7_36

-- ATTACK fc-379fc029-parts-i-e0c9538a46-counterexample-v1 exact_search
theorem probe_7_37 : ¬ (fcTypeOfName% "Erdos1101.erdos_1101.parts.i") := by
  exact?
#print axioms probe_7_37

-- ATTACK fc-379fc029-parts-i-e0c9538a46-counterexample-v1 apply_search
theorem probe_7_38 : ¬ (fcTypeOfName% "Erdos1101.erdos_1101.parts.i") := by
  apply?
#print axioms probe_7_38

-- ATTACK fc-379fc029-parts-i-e0c9538a46-counterexample-v1 library_search
theorem probe_7_39 : ¬ (fcTypeOfName% "Erdos1101.erdos_1101.parts.i") := by
  library_search
#print axioms probe_7_39

-- ATTACK fc-379fc029-parts-i-e0c9538a46-counterexample-v1 aesop_search
theorem probe_7_40 : ¬ (fcTypeOfName% "Erdos1101.erdos_1101.parts.i") := by
  aesop?
#print axioms probe_7_40

-- ATTACK fc-379fc029-parts-i-e0c9538a46-counterexample-v1 simp_search
theorem probe_7_41 : ¬ (fcTypeOfName% "Erdos1101.erdos_1101.parts.i") := by
  simp?
#print axioms probe_7_41

-- ATTACK fc-379fc029-erdos138-erdos-138-fb61145fce-counterexample-v1 simp
theorem probe_7_42 : ¬ (fcTypeOfName% "Erdos138.erdos_138") := by
  simp
#print axioms probe_7_42

-- ATTACK fc-379fc029-erdos138-erdos-138-fb61145fce-counterexample-v1 simpa
theorem probe_7_43 : ¬ (fcTypeOfName% "Erdos138.erdos_138") := by
  simpa
#print axioms probe_7_43

-- ATTACK fc-379fc029-erdos138-erdos-138-fb61145fce-counterexample-v1 simp_all
theorem probe_7_44 : ¬ (fcTypeOfName% "Erdos138.erdos_138") := by
  simp_all
#print axioms probe_7_44

-- ATTACK fc-379fc029-erdos138-erdos-138-fb61145fce-counterexample-v1 aesop
theorem probe_7_45 : ¬ (fcTypeOfName% "Erdos138.erdos_138") := by
  aesop
#print axioms probe_7_45

-- ATTACK fc-379fc029-erdos138-erdos-138-fb61145fce-counterexample-v1 omega
theorem probe_7_46 : ¬ (fcTypeOfName% "Erdos138.erdos_138") := by
  omega
#print axioms probe_7_46

-- ATTACK fc-379fc029-erdos138-erdos-138-fb61145fce-counterexample-v1 norm_num
theorem probe_7_47 : ¬ (fcTypeOfName% "Erdos138.erdos_138") := by
  norm_num
#print axioms probe_7_47

-- ATTACK fc-379fc029-erdos138-erdos-138-fb61145fce-counterexample-v1 decide
theorem probe_7_48 : ¬ (fcTypeOfName% "Erdos138.erdos_138") := by
  decide
#print axioms probe_7_48

-- ATTACK fc-379fc029-erdos138-erdos-138-fb61145fce-counterexample-v1 native_decide
theorem probe_7_49 : ¬ (fcTypeOfName% "Erdos138.erdos_138") := by
  native_decide
#print axioms probe_7_49

-- ATTACK fc-379fc029-erdos138-erdos-138-fb61145fce-counterexample-v1 true_intro
theorem probe_7_50 : ¬ (fcTypeOfName% "Erdos138.erdos_138") := by
  exact True.intro
#print axioms probe_7_50

-- ATTACK fc-379fc029-erdos138-erdos-138-fb61145fce-counterexample-v1 false_elim_simp
theorem probe_7_51 : ¬ (fcTypeOfName% "Erdos138.erdos_138") := by
  apply False.elim
  simp_all
#print axioms probe_7_51

-- ATTACK fc-379fc029-erdos138-erdos-138-fb61145fce-counterexample-v1 constructor
theorem probe_7_52 : ¬ (fcTypeOfName% "Erdos138.erdos_138") := by
  constructor
#print axioms probe_7_52

-- ATTACK fc-379fc029-erdos138-erdos-138-fb61145fce-counterexample-v1 constructor_simp
theorem probe_7_53 : ¬ (fcTypeOfName% "Erdos138.erdos_138") := by
  constructor <;> simp
#print axioms probe_7_53

-- ATTACK fc-379fc029-erdos138-erdos-138-fb61145fce-counterexample-v1 constructor_aesop
theorem probe_7_54 : ¬ (fcTypeOfName% "Erdos138.erdos_138") := by
  constructor <;> aesop
#print axioms probe_7_54

-- ATTACK fc-379fc029-erdos138-erdos-138-fb61145fce-counterexample-v1 rfl
theorem probe_7_55 : ¬ (fcTypeOfName% "Erdos138.erdos_138") := by
  rfl
#print axioms probe_7_55

-- ATTACK fc-379fc029-erdos138-erdos-138-fb61145fce-counterexample-v1 trivial
theorem probe_7_56 : ¬ (fcTypeOfName% "Erdos138.erdos_138") := by
  trivial
#print axioms probe_7_56

-- ATTACK fc-379fc029-erdos138-erdos-138-fb61145fce-counterexample-v1 tauto
theorem probe_7_57 : ¬ (fcTypeOfName% "Erdos138.erdos_138") := by
  tauto
#print axioms probe_7_57

-- ATTACK fc-379fc029-erdos138-erdos-138-fb61145fce-counterexample-v1 positivity
theorem probe_7_58 : ¬ (fcTypeOfName% "Erdos138.erdos_138") := by
  positivity
#print axioms probe_7_58

-- ATTACK fc-379fc029-erdos138-erdos-138-fb61145fce-counterexample-v1 linarith
theorem probe_7_59 : ¬ (fcTypeOfName% "Erdos138.erdos_138") := by
  linarith
#print axioms probe_7_59

-- ATTACK fc-379fc029-erdos138-erdos-138-fb61145fce-counterexample-v1 nlinarith
theorem probe_7_60 : ¬ (fcTypeOfName% "Erdos138.erdos_138") := by
  nlinarith
#print axioms probe_7_60

-- ATTACK fc-379fc029-erdos138-erdos-138-fb61145fce-counterexample-v1 intros_simp_all
theorem probe_7_61 : ¬ (fcTypeOfName% "Erdos138.erdos_138") := by
  intros
  simp_all
#print axioms probe_7_61

-- ATTACK fc-379fc029-erdos138-erdos-138-fb61145fce-counterexample-v1 intros_omega
theorem probe_7_62 : ¬ (fcTypeOfName% "Erdos138.erdos_138") := by
  intros
  omega
#print axioms probe_7_62

-- ATTACK fc-379fc029-erdos138-erdos-138-fb61145fce-counterexample-v1 intros_norm_num
theorem probe_7_63 : ¬ (fcTypeOfName% "Erdos138.erdos_138") := by
  intros
  norm_num at *
#print axioms probe_7_63

-- ATTACK fc-379fc029-erdos138-erdos-138-fb61145fce-counterexample-v1 intros_aesop
theorem probe_7_64 : ¬ (fcTypeOfName% "Erdos138.erdos_138") := by
  intros
  aesop
#print axioms probe_7_64

-- ATTACK fc-379fc029-erdos138-erdos-138-fb61145fce-counterexample-v1 by_contra_simp_all
theorem probe_7_65 : ¬ (fcTypeOfName% "Erdos138.erdos_138") := by
  by_contra h
  simp_all
#print axioms probe_7_65

-- ATTACK fc-379fc029-erdos138-erdos-138-fb61145fce-counterexample-v1 classical_simp_all
theorem probe_7_66 : ¬ (fcTypeOfName% "Erdos138.erdos_138") := by
  classical
  simp_all
#print axioms probe_7_66

-- ATTACK fc-379fc029-erdos138-erdos-138-fb61145fce-counterexample-v1 classical_aesop
theorem probe_7_67 : ¬ (fcTypeOfName% "Erdos138.erdos_138") := by
  classical
  aesop
#print axioms probe_7_67

-- ATTACK fc-379fc029-erdos138-erdos-138-fb61145fce-counterexample-v1 refine_pair_simp
theorem probe_7_68 : ¬ (fcTypeOfName% "Erdos138.erdos_138") := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_7_68

-- ATTACK fc-379fc029-erdos138-erdos-138-fb61145fce-counterexample-v1 refine_pair_aesop
theorem probe_7_69 : ¬ (fcTypeOfName% "Erdos138.erdos_138") := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_7_69

-- ATTACK fc-379fc029-erdos138-erdos-138-fb61145fce-counterexample-v1 use_zero_simp
theorem probe_7_70 : ¬ (fcTypeOfName% "Erdos138.erdos_138") := by
  use 0 <;> simp
#print axioms probe_7_70

-- ATTACK fc-379fc029-erdos138-erdos-138-fb61145fce-counterexample-v1 use_one_simp
theorem probe_7_71 : ¬ (fcTypeOfName% "Erdos138.erdos_138") := by
  use 1 <;> simp
#print axioms probe_7_71

-- ATTACK fc-379fc029-erdos138-erdos-138-fb61145fce-counterexample-v1 use_empty_simp
theorem probe_7_72 : ¬ (fcTypeOfName% "Erdos138.erdos_138") := by
  use ∅ <;> simp
#print axioms probe_7_72

-- ATTACK fc-379fc029-erdos138-erdos-138-fb61145fce-counterexample-v1 assumption
theorem probe_7_73 : ¬ (fcTypeOfName% "Erdos138.erdos_138") := by
  assumption
#print axioms probe_7_73

-- ATTACK fc-379fc029-erdos138-erdos-138-fb61145fce-counterexample-v1 infer_instance
theorem probe_7_74 : ¬ (fcTypeOfName% "Erdos138.erdos_138") := by
  infer_instance
#print axioms probe_7_74

-- ATTACK fc-379fc029-erdos138-erdos-138-fb61145fce-counterexample-v1 contradiction
theorem probe_7_75 : ¬ (fcTypeOfName% "Erdos138.erdos_138") := by
  contradiction
#print axioms probe_7_75

-- ATTACK fc-379fc029-erdos138-erdos-138-fb61145fce-counterexample-v1 solve_by_elim
theorem probe_7_76 : ¬ (fcTypeOfName% "Erdos138.erdos_138") := by
  solve_by_elim
#print axioms probe_7_76

-- ATTACK fc-379fc029-erdos138-erdos-138-fb61145fce-counterexample-v1 first_order
theorem probe_7_77 : ¬ (fcTypeOfName% "Erdos138.erdos_138") := by
  first_order
#print axioms probe_7_77

-- ATTACK fc-379fc029-erdos138-erdos-138-fb61145fce-counterexample-v1 grind
theorem probe_7_78 : ¬ (fcTypeOfName% "Erdos138.erdos_138") := by
  grind
#print axioms probe_7_78

-- ATTACK fc-379fc029-erdos138-erdos-138-fb61145fce-counterexample-v1 exact_search
theorem probe_7_79 : ¬ (fcTypeOfName% "Erdos138.erdos_138") := by
  exact?
#print axioms probe_7_79

-- ATTACK fc-379fc029-erdos138-erdos-138-fb61145fce-counterexample-v1 apply_search
theorem probe_7_80 : ¬ (fcTypeOfName% "Erdos138.erdos_138") := by
  apply?
#print axioms probe_7_80

-- ATTACK fc-379fc029-erdos138-erdos-138-fb61145fce-counterexample-v1 library_search
theorem probe_7_81 : ¬ (fcTypeOfName% "Erdos138.erdos_138") := by
  library_search
#print axioms probe_7_81

-- ATTACK fc-379fc029-erdos138-erdos-138-fb61145fce-counterexample-v1 aesop_search
theorem probe_7_82 : ¬ (fcTypeOfName% "Erdos138.erdos_138") := by
  aesop?
#print axioms probe_7_82

-- ATTACK fc-379fc029-erdos138-erdos-138-fb61145fce-counterexample-v1 simp_search
theorem probe_7_83 : ¬ (fcTypeOfName% "Erdos138.erdos_138") := by
  simp?
#print axioms probe_7_83

-- ATTACK fc-379fc029-erdos25-erdos-25-787baeea83-counterexample-v1 simp
theorem probe_7_84 : ¬ (fcTypeOfName% "Erdos25.erdos_25") := by
  simp
#print axioms probe_7_84

-- ATTACK fc-379fc029-erdos25-erdos-25-787baeea83-counterexample-v1 simpa
theorem probe_7_85 : ¬ (fcTypeOfName% "Erdos25.erdos_25") := by
  simpa
#print axioms probe_7_85

-- ATTACK fc-379fc029-erdos25-erdos-25-787baeea83-counterexample-v1 simp_all
theorem probe_7_86 : ¬ (fcTypeOfName% "Erdos25.erdos_25") := by
  simp_all
#print axioms probe_7_86

-- ATTACK fc-379fc029-erdos25-erdos-25-787baeea83-counterexample-v1 aesop
theorem probe_7_87 : ¬ (fcTypeOfName% "Erdos25.erdos_25") := by
  aesop
#print axioms probe_7_87

-- ATTACK fc-379fc029-erdos25-erdos-25-787baeea83-counterexample-v1 omega
theorem probe_7_88 : ¬ (fcTypeOfName% "Erdos25.erdos_25") := by
  omega
#print axioms probe_7_88

-- ATTACK fc-379fc029-erdos25-erdos-25-787baeea83-counterexample-v1 norm_num
theorem probe_7_89 : ¬ (fcTypeOfName% "Erdos25.erdos_25") := by
  norm_num
#print axioms probe_7_89

-- ATTACK fc-379fc029-erdos25-erdos-25-787baeea83-counterexample-v1 decide
theorem probe_7_90 : ¬ (fcTypeOfName% "Erdos25.erdos_25") := by
  decide
#print axioms probe_7_90

-- ATTACK fc-379fc029-erdos25-erdos-25-787baeea83-counterexample-v1 native_decide
theorem probe_7_91 : ¬ (fcTypeOfName% "Erdos25.erdos_25") := by
  native_decide
#print axioms probe_7_91

-- ATTACK fc-379fc029-erdos25-erdos-25-787baeea83-counterexample-v1 true_intro
theorem probe_7_92 : ¬ (fcTypeOfName% "Erdos25.erdos_25") := by
  exact True.intro
#print axioms probe_7_92

-- ATTACK fc-379fc029-erdos25-erdos-25-787baeea83-counterexample-v1 false_elim_simp
theorem probe_7_93 : ¬ (fcTypeOfName% "Erdos25.erdos_25") := by
  apply False.elim
  simp_all
#print axioms probe_7_93

-- ATTACK fc-379fc029-erdos25-erdos-25-787baeea83-counterexample-v1 constructor
theorem probe_7_94 : ¬ (fcTypeOfName% "Erdos25.erdos_25") := by
  constructor
#print axioms probe_7_94

-- ATTACK fc-379fc029-erdos25-erdos-25-787baeea83-counterexample-v1 constructor_simp
theorem probe_7_95 : ¬ (fcTypeOfName% "Erdos25.erdos_25") := by
  constructor <;> simp
#print axioms probe_7_95

-- ATTACK fc-379fc029-erdos25-erdos-25-787baeea83-counterexample-v1 constructor_aesop
theorem probe_7_96 : ¬ (fcTypeOfName% "Erdos25.erdos_25") := by
  constructor <;> aesop
#print axioms probe_7_96

-- ATTACK fc-379fc029-erdos25-erdos-25-787baeea83-counterexample-v1 rfl
theorem probe_7_97 : ¬ (fcTypeOfName% "Erdos25.erdos_25") := by
  rfl
#print axioms probe_7_97

-- ATTACK fc-379fc029-erdos25-erdos-25-787baeea83-counterexample-v1 trivial
theorem probe_7_98 : ¬ (fcTypeOfName% "Erdos25.erdos_25") := by
  trivial
#print axioms probe_7_98

-- ATTACK fc-379fc029-erdos25-erdos-25-787baeea83-counterexample-v1 tauto
theorem probe_7_99 : ¬ (fcTypeOfName% "Erdos25.erdos_25") := by
  tauto
#print axioms probe_7_99

-- ATTACK fc-379fc029-erdos25-erdos-25-787baeea83-counterexample-v1 positivity
theorem probe_7_100 : ¬ (fcTypeOfName% "Erdos25.erdos_25") := by
  positivity
#print axioms probe_7_100

-- ATTACK fc-379fc029-erdos25-erdos-25-787baeea83-counterexample-v1 linarith
theorem probe_7_101 : ¬ (fcTypeOfName% "Erdos25.erdos_25") := by
  linarith
#print axioms probe_7_101

-- ATTACK fc-379fc029-erdos25-erdos-25-787baeea83-counterexample-v1 nlinarith
theorem probe_7_102 : ¬ (fcTypeOfName% "Erdos25.erdos_25") := by
  nlinarith
#print axioms probe_7_102

-- ATTACK fc-379fc029-erdos25-erdos-25-787baeea83-counterexample-v1 intros_simp_all
theorem probe_7_103 : ¬ (fcTypeOfName% "Erdos25.erdos_25") := by
  intros
  simp_all
#print axioms probe_7_103

-- ATTACK fc-379fc029-erdos25-erdos-25-787baeea83-counterexample-v1 intros_omega
theorem probe_7_104 : ¬ (fcTypeOfName% "Erdos25.erdos_25") := by
  intros
  omega
#print axioms probe_7_104

-- ATTACK fc-379fc029-erdos25-erdos-25-787baeea83-counterexample-v1 intros_norm_num
theorem probe_7_105 : ¬ (fcTypeOfName% "Erdos25.erdos_25") := by
  intros
  norm_num at *
#print axioms probe_7_105

-- ATTACK fc-379fc029-erdos25-erdos-25-787baeea83-counterexample-v1 intros_aesop
theorem probe_7_106 : ¬ (fcTypeOfName% "Erdos25.erdos_25") := by
  intros
  aesop
#print axioms probe_7_106

-- ATTACK fc-379fc029-erdos25-erdos-25-787baeea83-counterexample-v1 by_contra_simp_all
theorem probe_7_107 : ¬ (fcTypeOfName% "Erdos25.erdos_25") := by
  by_contra h
  simp_all
#print axioms probe_7_107

-- ATTACK fc-379fc029-erdos25-erdos-25-787baeea83-counterexample-v1 classical_simp_all
theorem probe_7_108 : ¬ (fcTypeOfName% "Erdos25.erdos_25") := by
  classical
  simp_all
#print axioms probe_7_108

-- ATTACK fc-379fc029-erdos25-erdos-25-787baeea83-counterexample-v1 classical_aesop
theorem probe_7_109 : ¬ (fcTypeOfName% "Erdos25.erdos_25") := by
  classical
  aesop
#print axioms probe_7_109

-- ATTACK fc-379fc029-erdos25-erdos-25-787baeea83-counterexample-v1 refine_pair_simp
theorem probe_7_110 : ¬ (fcTypeOfName% "Erdos25.erdos_25") := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_7_110

-- ATTACK fc-379fc029-erdos25-erdos-25-787baeea83-counterexample-v1 refine_pair_aesop
theorem probe_7_111 : ¬ (fcTypeOfName% "Erdos25.erdos_25") := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_7_111

-- ATTACK fc-379fc029-erdos25-erdos-25-787baeea83-counterexample-v1 use_zero_simp
theorem probe_7_112 : ¬ (fcTypeOfName% "Erdos25.erdos_25") := by
  use 0 <;> simp
#print axioms probe_7_112

-- ATTACK fc-379fc029-erdos25-erdos-25-787baeea83-counterexample-v1 use_one_simp
theorem probe_7_113 : ¬ (fcTypeOfName% "Erdos25.erdos_25") := by
  use 1 <;> simp
#print axioms probe_7_113

-- ATTACK fc-379fc029-erdos25-erdos-25-787baeea83-counterexample-v1 use_empty_simp
theorem probe_7_114 : ¬ (fcTypeOfName% "Erdos25.erdos_25") := by
  use ∅ <;> simp
#print axioms probe_7_114

-- ATTACK fc-379fc029-erdos25-erdos-25-787baeea83-counterexample-v1 assumption
theorem probe_7_115 : ¬ (fcTypeOfName% "Erdos25.erdos_25") := by
  assumption
#print axioms probe_7_115

-- ATTACK fc-379fc029-erdos25-erdos-25-787baeea83-counterexample-v1 infer_instance
theorem probe_7_116 : ¬ (fcTypeOfName% "Erdos25.erdos_25") := by
  infer_instance
#print axioms probe_7_116

-- ATTACK fc-379fc029-erdos25-erdos-25-787baeea83-counterexample-v1 contradiction
theorem probe_7_117 : ¬ (fcTypeOfName% "Erdos25.erdos_25") := by
  contradiction
#print axioms probe_7_117

-- ATTACK fc-379fc029-erdos25-erdos-25-787baeea83-counterexample-v1 solve_by_elim
theorem probe_7_118 : ¬ (fcTypeOfName% "Erdos25.erdos_25") := by
  solve_by_elim
#print axioms probe_7_118

-- ATTACK fc-379fc029-erdos25-erdos-25-787baeea83-counterexample-v1 first_order
theorem probe_7_119 : ¬ (fcTypeOfName% "Erdos25.erdos_25") := by
  first_order
#print axioms probe_7_119

-- ATTACK fc-379fc029-erdos25-erdos-25-787baeea83-counterexample-v1 grind
theorem probe_7_120 : ¬ (fcTypeOfName% "Erdos25.erdos_25") := by
  grind
#print axioms probe_7_120

-- ATTACK fc-379fc029-erdos25-erdos-25-787baeea83-counterexample-v1 exact_search
theorem probe_7_121 : ¬ (fcTypeOfName% "Erdos25.erdos_25") := by
  exact?
#print axioms probe_7_121

-- ATTACK fc-379fc029-erdos25-erdos-25-787baeea83-counterexample-v1 apply_search
theorem probe_7_122 : ¬ (fcTypeOfName% "Erdos25.erdos_25") := by
  apply?
#print axioms probe_7_122

-- ATTACK fc-379fc029-erdos25-erdos-25-787baeea83-counterexample-v1 library_search
theorem probe_7_123 : ¬ (fcTypeOfName% "Erdos25.erdos_25") := by
  library_search
#print axioms probe_7_123

-- ATTACK fc-379fc029-erdos25-erdos-25-787baeea83-counterexample-v1 aesop_search
theorem probe_7_124 : ¬ (fcTypeOfName% "Erdos25.erdos_25") := by
  aesop?
#print axioms probe_7_124

-- ATTACK fc-379fc029-erdos25-erdos-25-787baeea83-counterexample-v1 simp_search
theorem probe_7_125 : ¬ (fcTypeOfName% "Erdos25.erdos_25") := by
  simp?
#print axioms probe_7_125

-- ATTACK fc-379fc029-erdos304-upper-bound-f118563f2b-counterexample-v1 simp
theorem probe_7_126 : ¬ (fcTypeOfName% "Erdos304.upper_bound") := by
  simp
#print axioms probe_7_126

-- ATTACK fc-379fc029-erdos304-upper-bound-f118563f2b-counterexample-v1 simpa
theorem probe_7_127 : ¬ (fcTypeOfName% "Erdos304.upper_bound") := by
  simpa
#print axioms probe_7_127

-- ATTACK fc-379fc029-erdos304-upper-bound-f118563f2b-counterexample-v1 simp_all
theorem probe_7_128 : ¬ (fcTypeOfName% "Erdos304.upper_bound") := by
  simp_all
#print axioms probe_7_128

-- ATTACK fc-379fc029-erdos304-upper-bound-f118563f2b-counterexample-v1 aesop
theorem probe_7_129 : ¬ (fcTypeOfName% "Erdos304.upper_bound") := by
  aesop
#print axioms probe_7_129

-- ATTACK fc-379fc029-erdos304-upper-bound-f118563f2b-counterexample-v1 omega
theorem probe_7_130 : ¬ (fcTypeOfName% "Erdos304.upper_bound") := by
  omega
#print axioms probe_7_130

-- ATTACK fc-379fc029-erdos304-upper-bound-f118563f2b-counterexample-v1 norm_num
theorem probe_7_131 : ¬ (fcTypeOfName% "Erdos304.upper_bound") := by
  norm_num
#print axioms probe_7_131

-- ATTACK fc-379fc029-erdos304-upper-bound-f118563f2b-counterexample-v1 decide
theorem probe_7_132 : ¬ (fcTypeOfName% "Erdos304.upper_bound") := by
  decide
#print axioms probe_7_132

-- ATTACK fc-379fc029-erdos304-upper-bound-f118563f2b-counterexample-v1 native_decide
theorem probe_7_133 : ¬ (fcTypeOfName% "Erdos304.upper_bound") := by
  native_decide
#print axioms probe_7_133

-- ATTACK fc-379fc029-erdos304-upper-bound-f118563f2b-counterexample-v1 true_intro
theorem probe_7_134 : ¬ (fcTypeOfName% "Erdos304.upper_bound") := by
  exact True.intro
#print axioms probe_7_134

-- ATTACK fc-379fc029-erdos304-upper-bound-f118563f2b-counterexample-v1 false_elim_simp
theorem probe_7_135 : ¬ (fcTypeOfName% "Erdos304.upper_bound") := by
  apply False.elim
  simp_all
#print axioms probe_7_135

-- ATTACK fc-379fc029-erdos304-upper-bound-f118563f2b-counterexample-v1 constructor
theorem probe_7_136 : ¬ (fcTypeOfName% "Erdos304.upper_bound") := by
  constructor
#print axioms probe_7_136

-- ATTACK fc-379fc029-erdos304-upper-bound-f118563f2b-counterexample-v1 constructor_simp
theorem probe_7_137 : ¬ (fcTypeOfName% "Erdos304.upper_bound") := by
  constructor <;> simp
#print axioms probe_7_137

-- ATTACK fc-379fc029-erdos304-upper-bound-f118563f2b-counterexample-v1 constructor_aesop
theorem probe_7_138 : ¬ (fcTypeOfName% "Erdos304.upper_bound") := by
  constructor <;> aesop
#print axioms probe_7_138

-- ATTACK fc-379fc029-erdos304-upper-bound-f118563f2b-counterexample-v1 rfl
theorem probe_7_139 : ¬ (fcTypeOfName% "Erdos304.upper_bound") := by
  rfl
#print axioms probe_7_139

-- ATTACK fc-379fc029-erdos304-upper-bound-f118563f2b-counterexample-v1 trivial
theorem probe_7_140 : ¬ (fcTypeOfName% "Erdos304.upper_bound") := by
  trivial
#print axioms probe_7_140

-- ATTACK fc-379fc029-erdos304-upper-bound-f118563f2b-counterexample-v1 tauto
theorem probe_7_141 : ¬ (fcTypeOfName% "Erdos304.upper_bound") := by
  tauto
#print axioms probe_7_141

-- ATTACK fc-379fc029-erdos304-upper-bound-f118563f2b-counterexample-v1 positivity
theorem probe_7_142 : ¬ (fcTypeOfName% "Erdos304.upper_bound") := by
  positivity
#print axioms probe_7_142

-- ATTACK fc-379fc029-erdos304-upper-bound-f118563f2b-counterexample-v1 linarith
theorem probe_7_143 : ¬ (fcTypeOfName% "Erdos304.upper_bound") := by
  linarith
#print axioms probe_7_143

-- ATTACK fc-379fc029-erdos304-upper-bound-f118563f2b-counterexample-v1 nlinarith
theorem probe_7_144 : ¬ (fcTypeOfName% "Erdos304.upper_bound") := by
  nlinarith
#print axioms probe_7_144

-- ATTACK fc-379fc029-erdos304-upper-bound-f118563f2b-counterexample-v1 intros_simp_all
theorem probe_7_145 : ¬ (fcTypeOfName% "Erdos304.upper_bound") := by
  intros
  simp_all
#print axioms probe_7_145

-- ATTACK fc-379fc029-erdos304-upper-bound-f118563f2b-counterexample-v1 intros_omega
theorem probe_7_146 : ¬ (fcTypeOfName% "Erdos304.upper_bound") := by
  intros
  omega
#print axioms probe_7_146

-- ATTACK fc-379fc029-erdos304-upper-bound-f118563f2b-counterexample-v1 intros_norm_num
theorem probe_7_147 : ¬ (fcTypeOfName% "Erdos304.upper_bound") := by
  intros
  norm_num at *
#print axioms probe_7_147

-- ATTACK fc-379fc029-erdos304-upper-bound-f118563f2b-counterexample-v1 intros_aesop
theorem probe_7_148 : ¬ (fcTypeOfName% "Erdos304.upper_bound") := by
  intros
  aesop
#print axioms probe_7_148

-- ATTACK fc-379fc029-erdos304-upper-bound-f118563f2b-counterexample-v1 by_contra_simp_all
theorem probe_7_149 : ¬ (fcTypeOfName% "Erdos304.upper_bound") := by
  by_contra h
  simp_all
#print axioms probe_7_149

-- ATTACK fc-379fc029-erdos304-upper-bound-f118563f2b-counterexample-v1 classical_simp_all
theorem probe_7_150 : ¬ (fcTypeOfName% "Erdos304.upper_bound") := by
  classical
  simp_all
#print axioms probe_7_150

-- ATTACK fc-379fc029-erdos304-upper-bound-f118563f2b-counterexample-v1 classical_aesop
theorem probe_7_151 : ¬ (fcTypeOfName% "Erdos304.upper_bound") := by
  classical
  aesop
#print axioms probe_7_151

-- ATTACK fc-379fc029-erdos304-upper-bound-f118563f2b-counterexample-v1 refine_pair_simp
theorem probe_7_152 : ¬ (fcTypeOfName% "Erdos304.upper_bound") := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_7_152

-- ATTACK fc-379fc029-erdos304-upper-bound-f118563f2b-counterexample-v1 refine_pair_aesop
theorem probe_7_153 : ¬ (fcTypeOfName% "Erdos304.upper_bound") := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_7_153

-- ATTACK fc-379fc029-erdos304-upper-bound-f118563f2b-counterexample-v1 use_zero_simp
theorem probe_7_154 : ¬ (fcTypeOfName% "Erdos304.upper_bound") := by
  use 0 <;> simp
#print axioms probe_7_154

-- ATTACK fc-379fc029-erdos304-upper-bound-f118563f2b-counterexample-v1 use_one_simp
theorem probe_7_155 : ¬ (fcTypeOfName% "Erdos304.upper_bound") := by
  use 1 <;> simp
#print axioms probe_7_155

-- ATTACK fc-379fc029-erdos304-upper-bound-f118563f2b-counterexample-v1 use_empty_simp
theorem probe_7_156 : ¬ (fcTypeOfName% "Erdos304.upper_bound") := by
  use ∅ <;> simp
#print axioms probe_7_156

-- ATTACK fc-379fc029-erdos304-upper-bound-f118563f2b-counterexample-v1 assumption
theorem probe_7_157 : ¬ (fcTypeOfName% "Erdos304.upper_bound") := by
  assumption
#print axioms probe_7_157

-- ATTACK fc-379fc029-erdos304-upper-bound-f118563f2b-counterexample-v1 infer_instance
theorem probe_7_158 : ¬ (fcTypeOfName% "Erdos304.upper_bound") := by
  infer_instance
#print axioms probe_7_158

-- ATTACK fc-379fc029-erdos304-upper-bound-f118563f2b-counterexample-v1 contradiction
theorem probe_7_159 : ¬ (fcTypeOfName% "Erdos304.upper_bound") := by
  contradiction
#print axioms probe_7_159

-- ATTACK fc-379fc029-erdos304-upper-bound-f118563f2b-counterexample-v1 solve_by_elim
theorem probe_7_160 : ¬ (fcTypeOfName% "Erdos304.upper_bound") := by
  solve_by_elim
#print axioms probe_7_160

-- ATTACK fc-379fc029-erdos304-upper-bound-f118563f2b-counterexample-v1 first_order
theorem probe_7_161 : ¬ (fcTypeOfName% "Erdos304.upper_bound") := by
  first_order
#print axioms probe_7_161

-- ATTACK fc-379fc029-erdos304-upper-bound-f118563f2b-counterexample-v1 grind
theorem probe_7_162 : ¬ (fcTypeOfName% "Erdos304.upper_bound") := by
  grind
#print axioms probe_7_162

-- ATTACK fc-379fc029-erdos304-upper-bound-f118563f2b-counterexample-v1 exact_search
theorem probe_7_163 : ¬ (fcTypeOfName% "Erdos304.upper_bound") := by
  exact?
#print axioms probe_7_163

-- ATTACK fc-379fc029-erdos304-upper-bound-f118563f2b-counterexample-v1 apply_search
theorem probe_7_164 : ¬ (fcTypeOfName% "Erdos304.upper_bound") := by
  apply?
#print axioms probe_7_164

-- ATTACK fc-379fc029-erdos304-upper-bound-f118563f2b-counterexample-v1 library_search
theorem probe_7_165 : ¬ (fcTypeOfName% "Erdos304.upper_bound") := by
  library_search
#print axioms probe_7_165

-- ATTACK fc-379fc029-erdos304-upper-bound-f118563f2b-counterexample-v1 aesop_search
theorem probe_7_166 : ¬ (fcTypeOfName% "Erdos304.upper_bound") := by
  aesop?
#print axioms probe_7_166

-- ATTACK fc-379fc029-erdos304-upper-bound-f118563f2b-counterexample-v1 simp_search
theorem probe_7_167 : ¬ (fcTypeOfName% "Erdos304.upper_bound") := by
  simp?
#print axioms probe_7_167

-- ATTACK fc-379fc029-parts-ii-920d701aab-counterexample-v1 simp
theorem probe_7_168 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.ii") := by
  simp
#print axioms probe_7_168

-- ATTACK fc-379fc029-parts-ii-920d701aab-counterexample-v1 simpa
theorem probe_7_169 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.ii") := by
  simpa
#print axioms probe_7_169

-- ATTACK fc-379fc029-parts-ii-920d701aab-counterexample-v1 simp_all
theorem probe_7_170 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.ii") := by
  simp_all
#print axioms probe_7_170

-- ATTACK fc-379fc029-parts-ii-920d701aab-counterexample-v1 aesop
theorem probe_7_171 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.ii") := by
  aesop
#print axioms probe_7_171

-- ATTACK fc-379fc029-parts-ii-920d701aab-counterexample-v1 omega
theorem probe_7_172 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.ii") := by
  omega
#print axioms probe_7_172

-- ATTACK fc-379fc029-parts-ii-920d701aab-counterexample-v1 norm_num
theorem probe_7_173 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.ii") := by
  norm_num
#print axioms probe_7_173

-- ATTACK fc-379fc029-parts-ii-920d701aab-counterexample-v1 decide
theorem probe_7_174 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.ii") := by
  decide
#print axioms probe_7_174

-- ATTACK fc-379fc029-parts-ii-920d701aab-counterexample-v1 native_decide
theorem probe_7_175 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.ii") := by
  native_decide
#print axioms probe_7_175

-- ATTACK fc-379fc029-parts-ii-920d701aab-counterexample-v1 true_intro
theorem probe_7_176 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.ii") := by
  exact True.intro
#print axioms probe_7_176

-- ATTACK fc-379fc029-parts-ii-920d701aab-counterexample-v1 false_elim_simp
theorem probe_7_177 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.ii") := by
  apply False.elim
  simp_all
#print axioms probe_7_177

-- ATTACK fc-379fc029-parts-ii-920d701aab-counterexample-v1 constructor
theorem probe_7_178 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.ii") := by
  constructor
#print axioms probe_7_178

-- ATTACK fc-379fc029-parts-ii-920d701aab-counterexample-v1 constructor_simp
theorem probe_7_179 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.ii") := by
  constructor <;> simp
#print axioms probe_7_179

-- ATTACK fc-379fc029-parts-ii-920d701aab-counterexample-v1 constructor_aesop
theorem probe_7_180 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.ii") := by
  constructor <;> aesop
#print axioms probe_7_180

-- ATTACK fc-379fc029-parts-ii-920d701aab-counterexample-v1 rfl
theorem probe_7_181 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.ii") := by
  rfl
#print axioms probe_7_181

-- ATTACK fc-379fc029-parts-ii-920d701aab-counterexample-v1 trivial
theorem probe_7_182 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.ii") := by
  trivial
#print axioms probe_7_182

-- ATTACK fc-379fc029-parts-ii-920d701aab-counterexample-v1 tauto
theorem probe_7_183 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.ii") := by
  tauto
#print axioms probe_7_183

-- ATTACK fc-379fc029-parts-ii-920d701aab-counterexample-v1 positivity
theorem probe_7_184 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.ii") := by
  positivity
#print axioms probe_7_184

-- ATTACK fc-379fc029-parts-ii-920d701aab-counterexample-v1 linarith
theorem probe_7_185 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.ii") := by
  linarith
#print axioms probe_7_185

-- ATTACK fc-379fc029-parts-ii-920d701aab-counterexample-v1 nlinarith
theorem probe_7_186 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.ii") := by
  nlinarith
#print axioms probe_7_186

-- ATTACK fc-379fc029-parts-ii-920d701aab-counterexample-v1 intros_simp_all
theorem probe_7_187 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.ii") := by
  intros
  simp_all
#print axioms probe_7_187

-- ATTACK fc-379fc029-parts-ii-920d701aab-counterexample-v1 intros_omega
theorem probe_7_188 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.ii") := by
  intros
  omega
#print axioms probe_7_188

-- ATTACK fc-379fc029-parts-ii-920d701aab-counterexample-v1 intros_norm_num
theorem probe_7_189 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.ii") := by
  intros
  norm_num at *
#print axioms probe_7_189

-- ATTACK fc-379fc029-parts-ii-920d701aab-counterexample-v1 intros_aesop
theorem probe_7_190 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.ii") := by
  intros
  aesop
#print axioms probe_7_190

-- ATTACK fc-379fc029-parts-ii-920d701aab-counterexample-v1 by_contra_simp_all
theorem probe_7_191 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.ii") := by
  by_contra h
  simp_all
#print axioms probe_7_191

-- ATTACK fc-379fc029-parts-ii-920d701aab-counterexample-v1 classical_simp_all
theorem probe_7_192 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.ii") := by
  classical
  simp_all
#print axioms probe_7_192

-- ATTACK fc-379fc029-parts-ii-920d701aab-counterexample-v1 classical_aesop
theorem probe_7_193 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.ii") := by
  classical
  aesop
#print axioms probe_7_193

-- ATTACK fc-379fc029-parts-ii-920d701aab-counterexample-v1 refine_pair_simp
theorem probe_7_194 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.ii") := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_7_194

-- ATTACK fc-379fc029-parts-ii-920d701aab-counterexample-v1 refine_pair_aesop
theorem probe_7_195 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.ii") := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_7_195

-- ATTACK fc-379fc029-parts-ii-920d701aab-counterexample-v1 use_zero_simp
theorem probe_7_196 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.ii") := by
  use 0 <;> simp
#print axioms probe_7_196

-- ATTACK fc-379fc029-parts-ii-920d701aab-counterexample-v1 use_one_simp
theorem probe_7_197 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.ii") := by
  use 1 <;> simp
#print axioms probe_7_197

-- ATTACK fc-379fc029-parts-ii-920d701aab-counterexample-v1 use_empty_simp
theorem probe_7_198 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.ii") := by
  use ∅ <;> simp
#print axioms probe_7_198

-- ATTACK fc-379fc029-parts-ii-920d701aab-counterexample-v1 assumption
theorem probe_7_199 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.ii") := by
  assumption
#print axioms probe_7_199

-- ATTACK fc-379fc029-parts-ii-920d701aab-counterexample-v1 infer_instance
theorem probe_7_200 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.ii") := by
  infer_instance
#print axioms probe_7_200

-- ATTACK fc-379fc029-parts-ii-920d701aab-counterexample-v1 contradiction
theorem probe_7_201 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.ii") := by
  contradiction
#print axioms probe_7_201

-- ATTACK fc-379fc029-parts-ii-920d701aab-counterexample-v1 solve_by_elim
theorem probe_7_202 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.ii") := by
  solve_by_elim
#print axioms probe_7_202

-- ATTACK fc-379fc029-parts-ii-920d701aab-counterexample-v1 first_order
theorem probe_7_203 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.ii") := by
  first_order
#print axioms probe_7_203

-- ATTACK fc-379fc029-parts-ii-920d701aab-counterexample-v1 grind
theorem probe_7_204 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.ii") := by
  grind
#print axioms probe_7_204

-- ATTACK fc-379fc029-parts-ii-920d701aab-counterexample-v1 exact_search
theorem probe_7_205 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.ii") := by
  exact?
#print axioms probe_7_205

-- ATTACK fc-379fc029-parts-ii-920d701aab-counterexample-v1 apply_search
theorem probe_7_206 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.ii") := by
  apply?
#print axioms probe_7_206

-- ATTACK fc-379fc029-parts-ii-920d701aab-counterexample-v1 library_search
theorem probe_7_207 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.ii") := by
  library_search
#print axioms probe_7_207

-- ATTACK fc-379fc029-parts-ii-920d701aab-counterexample-v1 aesop_search
theorem probe_7_208 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.ii") := by
  aesop?
#print axioms probe_7_208

-- ATTACK fc-379fc029-parts-ii-920d701aab-counterexample-v1 simp_search
theorem probe_7_209 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.ii") := by
  simp?
#print axioms probe_7_209

-- ATTACK fc-379fc029-erdos495-erdos-495-999add5179-counterexample-v1 simp
theorem probe_7_210 : ¬ (fcTypeOfName% "Erdos495.erdos_495") := by
  simp
#print axioms probe_7_210

-- ATTACK fc-379fc029-erdos495-erdos-495-999add5179-counterexample-v1 simpa
theorem probe_7_211 : ¬ (fcTypeOfName% "Erdos495.erdos_495") := by
  simpa
#print axioms probe_7_211

-- ATTACK fc-379fc029-erdos495-erdos-495-999add5179-counterexample-v1 simp_all
theorem probe_7_212 : ¬ (fcTypeOfName% "Erdos495.erdos_495") := by
  simp_all
#print axioms probe_7_212

-- ATTACK fc-379fc029-erdos495-erdos-495-999add5179-counterexample-v1 aesop
theorem probe_7_213 : ¬ (fcTypeOfName% "Erdos495.erdos_495") := by
  aesop
#print axioms probe_7_213

-- ATTACK fc-379fc029-erdos495-erdos-495-999add5179-counterexample-v1 omega
theorem probe_7_214 : ¬ (fcTypeOfName% "Erdos495.erdos_495") := by
  omega
#print axioms probe_7_214

-- ATTACK fc-379fc029-erdos495-erdos-495-999add5179-counterexample-v1 norm_num
theorem probe_7_215 : ¬ (fcTypeOfName% "Erdos495.erdos_495") := by
  norm_num
#print axioms probe_7_215

-- ATTACK fc-379fc029-erdos495-erdos-495-999add5179-counterexample-v1 decide
theorem probe_7_216 : ¬ (fcTypeOfName% "Erdos495.erdos_495") := by
  decide
#print axioms probe_7_216

-- ATTACK fc-379fc029-erdos495-erdos-495-999add5179-counterexample-v1 native_decide
theorem probe_7_217 : ¬ (fcTypeOfName% "Erdos495.erdos_495") := by
  native_decide
#print axioms probe_7_217

-- ATTACK fc-379fc029-erdos495-erdos-495-999add5179-counterexample-v1 true_intro
theorem probe_7_218 : ¬ (fcTypeOfName% "Erdos495.erdos_495") := by
  exact True.intro
#print axioms probe_7_218

-- ATTACK fc-379fc029-erdos495-erdos-495-999add5179-counterexample-v1 false_elim_simp
theorem probe_7_219 : ¬ (fcTypeOfName% "Erdos495.erdos_495") := by
  apply False.elim
  simp_all
#print axioms probe_7_219

-- ATTACK fc-379fc029-erdos495-erdos-495-999add5179-counterexample-v1 constructor
theorem probe_7_220 : ¬ (fcTypeOfName% "Erdos495.erdos_495") := by
  constructor
#print axioms probe_7_220

-- ATTACK fc-379fc029-erdos495-erdos-495-999add5179-counterexample-v1 constructor_simp
theorem probe_7_221 : ¬ (fcTypeOfName% "Erdos495.erdos_495") := by
  constructor <;> simp
#print axioms probe_7_221

-- ATTACK fc-379fc029-erdos495-erdos-495-999add5179-counterexample-v1 constructor_aesop
theorem probe_7_222 : ¬ (fcTypeOfName% "Erdos495.erdos_495") := by
  constructor <;> aesop
#print axioms probe_7_222

-- ATTACK fc-379fc029-erdos495-erdos-495-999add5179-counterexample-v1 rfl
theorem probe_7_223 : ¬ (fcTypeOfName% "Erdos495.erdos_495") := by
  rfl
#print axioms probe_7_223

-- ATTACK fc-379fc029-erdos495-erdos-495-999add5179-counterexample-v1 trivial
theorem probe_7_224 : ¬ (fcTypeOfName% "Erdos495.erdos_495") := by
  trivial
#print axioms probe_7_224

-- ATTACK fc-379fc029-erdos495-erdos-495-999add5179-counterexample-v1 tauto
theorem probe_7_225 : ¬ (fcTypeOfName% "Erdos495.erdos_495") := by
  tauto
#print axioms probe_7_225

-- ATTACK fc-379fc029-erdos495-erdos-495-999add5179-counterexample-v1 positivity
theorem probe_7_226 : ¬ (fcTypeOfName% "Erdos495.erdos_495") := by
  positivity
#print axioms probe_7_226

-- ATTACK fc-379fc029-erdos495-erdos-495-999add5179-counterexample-v1 linarith
theorem probe_7_227 : ¬ (fcTypeOfName% "Erdos495.erdos_495") := by
  linarith
#print axioms probe_7_227

-- ATTACK fc-379fc029-erdos495-erdos-495-999add5179-counterexample-v1 nlinarith
theorem probe_7_228 : ¬ (fcTypeOfName% "Erdos495.erdos_495") := by
  nlinarith
#print axioms probe_7_228

-- ATTACK fc-379fc029-erdos495-erdos-495-999add5179-counterexample-v1 intros_simp_all
theorem probe_7_229 : ¬ (fcTypeOfName% "Erdos495.erdos_495") := by
  intros
  simp_all
#print axioms probe_7_229

-- ATTACK fc-379fc029-erdos495-erdos-495-999add5179-counterexample-v1 intros_omega
theorem probe_7_230 : ¬ (fcTypeOfName% "Erdos495.erdos_495") := by
  intros
  omega
#print axioms probe_7_230

-- ATTACK fc-379fc029-erdos495-erdos-495-999add5179-counterexample-v1 intros_norm_num
theorem probe_7_231 : ¬ (fcTypeOfName% "Erdos495.erdos_495") := by
  intros
  norm_num at *
#print axioms probe_7_231

-- ATTACK fc-379fc029-erdos495-erdos-495-999add5179-counterexample-v1 intros_aesop
theorem probe_7_232 : ¬ (fcTypeOfName% "Erdos495.erdos_495") := by
  intros
  aesop
#print axioms probe_7_232

-- ATTACK fc-379fc029-erdos495-erdos-495-999add5179-counterexample-v1 by_contra_simp_all
theorem probe_7_233 : ¬ (fcTypeOfName% "Erdos495.erdos_495") := by
  by_contra h
  simp_all
#print axioms probe_7_233

-- ATTACK fc-379fc029-erdos495-erdos-495-999add5179-counterexample-v1 classical_simp_all
theorem probe_7_234 : ¬ (fcTypeOfName% "Erdos495.erdos_495") := by
  classical
  simp_all
#print axioms probe_7_234

-- ATTACK fc-379fc029-erdos495-erdos-495-999add5179-counterexample-v1 classical_aesop
theorem probe_7_235 : ¬ (fcTypeOfName% "Erdos495.erdos_495") := by
  classical
  aesop
#print axioms probe_7_235

-- ATTACK fc-379fc029-erdos495-erdos-495-999add5179-counterexample-v1 refine_pair_simp
theorem probe_7_236 : ¬ (fcTypeOfName% "Erdos495.erdos_495") := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_7_236

-- ATTACK fc-379fc029-erdos495-erdos-495-999add5179-counterexample-v1 refine_pair_aesop
theorem probe_7_237 : ¬ (fcTypeOfName% "Erdos495.erdos_495") := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_7_237

-- ATTACK fc-379fc029-erdos495-erdos-495-999add5179-counterexample-v1 use_zero_simp
theorem probe_7_238 : ¬ (fcTypeOfName% "Erdos495.erdos_495") := by
  use 0 <;> simp
#print axioms probe_7_238

-- ATTACK fc-379fc029-erdos495-erdos-495-999add5179-counterexample-v1 use_one_simp
theorem probe_7_239 : ¬ (fcTypeOfName% "Erdos495.erdos_495") := by
  use 1 <;> simp
#print axioms probe_7_239

-- ATTACK fc-379fc029-erdos495-erdos-495-999add5179-counterexample-v1 use_empty_simp
theorem probe_7_240 : ¬ (fcTypeOfName% "Erdos495.erdos_495") := by
  use ∅ <;> simp
#print axioms probe_7_240

-- ATTACK fc-379fc029-erdos495-erdos-495-999add5179-counterexample-v1 assumption
theorem probe_7_241 : ¬ (fcTypeOfName% "Erdos495.erdos_495") := by
  assumption
#print axioms probe_7_241

-- ATTACK fc-379fc029-erdos495-erdos-495-999add5179-counterexample-v1 infer_instance
theorem probe_7_242 : ¬ (fcTypeOfName% "Erdos495.erdos_495") := by
  infer_instance
#print axioms probe_7_242

-- ATTACK fc-379fc029-erdos495-erdos-495-999add5179-counterexample-v1 contradiction
theorem probe_7_243 : ¬ (fcTypeOfName% "Erdos495.erdos_495") := by
  contradiction
#print axioms probe_7_243

-- ATTACK fc-379fc029-erdos495-erdos-495-999add5179-counterexample-v1 solve_by_elim
theorem probe_7_244 : ¬ (fcTypeOfName% "Erdos495.erdos_495") := by
  solve_by_elim
#print axioms probe_7_244

-- ATTACK fc-379fc029-erdos495-erdos-495-999add5179-counterexample-v1 first_order
theorem probe_7_245 : ¬ (fcTypeOfName% "Erdos495.erdos_495") := by
  first_order
#print axioms probe_7_245

-- ATTACK fc-379fc029-erdos495-erdos-495-999add5179-counterexample-v1 grind
theorem probe_7_246 : ¬ (fcTypeOfName% "Erdos495.erdos_495") := by
  grind
#print axioms probe_7_246

-- ATTACK fc-379fc029-erdos495-erdos-495-999add5179-counterexample-v1 exact_search
theorem probe_7_247 : ¬ (fcTypeOfName% "Erdos495.erdos_495") := by
  exact?
#print axioms probe_7_247

-- ATTACK fc-379fc029-erdos495-erdos-495-999add5179-counterexample-v1 apply_search
theorem probe_7_248 : ¬ (fcTypeOfName% "Erdos495.erdos_495") := by
  apply?
#print axioms probe_7_248

-- ATTACK fc-379fc029-erdos495-erdos-495-999add5179-counterexample-v1 library_search
theorem probe_7_249 : ¬ (fcTypeOfName% "Erdos495.erdos_495") := by
  library_search
#print axioms probe_7_249

-- ATTACK fc-379fc029-erdos495-erdos-495-999add5179-counterexample-v1 aesop_search
theorem probe_7_250 : ¬ (fcTypeOfName% "Erdos495.erdos_495") := by
  aesop?
#print axioms probe_7_250

-- ATTACK fc-379fc029-erdos495-erdos-495-999add5179-counterexample-v1 simp_search
theorem probe_7_251 : ¬ (fcTypeOfName% "Erdos495.erdos_495") := by
  simp?
#print axioms probe_7_251

-- ATTACK fc-379fc029-erdos681-erdos-681-f3d9c78d6e-counterexample-v1 simp
theorem probe_7_252 : ¬ (fcTypeOfName% "Erdos681.erdos_681") := by
  simp
#print axioms probe_7_252

-- ATTACK fc-379fc029-erdos681-erdos-681-f3d9c78d6e-counterexample-v1 simpa
theorem probe_7_253 : ¬ (fcTypeOfName% "Erdos681.erdos_681") := by
  simpa
#print axioms probe_7_253

-- ATTACK fc-379fc029-erdos681-erdos-681-f3d9c78d6e-counterexample-v1 simp_all
theorem probe_7_254 : ¬ (fcTypeOfName% "Erdos681.erdos_681") := by
  simp_all
#print axioms probe_7_254

-- ATTACK fc-379fc029-erdos681-erdos-681-f3d9c78d6e-counterexample-v1 aesop
theorem probe_7_255 : ¬ (fcTypeOfName% "Erdos681.erdos_681") := by
  aesop
#print axioms probe_7_255

-- ATTACK fc-379fc029-erdos681-erdos-681-f3d9c78d6e-counterexample-v1 omega
theorem probe_7_256 : ¬ (fcTypeOfName% "Erdos681.erdos_681") := by
  omega
#print axioms probe_7_256

-- ATTACK fc-379fc029-erdos681-erdos-681-f3d9c78d6e-counterexample-v1 norm_num
theorem probe_7_257 : ¬ (fcTypeOfName% "Erdos681.erdos_681") := by
  norm_num
#print axioms probe_7_257

-- ATTACK fc-379fc029-erdos681-erdos-681-f3d9c78d6e-counterexample-v1 decide
theorem probe_7_258 : ¬ (fcTypeOfName% "Erdos681.erdos_681") := by
  decide
#print axioms probe_7_258

-- ATTACK fc-379fc029-erdos681-erdos-681-f3d9c78d6e-counterexample-v1 native_decide
theorem probe_7_259 : ¬ (fcTypeOfName% "Erdos681.erdos_681") := by
  native_decide
#print axioms probe_7_259

-- ATTACK fc-379fc029-erdos681-erdos-681-f3d9c78d6e-counterexample-v1 true_intro
theorem probe_7_260 : ¬ (fcTypeOfName% "Erdos681.erdos_681") := by
  exact True.intro
#print axioms probe_7_260

-- ATTACK fc-379fc029-erdos681-erdos-681-f3d9c78d6e-counterexample-v1 false_elim_simp
theorem probe_7_261 : ¬ (fcTypeOfName% "Erdos681.erdos_681") := by
  apply False.elim
  simp_all
#print axioms probe_7_261

-- ATTACK fc-379fc029-erdos681-erdos-681-f3d9c78d6e-counterexample-v1 constructor
theorem probe_7_262 : ¬ (fcTypeOfName% "Erdos681.erdos_681") := by
  constructor
#print axioms probe_7_262

-- ATTACK fc-379fc029-erdos681-erdos-681-f3d9c78d6e-counterexample-v1 constructor_simp
theorem probe_7_263 : ¬ (fcTypeOfName% "Erdos681.erdos_681") := by
  constructor <;> simp
#print axioms probe_7_263

-- ATTACK fc-379fc029-erdos681-erdos-681-f3d9c78d6e-counterexample-v1 constructor_aesop
theorem probe_7_264 : ¬ (fcTypeOfName% "Erdos681.erdos_681") := by
  constructor <;> aesop
#print axioms probe_7_264

-- ATTACK fc-379fc029-erdos681-erdos-681-f3d9c78d6e-counterexample-v1 rfl
theorem probe_7_265 : ¬ (fcTypeOfName% "Erdos681.erdos_681") := by
  rfl
#print axioms probe_7_265

-- ATTACK fc-379fc029-erdos681-erdos-681-f3d9c78d6e-counterexample-v1 trivial
theorem probe_7_266 : ¬ (fcTypeOfName% "Erdos681.erdos_681") := by
  trivial
#print axioms probe_7_266

-- ATTACK fc-379fc029-erdos681-erdos-681-f3d9c78d6e-counterexample-v1 tauto
theorem probe_7_267 : ¬ (fcTypeOfName% "Erdos681.erdos_681") := by
  tauto
#print axioms probe_7_267

-- ATTACK fc-379fc029-erdos681-erdos-681-f3d9c78d6e-counterexample-v1 positivity
theorem probe_7_268 : ¬ (fcTypeOfName% "Erdos681.erdos_681") := by
  positivity
#print axioms probe_7_268

-- ATTACK fc-379fc029-erdos681-erdos-681-f3d9c78d6e-counterexample-v1 linarith
theorem probe_7_269 : ¬ (fcTypeOfName% "Erdos681.erdos_681") := by
  linarith
#print axioms probe_7_269

-- ATTACK fc-379fc029-erdos681-erdos-681-f3d9c78d6e-counterexample-v1 nlinarith
theorem probe_7_270 : ¬ (fcTypeOfName% "Erdos681.erdos_681") := by
  nlinarith
#print axioms probe_7_270

-- ATTACK fc-379fc029-erdos681-erdos-681-f3d9c78d6e-counterexample-v1 intros_simp_all
theorem probe_7_271 : ¬ (fcTypeOfName% "Erdos681.erdos_681") := by
  intros
  simp_all
#print axioms probe_7_271

-- ATTACK fc-379fc029-erdos681-erdos-681-f3d9c78d6e-counterexample-v1 intros_omega
theorem probe_7_272 : ¬ (fcTypeOfName% "Erdos681.erdos_681") := by
  intros
  omega
#print axioms probe_7_272

-- ATTACK fc-379fc029-erdos681-erdos-681-f3d9c78d6e-counterexample-v1 intros_norm_num
theorem probe_7_273 : ¬ (fcTypeOfName% "Erdos681.erdos_681") := by
  intros
  norm_num at *
#print axioms probe_7_273

-- ATTACK fc-379fc029-erdos681-erdos-681-f3d9c78d6e-counterexample-v1 intros_aesop
theorem probe_7_274 : ¬ (fcTypeOfName% "Erdos681.erdos_681") := by
  intros
  aesop
#print axioms probe_7_274

-- ATTACK fc-379fc029-erdos681-erdos-681-f3d9c78d6e-counterexample-v1 by_contra_simp_all
theorem probe_7_275 : ¬ (fcTypeOfName% "Erdos681.erdos_681") := by
  by_contra h
  simp_all
#print axioms probe_7_275

-- ATTACK fc-379fc029-erdos681-erdos-681-f3d9c78d6e-counterexample-v1 classical_simp_all
theorem probe_7_276 : ¬ (fcTypeOfName% "Erdos681.erdos_681") := by
  classical
  simp_all
#print axioms probe_7_276

-- ATTACK fc-379fc029-erdos681-erdos-681-f3d9c78d6e-counterexample-v1 classical_aesop
theorem probe_7_277 : ¬ (fcTypeOfName% "Erdos681.erdos_681") := by
  classical
  aesop
#print axioms probe_7_277

-- ATTACK fc-379fc029-erdos681-erdos-681-f3d9c78d6e-counterexample-v1 refine_pair_simp
theorem probe_7_278 : ¬ (fcTypeOfName% "Erdos681.erdos_681") := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_7_278

-- ATTACK fc-379fc029-erdos681-erdos-681-f3d9c78d6e-counterexample-v1 refine_pair_aesop
theorem probe_7_279 : ¬ (fcTypeOfName% "Erdos681.erdos_681") := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_7_279

-- ATTACK fc-379fc029-erdos681-erdos-681-f3d9c78d6e-counterexample-v1 use_zero_simp
theorem probe_7_280 : ¬ (fcTypeOfName% "Erdos681.erdos_681") := by
  use 0 <;> simp
#print axioms probe_7_280

-- ATTACK fc-379fc029-erdos681-erdos-681-f3d9c78d6e-counterexample-v1 use_one_simp
theorem probe_7_281 : ¬ (fcTypeOfName% "Erdos681.erdos_681") := by
  use 1 <;> simp
#print axioms probe_7_281

-- ATTACK fc-379fc029-erdos681-erdos-681-f3d9c78d6e-counterexample-v1 use_empty_simp
theorem probe_7_282 : ¬ (fcTypeOfName% "Erdos681.erdos_681") := by
  use ∅ <;> simp
#print axioms probe_7_282

-- ATTACK fc-379fc029-erdos681-erdos-681-f3d9c78d6e-counterexample-v1 assumption
theorem probe_7_283 : ¬ (fcTypeOfName% "Erdos681.erdos_681") := by
  assumption
#print axioms probe_7_283

-- ATTACK fc-379fc029-erdos681-erdos-681-f3d9c78d6e-counterexample-v1 infer_instance
theorem probe_7_284 : ¬ (fcTypeOfName% "Erdos681.erdos_681") := by
  infer_instance
#print axioms probe_7_284

-- ATTACK fc-379fc029-erdos681-erdos-681-f3d9c78d6e-counterexample-v1 contradiction
theorem probe_7_285 : ¬ (fcTypeOfName% "Erdos681.erdos_681") := by
  contradiction
#print axioms probe_7_285

-- ATTACK fc-379fc029-erdos681-erdos-681-f3d9c78d6e-counterexample-v1 solve_by_elim
theorem probe_7_286 : ¬ (fcTypeOfName% "Erdos681.erdos_681") := by
  solve_by_elim
#print axioms probe_7_286

-- ATTACK fc-379fc029-erdos681-erdos-681-f3d9c78d6e-counterexample-v1 first_order
theorem probe_7_287 : ¬ (fcTypeOfName% "Erdos681.erdos_681") := by
  first_order
#print axioms probe_7_287

-- ATTACK fc-379fc029-erdos681-erdos-681-f3d9c78d6e-counterexample-v1 grind
theorem probe_7_288 : ¬ (fcTypeOfName% "Erdos681.erdos_681") := by
  grind
#print axioms probe_7_288

-- ATTACK fc-379fc029-erdos681-erdos-681-f3d9c78d6e-counterexample-v1 exact_search
theorem probe_7_289 : ¬ (fcTypeOfName% "Erdos681.erdos_681") := by
  exact?
#print axioms probe_7_289

-- ATTACK fc-379fc029-erdos681-erdos-681-f3d9c78d6e-counterexample-v1 apply_search
theorem probe_7_290 : ¬ (fcTypeOfName% "Erdos681.erdos_681") := by
  apply?
#print axioms probe_7_290

-- ATTACK fc-379fc029-erdos681-erdos-681-f3d9c78d6e-counterexample-v1 library_search
theorem probe_7_291 : ¬ (fcTypeOfName% "Erdos681.erdos_681") := by
  library_search
#print axioms probe_7_291

-- ATTACK fc-379fc029-erdos681-erdos-681-f3d9c78d6e-counterexample-v1 aesop_search
theorem probe_7_292 : ¬ (fcTypeOfName% "Erdos681.erdos_681") := by
  aesop?
#print axioms probe_7_292

-- ATTACK fc-379fc029-erdos681-erdos-681-f3d9c78d6e-counterexample-v1 simp_search
theorem probe_7_293 : ¬ (fcTypeOfName% "Erdos681.erdos_681") := by
  simp?
#print axioms probe_7_293

-- ATTACK fc-379fc029-erdos886-erdos-886-459aeab73c-counterexample-v1 simp
theorem probe_7_294 : ¬ (fcTypeOfName% "Erdos886.erdos_886") := by
  simp
#print axioms probe_7_294

-- ATTACK fc-379fc029-erdos886-erdos-886-459aeab73c-counterexample-v1 simpa
theorem probe_7_295 : ¬ (fcTypeOfName% "Erdos886.erdos_886") := by
  simpa
#print axioms probe_7_295

-- ATTACK fc-379fc029-erdos886-erdos-886-459aeab73c-counterexample-v1 simp_all
theorem probe_7_296 : ¬ (fcTypeOfName% "Erdos886.erdos_886") := by
  simp_all
#print axioms probe_7_296

-- ATTACK fc-379fc029-erdos886-erdos-886-459aeab73c-counterexample-v1 aesop
theorem probe_7_297 : ¬ (fcTypeOfName% "Erdos886.erdos_886") := by
  aesop
#print axioms probe_7_297

-- ATTACK fc-379fc029-erdos886-erdos-886-459aeab73c-counterexample-v1 omega
theorem probe_7_298 : ¬ (fcTypeOfName% "Erdos886.erdos_886") := by
  omega
#print axioms probe_7_298

-- ATTACK fc-379fc029-erdos886-erdos-886-459aeab73c-counterexample-v1 norm_num
theorem probe_7_299 : ¬ (fcTypeOfName% "Erdos886.erdos_886") := by
  norm_num
#print axioms probe_7_299

-- ATTACK fc-379fc029-erdos886-erdos-886-459aeab73c-counterexample-v1 decide
theorem probe_7_300 : ¬ (fcTypeOfName% "Erdos886.erdos_886") := by
  decide
#print axioms probe_7_300

-- ATTACK fc-379fc029-erdos886-erdos-886-459aeab73c-counterexample-v1 native_decide
theorem probe_7_301 : ¬ (fcTypeOfName% "Erdos886.erdos_886") := by
  native_decide
#print axioms probe_7_301

-- ATTACK fc-379fc029-erdos886-erdos-886-459aeab73c-counterexample-v1 true_intro
theorem probe_7_302 : ¬ (fcTypeOfName% "Erdos886.erdos_886") := by
  exact True.intro
#print axioms probe_7_302

-- ATTACK fc-379fc029-erdos886-erdos-886-459aeab73c-counterexample-v1 false_elim_simp
theorem probe_7_303 : ¬ (fcTypeOfName% "Erdos886.erdos_886") := by
  apply False.elim
  simp_all
#print axioms probe_7_303

-- ATTACK fc-379fc029-erdos886-erdos-886-459aeab73c-counterexample-v1 constructor
theorem probe_7_304 : ¬ (fcTypeOfName% "Erdos886.erdos_886") := by
  constructor
#print axioms probe_7_304

-- ATTACK fc-379fc029-erdos886-erdos-886-459aeab73c-counterexample-v1 constructor_simp
theorem probe_7_305 : ¬ (fcTypeOfName% "Erdos886.erdos_886") := by
  constructor <;> simp
#print axioms probe_7_305

-- ATTACK fc-379fc029-erdos886-erdos-886-459aeab73c-counterexample-v1 constructor_aesop
theorem probe_7_306 : ¬ (fcTypeOfName% "Erdos886.erdos_886") := by
  constructor <;> aesop
#print axioms probe_7_306

-- ATTACK fc-379fc029-erdos886-erdos-886-459aeab73c-counterexample-v1 rfl
theorem probe_7_307 : ¬ (fcTypeOfName% "Erdos886.erdos_886") := by
  rfl
#print axioms probe_7_307

-- ATTACK fc-379fc029-erdos886-erdos-886-459aeab73c-counterexample-v1 trivial
theorem probe_7_308 : ¬ (fcTypeOfName% "Erdos886.erdos_886") := by
  trivial
#print axioms probe_7_308

-- ATTACK fc-379fc029-erdos886-erdos-886-459aeab73c-counterexample-v1 tauto
theorem probe_7_309 : ¬ (fcTypeOfName% "Erdos886.erdos_886") := by
  tauto
#print axioms probe_7_309

-- ATTACK fc-379fc029-erdos886-erdos-886-459aeab73c-counterexample-v1 positivity
theorem probe_7_310 : ¬ (fcTypeOfName% "Erdos886.erdos_886") := by
  positivity
#print axioms probe_7_310

-- ATTACK fc-379fc029-erdos886-erdos-886-459aeab73c-counterexample-v1 linarith
theorem probe_7_311 : ¬ (fcTypeOfName% "Erdos886.erdos_886") := by
  linarith
#print axioms probe_7_311

-- ATTACK fc-379fc029-erdos886-erdos-886-459aeab73c-counterexample-v1 nlinarith
theorem probe_7_312 : ¬ (fcTypeOfName% "Erdos886.erdos_886") := by
  nlinarith
#print axioms probe_7_312

-- ATTACK fc-379fc029-erdos886-erdos-886-459aeab73c-counterexample-v1 intros_simp_all
theorem probe_7_313 : ¬ (fcTypeOfName% "Erdos886.erdos_886") := by
  intros
  simp_all
#print axioms probe_7_313

-- ATTACK fc-379fc029-erdos886-erdos-886-459aeab73c-counterexample-v1 intros_omega
theorem probe_7_314 : ¬ (fcTypeOfName% "Erdos886.erdos_886") := by
  intros
  omega
#print axioms probe_7_314

-- ATTACK fc-379fc029-erdos886-erdos-886-459aeab73c-counterexample-v1 intros_norm_num
theorem probe_7_315 : ¬ (fcTypeOfName% "Erdos886.erdos_886") := by
  intros
  norm_num at *
#print axioms probe_7_315

-- ATTACK fc-379fc029-erdos886-erdos-886-459aeab73c-counterexample-v1 intros_aesop
theorem probe_7_316 : ¬ (fcTypeOfName% "Erdos886.erdos_886") := by
  intros
  aesop
#print axioms probe_7_316

-- ATTACK fc-379fc029-erdos886-erdos-886-459aeab73c-counterexample-v1 by_contra_simp_all
theorem probe_7_317 : ¬ (fcTypeOfName% "Erdos886.erdos_886") := by
  by_contra h
  simp_all
#print axioms probe_7_317

-- ATTACK fc-379fc029-erdos886-erdos-886-459aeab73c-counterexample-v1 classical_simp_all
theorem probe_7_318 : ¬ (fcTypeOfName% "Erdos886.erdos_886") := by
  classical
  simp_all
#print axioms probe_7_318

-- ATTACK fc-379fc029-erdos886-erdos-886-459aeab73c-counterexample-v1 classical_aesop
theorem probe_7_319 : ¬ (fcTypeOfName% "Erdos886.erdos_886") := by
  classical
  aesop
#print axioms probe_7_319

-- ATTACK fc-379fc029-erdos886-erdos-886-459aeab73c-counterexample-v1 refine_pair_simp
theorem probe_7_320 : ¬ (fcTypeOfName% "Erdos886.erdos_886") := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_7_320

-- ATTACK fc-379fc029-erdos886-erdos-886-459aeab73c-counterexample-v1 refine_pair_aesop
theorem probe_7_321 : ¬ (fcTypeOfName% "Erdos886.erdos_886") := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_7_321

-- ATTACK fc-379fc029-erdos886-erdos-886-459aeab73c-counterexample-v1 use_zero_simp
theorem probe_7_322 : ¬ (fcTypeOfName% "Erdos886.erdos_886") := by
  use 0 <;> simp
#print axioms probe_7_322

-- ATTACK fc-379fc029-erdos886-erdos-886-459aeab73c-counterexample-v1 use_one_simp
theorem probe_7_323 : ¬ (fcTypeOfName% "Erdos886.erdos_886") := by
  use 1 <;> simp
#print axioms probe_7_323

-- ATTACK fc-379fc029-erdos886-erdos-886-459aeab73c-counterexample-v1 use_empty_simp
theorem probe_7_324 : ¬ (fcTypeOfName% "Erdos886.erdos_886") := by
  use ∅ <;> simp
#print axioms probe_7_324

-- ATTACK fc-379fc029-erdos886-erdos-886-459aeab73c-counterexample-v1 assumption
theorem probe_7_325 : ¬ (fcTypeOfName% "Erdos886.erdos_886") := by
  assumption
#print axioms probe_7_325

-- ATTACK fc-379fc029-erdos886-erdos-886-459aeab73c-counterexample-v1 infer_instance
theorem probe_7_326 : ¬ (fcTypeOfName% "Erdos886.erdos_886") := by
  infer_instance
#print axioms probe_7_326

-- ATTACK fc-379fc029-erdos886-erdos-886-459aeab73c-counterexample-v1 contradiction
theorem probe_7_327 : ¬ (fcTypeOfName% "Erdos886.erdos_886") := by
  contradiction
#print axioms probe_7_327

-- ATTACK fc-379fc029-erdos886-erdos-886-459aeab73c-counterexample-v1 solve_by_elim
theorem probe_7_328 : ¬ (fcTypeOfName% "Erdos886.erdos_886") := by
  solve_by_elim
#print axioms probe_7_328

-- ATTACK fc-379fc029-erdos886-erdos-886-459aeab73c-counterexample-v1 first_order
theorem probe_7_329 : ¬ (fcTypeOfName% "Erdos886.erdos_886") := by
  first_order
#print axioms probe_7_329

-- ATTACK fc-379fc029-erdos886-erdos-886-459aeab73c-counterexample-v1 grind
theorem probe_7_330 : ¬ (fcTypeOfName% "Erdos886.erdos_886") := by
  grind
#print axioms probe_7_330

-- ATTACK fc-379fc029-erdos886-erdos-886-459aeab73c-counterexample-v1 exact_search
theorem probe_7_331 : ¬ (fcTypeOfName% "Erdos886.erdos_886") := by
  exact?
#print axioms probe_7_331

-- ATTACK fc-379fc029-erdos886-erdos-886-459aeab73c-counterexample-v1 apply_search
theorem probe_7_332 : ¬ (fcTypeOfName% "Erdos886.erdos_886") := by
  apply?
#print axioms probe_7_332

-- ATTACK fc-379fc029-erdos886-erdos-886-459aeab73c-counterexample-v1 library_search
theorem probe_7_333 : ¬ (fcTypeOfName% "Erdos886.erdos_886") := by
  library_search
#print axioms probe_7_333

-- ATTACK fc-379fc029-erdos886-erdos-886-459aeab73c-counterexample-v1 aesop_search
theorem probe_7_334 : ¬ (fcTypeOfName% "Erdos886.erdos_886") := by
  aesop?
#print axioms probe_7_334

-- ATTACK fc-379fc029-erdos886-erdos-886-459aeab73c-counterexample-v1 simp_search
theorem probe_7_335 : ¬ (fcTypeOfName% "Erdos886.erdos_886") := by
  simp?
#print axioms probe_7_335

-- ATTACK fc-379fc029-erdos933-erdos-933-495f22a32a-counterexample-v1 simp
theorem probe_7_336 : ¬ (fcTypeOfName% "Erdos933.erdos_933") := by
  simp
#print axioms probe_7_336

-- ATTACK fc-379fc029-erdos933-erdos-933-495f22a32a-counterexample-v1 simpa
theorem probe_7_337 : ¬ (fcTypeOfName% "Erdos933.erdos_933") := by
  simpa
#print axioms probe_7_337

-- ATTACK fc-379fc029-erdos933-erdos-933-495f22a32a-counterexample-v1 simp_all
theorem probe_7_338 : ¬ (fcTypeOfName% "Erdos933.erdos_933") := by
  simp_all
#print axioms probe_7_338

-- ATTACK fc-379fc029-erdos933-erdos-933-495f22a32a-counterexample-v1 aesop
theorem probe_7_339 : ¬ (fcTypeOfName% "Erdos933.erdos_933") := by
  aesop
#print axioms probe_7_339

-- ATTACK fc-379fc029-erdos933-erdos-933-495f22a32a-counterexample-v1 omega
theorem probe_7_340 : ¬ (fcTypeOfName% "Erdos933.erdos_933") := by
  omega
#print axioms probe_7_340

-- ATTACK fc-379fc029-erdos933-erdos-933-495f22a32a-counterexample-v1 norm_num
theorem probe_7_341 : ¬ (fcTypeOfName% "Erdos933.erdos_933") := by
  norm_num
#print axioms probe_7_341

-- ATTACK fc-379fc029-erdos933-erdos-933-495f22a32a-counterexample-v1 decide
theorem probe_7_342 : ¬ (fcTypeOfName% "Erdos933.erdos_933") := by
  decide
#print axioms probe_7_342

-- ATTACK fc-379fc029-erdos933-erdos-933-495f22a32a-counterexample-v1 native_decide
theorem probe_7_343 : ¬ (fcTypeOfName% "Erdos933.erdos_933") := by
  native_decide
#print axioms probe_7_343

-- ATTACK fc-379fc029-erdos933-erdos-933-495f22a32a-counterexample-v1 true_intro
theorem probe_7_344 : ¬ (fcTypeOfName% "Erdos933.erdos_933") := by
  exact True.intro
#print axioms probe_7_344

-- ATTACK fc-379fc029-erdos933-erdos-933-495f22a32a-counterexample-v1 false_elim_simp
theorem probe_7_345 : ¬ (fcTypeOfName% "Erdos933.erdos_933") := by
  apply False.elim
  simp_all
#print axioms probe_7_345

-- ATTACK fc-379fc029-erdos933-erdos-933-495f22a32a-counterexample-v1 constructor
theorem probe_7_346 : ¬ (fcTypeOfName% "Erdos933.erdos_933") := by
  constructor
#print axioms probe_7_346

-- ATTACK fc-379fc029-erdos933-erdos-933-495f22a32a-counterexample-v1 constructor_simp
theorem probe_7_347 : ¬ (fcTypeOfName% "Erdos933.erdos_933") := by
  constructor <;> simp
#print axioms probe_7_347

-- ATTACK fc-379fc029-erdos933-erdos-933-495f22a32a-counterexample-v1 constructor_aesop
theorem probe_7_348 : ¬ (fcTypeOfName% "Erdos933.erdos_933") := by
  constructor <;> aesop
#print axioms probe_7_348

-- ATTACK fc-379fc029-erdos933-erdos-933-495f22a32a-counterexample-v1 rfl
theorem probe_7_349 : ¬ (fcTypeOfName% "Erdos933.erdos_933") := by
  rfl
#print axioms probe_7_349

-- ATTACK fc-379fc029-erdos933-erdos-933-495f22a32a-counterexample-v1 trivial
theorem probe_7_350 : ¬ (fcTypeOfName% "Erdos933.erdos_933") := by
  trivial
#print axioms probe_7_350

-- ATTACK fc-379fc029-erdos933-erdos-933-495f22a32a-counterexample-v1 tauto
theorem probe_7_351 : ¬ (fcTypeOfName% "Erdos933.erdos_933") := by
  tauto
#print axioms probe_7_351

-- ATTACK fc-379fc029-erdos933-erdos-933-495f22a32a-counterexample-v1 positivity
theorem probe_7_352 : ¬ (fcTypeOfName% "Erdos933.erdos_933") := by
  positivity
#print axioms probe_7_352

-- ATTACK fc-379fc029-erdos933-erdos-933-495f22a32a-counterexample-v1 linarith
theorem probe_7_353 : ¬ (fcTypeOfName% "Erdos933.erdos_933") := by
  linarith
#print axioms probe_7_353

-- ATTACK fc-379fc029-erdos933-erdos-933-495f22a32a-counterexample-v1 nlinarith
theorem probe_7_354 : ¬ (fcTypeOfName% "Erdos933.erdos_933") := by
  nlinarith
#print axioms probe_7_354

-- ATTACK fc-379fc029-erdos933-erdos-933-495f22a32a-counterexample-v1 intros_simp_all
theorem probe_7_355 : ¬ (fcTypeOfName% "Erdos933.erdos_933") := by
  intros
  simp_all
#print axioms probe_7_355

-- ATTACK fc-379fc029-erdos933-erdos-933-495f22a32a-counterexample-v1 intros_omega
theorem probe_7_356 : ¬ (fcTypeOfName% "Erdos933.erdos_933") := by
  intros
  omega
#print axioms probe_7_356

-- ATTACK fc-379fc029-erdos933-erdos-933-495f22a32a-counterexample-v1 intros_norm_num
theorem probe_7_357 : ¬ (fcTypeOfName% "Erdos933.erdos_933") := by
  intros
  norm_num at *
#print axioms probe_7_357

-- ATTACK fc-379fc029-erdos933-erdos-933-495f22a32a-counterexample-v1 intros_aesop
theorem probe_7_358 : ¬ (fcTypeOfName% "Erdos933.erdos_933") := by
  intros
  aesop
#print axioms probe_7_358

-- ATTACK fc-379fc029-erdos933-erdos-933-495f22a32a-counterexample-v1 by_contra_simp_all
theorem probe_7_359 : ¬ (fcTypeOfName% "Erdos933.erdos_933") := by
  by_contra h
  simp_all
#print axioms probe_7_359

-- ATTACK fc-379fc029-erdos933-erdos-933-495f22a32a-counterexample-v1 classical_simp_all
theorem probe_7_360 : ¬ (fcTypeOfName% "Erdos933.erdos_933") := by
  classical
  simp_all
#print axioms probe_7_360

-- ATTACK fc-379fc029-erdos933-erdos-933-495f22a32a-counterexample-v1 classical_aesop
theorem probe_7_361 : ¬ (fcTypeOfName% "Erdos933.erdos_933") := by
  classical
  aesop
#print axioms probe_7_361

-- ATTACK fc-379fc029-erdos933-erdos-933-495f22a32a-counterexample-v1 refine_pair_simp
theorem probe_7_362 : ¬ (fcTypeOfName% "Erdos933.erdos_933") := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_7_362

-- ATTACK fc-379fc029-erdos933-erdos-933-495f22a32a-counterexample-v1 refine_pair_aesop
theorem probe_7_363 : ¬ (fcTypeOfName% "Erdos933.erdos_933") := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_7_363

-- ATTACK fc-379fc029-erdos933-erdos-933-495f22a32a-counterexample-v1 use_zero_simp
theorem probe_7_364 : ¬ (fcTypeOfName% "Erdos933.erdos_933") := by
  use 0 <;> simp
#print axioms probe_7_364

-- ATTACK fc-379fc029-erdos933-erdos-933-495f22a32a-counterexample-v1 use_one_simp
theorem probe_7_365 : ¬ (fcTypeOfName% "Erdos933.erdos_933") := by
  use 1 <;> simp
#print axioms probe_7_365

-- ATTACK fc-379fc029-erdos933-erdos-933-495f22a32a-counterexample-v1 use_empty_simp
theorem probe_7_366 : ¬ (fcTypeOfName% "Erdos933.erdos_933") := by
  use ∅ <;> simp
#print axioms probe_7_366

-- ATTACK fc-379fc029-erdos933-erdos-933-495f22a32a-counterexample-v1 assumption
theorem probe_7_367 : ¬ (fcTypeOfName% "Erdos933.erdos_933") := by
  assumption
#print axioms probe_7_367

-- ATTACK fc-379fc029-erdos933-erdos-933-495f22a32a-counterexample-v1 infer_instance
theorem probe_7_368 : ¬ (fcTypeOfName% "Erdos933.erdos_933") := by
  infer_instance
#print axioms probe_7_368

-- ATTACK fc-379fc029-erdos933-erdos-933-495f22a32a-counterexample-v1 contradiction
theorem probe_7_369 : ¬ (fcTypeOfName% "Erdos933.erdos_933") := by
  contradiction
#print axioms probe_7_369

-- ATTACK fc-379fc029-erdos933-erdos-933-495f22a32a-counterexample-v1 solve_by_elim
theorem probe_7_370 : ¬ (fcTypeOfName% "Erdos933.erdos_933") := by
  solve_by_elim
#print axioms probe_7_370

-- ATTACK fc-379fc029-erdos933-erdos-933-495f22a32a-counterexample-v1 first_order
theorem probe_7_371 : ¬ (fcTypeOfName% "Erdos933.erdos_933") := by
  first_order
#print axioms probe_7_371

-- ATTACK fc-379fc029-erdos933-erdos-933-495f22a32a-counterexample-v1 grind
theorem probe_7_372 : ¬ (fcTypeOfName% "Erdos933.erdos_933") := by
  grind
#print axioms probe_7_372

-- ATTACK fc-379fc029-erdos933-erdos-933-495f22a32a-counterexample-v1 exact_search
theorem probe_7_373 : ¬ (fcTypeOfName% "Erdos933.erdos_933") := by
  exact?
#print axioms probe_7_373

-- ATTACK fc-379fc029-erdos933-erdos-933-495f22a32a-counterexample-v1 apply_search
theorem probe_7_374 : ¬ (fcTypeOfName% "Erdos933.erdos_933") := by
  apply?
#print axioms probe_7_374

-- ATTACK fc-379fc029-erdos933-erdos-933-495f22a32a-counterexample-v1 library_search
theorem probe_7_375 : ¬ (fcTypeOfName% "Erdos933.erdos_933") := by
  library_search
#print axioms probe_7_375

-- ATTACK fc-379fc029-erdos933-erdos-933-495f22a32a-counterexample-v1 aesop_search
theorem probe_7_376 : ¬ (fcTypeOfName% "Erdos933.erdos_933") := by
  aesop?
#print axioms probe_7_376

-- ATTACK fc-379fc029-erdos933-erdos-933-495f22a32a-counterexample-v1 simp_search
theorem probe_7_377 : ¬ (fcTypeOfName% "Erdos933.erdos_933") := by
  simp?
#print axioms probe_7_377

-- ATTACK fc-379fc029-erdos949-erdos-949-5465ae622b-counterexample-v1 simp
theorem probe_7_378 : ¬ (fcTypeOfName% "Erdos949.erdos_949") := by
  simp
#print axioms probe_7_378

-- ATTACK fc-379fc029-erdos949-erdos-949-5465ae622b-counterexample-v1 simpa
theorem probe_7_379 : ¬ (fcTypeOfName% "Erdos949.erdos_949") := by
  simpa
#print axioms probe_7_379

-- ATTACK fc-379fc029-erdos949-erdos-949-5465ae622b-counterexample-v1 simp_all
theorem probe_7_380 : ¬ (fcTypeOfName% "Erdos949.erdos_949") := by
  simp_all
#print axioms probe_7_380

-- ATTACK fc-379fc029-erdos949-erdos-949-5465ae622b-counterexample-v1 aesop
theorem probe_7_381 : ¬ (fcTypeOfName% "Erdos949.erdos_949") := by
  aesop
#print axioms probe_7_381

-- ATTACK fc-379fc029-erdos949-erdos-949-5465ae622b-counterexample-v1 omega
theorem probe_7_382 : ¬ (fcTypeOfName% "Erdos949.erdos_949") := by
  omega
#print axioms probe_7_382

-- ATTACK fc-379fc029-erdos949-erdos-949-5465ae622b-counterexample-v1 norm_num
theorem probe_7_383 : ¬ (fcTypeOfName% "Erdos949.erdos_949") := by
  norm_num
#print axioms probe_7_383

-- ATTACK fc-379fc029-erdos949-erdos-949-5465ae622b-counterexample-v1 decide
theorem probe_7_384 : ¬ (fcTypeOfName% "Erdos949.erdos_949") := by
  decide
#print axioms probe_7_384

-- ATTACK fc-379fc029-erdos949-erdos-949-5465ae622b-counterexample-v1 native_decide
theorem probe_7_385 : ¬ (fcTypeOfName% "Erdos949.erdos_949") := by
  native_decide
#print axioms probe_7_385

-- ATTACK fc-379fc029-erdos949-erdos-949-5465ae622b-counterexample-v1 true_intro
theorem probe_7_386 : ¬ (fcTypeOfName% "Erdos949.erdos_949") := by
  exact True.intro
#print axioms probe_7_386

-- ATTACK fc-379fc029-erdos949-erdos-949-5465ae622b-counterexample-v1 false_elim_simp
theorem probe_7_387 : ¬ (fcTypeOfName% "Erdos949.erdos_949") := by
  apply False.elim
  simp_all
#print axioms probe_7_387

-- ATTACK fc-379fc029-erdos949-erdos-949-5465ae622b-counterexample-v1 constructor
theorem probe_7_388 : ¬ (fcTypeOfName% "Erdos949.erdos_949") := by
  constructor
#print axioms probe_7_388

-- ATTACK fc-379fc029-erdos949-erdos-949-5465ae622b-counterexample-v1 constructor_simp
theorem probe_7_389 : ¬ (fcTypeOfName% "Erdos949.erdos_949") := by
  constructor <;> simp
#print axioms probe_7_389

-- ATTACK fc-379fc029-erdos949-erdos-949-5465ae622b-counterexample-v1 constructor_aesop
theorem probe_7_390 : ¬ (fcTypeOfName% "Erdos949.erdos_949") := by
  constructor <;> aesop
#print axioms probe_7_390

-- ATTACK fc-379fc029-erdos949-erdos-949-5465ae622b-counterexample-v1 rfl
theorem probe_7_391 : ¬ (fcTypeOfName% "Erdos949.erdos_949") := by
  rfl
#print axioms probe_7_391

-- ATTACK fc-379fc029-erdos949-erdos-949-5465ae622b-counterexample-v1 trivial
theorem probe_7_392 : ¬ (fcTypeOfName% "Erdos949.erdos_949") := by
  trivial
#print axioms probe_7_392

-- ATTACK fc-379fc029-erdos949-erdos-949-5465ae622b-counterexample-v1 tauto
theorem probe_7_393 : ¬ (fcTypeOfName% "Erdos949.erdos_949") := by
  tauto
#print axioms probe_7_393

-- ATTACK fc-379fc029-erdos949-erdos-949-5465ae622b-counterexample-v1 positivity
theorem probe_7_394 : ¬ (fcTypeOfName% "Erdos949.erdos_949") := by
  positivity
#print axioms probe_7_394

-- ATTACK fc-379fc029-erdos949-erdos-949-5465ae622b-counterexample-v1 linarith
theorem probe_7_395 : ¬ (fcTypeOfName% "Erdos949.erdos_949") := by
  linarith
#print axioms probe_7_395

-- ATTACK fc-379fc029-erdos949-erdos-949-5465ae622b-counterexample-v1 nlinarith
theorem probe_7_396 : ¬ (fcTypeOfName% "Erdos949.erdos_949") := by
  nlinarith
#print axioms probe_7_396

-- ATTACK fc-379fc029-erdos949-erdos-949-5465ae622b-counterexample-v1 intros_simp_all
theorem probe_7_397 : ¬ (fcTypeOfName% "Erdos949.erdos_949") := by
  intros
  simp_all
#print axioms probe_7_397

-- ATTACK fc-379fc029-erdos949-erdos-949-5465ae622b-counterexample-v1 intros_omega
theorem probe_7_398 : ¬ (fcTypeOfName% "Erdos949.erdos_949") := by
  intros
  omega
#print axioms probe_7_398

-- ATTACK fc-379fc029-erdos949-erdos-949-5465ae622b-counterexample-v1 intros_norm_num
theorem probe_7_399 : ¬ (fcTypeOfName% "Erdos949.erdos_949") := by
  intros
  norm_num at *
#print axioms probe_7_399

-- ATTACK fc-379fc029-erdos949-erdos-949-5465ae622b-counterexample-v1 intros_aesop
theorem probe_7_400 : ¬ (fcTypeOfName% "Erdos949.erdos_949") := by
  intros
  aesop
#print axioms probe_7_400

-- ATTACK fc-379fc029-erdos949-erdos-949-5465ae622b-counterexample-v1 by_contra_simp_all
theorem probe_7_401 : ¬ (fcTypeOfName% "Erdos949.erdos_949") := by
  by_contra h
  simp_all
#print axioms probe_7_401

-- ATTACK fc-379fc029-erdos949-erdos-949-5465ae622b-counterexample-v1 classical_simp_all
theorem probe_7_402 : ¬ (fcTypeOfName% "Erdos949.erdos_949") := by
  classical
  simp_all
#print axioms probe_7_402

-- ATTACK fc-379fc029-erdos949-erdos-949-5465ae622b-counterexample-v1 classical_aesop
theorem probe_7_403 : ¬ (fcTypeOfName% "Erdos949.erdos_949") := by
  classical
  aesop
#print axioms probe_7_403

-- ATTACK fc-379fc029-erdos949-erdos-949-5465ae622b-counterexample-v1 refine_pair_simp
theorem probe_7_404 : ¬ (fcTypeOfName% "Erdos949.erdos_949") := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_7_404

-- ATTACK fc-379fc029-erdos949-erdos-949-5465ae622b-counterexample-v1 refine_pair_aesop
theorem probe_7_405 : ¬ (fcTypeOfName% "Erdos949.erdos_949") := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_7_405

-- ATTACK fc-379fc029-erdos949-erdos-949-5465ae622b-counterexample-v1 use_zero_simp
theorem probe_7_406 : ¬ (fcTypeOfName% "Erdos949.erdos_949") := by
  use 0 <;> simp
#print axioms probe_7_406

-- ATTACK fc-379fc029-erdos949-erdos-949-5465ae622b-counterexample-v1 use_one_simp
theorem probe_7_407 : ¬ (fcTypeOfName% "Erdos949.erdos_949") := by
  use 1 <;> simp
#print axioms probe_7_407

-- ATTACK fc-379fc029-erdos949-erdos-949-5465ae622b-counterexample-v1 use_empty_simp
theorem probe_7_408 : ¬ (fcTypeOfName% "Erdos949.erdos_949") := by
  use ∅ <;> simp
#print axioms probe_7_408

-- ATTACK fc-379fc029-erdos949-erdos-949-5465ae622b-counterexample-v1 assumption
theorem probe_7_409 : ¬ (fcTypeOfName% "Erdos949.erdos_949") := by
  assumption
#print axioms probe_7_409

-- ATTACK fc-379fc029-erdos949-erdos-949-5465ae622b-counterexample-v1 infer_instance
theorem probe_7_410 : ¬ (fcTypeOfName% "Erdos949.erdos_949") := by
  infer_instance
#print axioms probe_7_410

-- ATTACK fc-379fc029-erdos949-erdos-949-5465ae622b-counterexample-v1 contradiction
theorem probe_7_411 : ¬ (fcTypeOfName% "Erdos949.erdos_949") := by
  contradiction
#print axioms probe_7_411

-- ATTACK fc-379fc029-erdos949-erdos-949-5465ae622b-counterexample-v1 solve_by_elim
theorem probe_7_412 : ¬ (fcTypeOfName% "Erdos949.erdos_949") := by
  solve_by_elim
#print axioms probe_7_412

-- ATTACK fc-379fc029-erdos949-erdos-949-5465ae622b-counterexample-v1 first_order
theorem probe_7_413 : ¬ (fcTypeOfName% "Erdos949.erdos_949") := by
  first_order
#print axioms probe_7_413

-- ATTACK fc-379fc029-erdos949-erdos-949-5465ae622b-counterexample-v1 grind
theorem probe_7_414 : ¬ (fcTypeOfName% "Erdos949.erdos_949") := by
  grind
#print axioms probe_7_414

-- ATTACK fc-379fc029-erdos949-erdos-949-5465ae622b-counterexample-v1 exact_search
theorem probe_7_415 : ¬ (fcTypeOfName% "Erdos949.erdos_949") := by
  exact?
#print axioms probe_7_415

-- ATTACK fc-379fc029-erdos949-erdos-949-5465ae622b-counterexample-v1 apply_search
theorem probe_7_416 : ¬ (fcTypeOfName% "Erdos949.erdos_949") := by
  apply?
#print axioms probe_7_416

-- ATTACK fc-379fc029-erdos949-erdos-949-5465ae622b-counterexample-v1 library_search
theorem probe_7_417 : ¬ (fcTypeOfName% "Erdos949.erdos_949") := by
  library_search
#print axioms probe_7_417

-- ATTACK fc-379fc029-erdos949-erdos-949-5465ae622b-counterexample-v1 aesop_search
theorem probe_7_418 : ¬ (fcTypeOfName% "Erdos949.erdos_949") := by
  aesop?
#print axioms probe_7_418

-- ATTACK fc-379fc029-erdos949-erdos-949-5465ae622b-counterexample-v1 simp_search
theorem probe_7_419 : ¬ (fcTypeOfName% "Erdos949.erdos_949") := by
  simp?
#print axioms probe_7_419

-- ATTACK fc-379fc029-erdos98-erdos-98-a793d966ae-counterexample-v1 simp
theorem probe_7_420 : ¬ (fcTypeOfName% "Erdos98.erdos_98") := by
  simp
#print axioms probe_7_420

-- ATTACK fc-379fc029-erdos98-erdos-98-a793d966ae-counterexample-v1 simpa
theorem probe_7_421 : ¬ (fcTypeOfName% "Erdos98.erdos_98") := by
  simpa
#print axioms probe_7_421

-- ATTACK fc-379fc029-erdos98-erdos-98-a793d966ae-counterexample-v1 simp_all
theorem probe_7_422 : ¬ (fcTypeOfName% "Erdos98.erdos_98") := by
  simp_all
#print axioms probe_7_422

-- ATTACK fc-379fc029-erdos98-erdos-98-a793d966ae-counterexample-v1 aesop
theorem probe_7_423 : ¬ (fcTypeOfName% "Erdos98.erdos_98") := by
  aesop
#print axioms probe_7_423

-- ATTACK fc-379fc029-erdos98-erdos-98-a793d966ae-counterexample-v1 omega
theorem probe_7_424 : ¬ (fcTypeOfName% "Erdos98.erdos_98") := by
  omega
#print axioms probe_7_424

-- ATTACK fc-379fc029-erdos98-erdos-98-a793d966ae-counterexample-v1 norm_num
theorem probe_7_425 : ¬ (fcTypeOfName% "Erdos98.erdos_98") := by
  norm_num
#print axioms probe_7_425

-- ATTACK fc-379fc029-erdos98-erdos-98-a793d966ae-counterexample-v1 decide
theorem probe_7_426 : ¬ (fcTypeOfName% "Erdos98.erdos_98") := by
  decide
#print axioms probe_7_426

-- ATTACK fc-379fc029-erdos98-erdos-98-a793d966ae-counterexample-v1 native_decide
theorem probe_7_427 : ¬ (fcTypeOfName% "Erdos98.erdos_98") := by
  native_decide
#print axioms probe_7_427

-- ATTACK fc-379fc029-erdos98-erdos-98-a793d966ae-counterexample-v1 true_intro
theorem probe_7_428 : ¬ (fcTypeOfName% "Erdos98.erdos_98") := by
  exact True.intro
#print axioms probe_7_428

-- ATTACK fc-379fc029-erdos98-erdos-98-a793d966ae-counterexample-v1 false_elim_simp
theorem probe_7_429 : ¬ (fcTypeOfName% "Erdos98.erdos_98") := by
  apply False.elim
  simp_all
#print axioms probe_7_429

-- ATTACK fc-379fc029-erdos98-erdos-98-a793d966ae-counterexample-v1 constructor
theorem probe_7_430 : ¬ (fcTypeOfName% "Erdos98.erdos_98") := by
  constructor
#print axioms probe_7_430

-- ATTACK fc-379fc029-erdos98-erdos-98-a793d966ae-counterexample-v1 constructor_simp
theorem probe_7_431 : ¬ (fcTypeOfName% "Erdos98.erdos_98") := by
  constructor <;> simp
#print axioms probe_7_431

-- ATTACK fc-379fc029-erdos98-erdos-98-a793d966ae-counterexample-v1 constructor_aesop
theorem probe_7_432 : ¬ (fcTypeOfName% "Erdos98.erdos_98") := by
  constructor <;> aesop
#print axioms probe_7_432

-- ATTACK fc-379fc029-erdos98-erdos-98-a793d966ae-counterexample-v1 rfl
theorem probe_7_433 : ¬ (fcTypeOfName% "Erdos98.erdos_98") := by
  rfl
#print axioms probe_7_433

-- ATTACK fc-379fc029-erdos98-erdos-98-a793d966ae-counterexample-v1 trivial
theorem probe_7_434 : ¬ (fcTypeOfName% "Erdos98.erdos_98") := by
  trivial
#print axioms probe_7_434

-- ATTACK fc-379fc029-erdos98-erdos-98-a793d966ae-counterexample-v1 tauto
theorem probe_7_435 : ¬ (fcTypeOfName% "Erdos98.erdos_98") := by
  tauto
#print axioms probe_7_435

-- ATTACK fc-379fc029-erdos98-erdos-98-a793d966ae-counterexample-v1 positivity
theorem probe_7_436 : ¬ (fcTypeOfName% "Erdos98.erdos_98") := by
  positivity
#print axioms probe_7_436

-- ATTACK fc-379fc029-erdos98-erdos-98-a793d966ae-counterexample-v1 linarith
theorem probe_7_437 : ¬ (fcTypeOfName% "Erdos98.erdos_98") := by
  linarith
#print axioms probe_7_437

-- ATTACK fc-379fc029-erdos98-erdos-98-a793d966ae-counterexample-v1 nlinarith
theorem probe_7_438 : ¬ (fcTypeOfName% "Erdos98.erdos_98") := by
  nlinarith
#print axioms probe_7_438

-- ATTACK fc-379fc029-erdos98-erdos-98-a793d966ae-counterexample-v1 intros_simp_all
theorem probe_7_439 : ¬ (fcTypeOfName% "Erdos98.erdos_98") := by
  intros
  simp_all
#print axioms probe_7_439

-- ATTACK fc-379fc029-erdos98-erdos-98-a793d966ae-counterexample-v1 intros_omega
theorem probe_7_440 : ¬ (fcTypeOfName% "Erdos98.erdos_98") := by
  intros
  omega
#print axioms probe_7_440

-- ATTACK fc-379fc029-erdos98-erdos-98-a793d966ae-counterexample-v1 intros_norm_num
theorem probe_7_441 : ¬ (fcTypeOfName% "Erdos98.erdos_98") := by
  intros
  norm_num at *
#print axioms probe_7_441

-- ATTACK fc-379fc029-erdos98-erdos-98-a793d966ae-counterexample-v1 intros_aesop
theorem probe_7_442 : ¬ (fcTypeOfName% "Erdos98.erdos_98") := by
  intros
  aesop
#print axioms probe_7_442

-- ATTACK fc-379fc029-erdos98-erdos-98-a793d966ae-counterexample-v1 by_contra_simp_all
theorem probe_7_443 : ¬ (fcTypeOfName% "Erdos98.erdos_98") := by
  by_contra h
  simp_all
#print axioms probe_7_443

-- ATTACK fc-379fc029-erdos98-erdos-98-a793d966ae-counterexample-v1 classical_simp_all
theorem probe_7_444 : ¬ (fcTypeOfName% "Erdos98.erdos_98") := by
  classical
  simp_all
#print axioms probe_7_444

-- ATTACK fc-379fc029-erdos98-erdos-98-a793d966ae-counterexample-v1 classical_aesop
theorem probe_7_445 : ¬ (fcTypeOfName% "Erdos98.erdos_98") := by
  classical
  aesop
#print axioms probe_7_445

-- ATTACK fc-379fc029-erdos98-erdos-98-a793d966ae-counterexample-v1 refine_pair_simp
theorem probe_7_446 : ¬ (fcTypeOfName% "Erdos98.erdos_98") := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_7_446

-- ATTACK fc-379fc029-erdos98-erdos-98-a793d966ae-counterexample-v1 refine_pair_aesop
theorem probe_7_447 : ¬ (fcTypeOfName% "Erdos98.erdos_98") := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_7_447

-- ATTACK fc-379fc029-erdos98-erdos-98-a793d966ae-counterexample-v1 use_zero_simp
theorem probe_7_448 : ¬ (fcTypeOfName% "Erdos98.erdos_98") := by
  use 0 <;> simp
#print axioms probe_7_448

-- ATTACK fc-379fc029-erdos98-erdos-98-a793d966ae-counterexample-v1 use_one_simp
theorem probe_7_449 : ¬ (fcTypeOfName% "Erdos98.erdos_98") := by
  use 1 <;> simp
#print axioms probe_7_449

-- ATTACK fc-379fc029-erdos98-erdos-98-a793d966ae-counterexample-v1 use_empty_simp
theorem probe_7_450 : ¬ (fcTypeOfName% "Erdos98.erdos_98") := by
  use ∅ <;> simp
#print axioms probe_7_450

-- ATTACK fc-379fc029-erdos98-erdos-98-a793d966ae-counterexample-v1 assumption
theorem probe_7_451 : ¬ (fcTypeOfName% "Erdos98.erdos_98") := by
  assumption
#print axioms probe_7_451

-- ATTACK fc-379fc029-erdos98-erdos-98-a793d966ae-counterexample-v1 infer_instance
theorem probe_7_452 : ¬ (fcTypeOfName% "Erdos98.erdos_98") := by
  infer_instance
#print axioms probe_7_452

-- ATTACK fc-379fc029-erdos98-erdos-98-a793d966ae-counterexample-v1 contradiction
theorem probe_7_453 : ¬ (fcTypeOfName% "Erdos98.erdos_98") := by
  contradiction
#print axioms probe_7_453

-- ATTACK fc-379fc029-erdos98-erdos-98-a793d966ae-counterexample-v1 solve_by_elim
theorem probe_7_454 : ¬ (fcTypeOfName% "Erdos98.erdos_98") := by
  solve_by_elim
#print axioms probe_7_454

-- ATTACK fc-379fc029-erdos98-erdos-98-a793d966ae-counterexample-v1 first_order
theorem probe_7_455 : ¬ (fcTypeOfName% "Erdos98.erdos_98") := by
  first_order
#print axioms probe_7_455

-- ATTACK fc-379fc029-erdos98-erdos-98-a793d966ae-counterexample-v1 grind
theorem probe_7_456 : ¬ (fcTypeOfName% "Erdos98.erdos_98") := by
  grind
#print axioms probe_7_456

-- ATTACK fc-379fc029-erdos98-erdos-98-a793d966ae-counterexample-v1 exact_search
theorem probe_7_457 : ¬ (fcTypeOfName% "Erdos98.erdos_98") := by
  exact?
#print axioms probe_7_457

-- ATTACK fc-379fc029-erdos98-erdos-98-a793d966ae-counterexample-v1 apply_search
theorem probe_7_458 : ¬ (fcTypeOfName% "Erdos98.erdos_98") := by
  apply?
#print axioms probe_7_458

-- ATTACK fc-379fc029-erdos98-erdos-98-a793d966ae-counterexample-v1 library_search
theorem probe_7_459 : ¬ (fcTypeOfName% "Erdos98.erdos_98") := by
  library_search
#print axioms probe_7_459

-- ATTACK fc-379fc029-erdos98-erdos-98-a793d966ae-counterexample-v1 aesop_search
theorem probe_7_460 : ¬ (fcTypeOfName% "Erdos98.erdos_98") := by
  aesop?
#print axioms probe_7_460

-- ATTACK fc-379fc029-erdos98-erdos-98-a793d966ae-counterexample-v1 simp_search
theorem probe_7_461 : ¬ (fcTypeOfName% "Erdos98.erdos_98") := by
  simp?
#print axioms probe_7_461

-- ATTACK fc-379fc029-green47-green-47-974053eeb7-counterexample-v1 simp
theorem probe_7_462 : ¬ (fcTypeOfName% "Green47.green_47") := by
  simp
#print axioms probe_7_462

-- ATTACK fc-379fc029-green47-green-47-974053eeb7-counterexample-v1 simpa
theorem probe_7_463 : ¬ (fcTypeOfName% "Green47.green_47") := by
  simpa
#print axioms probe_7_463

-- ATTACK fc-379fc029-green47-green-47-974053eeb7-counterexample-v1 simp_all
theorem probe_7_464 : ¬ (fcTypeOfName% "Green47.green_47") := by
  simp_all
#print axioms probe_7_464

-- ATTACK fc-379fc029-green47-green-47-974053eeb7-counterexample-v1 aesop
theorem probe_7_465 : ¬ (fcTypeOfName% "Green47.green_47") := by
  aesop
#print axioms probe_7_465

-- ATTACK fc-379fc029-green47-green-47-974053eeb7-counterexample-v1 omega
theorem probe_7_466 : ¬ (fcTypeOfName% "Green47.green_47") := by
  omega
#print axioms probe_7_466

-- ATTACK fc-379fc029-green47-green-47-974053eeb7-counterexample-v1 norm_num
theorem probe_7_467 : ¬ (fcTypeOfName% "Green47.green_47") := by
  norm_num
#print axioms probe_7_467

-- ATTACK fc-379fc029-green47-green-47-974053eeb7-counterexample-v1 decide
theorem probe_7_468 : ¬ (fcTypeOfName% "Green47.green_47") := by
  decide
#print axioms probe_7_468

-- ATTACK fc-379fc029-green47-green-47-974053eeb7-counterexample-v1 native_decide
theorem probe_7_469 : ¬ (fcTypeOfName% "Green47.green_47") := by
  native_decide
#print axioms probe_7_469

-- ATTACK fc-379fc029-green47-green-47-974053eeb7-counterexample-v1 true_intro
theorem probe_7_470 : ¬ (fcTypeOfName% "Green47.green_47") := by
  exact True.intro
#print axioms probe_7_470

-- ATTACK fc-379fc029-green47-green-47-974053eeb7-counterexample-v1 false_elim_simp
theorem probe_7_471 : ¬ (fcTypeOfName% "Green47.green_47") := by
  apply False.elim
  simp_all
#print axioms probe_7_471

-- ATTACK fc-379fc029-green47-green-47-974053eeb7-counterexample-v1 constructor
theorem probe_7_472 : ¬ (fcTypeOfName% "Green47.green_47") := by
  constructor
#print axioms probe_7_472

-- ATTACK fc-379fc029-green47-green-47-974053eeb7-counterexample-v1 constructor_simp
theorem probe_7_473 : ¬ (fcTypeOfName% "Green47.green_47") := by
  constructor <;> simp
#print axioms probe_7_473

-- ATTACK fc-379fc029-green47-green-47-974053eeb7-counterexample-v1 constructor_aesop
theorem probe_7_474 : ¬ (fcTypeOfName% "Green47.green_47") := by
  constructor <;> aesop
#print axioms probe_7_474

-- ATTACK fc-379fc029-green47-green-47-974053eeb7-counterexample-v1 rfl
theorem probe_7_475 : ¬ (fcTypeOfName% "Green47.green_47") := by
  rfl
#print axioms probe_7_475

-- ATTACK fc-379fc029-green47-green-47-974053eeb7-counterexample-v1 trivial
theorem probe_7_476 : ¬ (fcTypeOfName% "Green47.green_47") := by
  trivial
#print axioms probe_7_476

-- ATTACK fc-379fc029-green47-green-47-974053eeb7-counterexample-v1 tauto
theorem probe_7_477 : ¬ (fcTypeOfName% "Green47.green_47") := by
  tauto
#print axioms probe_7_477

-- ATTACK fc-379fc029-green47-green-47-974053eeb7-counterexample-v1 positivity
theorem probe_7_478 : ¬ (fcTypeOfName% "Green47.green_47") := by
  positivity
#print axioms probe_7_478

-- ATTACK fc-379fc029-green47-green-47-974053eeb7-counterexample-v1 linarith
theorem probe_7_479 : ¬ (fcTypeOfName% "Green47.green_47") := by
  linarith
#print axioms probe_7_479

-- ATTACK fc-379fc029-green47-green-47-974053eeb7-counterexample-v1 nlinarith
theorem probe_7_480 : ¬ (fcTypeOfName% "Green47.green_47") := by
  nlinarith
#print axioms probe_7_480

-- ATTACK fc-379fc029-green47-green-47-974053eeb7-counterexample-v1 intros_simp_all
theorem probe_7_481 : ¬ (fcTypeOfName% "Green47.green_47") := by
  intros
  simp_all
#print axioms probe_7_481

-- ATTACK fc-379fc029-green47-green-47-974053eeb7-counterexample-v1 intros_omega
theorem probe_7_482 : ¬ (fcTypeOfName% "Green47.green_47") := by
  intros
  omega
#print axioms probe_7_482

-- ATTACK fc-379fc029-green47-green-47-974053eeb7-counterexample-v1 intros_norm_num
theorem probe_7_483 : ¬ (fcTypeOfName% "Green47.green_47") := by
  intros
  norm_num at *
#print axioms probe_7_483

-- ATTACK fc-379fc029-green47-green-47-974053eeb7-counterexample-v1 intros_aesop
theorem probe_7_484 : ¬ (fcTypeOfName% "Green47.green_47") := by
  intros
  aesop
#print axioms probe_7_484

-- ATTACK fc-379fc029-green47-green-47-974053eeb7-counterexample-v1 by_contra_simp_all
theorem probe_7_485 : ¬ (fcTypeOfName% "Green47.green_47") := by
  by_contra h
  simp_all
#print axioms probe_7_485

-- ATTACK fc-379fc029-green47-green-47-974053eeb7-counterexample-v1 classical_simp_all
theorem probe_7_486 : ¬ (fcTypeOfName% "Green47.green_47") := by
  classical
  simp_all
#print axioms probe_7_486

-- ATTACK fc-379fc029-green47-green-47-974053eeb7-counterexample-v1 classical_aesop
theorem probe_7_487 : ¬ (fcTypeOfName% "Green47.green_47") := by
  classical
  aesop
#print axioms probe_7_487

-- ATTACK fc-379fc029-green47-green-47-974053eeb7-counterexample-v1 refine_pair_simp
theorem probe_7_488 : ¬ (fcTypeOfName% "Green47.green_47") := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_7_488

-- ATTACK fc-379fc029-green47-green-47-974053eeb7-counterexample-v1 refine_pair_aesop
theorem probe_7_489 : ¬ (fcTypeOfName% "Green47.green_47") := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_7_489

-- ATTACK fc-379fc029-green47-green-47-974053eeb7-counterexample-v1 use_zero_simp
theorem probe_7_490 : ¬ (fcTypeOfName% "Green47.green_47") := by
  use 0 <;> simp
#print axioms probe_7_490

-- ATTACK fc-379fc029-green47-green-47-974053eeb7-counterexample-v1 use_one_simp
theorem probe_7_491 : ¬ (fcTypeOfName% "Green47.green_47") := by
  use 1 <;> simp
#print axioms probe_7_491

-- ATTACK fc-379fc029-green47-green-47-974053eeb7-counterexample-v1 use_empty_simp
theorem probe_7_492 : ¬ (fcTypeOfName% "Green47.green_47") := by
  use ∅ <;> simp
#print axioms probe_7_492

-- ATTACK fc-379fc029-green47-green-47-974053eeb7-counterexample-v1 assumption
theorem probe_7_493 : ¬ (fcTypeOfName% "Green47.green_47") := by
  assumption
#print axioms probe_7_493

-- ATTACK fc-379fc029-green47-green-47-974053eeb7-counterexample-v1 infer_instance
theorem probe_7_494 : ¬ (fcTypeOfName% "Green47.green_47") := by
  infer_instance
#print axioms probe_7_494

-- ATTACK fc-379fc029-green47-green-47-974053eeb7-counterexample-v1 contradiction
theorem probe_7_495 : ¬ (fcTypeOfName% "Green47.green_47") := by
  contradiction
#print axioms probe_7_495

-- ATTACK fc-379fc029-green47-green-47-974053eeb7-counterexample-v1 solve_by_elim
theorem probe_7_496 : ¬ (fcTypeOfName% "Green47.green_47") := by
  solve_by_elim
#print axioms probe_7_496

-- ATTACK fc-379fc029-green47-green-47-974053eeb7-counterexample-v1 first_order
theorem probe_7_497 : ¬ (fcTypeOfName% "Green47.green_47") := by
  first_order
#print axioms probe_7_497

-- ATTACK fc-379fc029-green47-green-47-974053eeb7-counterexample-v1 grind
theorem probe_7_498 : ¬ (fcTypeOfName% "Green47.green_47") := by
  grind
#print axioms probe_7_498

-- ATTACK fc-379fc029-green47-green-47-974053eeb7-counterexample-v1 exact_search
theorem probe_7_499 : ¬ (fcTypeOfName% "Green47.green_47") := by
  exact?
#print axioms probe_7_499

-- ATTACK fc-379fc029-green47-green-47-974053eeb7-counterexample-v1 apply_search
theorem probe_7_500 : ¬ (fcTypeOfName% "Green47.green_47") := by
  apply?
#print axioms probe_7_500

-- ATTACK fc-379fc029-green47-green-47-974053eeb7-counterexample-v1 library_search
theorem probe_7_501 : ¬ (fcTypeOfName% "Green47.green_47") := by
  library_search
#print axioms probe_7_501

-- ATTACK fc-379fc029-green47-green-47-974053eeb7-counterexample-v1 aesop_search
theorem probe_7_502 : ¬ (fcTypeOfName% "Green47.green_47") := by
  aesop?
#print axioms probe_7_502

-- ATTACK fc-379fc029-green47-green-47-974053eeb7-counterexample-v1 simp_search
theorem probe_7_503 : ¬ (fcTypeOfName% "Green47.green_47") := by
  simp?
#print axioms probe_7_503

end AttackBattery
