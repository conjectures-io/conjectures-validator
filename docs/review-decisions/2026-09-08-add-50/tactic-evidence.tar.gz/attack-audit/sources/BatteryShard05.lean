import FormalConjectures.ErdosProblems.«1082»
import FormalConjectures.ErdosProblems.«124»
import FormalConjectures.ErdosProblems.«234»
import FormalConjectures.ErdosProblems.«30»
import FormalConjectures.ErdosProblems.«323»
import FormalConjectures.ErdosProblems.«413»
import FormalConjectures.ErdosProblems.«647»
import FormalConjectures.ErdosProblems.«770»
import FormalConjectures.ErdosProblems.«930»
import FormalConjectures.ErdosProblems.«944»
import FormalConjectures.ErdosProblems.«979»
import FormalConjectures.GreensOpenProblems.«44»
import TaskSupport

set_option maxHeartbeats 20000
namespace AttackBattery

-- ATTACK fc-379fc029-parts-i-e12e148b42-counterexample-v1 simp
theorem probe_5_0 : ¬ (fcTypeOfName% "Erdos1082.erdos_1082.parts.i") := by
  simp
#print axioms probe_5_0

-- ATTACK fc-379fc029-parts-i-e12e148b42-counterexample-v1 simpa
theorem probe_5_1 : ¬ (fcTypeOfName% "Erdos1082.erdos_1082.parts.i") := by
  simpa
#print axioms probe_5_1

-- ATTACK fc-379fc029-parts-i-e12e148b42-counterexample-v1 simp_all
theorem probe_5_2 : ¬ (fcTypeOfName% "Erdos1082.erdos_1082.parts.i") := by
  simp_all
#print axioms probe_5_2

-- ATTACK fc-379fc029-parts-i-e12e148b42-counterexample-v1 aesop
theorem probe_5_3 : ¬ (fcTypeOfName% "Erdos1082.erdos_1082.parts.i") := by
  aesop
#print axioms probe_5_3

-- ATTACK fc-379fc029-parts-i-e12e148b42-counterexample-v1 omega
theorem probe_5_4 : ¬ (fcTypeOfName% "Erdos1082.erdos_1082.parts.i") := by
  omega
#print axioms probe_5_4

-- ATTACK fc-379fc029-parts-i-e12e148b42-counterexample-v1 norm_num
theorem probe_5_5 : ¬ (fcTypeOfName% "Erdos1082.erdos_1082.parts.i") := by
  norm_num
#print axioms probe_5_5

-- ATTACK fc-379fc029-parts-i-e12e148b42-counterexample-v1 decide
theorem probe_5_6 : ¬ (fcTypeOfName% "Erdos1082.erdos_1082.parts.i") := by
  decide
#print axioms probe_5_6

-- ATTACK fc-379fc029-parts-i-e12e148b42-counterexample-v1 native_decide
theorem probe_5_7 : ¬ (fcTypeOfName% "Erdos1082.erdos_1082.parts.i") := by
  native_decide
#print axioms probe_5_7

-- ATTACK fc-379fc029-parts-i-e12e148b42-counterexample-v1 true_intro
theorem probe_5_8 : ¬ (fcTypeOfName% "Erdos1082.erdos_1082.parts.i") := by
  exact True.intro
#print axioms probe_5_8

-- ATTACK fc-379fc029-parts-i-e12e148b42-counterexample-v1 false_elim_simp
theorem probe_5_9 : ¬ (fcTypeOfName% "Erdos1082.erdos_1082.parts.i") := by
  apply False.elim
  simp_all
#print axioms probe_5_9

-- ATTACK fc-379fc029-parts-i-e12e148b42-counterexample-v1 constructor
theorem probe_5_10 : ¬ (fcTypeOfName% "Erdos1082.erdos_1082.parts.i") := by
  constructor
#print axioms probe_5_10

-- ATTACK fc-379fc029-parts-i-e12e148b42-counterexample-v1 constructor_simp
theorem probe_5_11 : ¬ (fcTypeOfName% "Erdos1082.erdos_1082.parts.i") := by
  constructor <;> simp
#print axioms probe_5_11

-- ATTACK fc-379fc029-parts-i-e12e148b42-counterexample-v1 constructor_aesop
theorem probe_5_12 : ¬ (fcTypeOfName% "Erdos1082.erdos_1082.parts.i") := by
  constructor <;> aesop
#print axioms probe_5_12

-- ATTACK fc-379fc029-parts-i-e12e148b42-counterexample-v1 rfl
theorem probe_5_13 : ¬ (fcTypeOfName% "Erdos1082.erdos_1082.parts.i") := by
  rfl
#print axioms probe_5_13

-- ATTACK fc-379fc029-parts-i-e12e148b42-counterexample-v1 trivial
theorem probe_5_14 : ¬ (fcTypeOfName% "Erdos1082.erdos_1082.parts.i") := by
  trivial
#print axioms probe_5_14

-- ATTACK fc-379fc029-parts-i-e12e148b42-counterexample-v1 tauto
theorem probe_5_15 : ¬ (fcTypeOfName% "Erdos1082.erdos_1082.parts.i") := by
  tauto
#print axioms probe_5_15

-- ATTACK fc-379fc029-parts-i-e12e148b42-counterexample-v1 positivity
theorem probe_5_16 : ¬ (fcTypeOfName% "Erdos1082.erdos_1082.parts.i") := by
  positivity
#print axioms probe_5_16

-- ATTACK fc-379fc029-parts-i-e12e148b42-counterexample-v1 linarith
theorem probe_5_17 : ¬ (fcTypeOfName% "Erdos1082.erdos_1082.parts.i") := by
  linarith
#print axioms probe_5_17

-- ATTACK fc-379fc029-parts-i-e12e148b42-counterexample-v1 nlinarith
theorem probe_5_18 : ¬ (fcTypeOfName% "Erdos1082.erdos_1082.parts.i") := by
  nlinarith
#print axioms probe_5_18

-- ATTACK fc-379fc029-parts-i-e12e148b42-counterexample-v1 intros_simp_all
theorem probe_5_19 : ¬ (fcTypeOfName% "Erdos1082.erdos_1082.parts.i") := by
  intros
  simp_all
#print axioms probe_5_19

-- ATTACK fc-379fc029-parts-i-e12e148b42-counterexample-v1 intros_omega
theorem probe_5_20 : ¬ (fcTypeOfName% "Erdos1082.erdos_1082.parts.i") := by
  intros
  omega
#print axioms probe_5_20

-- ATTACK fc-379fc029-parts-i-e12e148b42-counterexample-v1 intros_norm_num
theorem probe_5_21 : ¬ (fcTypeOfName% "Erdos1082.erdos_1082.parts.i") := by
  intros
  norm_num at *
#print axioms probe_5_21

-- ATTACK fc-379fc029-parts-i-e12e148b42-counterexample-v1 intros_aesop
theorem probe_5_22 : ¬ (fcTypeOfName% "Erdos1082.erdos_1082.parts.i") := by
  intros
  aesop
#print axioms probe_5_22

-- ATTACK fc-379fc029-parts-i-e12e148b42-counterexample-v1 by_contra_simp_all
theorem probe_5_23 : ¬ (fcTypeOfName% "Erdos1082.erdos_1082.parts.i") := by
  by_contra h
  simp_all
#print axioms probe_5_23

-- ATTACK fc-379fc029-parts-i-e12e148b42-counterexample-v1 classical_simp_all
theorem probe_5_24 : ¬ (fcTypeOfName% "Erdos1082.erdos_1082.parts.i") := by
  classical
  simp_all
#print axioms probe_5_24

-- ATTACK fc-379fc029-parts-i-e12e148b42-counterexample-v1 classical_aesop
theorem probe_5_25 : ¬ (fcTypeOfName% "Erdos1082.erdos_1082.parts.i") := by
  classical
  aesop
#print axioms probe_5_25

-- ATTACK fc-379fc029-parts-i-e12e148b42-counterexample-v1 refine_pair_simp
theorem probe_5_26 : ¬ (fcTypeOfName% "Erdos1082.erdos_1082.parts.i") := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_5_26

-- ATTACK fc-379fc029-parts-i-e12e148b42-counterexample-v1 refine_pair_aesop
theorem probe_5_27 : ¬ (fcTypeOfName% "Erdos1082.erdos_1082.parts.i") := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_5_27

-- ATTACK fc-379fc029-parts-i-e12e148b42-counterexample-v1 use_zero_simp
theorem probe_5_28 : ¬ (fcTypeOfName% "Erdos1082.erdos_1082.parts.i") := by
  use 0 <;> simp
#print axioms probe_5_28

-- ATTACK fc-379fc029-parts-i-e12e148b42-counterexample-v1 use_one_simp
theorem probe_5_29 : ¬ (fcTypeOfName% "Erdos1082.erdos_1082.parts.i") := by
  use 1 <;> simp
#print axioms probe_5_29

-- ATTACK fc-379fc029-parts-i-e12e148b42-counterexample-v1 use_empty_simp
theorem probe_5_30 : ¬ (fcTypeOfName% "Erdos1082.erdos_1082.parts.i") := by
  use ∅ <;> simp
#print axioms probe_5_30

-- ATTACK fc-379fc029-parts-i-e12e148b42-counterexample-v1 assumption
theorem probe_5_31 : ¬ (fcTypeOfName% "Erdos1082.erdos_1082.parts.i") := by
  assumption
#print axioms probe_5_31

-- ATTACK fc-379fc029-parts-i-e12e148b42-counterexample-v1 infer_instance
theorem probe_5_32 : ¬ (fcTypeOfName% "Erdos1082.erdos_1082.parts.i") := by
  infer_instance
#print axioms probe_5_32

-- ATTACK fc-379fc029-parts-i-e12e148b42-counterexample-v1 contradiction
theorem probe_5_33 : ¬ (fcTypeOfName% "Erdos1082.erdos_1082.parts.i") := by
  contradiction
#print axioms probe_5_33

-- ATTACK fc-379fc029-parts-i-e12e148b42-counterexample-v1 solve_by_elim
theorem probe_5_34 : ¬ (fcTypeOfName% "Erdos1082.erdos_1082.parts.i") := by
  solve_by_elim
#print axioms probe_5_34

-- ATTACK fc-379fc029-parts-i-e12e148b42-counterexample-v1 first_order
theorem probe_5_35 : ¬ (fcTypeOfName% "Erdos1082.erdos_1082.parts.i") := by
  first_order
#print axioms probe_5_35

-- ATTACK fc-379fc029-parts-i-e12e148b42-counterexample-v1 grind
theorem probe_5_36 : ¬ (fcTypeOfName% "Erdos1082.erdos_1082.parts.i") := by
  grind
#print axioms probe_5_36

-- ATTACK fc-379fc029-parts-i-e12e148b42-counterexample-v1 exact_search
theorem probe_5_37 : ¬ (fcTypeOfName% "Erdos1082.erdos_1082.parts.i") := by
  exact?
#print axioms probe_5_37

-- ATTACK fc-379fc029-parts-i-e12e148b42-counterexample-v1 apply_search
theorem probe_5_38 : ¬ (fcTypeOfName% "Erdos1082.erdos_1082.parts.i") := by
  apply?
#print axioms probe_5_38

-- ATTACK fc-379fc029-parts-i-e12e148b42-counterexample-v1 library_search
theorem probe_5_39 : ¬ (fcTypeOfName% "Erdos1082.erdos_1082.parts.i") := by
  library_search
#print axioms probe_5_39

-- ATTACK fc-379fc029-parts-i-e12e148b42-counterexample-v1 aesop_search
theorem probe_5_40 : ¬ (fcTypeOfName% "Erdos1082.erdos_1082.parts.i") := by
  aesop?
#print axioms probe_5_40

-- ATTACK fc-379fc029-parts-i-e12e148b42-counterexample-v1 simp_search
theorem probe_5_41 : ¬ (fcTypeOfName% "Erdos1082.erdos_1082.parts.i") := by
  simp?
#print axioms probe_5_41

-- ATTACK fc-379fc029-erdos124-ne-zero-5121119e55-counterexample-v1 simp
theorem probe_5_42 : ¬ (fcTypeOfName% "Erdos124.erdos124.ne_zero") := by
  simp
#print axioms probe_5_42

-- ATTACK fc-379fc029-erdos124-ne-zero-5121119e55-counterexample-v1 simpa
theorem probe_5_43 : ¬ (fcTypeOfName% "Erdos124.erdos124.ne_zero") := by
  simpa
#print axioms probe_5_43

-- ATTACK fc-379fc029-erdos124-ne-zero-5121119e55-counterexample-v1 simp_all
theorem probe_5_44 : ¬ (fcTypeOfName% "Erdos124.erdos124.ne_zero") := by
  simp_all
#print axioms probe_5_44

-- ATTACK fc-379fc029-erdos124-ne-zero-5121119e55-counterexample-v1 aesop
theorem probe_5_45 : ¬ (fcTypeOfName% "Erdos124.erdos124.ne_zero") := by
  aesop
#print axioms probe_5_45

-- ATTACK fc-379fc029-erdos124-ne-zero-5121119e55-counterexample-v1 omega
theorem probe_5_46 : ¬ (fcTypeOfName% "Erdos124.erdos124.ne_zero") := by
  omega
#print axioms probe_5_46

-- ATTACK fc-379fc029-erdos124-ne-zero-5121119e55-counterexample-v1 norm_num
theorem probe_5_47 : ¬ (fcTypeOfName% "Erdos124.erdos124.ne_zero") := by
  norm_num
#print axioms probe_5_47

-- ATTACK fc-379fc029-erdos124-ne-zero-5121119e55-counterexample-v1 decide
theorem probe_5_48 : ¬ (fcTypeOfName% "Erdos124.erdos124.ne_zero") := by
  decide
#print axioms probe_5_48

-- ATTACK fc-379fc029-erdos124-ne-zero-5121119e55-counterexample-v1 native_decide
theorem probe_5_49 : ¬ (fcTypeOfName% "Erdos124.erdos124.ne_zero") := by
  native_decide
#print axioms probe_5_49

-- ATTACK fc-379fc029-erdos124-ne-zero-5121119e55-counterexample-v1 true_intro
theorem probe_5_50 : ¬ (fcTypeOfName% "Erdos124.erdos124.ne_zero") := by
  exact True.intro
#print axioms probe_5_50

-- ATTACK fc-379fc029-erdos124-ne-zero-5121119e55-counterexample-v1 false_elim_simp
theorem probe_5_51 : ¬ (fcTypeOfName% "Erdos124.erdos124.ne_zero") := by
  apply False.elim
  simp_all
#print axioms probe_5_51

-- ATTACK fc-379fc029-erdos124-ne-zero-5121119e55-counterexample-v1 constructor
theorem probe_5_52 : ¬ (fcTypeOfName% "Erdos124.erdos124.ne_zero") := by
  constructor
#print axioms probe_5_52

-- ATTACK fc-379fc029-erdos124-ne-zero-5121119e55-counterexample-v1 constructor_simp
theorem probe_5_53 : ¬ (fcTypeOfName% "Erdos124.erdos124.ne_zero") := by
  constructor <;> simp
#print axioms probe_5_53

-- ATTACK fc-379fc029-erdos124-ne-zero-5121119e55-counterexample-v1 constructor_aesop
theorem probe_5_54 : ¬ (fcTypeOfName% "Erdos124.erdos124.ne_zero") := by
  constructor <;> aesop
#print axioms probe_5_54

-- ATTACK fc-379fc029-erdos124-ne-zero-5121119e55-counterexample-v1 rfl
theorem probe_5_55 : ¬ (fcTypeOfName% "Erdos124.erdos124.ne_zero") := by
  rfl
#print axioms probe_5_55

-- ATTACK fc-379fc029-erdos124-ne-zero-5121119e55-counterexample-v1 trivial
theorem probe_5_56 : ¬ (fcTypeOfName% "Erdos124.erdos124.ne_zero") := by
  trivial
#print axioms probe_5_56

-- ATTACK fc-379fc029-erdos124-ne-zero-5121119e55-counterexample-v1 tauto
theorem probe_5_57 : ¬ (fcTypeOfName% "Erdos124.erdos124.ne_zero") := by
  tauto
#print axioms probe_5_57

-- ATTACK fc-379fc029-erdos124-ne-zero-5121119e55-counterexample-v1 positivity
theorem probe_5_58 : ¬ (fcTypeOfName% "Erdos124.erdos124.ne_zero") := by
  positivity
#print axioms probe_5_58

-- ATTACK fc-379fc029-erdos124-ne-zero-5121119e55-counterexample-v1 linarith
theorem probe_5_59 : ¬ (fcTypeOfName% "Erdos124.erdos124.ne_zero") := by
  linarith
#print axioms probe_5_59

-- ATTACK fc-379fc029-erdos124-ne-zero-5121119e55-counterexample-v1 nlinarith
theorem probe_5_60 : ¬ (fcTypeOfName% "Erdos124.erdos124.ne_zero") := by
  nlinarith
#print axioms probe_5_60

-- ATTACK fc-379fc029-erdos124-ne-zero-5121119e55-counterexample-v1 intros_simp_all
theorem probe_5_61 : ¬ (fcTypeOfName% "Erdos124.erdos124.ne_zero") := by
  intros
  simp_all
#print axioms probe_5_61

-- ATTACK fc-379fc029-erdos124-ne-zero-5121119e55-counterexample-v1 intros_omega
theorem probe_5_62 : ¬ (fcTypeOfName% "Erdos124.erdos124.ne_zero") := by
  intros
  omega
#print axioms probe_5_62

-- ATTACK fc-379fc029-erdos124-ne-zero-5121119e55-counterexample-v1 intros_norm_num
theorem probe_5_63 : ¬ (fcTypeOfName% "Erdos124.erdos124.ne_zero") := by
  intros
  norm_num at *
#print axioms probe_5_63

-- ATTACK fc-379fc029-erdos124-ne-zero-5121119e55-counterexample-v1 intros_aesop
theorem probe_5_64 : ¬ (fcTypeOfName% "Erdos124.erdos124.ne_zero") := by
  intros
  aesop
#print axioms probe_5_64

-- ATTACK fc-379fc029-erdos124-ne-zero-5121119e55-counterexample-v1 by_contra_simp_all
theorem probe_5_65 : ¬ (fcTypeOfName% "Erdos124.erdos124.ne_zero") := by
  by_contra h
  simp_all
#print axioms probe_5_65

-- ATTACK fc-379fc029-erdos124-ne-zero-5121119e55-counterexample-v1 classical_simp_all
theorem probe_5_66 : ¬ (fcTypeOfName% "Erdos124.erdos124.ne_zero") := by
  classical
  simp_all
#print axioms probe_5_66

-- ATTACK fc-379fc029-erdos124-ne-zero-5121119e55-counterexample-v1 classical_aesop
theorem probe_5_67 : ¬ (fcTypeOfName% "Erdos124.erdos124.ne_zero") := by
  classical
  aesop
#print axioms probe_5_67

-- ATTACK fc-379fc029-erdos124-ne-zero-5121119e55-counterexample-v1 refine_pair_simp
theorem probe_5_68 : ¬ (fcTypeOfName% "Erdos124.erdos124.ne_zero") := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_5_68

-- ATTACK fc-379fc029-erdos124-ne-zero-5121119e55-counterexample-v1 refine_pair_aesop
theorem probe_5_69 : ¬ (fcTypeOfName% "Erdos124.erdos124.ne_zero") := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_5_69

-- ATTACK fc-379fc029-erdos124-ne-zero-5121119e55-counterexample-v1 use_zero_simp
theorem probe_5_70 : ¬ (fcTypeOfName% "Erdos124.erdos124.ne_zero") := by
  use 0 <;> simp
#print axioms probe_5_70

-- ATTACK fc-379fc029-erdos124-ne-zero-5121119e55-counterexample-v1 use_one_simp
theorem probe_5_71 : ¬ (fcTypeOfName% "Erdos124.erdos124.ne_zero") := by
  use 1 <;> simp
#print axioms probe_5_71

-- ATTACK fc-379fc029-erdos124-ne-zero-5121119e55-counterexample-v1 use_empty_simp
theorem probe_5_72 : ¬ (fcTypeOfName% "Erdos124.erdos124.ne_zero") := by
  use ∅ <;> simp
#print axioms probe_5_72

-- ATTACK fc-379fc029-erdos124-ne-zero-5121119e55-counterexample-v1 assumption
theorem probe_5_73 : ¬ (fcTypeOfName% "Erdos124.erdos124.ne_zero") := by
  assumption
#print axioms probe_5_73

-- ATTACK fc-379fc029-erdos124-ne-zero-5121119e55-counterexample-v1 infer_instance
theorem probe_5_74 : ¬ (fcTypeOfName% "Erdos124.erdos124.ne_zero") := by
  infer_instance
#print axioms probe_5_74

-- ATTACK fc-379fc029-erdos124-ne-zero-5121119e55-counterexample-v1 contradiction
theorem probe_5_75 : ¬ (fcTypeOfName% "Erdos124.erdos124.ne_zero") := by
  contradiction
#print axioms probe_5_75

-- ATTACK fc-379fc029-erdos124-ne-zero-5121119e55-counterexample-v1 solve_by_elim
theorem probe_5_76 : ¬ (fcTypeOfName% "Erdos124.erdos124.ne_zero") := by
  solve_by_elim
#print axioms probe_5_76

-- ATTACK fc-379fc029-erdos124-ne-zero-5121119e55-counterexample-v1 first_order
theorem probe_5_77 : ¬ (fcTypeOfName% "Erdos124.erdos124.ne_zero") := by
  first_order
#print axioms probe_5_77

-- ATTACK fc-379fc029-erdos124-ne-zero-5121119e55-counterexample-v1 grind
theorem probe_5_78 : ¬ (fcTypeOfName% "Erdos124.erdos124.ne_zero") := by
  grind
#print axioms probe_5_78

-- ATTACK fc-379fc029-erdos124-ne-zero-5121119e55-counterexample-v1 exact_search
theorem probe_5_79 : ¬ (fcTypeOfName% "Erdos124.erdos124.ne_zero") := by
  exact?
#print axioms probe_5_79

-- ATTACK fc-379fc029-erdos124-ne-zero-5121119e55-counterexample-v1 apply_search
theorem probe_5_80 : ¬ (fcTypeOfName% "Erdos124.erdos124.ne_zero") := by
  apply?
#print axioms probe_5_80

-- ATTACK fc-379fc029-erdos124-ne-zero-5121119e55-counterexample-v1 library_search
theorem probe_5_81 : ¬ (fcTypeOfName% "Erdos124.erdos124.ne_zero") := by
  library_search
#print axioms probe_5_81

-- ATTACK fc-379fc029-erdos124-ne-zero-5121119e55-counterexample-v1 aesop_search
theorem probe_5_82 : ¬ (fcTypeOfName% "Erdos124.erdos124.ne_zero") := by
  aesop?
#print axioms probe_5_82

-- ATTACK fc-379fc029-erdos124-ne-zero-5121119e55-counterexample-v1 simp_search
theorem probe_5_83 : ¬ (fcTypeOfName% "Erdos124.erdos124.ne_zero") := by
  simp?
#print axioms probe_5_83

-- ATTACK fc-379fc029-erdos234-erdos-234-6d7fde1f52-counterexample-v1 simp
theorem probe_5_84 : ¬ (fcTypeOfName% "Erdos234.erdos_234") := by
  simp
#print axioms probe_5_84

-- ATTACK fc-379fc029-erdos234-erdos-234-6d7fde1f52-counterexample-v1 simpa
theorem probe_5_85 : ¬ (fcTypeOfName% "Erdos234.erdos_234") := by
  simpa
#print axioms probe_5_85

-- ATTACK fc-379fc029-erdos234-erdos-234-6d7fde1f52-counterexample-v1 simp_all
theorem probe_5_86 : ¬ (fcTypeOfName% "Erdos234.erdos_234") := by
  simp_all
#print axioms probe_5_86

-- ATTACK fc-379fc029-erdos234-erdos-234-6d7fde1f52-counterexample-v1 aesop
theorem probe_5_87 : ¬ (fcTypeOfName% "Erdos234.erdos_234") := by
  aesop
#print axioms probe_5_87

-- ATTACK fc-379fc029-erdos234-erdos-234-6d7fde1f52-counterexample-v1 omega
theorem probe_5_88 : ¬ (fcTypeOfName% "Erdos234.erdos_234") := by
  omega
#print axioms probe_5_88

-- ATTACK fc-379fc029-erdos234-erdos-234-6d7fde1f52-counterexample-v1 norm_num
theorem probe_5_89 : ¬ (fcTypeOfName% "Erdos234.erdos_234") := by
  norm_num
#print axioms probe_5_89

-- ATTACK fc-379fc029-erdos234-erdos-234-6d7fde1f52-counterexample-v1 decide
theorem probe_5_90 : ¬ (fcTypeOfName% "Erdos234.erdos_234") := by
  decide
#print axioms probe_5_90

-- ATTACK fc-379fc029-erdos234-erdos-234-6d7fde1f52-counterexample-v1 native_decide
theorem probe_5_91 : ¬ (fcTypeOfName% "Erdos234.erdos_234") := by
  native_decide
#print axioms probe_5_91

-- ATTACK fc-379fc029-erdos234-erdos-234-6d7fde1f52-counterexample-v1 true_intro
theorem probe_5_92 : ¬ (fcTypeOfName% "Erdos234.erdos_234") := by
  exact True.intro
#print axioms probe_5_92

-- ATTACK fc-379fc029-erdos234-erdos-234-6d7fde1f52-counterexample-v1 false_elim_simp
theorem probe_5_93 : ¬ (fcTypeOfName% "Erdos234.erdos_234") := by
  apply False.elim
  simp_all
#print axioms probe_5_93

-- ATTACK fc-379fc029-erdos234-erdos-234-6d7fde1f52-counterexample-v1 constructor
theorem probe_5_94 : ¬ (fcTypeOfName% "Erdos234.erdos_234") := by
  constructor
#print axioms probe_5_94

-- ATTACK fc-379fc029-erdos234-erdos-234-6d7fde1f52-counterexample-v1 constructor_simp
theorem probe_5_95 : ¬ (fcTypeOfName% "Erdos234.erdos_234") := by
  constructor <;> simp
#print axioms probe_5_95

-- ATTACK fc-379fc029-erdos234-erdos-234-6d7fde1f52-counterexample-v1 constructor_aesop
theorem probe_5_96 : ¬ (fcTypeOfName% "Erdos234.erdos_234") := by
  constructor <;> aesop
#print axioms probe_5_96

-- ATTACK fc-379fc029-erdos234-erdos-234-6d7fde1f52-counterexample-v1 rfl
theorem probe_5_97 : ¬ (fcTypeOfName% "Erdos234.erdos_234") := by
  rfl
#print axioms probe_5_97

-- ATTACK fc-379fc029-erdos234-erdos-234-6d7fde1f52-counterexample-v1 trivial
theorem probe_5_98 : ¬ (fcTypeOfName% "Erdos234.erdos_234") := by
  trivial
#print axioms probe_5_98

-- ATTACK fc-379fc029-erdos234-erdos-234-6d7fde1f52-counterexample-v1 tauto
theorem probe_5_99 : ¬ (fcTypeOfName% "Erdos234.erdos_234") := by
  tauto
#print axioms probe_5_99

-- ATTACK fc-379fc029-erdos234-erdos-234-6d7fde1f52-counterexample-v1 positivity
theorem probe_5_100 : ¬ (fcTypeOfName% "Erdos234.erdos_234") := by
  positivity
#print axioms probe_5_100

-- ATTACK fc-379fc029-erdos234-erdos-234-6d7fde1f52-counterexample-v1 linarith
theorem probe_5_101 : ¬ (fcTypeOfName% "Erdos234.erdos_234") := by
  linarith
#print axioms probe_5_101

-- ATTACK fc-379fc029-erdos234-erdos-234-6d7fde1f52-counterexample-v1 nlinarith
theorem probe_5_102 : ¬ (fcTypeOfName% "Erdos234.erdos_234") := by
  nlinarith
#print axioms probe_5_102

-- ATTACK fc-379fc029-erdos234-erdos-234-6d7fde1f52-counterexample-v1 intros_simp_all
theorem probe_5_103 : ¬ (fcTypeOfName% "Erdos234.erdos_234") := by
  intros
  simp_all
#print axioms probe_5_103

-- ATTACK fc-379fc029-erdos234-erdos-234-6d7fde1f52-counterexample-v1 intros_omega
theorem probe_5_104 : ¬ (fcTypeOfName% "Erdos234.erdos_234") := by
  intros
  omega
#print axioms probe_5_104

-- ATTACK fc-379fc029-erdos234-erdos-234-6d7fde1f52-counterexample-v1 intros_norm_num
theorem probe_5_105 : ¬ (fcTypeOfName% "Erdos234.erdos_234") := by
  intros
  norm_num at *
#print axioms probe_5_105

-- ATTACK fc-379fc029-erdos234-erdos-234-6d7fde1f52-counterexample-v1 intros_aesop
theorem probe_5_106 : ¬ (fcTypeOfName% "Erdos234.erdos_234") := by
  intros
  aesop
#print axioms probe_5_106

-- ATTACK fc-379fc029-erdos234-erdos-234-6d7fde1f52-counterexample-v1 by_contra_simp_all
theorem probe_5_107 : ¬ (fcTypeOfName% "Erdos234.erdos_234") := by
  by_contra h
  simp_all
#print axioms probe_5_107

-- ATTACK fc-379fc029-erdos234-erdos-234-6d7fde1f52-counterexample-v1 classical_simp_all
theorem probe_5_108 : ¬ (fcTypeOfName% "Erdos234.erdos_234") := by
  classical
  simp_all
#print axioms probe_5_108

-- ATTACK fc-379fc029-erdos234-erdos-234-6d7fde1f52-counterexample-v1 classical_aesop
theorem probe_5_109 : ¬ (fcTypeOfName% "Erdos234.erdos_234") := by
  classical
  aesop
#print axioms probe_5_109

-- ATTACK fc-379fc029-erdos234-erdos-234-6d7fde1f52-counterexample-v1 refine_pair_simp
theorem probe_5_110 : ¬ (fcTypeOfName% "Erdos234.erdos_234") := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_5_110

-- ATTACK fc-379fc029-erdos234-erdos-234-6d7fde1f52-counterexample-v1 refine_pair_aesop
theorem probe_5_111 : ¬ (fcTypeOfName% "Erdos234.erdos_234") := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_5_111

-- ATTACK fc-379fc029-erdos234-erdos-234-6d7fde1f52-counterexample-v1 use_zero_simp
theorem probe_5_112 : ¬ (fcTypeOfName% "Erdos234.erdos_234") := by
  use 0 <;> simp
#print axioms probe_5_112

-- ATTACK fc-379fc029-erdos234-erdos-234-6d7fde1f52-counterexample-v1 use_one_simp
theorem probe_5_113 : ¬ (fcTypeOfName% "Erdos234.erdos_234") := by
  use 1 <;> simp
#print axioms probe_5_113

-- ATTACK fc-379fc029-erdos234-erdos-234-6d7fde1f52-counterexample-v1 use_empty_simp
theorem probe_5_114 : ¬ (fcTypeOfName% "Erdos234.erdos_234") := by
  use ∅ <;> simp
#print axioms probe_5_114

-- ATTACK fc-379fc029-erdos234-erdos-234-6d7fde1f52-counterexample-v1 assumption
theorem probe_5_115 : ¬ (fcTypeOfName% "Erdos234.erdos_234") := by
  assumption
#print axioms probe_5_115

-- ATTACK fc-379fc029-erdos234-erdos-234-6d7fde1f52-counterexample-v1 infer_instance
theorem probe_5_116 : ¬ (fcTypeOfName% "Erdos234.erdos_234") := by
  infer_instance
#print axioms probe_5_116

-- ATTACK fc-379fc029-erdos234-erdos-234-6d7fde1f52-counterexample-v1 contradiction
theorem probe_5_117 : ¬ (fcTypeOfName% "Erdos234.erdos_234") := by
  contradiction
#print axioms probe_5_117

-- ATTACK fc-379fc029-erdos234-erdos-234-6d7fde1f52-counterexample-v1 solve_by_elim
theorem probe_5_118 : ¬ (fcTypeOfName% "Erdos234.erdos_234") := by
  solve_by_elim
#print axioms probe_5_118

-- ATTACK fc-379fc029-erdos234-erdos-234-6d7fde1f52-counterexample-v1 first_order
theorem probe_5_119 : ¬ (fcTypeOfName% "Erdos234.erdos_234") := by
  first_order
#print axioms probe_5_119

-- ATTACK fc-379fc029-erdos234-erdos-234-6d7fde1f52-counterexample-v1 grind
theorem probe_5_120 : ¬ (fcTypeOfName% "Erdos234.erdos_234") := by
  grind
#print axioms probe_5_120

-- ATTACK fc-379fc029-erdos234-erdos-234-6d7fde1f52-counterexample-v1 exact_search
theorem probe_5_121 : ¬ (fcTypeOfName% "Erdos234.erdos_234") := by
  exact?
#print axioms probe_5_121

-- ATTACK fc-379fc029-erdos234-erdos-234-6d7fde1f52-counterexample-v1 apply_search
theorem probe_5_122 : ¬ (fcTypeOfName% "Erdos234.erdos_234") := by
  apply?
#print axioms probe_5_122

-- ATTACK fc-379fc029-erdos234-erdos-234-6d7fde1f52-counterexample-v1 library_search
theorem probe_5_123 : ¬ (fcTypeOfName% "Erdos234.erdos_234") := by
  library_search
#print axioms probe_5_123

-- ATTACK fc-379fc029-erdos234-erdos-234-6d7fde1f52-counterexample-v1 aesop_search
theorem probe_5_124 : ¬ (fcTypeOfName% "Erdos234.erdos_234") := by
  aesop?
#print axioms probe_5_124

-- ATTACK fc-379fc029-erdos234-erdos-234-6d7fde1f52-counterexample-v1 simp_search
theorem probe_5_125 : ¬ (fcTypeOfName% "Erdos234.erdos_234") := by
  simp?
#print axioms probe_5_125

-- ATTACK fc-379fc029-erdos30-erdos-30-a8bf6e6ade-counterexample-v1 simp
theorem probe_5_126 : ¬ (fcTypeOfName% "Erdos30.erdos_30") := by
  simp
#print axioms probe_5_126

-- ATTACK fc-379fc029-erdos30-erdos-30-a8bf6e6ade-counterexample-v1 simpa
theorem probe_5_127 : ¬ (fcTypeOfName% "Erdos30.erdos_30") := by
  simpa
#print axioms probe_5_127

-- ATTACK fc-379fc029-erdos30-erdos-30-a8bf6e6ade-counterexample-v1 simp_all
theorem probe_5_128 : ¬ (fcTypeOfName% "Erdos30.erdos_30") := by
  simp_all
#print axioms probe_5_128

-- ATTACK fc-379fc029-erdos30-erdos-30-a8bf6e6ade-counterexample-v1 aesop
theorem probe_5_129 : ¬ (fcTypeOfName% "Erdos30.erdos_30") := by
  aesop
#print axioms probe_5_129

-- ATTACK fc-379fc029-erdos30-erdos-30-a8bf6e6ade-counterexample-v1 omega
theorem probe_5_130 : ¬ (fcTypeOfName% "Erdos30.erdos_30") := by
  omega
#print axioms probe_5_130

-- ATTACK fc-379fc029-erdos30-erdos-30-a8bf6e6ade-counterexample-v1 norm_num
theorem probe_5_131 : ¬ (fcTypeOfName% "Erdos30.erdos_30") := by
  norm_num
#print axioms probe_5_131

-- ATTACK fc-379fc029-erdos30-erdos-30-a8bf6e6ade-counterexample-v1 decide
theorem probe_5_132 : ¬ (fcTypeOfName% "Erdos30.erdos_30") := by
  decide
#print axioms probe_5_132

-- ATTACK fc-379fc029-erdos30-erdos-30-a8bf6e6ade-counterexample-v1 native_decide
theorem probe_5_133 : ¬ (fcTypeOfName% "Erdos30.erdos_30") := by
  native_decide
#print axioms probe_5_133

-- ATTACK fc-379fc029-erdos30-erdos-30-a8bf6e6ade-counterexample-v1 true_intro
theorem probe_5_134 : ¬ (fcTypeOfName% "Erdos30.erdos_30") := by
  exact True.intro
#print axioms probe_5_134

-- ATTACK fc-379fc029-erdos30-erdos-30-a8bf6e6ade-counterexample-v1 false_elim_simp
theorem probe_5_135 : ¬ (fcTypeOfName% "Erdos30.erdos_30") := by
  apply False.elim
  simp_all
#print axioms probe_5_135

-- ATTACK fc-379fc029-erdos30-erdos-30-a8bf6e6ade-counterexample-v1 constructor
theorem probe_5_136 : ¬ (fcTypeOfName% "Erdos30.erdos_30") := by
  constructor
#print axioms probe_5_136

-- ATTACK fc-379fc029-erdos30-erdos-30-a8bf6e6ade-counterexample-v1 constructor_simp
theorem probe_5_137 : ¬ (fcTypeOfName% "Erdos30.erdos_30") := by
  constructor <;> simp
#print axioms probe_5_137

-- ATTACK fc-379fc029-erdos30-erdos-30-a8bf6e6ade-counterexample-v1 constructor_aesop
theorem probe_5_138 : ¬ (fcTypeOfName% "Erdos30.erdos_30") := by
  constructor <;> aesop
#print axioms probe_5_138

-- ATTACK fc-379fc029-erdos30-erdos-30-a8bf6e6ade-counterexample-v1 rfl
theorem probe_5_139 : ¬ (fcTypeOfName% "Erdos30.erdos_30") := by
  rfl
#print axioms probe_5_139

-- ATTACK fc-379fc029-erdos30-erdos-30-a8bf6e6ade-counterexample-v1 trivial
theorem probe_5_140 : ¬ (fcTypeOfName% "Erdos30.erdos_30") := by
  trivial
#print axioms probe_5_140

-- ATTACK fc-379fc029-erdos30-erdos-30-a8bf6e6ade-counterexample-v1 tauto
theorem probe_5_141 : ¬ (fcTypeOfName% "Erdos30.erdos_30") := by
  tauto
#print axioms probe_5_141

-- ATTACK fc-379fc029-erdos30-erdos-30-a8bf6e6ade-counterexample-v1 positivity
theorem probe_5_142 : ¬ (fcTypeOfName% "Erdos30.erdos_30") := by
  positivity
#print axioms probe_5_142

-- ATTACK fc-379fc029-erdos30-erdos-30-a8bf6e6ade-counterexample-v1 linarith
theorem probe_5_143 : ¬ (fcTypeOfName% "Erdos30.erdos_30") := by
  linarith
#print axioms probe_5_143

-- ATTACK fc-379fc029-erdos30-erdos-30-a8bf6e6ade-counterexample-v1 nlinarith
theorem probe_5_144 : ¬ (fcTypeOfName% "Erdos30.erdos_30") := by
  nlinarith
#print axioms probe_5_144

-- ATTACK fc-379fc029-erdos30-erdos-30-a8bf6e6ade-counterexample-v1 intros_simp_all
theorem probe_5_145 : ¬ (fcTypeOfName% "Erdos30.erdos_30") := by
  intros
  simp_all
#print axioms probe_5_145

-- ATTACK fc-379fc029-erdos30-erdos-30-a8bf6e6ade-counterexample-v1 intros_omega
theorem probe_5_146 : ¬ (fcTypeOfName% "Erdos30.erdos_30") := by
  intros
  omega
#print axioms probe_5_146

-- ATTACK fc-379fc029-erdos30-erdos-30-a8bf6e6ade-counterexample-v1 intros_norm_num
theorem probe_5_147 : ¬ (fcTypeOfName% "Erdos30.erdos_30") := by
  intros
  norm_num at *
#print axioms probe_5_147

-- ATTACK fc-379fc029-erdos30-erdos-30-a8bf6e6ade-counterexample-v1 intros_aesop
theorem probe_5_148 : ¬ (fcTypeOfName% "Erdos30.erdos_30") := by
  intros
  aesop
#print axioms probe_5_148

-- ATTACK fc-379fc029-erdos30-erdos-30-a8bf6e6ade-counterexample-v1 by_contra_simp_all
theorem probe_5_149 : ¬ (fcTypeOfName% "Erdos30.erdos_30") := by
  by_contra h
  simp_all
#print axioms probe_5_149

-- ATTACK fc-379fc029-erdos30-erdos-30-a8bf6e6ade-counterexample-v1 classical_simp_all
theorem probe_5_150 : ¬ (fcTypeOfName% "Erdos30.erdos_30") := by
  classical
  simp_all
#print axioms probe_5_150

-- ATTACK fc-379fc029-erdos30-erdos-30-a8bf6e6ade-counterexample-v1 classical_aesop
theorem probe_5_151 : ¬ (fcTypeOfName% "Erdos30.erdos_30") := by
  classical
  aesop
#print axioms probe_5_151

-- ATTACK fc-379fc029-erdos30-erdos-30-a8bf6e6ade-counterexample-v1 refine_pair_simp
theorem probe_5_152 : ¬ (fcTypeOfName% "Erdos30.erdos_30") := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_5_152

-- ATTACK fc-379fc029-erdos30-erdos-30-a8bf6e6ade-counterexample-v1 refine_pair_aesop
theorem probe_5_153 : ¬ (fcTypeOfName% "Erdos30.erdos_30") := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_5_153

-- ATTACK fc-379fc029-erdos30-erdos-30-a8bf6e6ade-counterexample-v1 use_zero_simp
theorem probe_5_154 : ¬ (fcTypeOfName% "Erdos30.erdos_30") := by
  use 0 <;> simp
#print axioms probe_5_154

-- ATTACK fc-379fc029-erdos30-erdos-30-a8bf6e6ade-counterexample-v1 use_one_simp
theorem probe_5_155 : ¬ (fcTypeOfName% "Erdos30.erdos_30") := by
  use 1 <;> simp
#print axioms probe_5_155

-- ATTACK fc-379fc029-erdos30-erdos-30-a8bf6e6ade-counterexample-v1 use_empty_simp
theorem probe_5_156 : ¬ (fcTypeOfName% "Erdos30.erdos_30") := by
  use ∅ <;> simp
#print axioms probe_5_156

-- ATTACK fc-379fc029-erdos30-erdos-30-a8bf6e6ade-counterexample-v1 assumption
theorem probe_5_157 : ¬ (fcTypeOfName% "Erdos30.erdos_30") := by
  assumption
#print axioms probe_5_157

-- ATTACK fc-379fc029-erdos30-erdos-30-a8bf6e6ade-counterexample-v1 infer_instance
theorem probe_5_158 : ¬ (fcTypeOfName% "Erdos30.erdos_30") := by
  infer_instance
#print axioms probe_5_158

-- ATTACK fc-379fc029-erdos30-erdos-30-a8bf6e6ade-counterexample-v1 contradiction
theorem probe_5_159 : ¬ (fcTypeOfName% "Erdos30.erdos_30") := by
  contradiction
#print axioms probe_5_159

-- ATTACK fc-379fc029-erdos30-erdos-30-a8bf6e6ade-counterexample-v1 solve_by_elim
theorem probe_5_160 : ¬ (fcTypeOfName% "Erdos30.erdos_30") := by
  solve_by_elim
#print axioms probe_5_160

-- ATTACK fc-379fc029-erdos30-erdos-30-a8bf6e6ade-counterexample-v1 first_order
theorem probe_5_161 : ¬ (fcTypeOfName% "Erdos30.erdos_30") := by
  first_order
#print axioms probe_5_161

-- ATTACK fc-379fc029-erdos30-erdos-30-a8bf6e6ade-counterexample-v1 grind
theorem probe_5_162 : ¬ (fcTypeOfName% "Erdos30.erdos_30") := by
  grind
#print axioms probe_5_162

-- ATTACK fc-379fc029-erdos30-erdos-30-a8bf6e6ade-counterexample-v1 exact_search
theorem probe_5_163 : ¬ (fcTypeOfName% "Erdos30.erdos_30") := by
  exact?
#print axioms probe_5_163

-- ATTACK fc-379fc029-erdos30-erdos-30-a8bf6e6ade-counterexample-v1 apply_search
theorem probe_5_164 : ¬ (fcTypeOfName% "Erdos30.erdos_30") := by
  apply?
#print axioms probe_5_164

-- ATTACK fc-379fc029-erdos30-erdos-30-a8bf6e6ade-counterexample-v1 library_search
theorem probe_5_165 : ¬ (fcTypeOfName% "Erdos30.erdos_30") := by
  library_search
#print axioms probe_5_165

-- ATTACK fc-379fc029-erdos30-erdos-30-a8bf6e6ade-counterexample-v1 aesop_search
theorem probe_5_166 : ¬ (fcTypeOfName% "Erdos30.erdos_30") := by
  aesop?
#print axioms probe_5_166

-- ATTACK fc-379fc029-erdos30-erdos-30-a8bf6e6ade-counterexample-v1 simp_search
theorem probe_5_167 : ¬ (fcTypeOfName% "Erdos30.erdos_30") := by
  simp?
#print axioms probe_5_167

-- ATTACK fc-379fc029-parts-i-e1dc546654-counterexample-v1 simp
theorem probe_5_168 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.i") := by
  simp
#print axioms probe_5_168

-- ATTACK fc-379fc029-parts-i-e1dc546654-counterexample-v1 simpa
theorem probe_5_169 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.i") := by
  simpa
#print axioms probe_5_169

-- ATTACK fc-379fc029-parts-i-e1dc546654-counterexample-v1 simp_all
theorem probe_5_170 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.i") := by
  simp_all
#print axioms probe_5_170

-- ATTACK fc-379fc029-parts-i-e1dc546654-counterexample-v1 aesop
theorem probe_5_171 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.i") := by
  aesop
#print axioms probe_5_171

-- ATTACK fc-379fc029-parts-i-e1dc546654-counterexample-v1 omega
theorem probe_5_172 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.i") := by
  omega
#print axioms probe_5_172

-- ATTACK fc-379fc029-parts-i-e1dc546654-counterexample-v1 norm_num
theorem probe_5_173 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.i") := by
  norm_num
#print axioms probe_5_173

-- ATTACK fc-379fc029-parts-i-e1dc546654-counterexample-v1 decide
theorem probe_5_174 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.i") := by
  decide
#print axioms probe_5_174

-- ATTACK fc-379fc029-parts-i-e1dc546654-counterexample-v1 native_decide
theorem probe_5_175 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.i") := by
  native_decide
#print axioms probe_5_175

-- ATTACK fc-379fc029-parts-i-e1dc546654-counterexample-v1 true_intro
theorem probe_5_176 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.i") := by
  exact True.intro
#print axioms probe_5_176

-- ATTACK fc-379fc029-parts-i-e1dc546654-counterexample-v1 false_elim_simp
theorem probe_5_177 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.i") := by
  apply False.elim
  simp_all
#print axioms probe_5_177

-- ATTACK fc-379fc029-parts-i-e1dc546654-counterexample-v1 constructor
theorem probe_5_178 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.i") := by
  constructor
#print axioms probe_5_178

-- ATTACK fc-379fc029-parts-i-e1dc546654-counterexample-v1 constructor_simp
theorem probe_5_179 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.i") := by
  constructor <;> simp
#print axioms probe_5_179

-- ATTACK fc-379fc029-parts-i-e1dc546654-counterexample-v1 constructor_aesop
theorem probe_5_180 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.i") := by
  constructor <;> aesop
#print axioms probe_5_180

-- ATTACK fc-379fc029-parts-i-e1dc546654-counterexample-v1 rfl
theorem probe_5_181 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.i") := by
  rfl
#print axioms probe_5_181

-- ATTACK fc-379fc029-parts-i-e1dc546654-counterexample-v1 trivial
theorem probe_5_182 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.i") := by
  trivial
#print axioms probe_5_182

-- ATTACK fc-379fc029-parts-i-e1dc546654-counterexample-v1 tauto
theorem probe_5_183 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.i") := by
  tauto
#print axioms probe_5_183

-- ATTACK fc-379fc029-parts-i-e1dc546654-counterexample-v1 positivity
theorem probe_5_184 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.i") := by
  positivity
#print axioms probe_5_184

-- ATTACK fc-379fc029-parts-i-e1dc546654-counterexample-v1 linarith
theorem probe_5_185 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.i") := by
  linarith
#print axioms probe_5_185

-- ATTACK fc-379fc029-parts-i-e1dc546654-counterexample-v1 nlinarith
theorem probe_5_186 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.i") := by
  nlinarith
#print axioms probe_5_186

-- ATTACK fc-379fc029-parts-i-e1dc546654-counterexample-v1 intros_simp_all
theorem probe_5_187 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.i") := by
  intros
  simp_all
#print axioms probe_5_187

-- ATTACK fc-379fc029-parts-i-e1dc546654-counterexample-v1 intros_omega
theorem probe_5_188 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.i") := by
  intros
  omega
#print axioms probe_5_188

-- ATTACK fc-379fc029-parts-i-e1dc546654-counterexample-v1 intros_norm_num
theorem probe_5_189 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.i") := by
  intros
  norm_num at *
#print axioms probe_5_189

-- ATTACK fc-379fc029-parts-i-e1dc546654-counterexample-v1 intros_aesop
theorem probe_5_190 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.i") := by
  intros
  aesop
#print axioms probe_5_190

-- ATTACK fc-379fc029-parts-i-e1dc546654-counterexample-v1 by_contra_simp_all
theorem probe_5_191 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.i") := by
  by_contra h
  simp_all
#print axioms probe_5_191

-- ATTACK fc-379fc029-parts-i-e1dc546654-counterexample-v1 classical_simp_all
theorem probe_5_192 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.i") := by
  classical
  simp_all
#print axioms probe_5_192

-- ATTACK fc-379fc029-parts-i-e1dc546654-counterexample-v1 classical_aesop
theorem probe_5_193 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.i") := by
  classical
  aesop
#print axioms probe_5_193

-- ATTACK fc-379fc029-parts-i-e1dc546654-counterexample-v1 refine_pair_simp
theorem probe_5_194 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.i") := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_5_194

-- ATTACK fc-379fc029-parts-i-e1dc546654-counterexample-v1 refine_pair_aesop
theorem probe_5_195 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.i") := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_5_195

-- ATTACK fc-379fc029-parts-i-e1dc546654-counterexample-v1 use_zero_simp
theorem probe_5_196 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.i") := by
  use 0 <;> simp
#print axioms probe_5_196

-- ATTACK fc-379fc029-parts-i-e1dc546654-counterexample-v1 use_one_simp
theorem probe_5_197 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.i") := by
  use 1 <;> simp
#print axioms probe_5_197

-- ATTACK fc-379fc029-parts-i-e1dc546654-counterexample-v1 use_empty_simp
theorem probe_5_198 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.i") := by
  use ∅ <;> simp
#print axioms probe_5_198

-- ATTACK fc-379fc029-parts-i-e1dc546654-counterexample-v1 assumption
theorem probe_5_199 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.i") := by
  assumption
#print axioms probe_5_199

-- ATTACK fc-379fc029-parts-i-e1dc546654-counterexample-v1 infer_instance
theorem probe_5_200 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.i") := by
  infer_instance
#print axioms probe_5_200

-- ATTACK fc-379fc029-parts-i-e1dc546654-counterexample-v1 contradiction
theorem probe_5_201 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.i") := by
  contradiction
#print axioms probe_5_201

-- ATTACK fc-379fc029-parts-i-e1dc546654-counterexample-v1 solve_by_elim
theorem probe_5_202 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.i") := by
  solve_by_elim
#print axioms probe_5_202

-- ATTACK fc-379fc029-parts-i-e1dc546654-counterexample-v1 first_order
theorem probe_5_203 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.i") := by
  first_order
#print axioms probe_5_203

-- ATTACK fc-379fc029-parts-i-e1dc546654-counterexample-v1 grind
theorem probe_5_204 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.i") := by
  grind
#print axioms probe_5_204

-- ATTACK fc-379fc029-parts-i-e1dc546654-counterexample-v1 exact_search
theorem probe_5_205 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.i") := by
  exact?
#print axioms probe_5_205

-- ATTACK fc-379fc029-parts-i-e1dc546654-counterexample-v1 apply_search
theorem probe_5_206 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.i") := by
  apply?
#print axioms probe_5_206

-- ATTACK fc-379fc029-parts-i-e1dc546654-counterexample-v1 library_search
theorem probe_5_207 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.i") := by
  library_search
#print axioms probe_5_207

-- ATTACK fc-379fc029-parts-i-e1dc546654-counterexample-v1 aesop_search
theorem probe_5_208 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.i") := by
  aesop?
#print axioms probe_5_208

-- ATTACK fc-379fc029-parts-i-e1dc546654-counterexample-v1 simp_search
theorem probe_5_209 : ¬ (fcTypeOfName% "Erdos323.erdos_323.parts.i") := by
  simp?
#print axioms probe_5_209

-- ATTACK fc-379fc029-parts-i-f1c95300ca-counterexample-v1 simp
theorem probe_5_210 : ¬ (fcTypeOfName% "Erdos413.erdos_413.parts.i") := by
  simp
#print axioms probe_5_210

-- ATTACK fc-379fc029-parts-i-f1c95300ca-counterexample-v1 simpa
theorem probe_5_211 : ¬ (fcTypeOfName% "Erdos413.erdos_413.parts.i") := by
  simpa
#print axioms probe_5_211

-- ATTACK fc-379fc029-parts-i-f1c95300ca-counterexample-v1 simp_all
theorem probe_5_212 : ¬ (fcTypeOfName% "Erdos413.erdos_413.parts.i") := by
  simp_all
#print axioms probe_5_212

-- ATTACK fc-379fc029-parts-i-f1c95300ca-counterexample-v1 aesop
theorem probe_5_213 : ¬ (fcTypeOfName% "Erdos413.erdos_413.parts.i") := by
  aesop
#print axioms probe_5_213

-- ATTACK fc-379fc029-parts-i-f1c95300ca-counterexample-v1 omega
theorem probe_5_214 : ¬ (fcTypeOfName% "Erdos413.erdos_413.parts.i") := by
  omega
#print axioms probe_5_214

-- ATTACK fc-379fc029-parts-i-f1c95300ca-counterexample-v1 norm_num
theorem probe_5_215 : ¬ (fcTypeOfName% "Erdos413.erdos_413.parts.i") := by
  norm_num
#print axioms probe_5_215

-- ATTACK fc-379fc029-parts-i-f1c95300ca-counterexample-v1 decide
theorem probe_5_216 : ¬ (fcTypeOfName% "Erdos413.erdos_413.parts.i") := by
  decide
#print axioms probe_5_216

-- ATTACK fc-379fc029-parts-i-f1c95300ca-counterexample-v1 native_decide
theorem probe_5_217 : ¬ (fcTypeOfName% "Erdos413.erdos_413.parts.i") := by
  native_decide
#print axioms probe_5_217

-- ATTACK fc-379fc029-parts-i-f1c95300ca-counterexample-v1 true_intro
theorem probe_5_218 : ¬ (fcTypeOfName% "Erdos413.erdos_413.parts.i") := by
  exact True.intro
#print axioms probe_5_218

-- ATTACK fc-379fc029-parts-i-f1c95300ca-counterexample-v1 false_elim_simp
theorem probe_5_219 : ¬ (fcTypeOfName% "Erdos413.erdos_413.parts.i") := by
  apply False.elim
  simp_all
#print axioms probe_5_219

-- ATTACK fc-379fc029-parts-i-f1c95300ca-counterexample-v1 constructor
theorem probe_5_220 : ¬ (fcTypeOfName% "Erdos413.erdos_413.parts.i") := by
  constructor
#print axioms probe_5_220

-- ATTACK fc-379fc029-parts-i-f1c95300ca-counterexample-v1 constructor_simp
theorem probe_5_221 : ¬ (fcTypeOfName% "Erdos413.erdos_413.parts.i") := by
  constructor <;> simp
#print axioms probe_5_221

-- ATTACK fc-379fc029-parts-i-f1c95300ca-counterexample-v1 constructor_aesop
theorem probe_5_222 : ¬ (fcTypeOfName% "Erdos413.erdos_413.parts.i") := by
  constructor <;> aesop
#print axioms probe_5_222

-- ATTACK fc-379fc029-parts-i-f1c95300ca-counterexample-v1 rfl
theorem probe_5_223 : ¬ (fcTypeOfName% "Erdos413.erdos_413.parts.i") := by
  rfl
#print axioms probe_5_223

-- ATTACK fc-379fc029-parts-i-f1c95300ca-counterexample-v1 trivial
theorem probe_5_224 : ¬ (fcTypeOfName% "Erdos413.erdos_413.parts.i") := by
  trivial
#print axioms probe_5_224

-- ATTACK fc-379fc029-parts-i-f1c95300ca-counterexample-v1 tauto
theorem probe_5_225 : ¬ (fcTypeOfName% "Erdos413.erdos_413.parts.i") := by
  tauto
#print axioms probe_5_225

-- ATTACK fc-379fc029-parts-i-f1c95300ca-counterexample-v1 positivity
theorem probe_5_226 : ¬ (fcTypeOfName% "Erdos413.erdos_413.parts.i") := by
  positivity
#print axioms probe_5_226

-- ATTACK fc-379fc029-parts-i-f1c95300ca-counterexample-v1 linarith
theorem probe_5_227 : ¬ (fcTypeOfName% "Erdos413.erdos_413.parts.i") := by
  linarith
#print axioms probe_5_227

-- ATTACK fc-379fc029-parts-i-f1c95300ca-counterexample-v1 nlinarith
theorem probe_5_228 : ¬ (fcTypeOfName% "Erdos413.erdos_413.parts.i") := by
  nlinarith
#print axioms probe_5_228

-- ATTACK fc-379fc029-parts-i-f1c95300ca-counterexample-v1 intros_simp_all
theorem probe_5_229 : ¬ (fcTypeOfName% "Erdos413.erdos_413.parts.i") := by
  intros
  simp_all
#print axioms probe_5_229

-- ATTACK fc-379fc029-parts-i-f1c95300ca-counterexample-v1 intros_omega
theorem probe_5_230 : ¬ (fcTypeOfName% "Erdos413.erdos_413.parts.i") := by
  intros
  omega
#print axioms probe_5_230

-- ATTACK fc-379fc029-parts-i-f1c95300ca-counterexample-v1 intros_norm_num
theorem probe_5_231 : ¬ (fcTypeOfName% "Erdos413.erdos_413.parts.i") := by
  intros
  norm_num at *
#print axioms probe_5_231

-- ATTACK fc-379fc029-parts-i-f1c95300ca-counterexample-v1 intros_aesop
theorem probe_5_232 : ¬ (fcTypeOfName% "Erdos413.erdos_413.parts.i") := by
  intros
  aesop
#print axioms probe_5_232

-- ATTACK fc-379fc029-parts-i-f1c95300ca-counterexample-v1 by_contra_simp_all
theorem probe_5_233 : ¬ (fcTypeOfName% "Erdos413.erdos_413.parts.i") := by
  by_contra h
  simp_all
#print axioms probe_5_233

-- ATTACK fc-379fc029-parts-i-f1c95300ca-counterexample-v1 classical_simp_all
theorem probe_5_234 : ¬ (fcTypeOfName% "Erdos413.erdos_413.parts.i") := by
  classical
  simp_all
#print axioms probe_5_234

-- ATTACK fc-379fc029-parts-i-f1c95300ca-counterexample-v1 classical_aesop
theorem probe_5_235 : ¬ (fcTypeOfName% "Erdos413.erdos_413.parts.i") := by
  classical
  aesop
#print axioms probe_5_235

-- ATTACK fc-379fc029-parts-i-f1c95300ca-counterexample-v1 refine_pair_simp
theorem probe_5_236 : ¬ (fcTypeOfName% "Erdos413.erdos_413.parts.i") := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_5_236

-- ATTACK fc-379fc029-parts-i-f1c95300ca-counterexample-v1 refine_pair_aesop
theorem probe_5_237 : ¬ (fcTypeOfName% "Erdos413.erdos_413.parts.i") := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_5_237

-- ATTACK fc-379fc029-parts-i-f1c95300ca-counterexample-v1 use_zero_simp
theorem probe_5_238 : ¬ (fcTypeOfName% "Erdos413.erdos_413.parts.i") := by
  use 0 <;> simp
#print axioms probe_5_238

-- ATTACK fc-379fc029-parts-i-f1c95300ca-counterexample-v1 use_one_simp
theorem probe_5_239 : ¬ (fcTypeOfName% "Erdos413.erdos_413.parts.i") := by
  use 1 <;> simp
#print axioms probe_5_239

-- ATTACK fc-379fc029-parts-i-f1c95300ca-counterexample-v1 use_empty_simp
theorem probe_5_240 : ¬ (fcTypeOfName% "Erdos413.erdos_413.parts.i") := by
  use ∅ <;> simp
#print axioms probe_5_240

-- ATTACK fc-379fc029-parts-i-f1c95300ca-counterexample-v1 assumption
theorem probe_5_241 : ¬ (fcTypeOfName% "Erdos413.erdos_413.parts.i") := by
  assumption
#print axioms probe_5_241

-- ATTACK fc-379fc029-parts-i-f1c95300ca-counterexample-v1 infer_instance
theorem probe_5_242 : ¬ (fcTypeOfName% "Erdos413.erdos_413.parts.i") := by
  infer_instance
#print axioms probe_5_242

-- ATTACK fc-379fc029-parts-i-f1c95300ca-counterexample-v1 contradiction
theorem probe_5_243 : ¬ (fcTypeOfName% "Erdos413.erdos_413.parts.i") := by
  contradiction
#print axioms probe_5_243

-- ATTACK fc-379fc029-parts-i-f1c95300ca-counterexample-v1 solve_by_elim
theorem probe_5_244 : ¬ (fcTypeOfName% "Erdos413.erdos_413.parts.i") := by
  solve_by_elim
#print axioms probe_5_244

-- ATTACK fc-379fc029-parts-i-f1c95300ca-counterexample-v1 first_order
theorem probe_5_245 : ¬ (fcTypeOfName% "Erdos413.erdos_413.parts.i") := by
  first_order
#print axioms probe_5_245

-- ATTACK fc-379fc029-parts-i-f1c95300ca-counterexample-v1 grind
theorem probe_5_246 : ¬ (fcTypeOfName% "Erdos413.erdos_413.parts.i") := by
  grind
#print axioms probe_5_246

-- ATTACK fc-379fc029-parts-i-f1c95300ca-counterexample-v1 exact_search
theorem probe_5_247 : ¬ (fcTypeOfName% "Erdos413.erdos_413.parts.i") := by
  exact?
#print axioms probe_5_247

-- ATTACK fc-379fc029-parts-i-f1c95300ca-counterexample-v1 apply_search
theorem probe_5_248 : ¬ (fcTypeOfName% "Erdos413.erdos_413.parts.i") := by
  apply?
#print axioms probe_5_248

-- ATTACK fc-379fc029-parts-i-f1c95300ca-counterexample-v1 library_search
theorem probe_5_249 : ¬ (fcTypeOfName% "Erdos413.erdos_413.parts.i") := by
  library_search
#print axioms probe_5_249

-- ATTACK fc-379fc029-parts-i-f1c95300ca-counterexample-v1 aesop_search
theorem probe_5_250 : ¬ (fcTypeOfName% "Erdos413.erdos_413.parts.i") := by
  aesop?
#print axioms probe_5_250

-- ATTACK fc-379fc029-parts-i-f1c95300ca-counterexample-v1 simp_search
theorem probe_5_251 : ¬ (fcTypeOfName% "Erdos413.erdos_413.parts.i") := by
  simp?
#print axioms probe_5_251

-- ATTACK fc-379fc029-erdos647-erdos-647-90e407d1ef-counterexample-v1 simp
theorem probe_5_252 : ¬ (fcTypeOfName% "Erdos647.erdos_647") := by
  simp
#print axioms probe_5_252

-- ATTACK fc-379fc029-erdos647-erdos-647-90e407d1ef-counterexample-v1 simpa
theorem probe_5_253 : ¬ (fcTypeOfName% "Erdos647.erdos_647") := by
  simpa
#print axioms probe_5_253

-- ATTACK fc-379fc029-erdos647-erdos-647-90e407d1ef-counterexample-v1 simp_all
theorem probe_5_254 : ¬ (fcTypeOfName% "Erdos647.erdos_647") := by
  simp_all
#print axioms probe_5_254

-- ATTACK fc-379fc029-erdos647-erdos-647-90e407d1ef-counterexample-v1 aesop
theorem probe_5_255 : ¬ (fcTypeOfName% "Erdos647.erdos_647") := by
  aesop
#print axioms probe_5_255

-- ATTACK fc-379fc029-erdos647-erdos-647-90e407d1ef-counterexample-v1 omega
theorem probe_5_256 : ¬ (fcTypeOfName% "Erdos647.erdos_647") := by
  omega
#print axioms probe_5_256

-- ATTACK fc-379fc029-erdos647-erdos-647-90e407d1ef-counterexample-v1 norm_num
theorem probe_5_257 : ¬ (fcTypeOfName% "Erdos647.erdos_647") := by
  norm_num
#print axioms probe_5_257

-- ATTACK fc-379fc029-erdos647-erdos-647-90e407d1ef-counterexample-v1 decide
theorem probe_5_258 : ¬ (fcTypeOfName% "Erdos647.erdos_647") := by
  decide
#print axioms probe_5_258

-- ATTACK fc-379fc029-erdos647-erdos-647-90e407d1ef-counterexample-v1 native_decide
theorem probe_5_259 : ¬ (fcTypeOfName% "Erdos647.erdos_647") := by
  native_decide
#print axioms probe_5_259

-- ATTACK fc-379fc029-erdos647-erdos-647-90e407d1ef-counterexample-v1 true_intro
theorem probe_5_260 : ¬ (fcTypeOfName% "Erdos647.erdos_647") := by
  exact True.intro
#print axioms probe_5_260

-- ATTACK fc-379fc029-erdos647-erdos-647-90e407d1ef-counterexample-v1 false_elim_simp
theorem probe_5_261 : ¬ (fcTypeOfName% "Erdos647.erdos_647") := by
  apply False.elim
  simp_all
#print axioms probe_5_261

-- ATTACK fc-379fc029-erdos647-erdos-647-90e407d1ef-counterexample-v1 constructor
theorem probe_5_262 : ¬ (fcTypeOfName% "Erdos647.erdos_647") := by
  constructor
#print axioms probe_5_262

-- ATTACK fc-379fc029-erdos647-erdos-647-90e407d1ef-counterexample-v1 constructor_simp
theorem probe_5_263 : ¬ (fcTypeOfName% "Erdos647.erdos_647") := by
  constructor <;> simp
#print axioms probe_5_263

-- ATTACK fc-379fc029-erdos647-erdos-647-90e407d1ef-counterexample-v1 constructor_aesop
theorem probe_5_264 : ¬ (fcTypeOfName% "Erdos647.erdos_647") := by
  constructor <;> aesop
#print axioms probe_5_264

-- ATTACK fc-379fc029-erdos647-erdos-647-90e407d1ef-counterexample-v1 rfl
theorem probe_5_265 : ¬ (fcTypeOfName% "Erdos647.erdos_647") := by
  rfl
#print axioms probe_5_265

-- ATTACK fc-379fc029-erdos647-erdos-647-90e407d1ef-counterexample-v1 trivial
theorem probe_5_266 : ¬ (fcTypeOfName% "Erdos647.erdos_647") := by
  trivial
#print axioms probe_5_266

-- ATTACK fc-379fc029-erdos647-erdos-647-90e407d1ef-counterexample-v1 tauto
theorem probe_5_267 : ¬ (fcTypeOfName% "Erdos647.erdos_647") := by
  tauto
#print axioms probe_5_267

-- ATTACK fc-379fc029-erdos647-erdos-647-90e407d1ef-counterexample-v1 positivity
theorem probe_5_268 : ¬ (fcTypeOfName% "Erdos647.erdos_647") := by
  positivity
#print axioms probe_5_268

-- ATTACK fc-379fc029-erdos647-erdos-647-90e407d1ef-counterexample-v1 linarith
theorem probe_5_269 : ¬ (fcTypeOfName% "Erdos647.erdos_647") := by
  linarith
#print axioms probe_5_269

-- ATTACK fc-379fc029-erdos647-erdos-647-90e407d1ef-counterexample-v1 nlinarith
theorem probe_5_270 : ¬ (fcTypeOfName% "Erdos647.erdos_647") := by
  nlinarith
#print axioms probe_5_270

-- ATTACK fc-379fc029-erdos647-erdos-647-90e407d1ef-counterexample-v1 intros_simp_all
theorem probe_5_271 : ¬ (fcTypeOfName% "Erdos647.erdos_647") := by
  intros
  simp_all
#print axioms probe_5_271

-- ATTACK fc-379fc029-erdos647-erdos-647-90e407d1ef-counterexample-v1 intros_omega
theorem probe_5_272 : ¬ (fcTypeOfName% "Erdos647.erdos_647") := by
  intros
  omega
#print axioms probe_5_272

-- ATTACK fc-379fc029-erdos647-erdos-647-90e407d1ef-counterexample-v1 intros_norm_num
theorem probe_5_273 : ¬ (fcTypeOfName% "Erdos647.erdos_647") := by
  intros
  norm_num at *
#print axioms probe_5_273

-- ATTACK fc-379fc029-erdos647-erdos-647-90e407d1ef-counterexample-v1 intros_aesop
theorem probe_5_274 : ¬ (fcTypeOfName% "Erdos647.erdos_647") := by
  intros
  aesop
#print axioms probe_5_274

-- ATTACK fc-379fc029-erdos647-erdos-647-90e407d1ef-counterexample-v1 by_contra_simp_all
theorem probe_5_275 : ¬ (fcTypeOfName% "Erdos647.erdos_647") := by
  by_contra h
  simp_all
#print axioms probe_5_275

-- ATTACK fc-379fc029-erdos647-erdos-647-90e407d1ef-counterexample-v1 classical_simp_all
theorem probe_5_276 : ¬ (fcTypeOfName% "Erdos647.erdos_647") := by
  classical
  simp_all
#print axioms probe_5_276

-- ATTACK fc-379fc029-erdos647-erdos-647-90e407d1ef-counterexample-v1 classical_aesop
theorem probe_5_277 : ¬ (fcTypeOfName% "Erdos647.erdos_647") := by
  classical
  aesop
#print axioms probe_5_277

-- ATTACK fc-379fc029-erdos647-erdos-647-90e407d1ef-counterexample-v1 refine_pair_simp
theorem probe_5_278 : ¬ (fcTypeOfName% "Erdos647.erdos_647") := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_5_278

-- ATTACK fc-379fc029-erdos647-erdos-647-90e407d1ef-counterexample-v1 refine_pair_aesop
theorem probe_5_279 : ¬ (fcTypeOfName% "Erdos647.erdos_647") := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_5_279

-- ATTACK fc-379fc029-erdos647-erdos-647-90e407d1ef-counterexample-v1 use_zero_simp
theorem probe_5_280 : ¬ (fcTypeOfName% "Erdos647.erdos_647") := by
  use 0 <;> simp
#print axioms probe_5_280

-- ATTACK fc-379fc029-erdos647-erdos-647-90e407d1ef-counterexample-v1 use_one_simp
theorem probe_5_281 : ¬ (fcTypeOfName% "Erdos647.erdos_647") := by
  use 1 <;> simp
#print axioms probe_5_281

-- ATTACK fc-379fc029-erdos647-erdos-647-90e407d1ef-counterexample-v1 use_empty_simp
theorem probe_5_282 : ¬ (fcTypeOfName% "Erdos647.erdos_647") := by
  use ∅ <;> simp
#print axioms probe_5_282

-- ATTACK fc-379fc029-erdos647-erdos-647-90e407d1ef-counterexample-v1 assumption
theorem probe_5_283 : ¬ (fcTypeOfName% "Erdos647.erdos_647") := by
  assumption
#print axioms probe_5_283

-- ATTACK fc-379fc029-erdos647-erdos-647-90e407d1ef-counterexample-v1 infer_instance
theorem probe_5_284 : ¬ (fcTypeOfName% "Erdos647.erdos_647") := by
  infer_instance
#print axioms probe_5_284

-- ATTACK fc-379fc029-erdos647-erdos-647-90e407d1ef-counterexample-v1 contradiction
theorem probe_5_285 : ¬ (fcTypeOfName% "Erdos647.erdos_647") := by
  contradiction
#print axioms probe_5_285

-- ATTACK fc-379fc029-erdos647-erdos-647-90e407d1ef-counterexample-v1 solve_by_elim
theorem probe_5_286 : ¬ (fcTypeOfName% "Erdos647.erdos_647") := by
  solve_by_elim
#print axioms probe_5_286

-- ATTACK fc-379fc029-erdos647-erdos-647-90e407d1ef-counterexample-v1 first_order
theorem probe_5_287 : ¬ (fcTypeOfName% "Erdos647.erdos_647") := by
  first_order
#print axioms probe_5_287

-- ATTACK fc-379fc029-erdos647-erdos-647-90e407d1ef-counterexample-v1 grind
theorem probe_5_288 : ¬ (fcTypeOfName% "Erdos647.erdos_647") := by
  grind
#print axioms probe_5_288

-- ATTACK fc-379fc029-erdos647-erdos-647-90e407d1ef-counterexample-v1 exact_search
theorem probe_5_289 : ¬ (fcTypeOfName% "Erdos647.erdos_647") := by
  exact?
#print axioms probe_5_289

-- ATTACK fc-379fc029-erdos647-erdos-647-90e407d1ef-counterexample-v1 apply_search
theorem probe_5_290 : ¬ (fcTypeOfName% "Erdos647.erdos_647") := by
  apply?
#print axioms probe_5_290

-- ATTACK fc-379fc029-erdos647-erdos-647-90e407d1ef-counterexample-v1 library_search
theorem probe_5_291 : ¬ (fcTypeOfName% "Erdos647.erdos_647") := by
  library_search
#print axioms probe_5_291

-- ATTACK fc-379fc029-erdos647-erdos-647-90e407d1ef-counterexample-v1 aesop_search
theorem probe_5_292 : ¬ (fcTypeOfName% "Erdos647.erdos_647") := by
  aesop?
#print axioms probe_5_292

-- ATTACK fc-379fc029-erdos647-erdos-647-90e407d1ef-counterexample-v1 simp_search
theorem probe_5_293 : ¬ (fcTypeOfName% "Erdos647.erdos_647") := by
  simp?
#print axioms probe_5_293

-- ATTACK fc-379fc029-parts-i-bab53eb271-counterexample-v1 simp
theorem probe_5_294 : ¬ (fcTypeOfName% "Erdos770.erdos_770.parts.i") := by
  simp
#print axioms probe_5_294

-- ATTACK fc-379fc029-parts-i-bab53eb271-counterexample-v1 simpa
theorem probe_5_295 : ¬ (fcTypeOfName% "Erdos770.erdos_770.parts.i") := by
  simpa
#print axioms probe_5_295

-- ATTACK fc-379fc029-parts-i-bab53eb271-counterexample-v1 simp_all
theorem probe_5_296 : ¬ (fcTypeOfName% "Erdos770.erdos_770.parts.i") := by
  simp_all
#print axioms probe_5_296

-- ATTACK fc-379fc029-parts-i-bab53eb271-counterexample-v1 aesop
theorem probe_5_297 : ¬ (fcTypeOfName% "Erdos770.erdos_770.parts.i") := by
  aesop
#print axioms probe_5_297

-- ATTACK fc-379fc029-parts-i-bab53eb271-counterexample-v1 omega
theorem probe_5_298 : ¬ (fcTypeOfName% "Erdos770.erdos_770.parts.i") := by
  omega
#print axioms probe_5_298

-- ATTACK fc-379fc029-parts-i-bab53eb271-counterexample-v1 norm_num
theorem probe_5_299 : ¬ (fcTypeOfName% "Erdos770.erdos_770.parts.i") := by
  norm_num
#print axioms probe_5_299

-- ATTACK fc-379fc029-parts-i-bab53eb271-counterexample-v1 decide
theorem probe_5_300 : ¬ (fcTypeOfName% "Erdos770.erdos_770.parts.i") := by
  decide
#print axioms probe_5_300

-- ATTACK fc-379fc029-parts-i-bab53eb271-counterexample-v1 native_decide
theorem probe_5_301 : ¬ (fcTypeOfName% "Erdos770.erdos_770.parts.i") := by
  native_decide
#print axioms probe_5_301

-- ATTACK fc-379fc029-parts-i-bab53eb271-counterexample-v1 true_intro
theorem probe_5_302 : ¬ (fcTypeOfName% "Erdos770.erdos_770.parts.i") := by
  exact True.intro
#print axioms probe_5_302

-- ATTACK fc-379fc029-parts-i-bab53eb271-counterexample-v1 false_elim_simp
theorem probe_5_303 : ¬ (fcTypeOfName% "Erdos770.erdos_770.parts.i") := by
  apply False.elim
  simp_all
#print axioms probe_5_303

-- ATTACK fc-379fc029-parts-i-bab53eb271-counterexample-v1 constructor
theorem probe_5_304 : ¬ (fcTypeOfName% "Erdos770.erdos_770.parts.i") := by
  constructor
#print axioms probe_5_304

-- ATTACK fc-379fc029-parts-i-bab53eb271-counterexample-v1 constructor_simp
theorem probe_5_305 : ¬ (fcTypeOfName% "Erdos770.erdos_770.parts.i") := by
  constructor <;> simp
#print axioms probe_5_305

-- ATTACK fc-379fc029-parts-i-bab53eb271-counterexample-v1 constructor_aesop
theorem probe_5_306 : ¬ (fcTypeOfName% "Erdos770.erdos_770.parts.i") := by
  constructor <;> aesop
#print axioms probe_5_306

-- ATTACK fc-379fc029-parts-i-bab53eb271-counterexample-v1 rfl
theorem probe_5_307 : ¬ (fcTypeOfName% "Erdos770.erdos_770.parts.i") := by
  rfl
#print axioms probe_5_307

-- ATTACK fc-379fc029-parts-i-bab53eb271-counterexample-v1 trivial
theorem probe_5_308 : ¬ (fcTypeOfName% "Erdos770.erdos_770.parts.i") := by
  trivial
#print axioms probe_5_308

-- ATTACK fc-379fc029-parts-i-bab53eb271-counterexample-v1 tauto
theorem probe_5_309 : ¬ (fcTypeOfName% "Erdos770.erdos_770.parts.i") := by
  tauto
#print axioms probe_5_309

-- ATTACK fc-379fc029-parts-i-bab53eb271-counterexample-v1 positivity
theorem probe_5_310 : ¬ (fcTypeOfName% "Erdos770.erdos_770.parts.i") := by
  positivity
#print axioms probe_5_310

-- ATTACK fc-379fc029-parts-i-bab53eb271-counterexample-v1 linarith
theorem probe_5_311 : ¬ (fcTypeOfName% "Erdos770.erdos_770.parts.i") := by
  linarith
#print axioms probe_5_311

-- ATTACK fc-379fc029-parts-i-bab53eb271-counterexample-v1 nlinarith
theorem probe_5_312 : ¬ (fcTypeOfName% "Erdos770.erdos_770.parts.i") := by
  nlinarith
#print axioms probe_5_312

-- ATTACK fc-379fc029-parts-i-bab53eb271-counterexample-v1 intros_simp_all
theorem probe_5_313 : ¬ (fcTypeOfName% "Erdos770.erdos_770.parts.i") := by
  intros
  simp_all
#print axioms probe_5_313

-- ATTACK fc-379fc029-parts-i-bab53eb271-counterexample-v1 intros_omega
theorem probe_5_314 : ¬ (fcTypeOfName% "Erdos770.erdos_770.parts.i") := by
  intros
  omega
#print axioms probe_5_314

-- ATTACK fc-379fc029-parts-i-bab53eb271-counterexample-v1 intros_norm_num
theorem probe_5_315 : ¬ (fcTypeOfName% "Erdos770.erdos_770.parts.i") := by
  intros
  norm_num at *
#print axioms probe_5_315

-- ATTACK fc-379fc029-parts-i-bab53eb271-counterexample-v1 intros_aesop
theorem probe_5_316 : ¬ (fcTypeOfName% "Erdos770.erdos_770.parts.i") := by
  intros
  aesop
#print axioms probe_5_316

-- ATTACK fc-379fc029-parts-i-bab53eb271-counterexample-v1 by_contra_simp_all
theorem probe_5_317 : ¬ (fcTypeOfName% "Erdos770.erdos_770.parts.i") := by
  by_contra h
  simp_all
#print axioms probe_5_317

-- ATTACK fc-379fc029-parts-i-bab53eb271-counterexample-v1 classical_simp_all
theorem probe_5_318 : ¬ (fcTypeOfName% "Erdos770.erdos_770.parts.i") := by
  classical
  simp_all
#print axioms probe_5_318

-- ATTACK fc-379fc029-parts-i-bab53eb271-counterexample-v1 classical_aesop
theorem probe_5_319 : ¬ (fcTypeOfName% "Erdos770.erdos_770.parts.i") := by
  classical
  aesop
#print axioms probe_5_319

-- ATTACK fc-379fc029-parts-i-bab53eb271-counterexample-v1 refine_pair_simp
theorem probe_5_320 : ¬ (fcTypeOfName% "Erdos770.erdos_770.parts.i") := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_5_320

-- ATTACK fc-379fc029-parts-i-bab53eb271-counterexample-v1 refine_pair_aesop
theorem probe_5_321 : ¬ (fcTypeOfName% "Erdos770.erdos_770.parts.i") := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_5_321

-- ATTACK fc-379fc029-parts-i-bab53eb271-counterexample-v1 use_zero_simp
theorem probe_5_322 : ¬ (fcTypeOfName% "Erdos770.erdos_770.parts.i") := by
  use 0 <;> simp
#print axioms probe_5_322

-- ATTACK fc-379fc029-parts-i-bab53eb271-counterexample-v1 use_one_simp
theorem probe_5_323 : ¬ (fcTypeOfName% "Erdos770.erdos_770.parts.i") := by
  use 1 <;> simp
#print axioms probe_5_323

-- ATTACK fc-379fc029-parts-i-bab53eb271-counterexample-v1 use_empty_simp
theorem probe_5_324 : ¬ (fcTypeOfName% "Erdos770.erdos_770.parts.i") := by
  use ∅ <;> simp
#print axioms probe_5_324

-- ATTACK fc-379fc029-parts-i-bab53eb271-counterexample-v1 assumption
theorem probe_5_325 : ¬ (fcTypeOfName% "Erdos770.erdos_770.parts.i") := by
  assumption
#print axioms probe_5_325

-- ATTACK fc-379fc029-parts-i-bab53eb271-counterexample-v1 infer_instance
theorem probe_5_326 : ¬ (fcTypeOfName% "Erdos770.erdos_770.parts.i") := by
  infer_instance
#print axioms probe_5_326

-- ATTACK fc-379fc029-parts-i-bab53eb271-counterexample-v1 contradiction
theorem probe_5_327 : ¬ (fcTypeOfName% "Erdos770.erdos_770.parts.i") := by
  contradiction
#print axioms probe_5_327

-- ATTACK fc-379fc029-parts-i-bab53eb271-counterexample-v1 solve_by_elim
theorem probe_5_328 : ¬ (fcTypeOfName% "Erdos770.erdos_770.parts.i") := by
  solve_by_elim
#print axioms probe_5_328

-- ATTACK fc-379fc029-parts-i-bab53eb271-counterexample-v1 first_order
theorem probe_5_329 : ¬ (fcTypeOfName% "Erdos770.erdos_770.parts.i") := by
  first_order
#print axioms probe_5_329

-- ATTACK fc-379fc029-parts-i-bab53eb271-counterexample-v1 grind
theorem probe_5_330 : ¬ (fcTypeOfName% "Erdos770.erdos_770.parts.i") := by
  grind
#print axioms probe_5_330

-- ATTACK fc-379fc029-parts-i-bab53eb271-counterexample-v1 exact_search
theorem probe_5_331 : ¬ (fcTypeOfName% "Erdos770.erdos_770.parts.i") := by
  exact?
#print axioms probe_5_331

-- ATTACK fc-379fc029-parts-i-bab53eb271-counterexample-v1 apply_search
theorem probe_5_332 : ¬ (fcTypeOfName% "Erdos770.erdos_770.parts.i") := by
  apply?
#print axioms probe_5_332

-- ATTACK fc-379fc029-parts-i-bab53eb271-counterexample-v1 library_search
theorem probe_5_333 : ¬ (fcTypeOfName% "Erdos770.erdos_770.parts.i") := by
  library_search
#print axioms probe_5_333

-- ATTACK fc-379fc029-parts-i-bab53eb271-counterexample-v1 aesop_search
theorem probe_5_334 : ¬ (fcTypeOfName% "Erdos770.erdos_770.parts.i") := by
  aesop?
#print axioms probe_5_334

-- ATTACK fc-379fc029-parts-i-bab53eb271-counterexample-v1 simp_search
theorem probe_5_335 : ¬ (fcTypeOfName% "Erdos770.erdos_770.parts.i") := by
  simp?
#print axioms probe_5_335

-- ATTACK fc-379fc029-erdos930-erdos-930-79379d1578-counterexample-v1 simp
theorem probe_5_336 : ¬ (fcTypeOfName% "Erdos930.erdos_930") := by
  simp
#print axioms probe_5_336

-- ATTACK fc-379fc029-erdos930-erdos-930-79379d1578-counterexample-v1 simpa
theorem probe_5_337 : ¬ (fcTypeOfName% "Erdos930.erdos_930") := by
  simpa
#print axioms probe_5_337

-- ATTACK fc-379fc029-erdos930-erdos-930-79379d1578-counterexample-v1 simp_all
theorem probe_5_338 : ¬ (fcTypeOfName% "Erdos930.erdos_930") := by
  simp_all
#print axioms probe_5_338

-- ATTACK fc-379fc029-erdos930-erdos-930-79379d1578-counterexample-v1 aesop
theorem probe_5_339 : ¬ (fcTypeOfName% "Erdos930.erdos_930") := by
  aesop
#print axioms probe_5_339

-- ATTACK fc-379fc029-erdos930-erdos-930-79379d1578-counterexample-v1 omega
theorem probe_5_340 : ¬ (fcTypeOfName% "Erdos930.erdos_930") := by
  omega
#print axioms probe_5_340

-- ATTACK fc-379fc029-erdos930-erdos-930-79379d1578-counterexample-v1 norm_num
theorem probe_5_341 : ¬ (fcTypeOfName% "Erdos930.erdos_930") := by
  norm_num
#print axioms probe_5_341

-- ATTACK fc-379fc029-erdos930-erdos-930-79379d1578-counterexample-v1 decide
theorem probe_5_342 : ¬ (fcTypeOfName% "Erdos930.erdos_930") := by
  decide
#print axioms probe_5_342

-- ATTACK fc-379fc029-erdos930-erdos-930-79379d1578-counterexample-v1 native_decide
theorem probe_5_343 : ¬ (fcTypeOfName% "Erdos930.erdos_930") := by
  native_decide
#print axioms probe_5_343

-- ATTACK fc-379fc029-erdos930-erdos-930-79379d1578-counterexample-v1 true_intro
theorem probe_5_344 : ¬ (fcTypeOfName% "Erdos930.erdos_930") := by
  exact True.intro
#print axioms probe_5_344

-- ATTACK fc-379fc029-erdos930-erdos-930-79379d1578-counterexample-v1 false_elim_simp
theorem probe_5_345 : ¬ (fcTypeOfName% "Erdos930.erdos_930") := by
  apply False.elim
  simp_all
#print axioms probe_5_345

-- ATTACK fc-379fc029-erdos930-erdos-930-79379d1578-counterexample-v1 constructor
theorem probe_5_346 : ¬ (fcTypeOfName% "Erdos930.erdos_930") := by
  constructor
#print axioms probe_5_346

-- ATTACK fc-379fc029-erdos930-erdos-930-79379d1578-counterexample-v1 constructor_simp
theorem probe_5_347 : ¬ (fcTypeOfName% "Erdos930.erdos_930") := by
  constructor <;> simp
#print axioms probe_5_347

-- ATTACK fc-379fc029-erdos930-erdos-930-79379d1578-counterexample-v1 constructor_aesop
theorem probe_5_348 : ¬ (fcTypeOfName% "Erdos930.erdos_930") := by
  constructor <;> aesop
#print axioms probe_5_348

-- ATTACK fc-379fc029-erdos930-erdos-930-79379d1578-counterexample-v1 rfl
theorem probe_5_349 : ¬ (fcTypeOfName% "Erdos930.erdos_930") := by
  rfl
#print axioms probe_5_349

-- ATTACK fc-379fc029-erdos930-erdos-930-79379d1578-counterexample-v1 trivial
theorem probe_5_350 : ¬ (fcTypeOfName% "Erdos930.erdos_930") := by
  trivial
#print axioms probe_5_350

-- ATTACK fc-379fc029-erdos930-erdos-930-79379d1578-counterexample-v1 tauto
theorem probe_5_351 : ¬ (fcTypeOfName% "Erdos930.erdos_930") := by
  tauto
#print axioms probe_5_351

-- ATTACK fc-379fc029-erdos930-erdos-930-79379d1578-counterexample-v1 positivity
theorem probe_5_352 : ¬ (fcTypeOfName% "Erdos930.erdos_930") := by
  positivity
#print axioms probe_5_352

-- ATTACK fc-379fc029-erdos930-erdos-930-79379d1578-counterexample-v1 linarith
theorem probe_5_353 : ¬ (fcTypeOfName% "Erdos930.erdos_930") := by
  linarith
#print axioms probe_5_353

-- ATTACK fc-379fc029-erdos930-erdos-930-79379d1578-counterexample-v1 nlinarith
theorem probe_5_354 : ¬ (fcTypeOfName% "Erdos930.erdos_930") := by
  nlinarith
#print axioms probe_5_354

-- ATTACK fc-379fc029-erdos930-erdos-930-79379d1578-counterexample-v1 intros_simp_all
theorem probe_5_355 : ¬ (fcTypeOfName% "Erdos930.erdos_930") := by
  intros
  simp_all
#print axioms probe_5_355

-- ATTACK fc-379fc029-erdos930-erdos-930-79379d1578-counterexample-v1 intros_omega
theorem probe_5_356 : ¬ (fcTypeOfName% "Erdos930.erdos_930") := by
  intros
  omega
#print axioms probe_5_356

-- ATTACK fc-379fc029-erdos930-erdos-930-79379d1578-counterexample-v1 intros_norm_num
theorem probe_5_357 : ¬ (fcTypeOfName% "Erdos930.erdos_930") := by
  intros
  norm_num at *
#print axioms probe_5_357

-- ATTACK fc-379fc029-erdos930-erdos-930-79379d1578-counterexample-v1 intros_aesop
theorem probe_5_358 : ¬ (fcTypeOfName% "Erdos930.erdos_930") := by
  intros
  aesop
#print axioms probe_5_358

-- ATTACK fc-379fc029-erdos930-erdos-930-79379d1578-counterexample-v1 by_contra_simp_all
theorem probe_5_359 : ¬ (fcTypeOfName% "Erdos930.erdos_930") := by
  by_contra h
  simp_all
#print axioms probe_5_359

-- ATTACK fc-379fc029-erdos930-erdos-930-79379d1578-counterexample-v1 classical_simp_all
theorem probe_5_360 : ¬ (fcTypeOfName% "Erdos930.erdos_930") := by
  classical
  simp_all
#print axioms probe_5_360

-- ATTACK fc-379fc029-erdos930-erdos-930-79379d1578-counterexample-v1 classical_aesop
theorem probe_5_361 : ¬ (fcTypeOfName% "Erdos930.erdos_930") := by
  classical
  aesop
#print axioms probe_5_361

-- ATTACK fc-379fc029-erdos930-erdos-930-79379d1578-counterexample-v1 refine_pair_simp
theorem probe_5_362 : ¬ (fcTypeOfName% "Erdos930.erdos_930") := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_5_362

-- ATTACK fc-379fc029-erdos930-erdos-930-79379d1578-counterexample-v1 refine_pair_aesop
theorem probe_5_363 : ¬ (fcTypeOfName% "Erdos930.erdos_930") := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_5_363

-- ATTACK fc-379fc029-erdos930-erdos-930-79379d1578-counterexample-v1 use_zero_simp
theorem probe_5_364 : ¬ (fcTypeOfName% "Erdos930.erdos_930") := by
  use 0 <;> simp
#print axioms probe_5_364

-- ATTACK fc-379fc029-erdos930-erdos-930-79379d1578-counterexample-v1 use_one_simp
theorem probe_5_365 : ¬ (fcTypeOfName% "Erdos930.erdos_930") := by
  use 1 <;> simp
#print axioms probe_5_365

-- ATTACK fc-379fc029-erdos930-erdos-930-79379d1578-counterexample-v1 use_empty_simp
theorem probe_5_366 : ¬ (fcTypeOfName% "Erdos930.erdos_930") := by
  use ∅ <;> simp
#print axioms probe_5_366

-- ATTACK fc-379fc029-erdos930-erdos-930-79379d1578-counterexample-v1 assumption
theorem probe_5_367 : ¬ (fcTypeOfName% "Erdos930.erdos_930") := by
  assumption
#print axioms probe_5_367

-- ATTACK fc-379fc029-erdos930-erdos-930-79379d1578-counterexample-v1 infer_instance
theorem probe_5_368 : ¬ (fcTypeOfName% "Erdos930.erdos_930") := by
  infer_instance
#print axioms probe_5_368

-- ATTACK fc-379fc029-erdos930-erdos-930-79379d1578-counterexample-v1 contradiction
theorem probe_5_369 : ¬ (fcTypeOfName% "Erdos930.erdos_930") := by
  contradiction
#print axioms probe_5_369

-- ATTACK fc-379fc029-erdos930-erdos-930-79379d1578-counterexample-v1 solve_by_elim
theorem probe_5_370 : ¬ (fcTypeOfName% "Erdos930.erdos_930") := by
  solve_by_elim
#print axioms probe_5_370

-- ATTACK fc-379fc029-erdos930-erdos-930-79379d1578-counterexample-v1 first_order
theorem probe_5_371 : ¬ (fcTypeOfName% "Erdos930.erdos_930") := by
  first_order
#print axioms probe_5_371

-- ATTACK fc-379fc029-erdos930-erdos-930-79379d1578-counterexample-v1 grind
theorem probe_5_372 : ¬ (fcTypeOfName% "Erdos930.erdos_930") := by
  grind
#print axioms probe_5_372

-- ATTACK fc-379fc029-erdos930-erdos-930-79379d1578-counterexample-v1 exact_search
theorem probe_5_373 : ¬ (fcTypeOfName% "Erdos930.erdos_930") := by
  exact?
#print axioms probe_5_373

-- ATTACK fc-379fc029-erdos930-erdos-930-79379d1578-counterexample-v1 apply_search
theorem probe_5_374 : ¬ (fcTypeOfName% "Erdos930.erdos_930") := by
  apply?
#print axioms probe_5_374

-- ATTACK fc-379fc029-erdos930-erdos-930-79379d1578-counterexample-v1 library_search
theorem probe_5_375 : ¬ (fcTypeOfName% "Erdos930.erdos_930") := by
  library_search
#print axioms probe_5_375

-- ATTACK fc-379fc029-erdos930-erdos-930-79379d1578-counterexample-v1 aesop_search
theorem probe_5_376 : ¬ (fcTypeOfName% "Erdos930.erdos_930") := by
  aesop?
#print axioms probe_5_376

-- ATTACK fc-379fc029-erdos930-erdos-930-79379d1578-counterexample-v1 simp_search
theorem probe_5_377 : ¬ (fcTypeOfName% "Erdos930.erdos_930") := by
  simp?
#print axioms probe_5_377

-- ATTACK fc-379fc029-erdos944-erdos-944-0b83f9b22e-counterexample-v1 simp
theorem probe_5_378 : ¬ (fcTypeOfName% "Erdos944.erdos_944") := by
  simp
#print axioms probe_5_378

-- ATTACK fc-379fc029-erdos944-erdos-944-0b83f9b22e-counterexample-v1 simpa
theorem probe_5_379 : ¬ (fcTypeOfName% "Erdos944.erdos_944") := by
  simpa
#print axioms probe_5_379

-- ATTACK fc-379fc029-erdos944-erdos-944-0b83f9b22e-counterexample-v1 simp_all
theorem probe_5_380 : ¬ (fcTypeOfName% "Erdos944.erdos_944") := by
  simp_all
#print axioms probe_5_380

-- ATTACK fc-379fc029-erdos944-erdos-944-0b83f9b22e-counterexample-v1 aesop
theorem probe_5_381 : ¬ (fcTypeOfName% "Erdos944.erdos_944") := by
  aesop
#print axioms probe_5_381

-- ATTACK fc-379fc029-erdos944-erdos-944-0b83f9b22e-counterexample-v1 omega
theorem probe_5_382 : ¬ (fcTypeOfName% "Erdos944.erdos_944") := by
  omega
#print axioms probe_5_382

-- ATTACK fc-379fc029-erdos944-erdos-944-0b83f9b22e-counterexample-v1 norm_num
theorem probe_5_383 : ¬ (fcTypeOfName% "Erdos944.erdos_944") := by
  norm_num
#print axioms probe_5_383

-- ATTACK fc-379fc029-erdos944-erdos-944-0b83f9b22e-counterexample-v1 decide
theorem probe_5_384 : ¬ (fcTypeOfName% "Erdos944.erdos_944") := by
  decide
#print axioms probe_5_384

-- ATTACK fc-379fc029-erdos944-erdos-944-0b83f9b22e-counterexample-v1 native_decide
theorem probe_5_385 : ¬ (fcTypeOfName% "Erdos944.erdos_944") := by
  native_decide
#print axioms probe_5_385

-- ATTACK fc-379fc029-erdos944-erdos-944-0b83f9b22e-counterexample-v1 true_intro
theorem probe_5_386 : ¬ (fcTypeOfName% "Erdos944.erdos_944") := by
  exact True.intro
#print axioms probe_5_386

-- ATTACK fc-379fc029-erdos944-erdos-944-0b83f9b22e-counterexample-v1 false_elim_simp
theorem probe_5_387 : ¬ (fcTypeOfName% "Erdos944.erdos_944") := by
  apply False.elim
  simp_all
#print axioms probe_5_387

-- ATTACK fc-379fc029-erdos944-erdos-944-0b83f9b22e-counterexample-v1 constructor
theorem probe_5_388 : ¬ (fcTypeOfName% "Erdos944.erdos_944") := by
  constructor
#print axioms probe_5_388

-- ATTACK fc-379fc029-erdos944-erdos-944-0b83f9b22e-counterexample-v1 constructor_simp
theorem probe_5_389 : ¬ (fcTypeOfName% "Erdos944.erdos_944") := by
  constructor <;> simp
#print axioms probe_5_389

-- ATTACK fc-379fc029-erdos944-erdos-944-0b83f9b22e-counterexample-v1 constructor_aesop
theorem probe_5_390 : ¬ (fcTypeOfName% "Erdos944.erdos_944") := by
  constructor <;> aesop
#print axioms probe_5_390

-- ATTACK fc-379fc029-erdos944-erdos-944-0b83f9b22e-counterexample-v1 rfl
theorem probe_5_391 : ¬ (fcTypeOfName% "Erdos944.erdos_944") := by
  rfl
#print axioms probe_5_391

-- ATTACK fc-379fc029-erdos944-erdos-944-0b83f9b22e-counterexample-v1 trivial
theorem probe_5_392 : ¬ (fcTypeOfName% "Erdos944.erdos_944") := by
  trivial
#print axioms probe_5_392

-- ATTACK fc-379fc029-erdos944-erdos-944-0b83f9b22e-counterexample-v1 tauto
theorem probe_5_393 : ¬ (fcTypeOfName% "Erdos944.erdos_944") := by
  tauto
#print axioms probe_5_393

-- ATTACK fc-379fc029-erdos944-erdos-944-0b83f9b22e-counterexample-v1 positivity
theorem probe_5_394 : ¬ (fcTypeOfName% "Erdos944.erdos_944") := by
  positivity
#print axioms probe_5_394

-- ATTACK fc-379fc029-erdos944-erdos-944-0b83f9b22e-counterexample-v1 linarith
theorem probe_5_395 : ¬ (fcTypeOfName% "Erdos944.erdos_944") := by
  linarith
#print axioms probe_5_395

-- ATTACK fc-379fc029-erdos944-erdos-944-0b83f9b22e-counterexample-v1 nlinarith
theorem probe_5_396 : ¬ (fcTypeOfName% "Erdos944.erdos_944") := by
  nlinarith
#print axioms probe_5_396

-- ATTACK fc-379fc029-erdos944-erdos-944-0b83f9b22e-counterexample-v1 intros_simp_all
theorem probe_5_397 : ¬ (fcTypeOfName% "Erdos944.erdos_944") := by
  intros
  simp_all
#print axioms probe_5_397

-- ATTACK fc-379fc029-erdos944-erdos-944-0b83f9b22e-counterexample-v1 intros_omega
theorem probe_5_398 : ¬ (fcTypeOfName% "Erdos944.erdos_944") := by
  intros
  omega
#print axioms probe_5_398

-- ATTACK fc-379fc029-erdos944-erdos-944-0b83f9b22e-counterexample-v1 intros_norm_num
theorem probe_5_399 : ¬ (fcTypeOfName% "Erdos944.erdos_944") := by
  intros
  norm_num at *
#print axioms probe_5_399

-- ATTACK fc-379fc029-erdos944-erdos-944-0b83f9b22e-counterexample-v1 intros_aesop
theorem probe_5_400 : ¬ (fcTypeOfName% "Erdos944.erdos_944") := by
  intros
  aesop
#print axioms probe_5_400

-- ATTACK fc-379fc029-erdos944-erdos-944-0b83f9b22e-counterexample-v1 by_contra_simp_all
theorem probe_5_401 : ¬ (fcTypeOfName% "Erdos944.erdos_944") := by
  by_contra h
  simp_all
#print axioms probe_5_401

-- ATTACK fc-379fc029-erdos944-erdos-944-0b83f9b22e-counterexample-v1 classical_simp_all
theorem probe_5_402 : ¬ (fcTypeOfName% "Erdos944.erdos_944") := by
  classical
  simp_all
#print axioms probe_5_402

-- ATTACK fc-379fc029-erdos944-erdos-944-0b83f9b22e-counterexample-v1 classical_aesop
theorem probe_5_403 : ¬ (fcTypeOfName% "Erdos944.erdos_944") := by
  classical
  aesop
#print axioms probe_5_403

-- ATTACK fc-379fc029-erdos944-erdos-944-0b83f9b22e-counterexample-v1 refine_pair_simp
theorem probe_5_404 : ¬ (fcTypeOfName% "Erdos944.erdos_944") := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_5_404

-- ATTACK fc-379fc029-erdos944-erdos-944-0b83f9b22e-counterexample-v1 refine_pair_aesop
theorem probe_5_405 : ¬ (fcTypeOfName% "Erdos944.erdos_944") := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_5_405

-- ATTACK fc-379fc029-erdos944-erdos-944-0b83f9b22e-counterexample-v1 use_zero_simp
theorem probe_5_406 : ¬ (fcTypeOfName% "Erdos944.erdos_944") := by
  use 0 <;> simp
#print axioms probe_5_406

-- ATTACK fc-379fc029-erdos944-erdos-944-0b83f9b22e-counterexample-v1 use_one_simp
theorem probe_5_407 : ¬ (fcTypeOfName% "Erdos944.erdos_944") := by
  use 1 <;> simp
#print axioms probe_5_407

-- ATTACK fc-379fc029-erdos944-erdos-944-0b83f9b22e-counterexample-v1 use_empty_simp
theorem probe_5_408 : ¬ (fcTypeOfName% "Erdos944.erdos_944") := by
  use ∅ <;> simp
#print axioms probe_5_408

-- ATTACK fc-379fc029-erdos944-erdos-944-0b83f9b22e-counterexample-v1 assumption
theorem probe_5_409 : ¬ (fcTypeOfName% "Erdos944.erdos_944") := by
  assumption
#print axioms probe_5_409

-- ATTACK fc-379fc029-erdos944-erdos-944-0b83f9b22e-counterexample-v1 infer_instance
theorem probe_5_410 : ¬ (fcTypeOfName% "Erdos944.erdos_944") := by
  infer_instance
#print axioms probe_5_410

-- ATTACK fc-379fc029-erdos944-erdos-944-0b83f9b22e-counterexample-v1 contradiction
theorem probe_5_411 : ¬ (fcTypeOfName% "Erdos944.erdos_944") := by
  contradiction
#print axioms probe_5_411

-- ATTACK fc-379fc029-erdos944-erdos-944-0b83f9b22e-counterexample-v1 solve_by_elim
theorem probe_5_412 : ¬ (fcTypeOfName% "Erdos944.erdos_944") := by
  solve_by_elim
#print axioms probe_5_412

-- ATTACK fc-379fc029-erdos944-erdos-944-0b83f9b22e-counterexample-v1 first_order
theorem probe_5_413 : ¬ (fcTypeOfName% "Erdos944.erdos_944") := by
  first_order
#print axioms probe_5_413

-- ATTACK fc-379fc029-erdos944-erdos-944-0b83f9b22e-counterexample-v1 grind
theorem probe_5_414 : ¬ (fcTypeOfName% "Erdos944.erdos_944") := by
  grind
#print axioms probe_5_414

-- ATTACK fc-379fc029-erdos944-erdos-944-0b83f9b22e-counterexample-v1 exact_search
theorem probe_5_415 : ¬ (fcTypeOfName% "Erdos944.erdos_944") := by
  exact?
#print axioms probe_5_415

-- ATTACK fc-379fc029-erdos944-erdos-944-0b83f9b22e-counterexample-v1 apply_search
theorem probe_5_416 : ¬ (fcTypeOfName% "Erdos944.erdos_944") := by
  apply?
#print axioms probe_5_416

-- ATTACK fc-379fc029-erdos944-erdos-944-0b83f9b22e-counterexample-v1 library_search
theorem probe_5_417 : ¬ (fcTypeOfName% "Erdos944.erdos_944") := by
  library_search
#print axioms probe_5_417

-- ATTACK fc-379fc029-erdos944-erdos-944-0b83f9b22e-counterexample-v1 aesop_search
theorem probe_5_418 : ¬ (fcTypeOfName% "Erdos944.erdos_944") := by
  aesop?
#print axioms probe_5_418

-- ATTACK fc-379fc029-erdos944-erdos-944-0b83f9b22e-counterexample-v1 simp_search
theorem probe_5_419 : ¬ (fcTypeOfName% "Erdos944.erdos_944") := by
  simp?
#print axioms probe_5_419

-- ATTACK fc-379fc029-erdos979-erdos-979-2ee748eee4-counterexample-v1 simp
theorem probe_5_420 : ¬ (fcTypeOfName% "Erdos979.erdos_979") := by
  simp
#print axioms probe_5_420

-- ATTACK fc-379fc029-erdos979-erdos-979-2ee748eee4-counterexample-v1 simpa
theorem probe_5_421 : ¬ (fcTypeOfName% "Erdos979.erdos_979") := by
  simpa
#print axioms probe_5_421

-- ATTACK fc-379fc029-erdos979-erdos-979-2ee748eee4-counterexample-v1 simp_all
theorem probe_5_422 : ¬ (fcTypeOfName% "Erdos979.erdos_979") := by
  simp_all
#print axioms probe_5_422

-- ATTACK fc-379fc029-erdos979-erdos-979-2ee748eee4-counterexample-v1 aesop
theorem probe_5_423 : ¬ (fcTypeOfName% "Erdos979.erdos_979") := by
  aesop
#print axioms probe_5_423

-- ATTACK fc-379fc029-erdos979-erdos-979-2ee748eee4-counterexample-v1 omega
theorem probe_5_424 : ¬ (fcTypeOfName% "Erdos979.erdos_979") := by
  omega
#print axioms probe_5_424

-- ATTACK fc-379fc029-erdos979-erdos-979-2ee748eee4-counterexample-v1 norm_num
theorem probe_5_425 : ¬ (fcTypeOfName% "Erdos979.erdos_979") := by
  norm_num
#print axioms probe_5_425

-- ATTACK fc-379fc029-erdos979-erdos-979-2ee748eee4-counterexample-v1 decide
theorem probe_5_426 : ¬ (fcTypeOfName% "Erdos979.erdos_979") := by
  decide
#print axioms probe_5_426

-- ATTACK fc-379fc029-erdos979-erdos-979-2ee748eee4-counterexample-v1 native_decide
theorem probe_5_427 : ¬ (fcTypeOfName% "Erdos979.erdos_979") := by
  native_decide
#print axioms probe_5_427

-- ATTACK fc-379fc029-erdos979-erdos-979-2ee748eee4-counterexample-v1 true_intro
theorem probe_5_428 : ¬ (fcTypeOfName% "Erdos979.erdos_979") := by
  exact True.intro
#print axioms probe_5_428

-- ATTACK fc-379fc029-erdos979-erdos-979-2ee748eee4-counterexample-v1 false_elim_simp
theorem probe_5_429 : ¬ (fcTypeOfName% "Erdos979.erdos_979") := by
  apply False.elim
  simp_all
#print axioms probe_5_429

-- ATTACK fc-379fc029-erdos979-erdos-979-2ee748eee4-counterexample-v1 constructor
theorem probe_5_430 : ¬ (fcTypeOfName% "Erdos979.erdos_979") := by
  constructor
#print axioms probe_5_430

-- ATTACK fc-379fc029-erdos979-erdos-979-2ee748eee4-counterexample-v1 constructor_simp
theorem probe_5_431 : ¬ (fcTypeOfName% "Erdos979.erdos_979") := by
  constructor <;> simp
#print axioms probe_5_431

-- ATTACK fc-379fc029-erdos979-erdos-979-2ee748eee4-counterexample-v1 constructor_aesop
theorem probe_5_432 : ¬ (fcTypeOfName% "Erdos979.erdos_979") := by
  constructor <;> aesop
#print axioms probe_5_432

-- ATTACK fc-379fc029-erdos979-erdos-979-2ee748eee4-counterexample-v1 rfl
theorem probe_5_433 : ¬ (fcTypeOfName% "Erdos979.erdos_979") := by
  rfl
#print axioms probe_5_433

-- ATTACK fc-379fc029-erdos979-erdos-979-2ee748eee4-counterexample-v1 trivial
theorem probe_5_434 : ¬ (fcTypeOfName% "Erdos979.erdos_979") := by
  trivial
#print axioms probe_5_434

-- ATTACK fc-379fc029-erdos979-erdos-979-2ee748eee4-counterexample-v1 tauto
theorem probe_5_435 : ¬ (fcTypeOfName% "Erdos979.erdos_979") := by
  tauto
#print axioms probe_5_435

-- ATTACK fc-379fc029-erdos979-erdos-979-2ee748eee4-counterexample-v1 positivity
theorem probe_5_436 : ¬ (fcTypeOfName% "Erdos979.erdos_979") := by
  positivity
#print axioms probe_5_436

-- ATTACK fc-379fc029-erdos979-erdos-979-2ee748eee4-counterexample-v1 linarith
theorem probe_5_437 : ¬ (fcTypeOfName% "Erdos979.erdos_979") := by
  linarith
#print axioms probe_5_437

-- ATTACK fc-379fc029-erdos979-erdos-979-2ee748eee4-counterexample-v1 nlinarith
theorem probe_5_438 : ¬ (fcTypeOfName% "Erdos979.erdos_979") := by
  nlinarith
#print axioms probe_5_438

-- ATTACK fc-379fc029-erdos979-erdos-979-2ee748eee4-counterexample-v1 intros_simp_all
theorem probe_5_439 : ¬ (fcTypeOfName% "Erdos979.erdos_979") := by
  intros
  simp_all
#print axioms probe_5_439

-- ATTACK fc-379fc029-erdos979-erdos-979-2ee748eee4-counterexample-v1 intros_omega
theorem probe_5_440 : ¬ (fcTypeOfName% "Erdos979.erdos_979") := by
  intros
  omega
#print axioms probe_5_440

-- ATTACK fc-379fc029-erdos979-erdos-979-2ee748eee4-counterexample-v1 intros_norm_num
theorem probe_5_441 : ¬ (fcTypeOfName% "Erdos979.erdos_979") := by
  intros
  norm_num at *
#print axioms probe_5_441

-- ATTACK fc-379fc029-erdos979-erdos-979-2ee748eee4-counterexample-v1 intros_aesop
theorem probe_5_442 : ¬ (fcTypeOfName% "Erdos979.erdos_979") := by
  intros
  aesop
#print axioms probe_5_442

-- ATTACK fc-379fc029-erdos979-erdos-979-2ee748eee4-counterexample-v1 by_contra_simp_all
theorem probe_5_443 : ¬ (fcTypeOfName% "Erdos979.erdos_979") := by
  by_contra h
  simp_all
#print axioms probe_5_443

-- ATTACK fc-379fc029-erdos979-erdos-979-2ee748eee4-counterexample-v1 classical_simp_all
theorem probe_5_444 : ¬ (fcTypeOfName% "Erdos979.erdos_979") := by
  classical
  simp_all
#print axioms probe_5_444

-- ATTACK fc-379fc029-erdos979-erdos-979-2ee748eee4-counterexample-v1 classical_aesop
theorem probe_5_445 : ¬ (fcTypeOfName% "Erdos979.erdos_979") := by
  classical
  aesop
#print axioms probe_5_445

-- ATTACK fc-379fc029-erdos979-erdos-979-2ee748eee4-counterexample-v1 refine_pair_simp
theorem probe_5_446 : ¬ (fcTypeOfName% "Erdos979.erdos_979") := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_5_446

-- ATTACK fc-379fc029-erdos979-erdos-979-2ee748eee4-counterexample-v1 refine_pair_aesop
theorem probe_5_447 : ¬ (fcTypeOfName% "Erdos979.erdos_979") := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_5_447

-- ATTACK fc-379fc029-erdos979-erdos-979-2ee748eee4-counterexample-v1 use_zero_simp
theorem probe_5_448 : ¬ (fcTypeOfName% "Erdos979.erdos_979") := by
  use 0 <;> simp
#print axioms probe_5_448

-- ATTACK fc-379fc029-erdos979-erdos-979-2ee748eee4-counterexample-v1 use_one_simp
theorem probe_5_449 : ¬ (fcTypeOfName% "Erdos979.erdos_979") := by
  use 1 <;> simp
#print axioms probe_5_449

-- ATTACK fc-379fc029-erdos979-erdos-979-2ee748eee4-counterexample-v1 use_empty_simp
theorem probe_5_450 : ¬ (fcTypeOfName% "Erdos979.erdos_979") := by
  use ∅ <;> simp
#print axioms probe_5_450

-- ATTACK fc-379fc029-erdos979-erdos-979-2ee748eee4-counterexample-v1 assumption
theorem probe_5_451 : ¬ (fcTypeOfName% "Erdos979.erdos_979") := by
  assumption
#print axioms probe_5_451

-- ATTACK fc-379fc029-erdos979-erdos-979-2ee748eee4-counterexample-v1 infer_instance
theorem probe_5_452 : ¬ (fcTypeOfName% "Erdos979.erdos_979") := by
  infer_instance
#print axioms probe_5_452

-- ATTACK fc-379fc029-erdos979-erdos-979-2ee748eee4-counterexample-v1 contradiction
theorem probe_5_453 : ¬ (fcTypeOfName% "Erdos979.erdos_979") := by
  contradiction
#print axioms probe_5_453

-- ATTACK fc-379fc029-erdos979-erdos-979-2ee748eee4-counterexample-v1 solve_by_elim
theorem probe_5_454 : ¬ (fcTypeOfName% "Erdos979.erdos_979") := by
  solve_by_elim
#print axioms probe_5_454

-- ATTACK fc-379fc029-erdos979-erdos-979-2ee748eee4-counterexample-v1 first_order
theorem probe_5_455 : ¬ (fcTypeOfName% "Erdos979.erdos_979") := by
  first_order
#print axioms probe_5_455

-- ATTACK fc-379fc029-erdos979-erdos-979-2ee748eee4-counterexample-v1 grind
theorem probe_5_456 : ¬ (fcTypeOfName% "Erdos979.erdos_979") := by
  grind
#print axioms probe_5_456

-- ATTACK fc-379fc029-erdos979-erdos-979-2ee748eee4-counterexample-v1 exact_search
theorem probe_5_457 : ¬ (fcTypeOfName% "Erdos979.erdos_979") := by
  exact?
#print axioms probe_5_457

-- ATTACK fc-379fc029-erdos979-erdos-979-2ee748eee4-counterexample-v1 apply_search
theorem probe_5_458 : ¬ (fcTypeOfName% "Erdos979.erdos_979") := by
  apply?
#print axioms probe_5_458

-- ATTACK fc-379fc029-erdos979-erdos-979-2ee748eee4-counterexample-v1 library_search
theorem probe_5_459 : ¬ (fcTypeOfName% "Erdos979.erdos_979") := by
  library_search
#print axioms probe_5_459

-- ATTACK fc-379fc029-erdos979-erdos-979-2ee748eee4-counterexample-v1 aesop_search
theorem probe_5_460 : ¬ (fcTypeOfName% "Erdos979.erdos_979") := by
  aesop?
#print axioms probe_5_460

-- ATTACK fc-379fc029-erdos979-erdos-979-2ee748eee4-counterexample-v1 simp_search
theorem probe_5_461 : ¬ (fcTypeOfName% "Erdos979.erdos_979") := by
  simp?
#print axioms probe_5_461

-- ATTACK fc-379fc029-green44-green-44-35e0d2eaec-counterexample-v1 simp
theorem probe_5_462 : ¬ (fcTypeOfName% "Green44.green_44") := by
  simp
#print axioms probe_5_462

-- ATTACK fc-379fc029-green44-green-44-35e0d2eaec-counterexample-v1 simpa
theorem probe_5_463 : ¬ (fcTypeOfName% "Green44.green_44") := by
  simpa
#print axioms probe_5_463

-- ATTACK fc-379fc029-green44-green-44-35e0d2eaec-counterexample-v1 simp_all
theorem probe_5_464 : ¬ (fcTypeOfName% "Green44.green_44") := by
  simp_all
#print axioms probe_5_464

-- ATTACK fc-379fc029-green44-green-44-35e0d2eaec-counterexample-v1 aesop
theorem probe_5_465 : ¬ (fcTypeOfName% "Green44.green_44") := by
  aesop
#print axioms probe_5_465

-- ATTACK fc-379fc029-green44-green-44-35e0d2eaec-counterexample-v1 omega
theorem probe_5_466 : ¬ (fcTypeOfName% "Green44.green_44") := by
  omega
#print axioms probe_5_466

-- ATTACK fc-379fc029-green44-green-44-35e0d2eaec-counterexample-v1 norm_num
theorem probe_5_467 : ¬ (fcTypeOfName% "Green44.green_44") := by
  norm_num
#print axioms probe_5_467

-- ATTACK fc-379fc029-green44-green-44-35e0d2eaec-counterexample-v1 decide
theorem probe_5_468 : ¬ (fcTypeOfName% "Green44.green_44") := by
  decide
#print axioms probe_5_468

-- ATTACK fc-379fc029-green44-green-44-35e0d2eaec-counterexample-v1 native_decide
theorem probe_5_469 : ¬ (fcTypeOfName% "Green44.green_44") := by
  native_decide
#print axioms probe_5_469

-- ATTACK fc-379fc029-green44-green-44-35e0d2eaec-counterexample-v1 true_intro
theorem probe_5_470 : ¬ (fcTypeOfName% "Green44.green_44") := by
  exact True.intro
#print axioms probe_5_470

-- ATTACK fc-379fc029-green44-green-44-35e0d2eaec-counterexample-v1 false_elim_simp
theorem probe_5_471 : ¬ (fcTypeOfName% "Green44.green_44") := by
  apply False.elim
  simp_all
#print axioms probe_5_471

-- ATTACK fc-379fc029-green44-green-44-35e0d2eaec-counterexample-v1 constructor
theorem probe_5_472 : ¬ (fcTypeOfName% "Green44.green_44") := by
  constructor
#print axioms probe_5_472

-- ATTACK fc-379fc029-green44-green-44-35e0d2eaec-counterexample-v1 constructor_simp
theorem probe_5_473 : ¬ (fcTypeOfName% "Green44.green_44") := by
  constructor <;> simp
#print axioms probe_5_473

-- ATTACK fc-379fc029-green44-green-44-35e0d2eaec-counterexample-v1 constructor_aesop
theorem probe_5_474 : ¬ (fcTypeOfName% "Green44.green_44") := by
  constructor <;> aesop
#print axioms probe_5_474

-- ATTACK fc-379fc029-green44-green-44-35e0d2eaec-counterexample-v1 rfl
theorem probe_5_475 : ¬ (fcTypeOfName% "Green44.green_44") := by
  rfl
#print axioms probe_5_475

-- ATTACK fc-379fc029-green44-green-44-35e0d2eaec-counterexample-v1 trivial
theorem probe_5_476 : ¬ (fcTypeOfName% "Green44.green_44") := by
  trivial
#print axioms probe_5_476

-- ATTACK fc-379fc029-green44-green-44-35e0d2eaec-counterexample-v1 tauto
theorem probe_5_477 : ¬ (fcTypeOfName% "Green44.green_44") := by
  tauto
#print axioms probe_5_477

-- ATTACK fc-379fc029-green44-green-44-35e0d2eaec-counterexample-v1 positivity
theorem probe_5_478 : ¬ (fcTypeOfName% "Green44.green_44") := by
  positivity
#print axioms probe_5_478

-- ATTACK fc-379fc029-green44-green-44-35e0d2eaec-counterexample-v1 linarith
theorem probe_5_479 : ¬ (fcTypeOfName% "Green44.green_44") := by
  linarith
#print axioms probe_5_479

-- ATTACK fc-379fc029-green44-green-44-35e0d2eaec-counterexample-v1 nlinarith
theorem probe_5_480 : ¬ (fcTypeOfName% "Green44.green_44") := by
  nlinarith
#print axioms probe_5_480

-- ATTACK fc-379fc029-green44-green-44-35e0d2eaec-counterexample-v1 intros_simp_all
theorem probe_5_481 : ¬ (fcTypeOfName% "Green44.green_44") := by
  intros
  simp_all
#print axioms probe_5_481

-- ATTACK fc-379fc029-green44-green-44-35e0d2eaec-counterexample-v1 intros_omega
theorem probe_5_482 : ¬ (fcTypeOfName% "Green44.green_44") := by
  intros
  omega
#print axioms probe_5_482

-- ATTACK fc-379fc029-green44-green-44-35e0d2eaec-counterexample-v1 intros_norm_num
theorem probe_5_483 : ¬ (fcTypeOfName% "Green44.green_44") := by
  intros
  norm_num at *
#print axioms probe_5_483

-- ATTACK fc-379fc029-green44-green-44-35e0d2eaec-counterexample-v1 intros_aesop
theorem probe_5_484 : ¬ (fcTypeOfName% "Green44.green_44") := by
  intros
  aesop
#print axioms probe_5_484

-- ATTACK fc-379fc029-green44-green-44-35e0d2eaec-counterexample-v1 by_contra_simp_all
theorem probe_5_485 : ¬ (fcTypeOfName% "Green44.green_44") := by
  by_contra h
  simp_all
#print axioms probe_5_485

-- ATTACK fc-379fc029-green44-green-44-35e0d2eaec-counterexample-v1 classical_simp_all
theorem probe_5_486 : ¬ (fcTypeOfName% "Green44.green_44") := by
  classical
  simp_all
#print axioms probe_5_486

-- ATTACK fc-379fc029-green44-green-44-35e0d2eaec-counterexample-v1 classical_aesop
theorem probe_5_487 : ¬ (fcTypeOfName% "Green44.green_44") := by
  classical
  aesop
#print axioms probe_5_487

-- ATTACK fc-379fc029-green44-green-44-35e0d2eaec-counterexample-v1 refine_pair_simp
theorem probe_5_488 : ¬ (fcTypeOfName% "Green44.green_44") := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_5_488

-- ATTACK fc-379fc029-green44-green-44-35e0d2eaec-counterexample-v1 refine_pair_aesop
theorem probe_5_489 : ¬ (fcTypeOfName% "Green44.green_44") := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_5_489

-- ATTACK fc-379fc029-green44-green-44-35e0d2eaec-counterexample-v1 use_zero_simp
theorem probe_5_490 : ¬ (fcTypeOfName% "Green44.green_44") := by
  use 0 <;> simp
#print axioms probe_5_490

-- ATTACK fc-379fc029-green44-green-44-35e0d2eaec-counterexample-v1 use_one_simp
theorem probe_5_491 : ¬ (fcTypeOfName% "Green44.green_44") := by
  use 1 <;> simp
#print axioms probe_5_491

-- ATTACK fc-379fc029-green44-green-44-35e0d2eaec-counterexample-v1 use_empty_simp
theorem probe_5_492 : ¬ (fcTypeOfName% "Green44.green_44") := by
  use ∅ <;> simp
#print axioms probe_5_492

-- ATTACK fc-379fc029-green44-green-44-35e0d2eaec-counterexample-v1 assumption
theorem probe_5_493 : ¬ (fcTypeOfName% "Green44.green_44") := by
  assumption
#print axioms probe_5_493

-- ATTACK fc-379fc029-green44-green-44-35e0d2eaec-counterexample-v1 infer_instance
theorem probe_5_494 : ¬ (fcTypeOfName% "Green44.green_44") := by
  infer_instance
#print axioms probe_5_494

-- ATTACK fc-379fc029-green44-green-44-35e0d2eaec-counterexample-v1 contradiction
theorem probe_5_495 : ¬ (fcTypeOfName% "Green44.green_44") := by
  contradiction
#print axioms probe_5_495

-- ATTACK fc-379fc029-green44-green-44-35e0d2eaec-counterexample-v1 solve_by_elim
theorem probe_5_496 : ¬ (fcTypeOfName% "Green44.green_44") := by
  solve_by_elim
#print axioms probe_5_496

-- ATTACK fc-379fc029-green44-green-44-35e0d2eaec-counterexample-v1 first_order
theorem probe_5_497 : ¬ (fcTypeOfName% "Green44.green_44") := by
  first_order
#print axioms probe_5_497

-- ATTACK fc-379fc029-green44-green-44-35e0d2eaec-counterexample-v1 grind
theorem probe_5_498 : ¬ (fcTypeOfName% "Green44.green_44") := by
  grind
#print axioms probe_5_498

-- ATTACK fc-379fc029-green44-green-44-35e0d2eaec-counterexample-v1 exact_search
theorem probe_5_499 : ¬ (fcTypeOfName% "Green44.green_44") := by
  exact?
#print axioms probe_5_499

-- ATTACK fc-379fc029-green44-green-44-35e0d2eaec-counterexample-v1 apply_search
theorem probe_5_500 : ¬ (fcTypeOfName% "Green44.green_44") := by
  apply?
#print axioms probe_5_500

-- ATTACK fc-379fc029-green44-green-44-35e0d2eaec-counterexample-v1 library_search
theorem probe_5_501 : ¬ (fcTypeOfName% "Green44.green_44") := by
  library_search
#print axioms probe_5_501

-- ATTACK fc-379fc029-green44-green-44-35e0d2eaec-counterexample-v1 aesop_search
theorem probe_5_502 : ¬ (fcTypeOfName% "Green44.green_44") := by
  aesop?
#print axioms probe_5_502

-- ATTACK fc-379fc029-green44-green-44-35e0d2eaec-counterexample-v1 simp_search
theorem probe_5_503 : ¬ (fcTypeOfName% "Green44.green_44") := by
  simp?
#print axioms probe_5_503

end AttackBattery
