import FormalConjectures.ErdosProblems.«700»
import TaskSupport

set_option maxHeartbeats 20000
namespace AttackBattery

-- ATTACK fc-379fc029-parts-ii-8d5ce1a920-formalized-v1 simp
theorem probe_2_0 : fcTypeOfName% "Erdos700.erdos_700.parts.ii" := by
  simp
#print axioms probe_2_0

-- ATTACK fc-379fc029-parts-ii-8d5ce1a920-formalized-v1 simpa
theorem probe_2_1 : fcTypeOfName% "Erdos700.erdos_700.parts.ii" := by
  simpa
#print axioms probe_2_1

-- ATTACK fc-379fc029-parts-ii-8d5ce1a920-formalized-v1 simp_all
theorem probe_2_2 : fcTypeOfName% "Erdos700.erdos_700.parts.ii" := by
  simp_all
#print axioms probe_2_2

-- ATTACK fc-379fc029-parts-ii-8d5ce1a920-formalized-v1 aesop
theorem probe_2_3 : fcTypeOfName% "Erdos700.erdos_700.parts.ii" := by
  aesop
#print axioms probe_2_3

-- ATTACK fc-379fc029-parts-ii-8d5ce1a920-formalized-v1 omega
theorem probe_2_4 : fcTypeOfName% "Erdos700.erdos_700.parts.ii" := by
  omega
#print axioms probe_2_4

-- ATTACK fc-379fc029-parts-ii-8d5ce1a920-formalized-v1 norm_num
theorem probe_2_5 : fcTypeOfName% "Erdos700.erdos_700.parts.ii" := by
  norm_num
#print axioms probe_2_5

-- ATTACK fc-379fc029-parts-ii-8d5ce1a920-formalized-v1 decide
theorem probe_2_6 : fcTypeOfName% "Erdos700.erdos_700.parts.ii" := by
  decide
#print axioms probe_2_6

-- ATTACK fc-379fc029-parts-ii-8d5ce1a920-formalized-v1 native_decide
theorem probe_2_7 : fcTypeOfName% "Erdos700.erdos_700.parts.ii" := by
  native_decide
#print axioms probe_2_7

-- ATTACK fc-379fc029-parts-ii-8d5ce1a920-formalized-v1 true_intro
theorem probe_2_8 : fcTypeOfName% "Erdos700.erdos_700.parts.ii" := by
  exact True.intro
#print axioms probe_2_8

-- ATTACK fc-379fc029-parts-ii-8d5ce1a920-formalized-v1 false_elim_simp
theorem probe_2_9 : fcTypeOfName% "Erdos700.erdos_700.parts.ii" := by
  apply False.elim
  simp_all
#print axioms probe_2_9

-- ATTACK fc-379fc029-parts-ii-8d5ce1a920-formalized-v1 constructor
theorem probe_2_10 : fcTypeOfName% "Erdos700.erdos_700.parts.ii" := by
  constructor
#print axioms probe_2_10

-- ATTACK fc-379fc029-parts-ii-8d5ce1a920-formalized-v1 constructor_simp
theorem probe_2_11 : fcTypeOfName% "Erdos700.erdos_700.parts.ii" := by
  constructor <;> simp
#print axioms probe_2_11

-- ATTACK fc-379fc029-parts-ii-8d5ce1a920-formalized-v1 constructor_aesop
theorem probe_2_12 : fcTypeOfName% "Erdos700.erdos_700.parts.ii" := by
  constructor <;> aesop
#print axioms probe_2_12

-- ATTACK fc-379fc029-parts-ii-8d5ce1a920-formalized-v1 rfl
theorem probe_2_13 : fcTypeOfName% "Erdos700.erdos_700.parts.ii" := by
  rfl
#print axioms probe_2_13

-- ATTACK fc-379fc029-parts-ii-8d5ce1a920-formalized-v1 trivial
theorem probe_2_14 : fcTypeOfName% "Erdos700.erdos_700.parts.ii" := by
  trivial
#print axioms probe_2_14

-- ATTACK fc-379fc029-parts-ii-8d5ce1a920-formalized-v1 tauto
theorem probe_2_15 : fcTypeOfName% "Erdos700.erdos_700.parts.ii" := by
  tauto
#print axioms probe_2_15

-- ATTACK fc-379fc029-parts-ii-8d5ce1a920-formalized-v1 positivity
theorem probe_2_16 : fcTypeOfName% "Erdos700.erdos_700.parts.ii" := by
  positivity
#print axioms probe_2_16

-- ATTACK fc-379fc029-parts-ii-8d5ce1a920-formalized-v1 linarith
theorem probe_2_17 : fcTypeOfName% "Erdos700.erdos_700.parts.ii" := by
  linarith
#print axioms probe_2_17

-- ATTACK fc-379fc029-parts-ii-8d5ce1a920-formalized-v1 nlinarith
theorem probe_2_18 : fcTypeOfName% "Erdos700.erdos_700.parts.ii" := by
  nlinarith
#print axioms probe_2_18

-- ATTACK fc-379fc029-parts-ii-8d5ce1a920-formalized-v1 intros_simp_all
theorem probe_2_19 : fcTypeOfName% "Erdos700.erdos_700.parts.ii" := by
  intros
  simp_all
#print axioms probe_2_19

-- ATTACK fc-379fc029-parts-ii-8d5ce1a920-formalized-v1 intros_omega
theorem probe_2_20 : fcTypeOfName% "Erdos700.erdos_700.parts.ii" := by
  intros
  omega
#print axioms probe_2_20

-- ATTACK fc-379fc029-parts-ii-8d5ce1a920-formalized-v1 intros_norm_num
theorem probe_2_21 : fcTypeOfName% "Erdos700.erdos_700.parts.ii" := by
  intros
  norm_num at *
#print axioms probe_2_21

-- ATTACK fc-379fc029-parts-ii-8d5ce1a920-formalized-v1 intros_aesop
theorem probe_2_22 : fcTypeOfName% "Erdos700.erdos_700.parts.ii" := by
  intros
  aesop
#print axioms probe_2_22

-- ATTACK fc-379fc029-parts-ii-8d5ce1a920-formalized-v1 by_contra_simp_all
theorem probe_2_23 : fcTypeOfName% "Erdos700.erdos_700.parts.ii" := by
  by_contra h
  simp_all
#print axioms probe_2_23

-- ATTACK fc-379fc029-parts-ii-8d5ce1a920-formalized-v1 classical_simp_all
theorem probe_2_24 : fcTypeOfName% "Erdos700.erdos_700.parts.ii" := by
  classical
  simp_all
#print axioms probe_2_24

-- ATTACK fc-379fc029-parts-ii-8d5ce1a920-formalized-v1 classical_aesop
theorem probe_2_25 : fcTypeOfName% "Erdos700.erdos_700.parts.ii" := by
  classical
  aesop
#print axioms probe_2_25

-- ATTACK fc-379fc029-parts-ii-8d5ce1a920-formalized-v1 refine_pair_simp
theorem probe_2_26 : fcTypeOfName% "Erdos700.erdos_700.parts.ii" := by
  refine ⟨?_, ?_⟩ <;> simp
#print axioms probe_2_26

-- ATTACK fc-379fc029-parts-ii-8d5ce1a920-formalized-v1 refine_pair_aesop
theorem probe_2_27 : fcTypeOfName% "Erdos700.erdos_700.parts.ii" := by
  refine ⟨?_, ?_⟩ <;> aesop
#print axioms probe_2_27

-- ATTACK fc-379fc029-parts-ii-8d5ce1a920-formalized-v1 use_zero_simp
theorem probe_2_28 : fcTypeOfName% "Erdos700.erdos_700.parts.ii" := by
  use 0 <;> simp
#print axioms probe_2_28

-- ATTACK fc-379fc029-parts-ii-8d5ce1a920-formalized-v1 use_one_simp
theorem probe_2_29 : fcTypeOfName% "Erdos700.erdos_700.parts.ii" := by
  use 1 <;> simp
#print axioms probe_2_29

-- ATTACK fc-379fc029-parts-ii-8d5ce1a920-formalized-v1 use_empty_simp
theorem probe_2_30 : fcTypeOfName% "Erdos700.erdos_700.parts.ii" := by
  use ∅ <;> simp
#print axioms probe_2_30

-- ATTACK fc-379fc029-parts-ii-8d5ce1a920-formalized-v1 assumption
theorem probe_2_31 : fcTypeOfName% "Erdos700.erdos_700.parts.ii" := by
  assumption
#print axioms probe_2_31

-- ATTACK fc-379fc029-parts-ii-8d5ce1a920-formalized-v1 infer_instance
theorem probe_2_32 : fcTypeOfName% "Erdos700.erdos_700.parts.ii" := by
  infer_instance
#print axioms probe_2_32

-- ATTACK fc-379fc029-parts-ii-8d5ce1a920-formalized-v1 contradiction
theorem probe_2_33 : fcTypeOfName% "Erdos700.erdos_700.parts.ii" := by
  contradiction
#print axioms probe_2_33

-- ATTACK fc-379fc029-parts-ii-8d5ce1a920-formalized-v1 solve_by_elim
theorem probe_2_34 : fcTypeOfName% "Erdos700.erdos_700.parts.ii" := by
  solve_by_elim
#print axioms probe_2_34

-- ATTACK fc-379fc029-parts-ii-8d5ce1a920-formalized-v1 first_order
theorem probe_2_35 : fcTypeOfName% "Erdos700.erdos_700.parts.ii" := by
  first_order
#print axioms probe_2_35

-- ATTACK fc-379fc029-parts-ii-8d5ce1a920-formalized-v1 grind
theorem probe_2_36 : fcTypeOfName% "Erdos700.erdos_700.parts.ii" := by
  grind
#print axioms probe_2_36

-- ATTACK fc-379fc029-parts-ii-8d5ce1a920-formalized-v1 exact_search
theorem probe_2_37 : fcTypeOfName% "Erdos700.erdos_700.parts.ii" := by
  exact?
#print axioms probe_2_37

-- ATTACK fc-379fc029-parts-ii-8d5ce1a920-formalized-v1 apply_search
theorem probe_2_38 : fcTypeOfName% "Erdos700.erdos_700.parts.ii" := by
  apply?
#print axioms probe_2_38

-- ATTACK fc-379fc029-parts-ii-8d5ce1a920-formalized-v1 library_search
theorem probe_2_39 : fcTypeOfName% "Erdos700.erdos_700.parts.ii" := by
  library_search
#print axioms probe_2_39

-- ATTACK fc-379fc029-parts-ii-8d5ce1a920-formalized-v1 aesop_search
theorem probe_2_40 : fcTypeOfName% "Erdos700.erdos_700.parts.ii" := by
  aesop?
#print axioms probe_2_40

-- ATTACK fc-379fc029-parts-ii-8d5ce1a920-formalized-v1 simp_search
theorem probe_2_41 : fcTypeOfName% "Erdos700.erdos_700.parts.ii" := by
  simp?
#print axioms probe_2_41

end AttackBattery
