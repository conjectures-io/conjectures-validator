# Erdős Problem 1059: Lean 4 formalization

**Paper:** [*A proposed solution to Erdős Problem 1059: Prime avoidance for a sparse set of shifts*](erdos_1059_full_proof.pdf) (Johan Land, 5 September 2026; revised after an adversarial validation pass).
The manuscript gives a proposed unconditional proof that infinitely many primes $p$ have $p - k!$ composite for every factorial $k! < p$. The argument establishes the stronger assertion that any $o(\log X)$ distinct shifts in $[1, X]$ can all be subtracted from some prime $p \in (2X, 3X]$ with composite results. This repository contains the complete Lean 4 formalization of the paper's theorems.

## Verification transcript

`lake build` on the verified tree produces no errors and no warnings; the single info line is the axiom report of the terminal theorem, printed by `Erdos1059/BuildAudit.lean`:

```console
$ cat lean-toolchain
leanprover/lean4:v4.34.0-rc2
$ lake build
ℹ [8948/8950] Replayed Erdos1059.BuildAudit
info: Erdos1059/BuildAudit.lean:18:0: 'Erdos1059.infinitelyManyFactorialAvoidingPrimes' depends on axioms: [propext, Classical.choice, Quot.sound]
Build completed successfully (8950 jobs).
```

`propext`, `Classical.choice`, and `Quot.sound` are [Lean's standard foundational axioms](https://lean-lang.org/theorem_proving_in_lean4/Axioms-and-Computation/). No `sorryAx`, no `Lean.ofReduceBool`, and no project-declared axiom appears: the terminal theorem `Erdos1059.infinitelyManyFactorialAvoidingPrimes` is proved using Mathlib (`v4.34.0-rc2`, revision `85e3a25e`, pinned in `lake-manifest.json`) and vendored proved lemmas under `Erdos1059/Analytic/`, with only standard foundational axioms.

Build-time assertions in [`Erdos1059/BuildAudit.lean`](Erdos1059/BuildAudit.lean) assert standard axioms for all three endpoints (`sparseShiftTheorem`, `factorialIntervalTheorem`, `infinitelyManyFactorialAvoidingPrimes`), printing the axiom report for the terminal theorem. The transcript above is an excerpt based on a recorded run (see [`docs/verification/lake-build.log`](docs/verification/lake-build.log)). It was recorded at git HEAD `f18787cdae3948bb3d7cf3de4651878bb16fd3db` with a modified working tree (the formalization files are largely untracked; this HEAD does not represent a completed clean source revision or release certificate). No independent replication or external audit is recorded here.

## How to read this repository

The trust chain has two distinct links, plus the integrity of the checking environment:

1. **The statement of faithfulness** (reproduced below). It is a correspondence explanation requiring human assessment. It states the claim that the formal propositions in [`Erdos1059/Statements.lean`](Erdos1059/Statements.lean) faithfully capture Erdős Problem 1059 and the manuscript's theorems; no machine can verify that a Lean type matches mathematical intention. No independent human audit of this correspondence is recorded here.
2. **The Lean kernel.** Once the terminal theorem `Erdos1059.infinitelyManyFactorialAvoidingPrimes` (lowercase `i`; the proof of `InfinitelyManyFactorialAvoidingPrimes`) is checked by Lean's kernel and `#print axioms` reports only `propext`, `Classical.choice`, and `Quot.sound`, the manuscript's analytic arguments, the tactics, the AI agents that assisted in writing proof scripts, and cited literature need not be trusted as mathematical authorities: the kernel-checked proof terms and their transitive dependencies supply the formal guarantee.

Trust remains in this human-formal correspondence, in Lean's logical foundations and checker, and in the integrity of the checking environment and source files.

## Statement of faithfulness

*Note: This explanation was prepared with AI assistance; no independent human audit or author certification of the full correspondence is recorded here.*

This statement examines the formal propositions in [`Erdos1059/Statements.lean`](Erdos1059/Statements.lean) and their connections to Erdős Problem 1059 and the paper. The exact declarations defining the terminal problem are:

```lean
/-- Strict compositeness: in particular, neither zero nor one is composite. -/
def Composite (n : ℕ) : Prop := 1 < n ∧ ¬ Nat.Prime n

/-- Including `k = 0` is harmless, since `0! = 1!`. Natural subtraction is only used
under the explicit hypothesis `k! < p`. -/
def FactorialAvoidingPrime (p : ℕ) : Prop :=
  Nat.Prime p ∧ ∀ k : ℕ, Nat.factorial k < p → Composite (p - Nat.factorial k)

/-- The final target, with strict compositeness. -/
def InfinitelyManyFactorialAvoidingPrimes : Prop := Set.Infinite {p : ℕ | FactorialAvoidingPrime p}
```

The manuscript's intermediate targets (Theorem 1 and Corollary 1) are formalized as:

```lean
/-- The uniform conclusion for a prescribed bound on the number of shifts. -/
def SparseShiftAvoidance (K : ℝ → ℕ) : Prop :=
  ∃ X₀ : ℝ, ∀ X : ℝ, X₀ ≤ X → ∀ H : Finset ℕ,
    (∀ h ∈ H, 1 ≤ h ∧ (h : ℝ) ≤ X) → H.card ≤ K X →
    ∃ p : ℕ, Nat.Prime p ∧ 2 * X < (p : ℝ) ∧ (p : ℝ) ≤ 3 * X ∧
      ∀ h ∈ H, Composite (p - h)

def SparseShiftTheorem : Prop :=
  ∀ K : ℝ → ℕ,
    Asymptotics.IsLittleO Filter.atTop (fun X => (K X : ℝ)) Real.log →
    SparseShiftAvoidance K

def FactorialIntervalTheorem : Prop :=
  ∃ M : ℕ, ∀ m : ℕ, M ≤ m →
    ∃ p : ℕ, 2 * Nat.factorial m < p ∧ p ≤ 3 * Nat.factorial m ∧
      FactorialAvoidingPrime p
```

The mathematical conventions and definitions address the problem as follows:

- **Strict compositeness:** `Composite n` requires $1 < n$ and $\neg \text{Nat.Prime } n$. In particular, 0 and 1 are not composite. For example, $2 - 1! = 1$ is not composite, excluding $p = 2$ from this strict target.
- **Factorial at $k = 0$:** Quantifying over all $k \in \mathbb{N}$ includes $k = 0$. Because $0! = 1 = 1!$, this introduces no shift other than $1!$ and leaves the set of required differences unchanged.
- **Natural subtraction under guard:** In Lean, $p - k!$ operates on `ℕ` (where $a - b = 0$ for $a \le b$). Here, natural subtraction is strictly guarded by the hypothesis $k! < p$, guaranteeing $p - k! \ge 1$ without truncating to zero.
- **Infinitude:** `InfinitelyManyFactorialAvoidingPrimes` defines the set of factorial-avoiding primes and asserts `Set.Infinite`, meaning infinitely many distinct prime numbers satisfy the property.
- **Envelope function and uniform threshold:** The envelope $K : \mathbb{R} \to \mathbb{N}$ is natural-valued, translating any non-negative real cardinality bound $C(X) = o(\log X)$ by taking its natural floor $\lfloor C(X) \rfloor$ (a mathematical translation, not a claimed compiled equivalence). In `SparseShiftAvoidance K`, the threshold $X_0 : \mathbb{R}$ depends only on the envelope $K$, and is strictly independent of the specific shift set $H$ and scale $X$.
- **Distinct shifts:** The shift set $H$ is a `Finset ℕ`, natively guaranteeing that its elements are pairwise distinct.
- **Real interval endpoints:** The conditions $2X < (p : ℝ) \le 3X$ and $(h : ℝ) \le X$ cast natural numbers to $\mathbb{R}$, matching the continuous scaling of the analytic sieve.
- **Implication chain:** In [`Erdos1059/FactorialGrowth.lean`](Erdos1059/FactorialGrowth.lean) and [`Erdos1059/Elementary.lean`](Erdos1059/Elementary.lean), the project proves `SparseShiftTheorem → FactorialIntervalTheorem → InfinitelyManyFactorialAvoidingPrimes`:
  - Factorial growth satisfies $m = o(\log(m!))$, enabling the definition of an envelope `factorialEnvelope X` with $(K(X) : \mathbb{R}) = o(\log X)$.
  - For $p \in (2 \cdot m!, 3 \cdot m!]$ with $m \ge 3$, any factorial $k! < p$ must satisfy $k \le m$ (as $(m+1)! > 3 \cdot m!$).
  - The interval theorem produces primes exceeding $2 \cdot m!$, which grow without bound as $m \to \infty$, establishing infinitude via `Set.infinite_of_forall_exists_gt`.

**Comparison with Formal Conjectures:** Our final theorem proves the affirmative statement of [Erdős Problem 1059 in Formal Conjectures](https://github.com/google-deepmind/formal-conjectures/blob/c252a41054125b5fd9c8356e2137cd9b55337657/FormalConjectures/ErdosProblems/1059.lean): infinitely many primes $p$ have $p - k!$ composite for every factorial $k! < p$. The two formulations are mathematically equivalent. Formal Conjectures quantifies over factorial values; ours quantifies over factorial indices. Both use strict compositeness, excluding 0 and 1.

## Verification and reproducibility

Verification artifacts and logs:

- [`docs/VERIFICATION.md`](docs/VERIFICATION.md): Verification procedure and environment summary.
- [`docs/verification/source-files.sha256`](docs/verification/source-files.sha256): SHA-256 digest catalog of the 206 proof and provenance files in this snapshot.
- [`docs/verification/lake-build.log`](docs/verification/lake-build.log): Recorded incremental build log.

The formalization is recorded as a dirty/untracked working tree snapshot at git HEAD `f18787cdae3948bb3d7cf3de4651878bb16fd3db` without a formal release tag or clean commit certificate.

### Standalone kernel verification

Reproduction requires [elan](https://github.com/leanprover/elan) (the Lean toolchain manager). To verify the build and test the terminal theorems with explicit type ascriptions:

```sh
# Fetch cached Mathlib binaries and build project
lake exe cache get
lake build

# Write a standalone scratch check file
mkdir -p .lake
cat << 'EOF' > .lake/example-audit.lean
import Erdos1059.FinalProof

#check (Erdos1059.sparseShiftTheorem : Erdos1059.SparseShiftTheorem)
#check (Erdos1059.factorialIntervalTheorem : Erdos1059.FactorialIntervalTheorem)
#check (Erdos1059.infinitelyManyFactorialAvoidingPrimes : Erdos1059.InfinitelyManyFactorialAvoidingPrimes)

#print axioms Erdos1059.sparseShiftTheorem
#print axioms Erdos1059.factorialIntervalTheorem
#print axioms Erdos1059.infinitelyManyFactorialAvoidingPrimes
EOF

# Execute standalone kernel check
lake env lean .lake/example-audit.lean
```

Each `#print axioms` line outputs exactly `[propext, Classical.choice, Quot.sound]`.

### Comprehensive audit script

Running `bash scripts/check.sh` executes the full verification pipeline:

1. `python3 scripts/check_axioms.py`: Scans all project Lean sources for forbidden tokens (`sorry`, `admit`, `axiom`, `unsafe`, `native_decide`) after stripping comments and strings.
2. `lake build`: Builds the project and evaluates compile-time assertions in [`Erdos1059/BuildAudit.lean`](Erdos1059/BuildAudit.lean).
3. `lake env lean -DwarningAsError=true Audit.lean | tee .lake/axiom-audit.log`: Evaluates `#print axioms` across all 1146 declarations in [`Audit.lean`](Audit.lean).
4. `python3 scripts/check_axioms.py .lake/axiom-audit.log`: Validates that all 1146 axiom reports depend strictly on Lean's standard foundations.

## Paper-to-Lean correspondence

The table below maps components of the manuscript (`erdos_1059_full_proof.pdf`) to Lean implementation files. A detailed section-and-lemma map is provided in [`docs/PAPER_CORRESPONDENCE.md`](docs/PAPER_CORRESPONDENCE.md).

| Paper component | Section / Equations | Principal Lean modules |
|---|---|---|
| Target statements & compositeness | Section 1 | [`Erdos1059/Statements.lean`](Erdos1059/Statements.lean) |
| Factorial reduction & interval witnesses | Section 1, Theorem 1, Corollary 1 | [`Erdos1059/Elementary.lean`](Erdos1059/Elementary.lean), [`Erdos1059/FactorialGrowth.lean`](Erdos1059/FactorialGrowth.lean) |
| Sieve parameters & auxiliary primes | Section 2, Eq. (1)–(2) | [`Erdos1059/Parameters.lean`](Erdos1059/Parameters.lean), [`Erdos1059/AuxiliaryPrimes.lean`](Erdos1059/AuxiliaryPrimes.lean), [`Erdos1059/OmittedPrimes.lean`](Erdos1059/OmittedPrimes.lean) |
| Reciprocal-log coefficients & Lemma 1 | Section 2, Eq. (3)–(7), Lemma 1 | [`Erdos1059/Coefficients.lean`](Erdos1059/Coefficients.lean), [`Erdos1059/CoefficientEstimates.lean`](Erdos1059/CoefficientEstimates.lean), [`Erdos1059/NormalizerBounds.lean`](Erdos1059/NormalizerBounds.lean) |
| Local coordinates & finite unit identities | Section 3, Eq. (8) | [`Erdos1059/LocalFactors.lean`](Erdos1059/LocalFactors.lean), [`Erdos1059/PrimeCoordinates.lean`](Erdos1059/PrimeCoordinates.lean) |
| Truncated product, Gram bounds & Lemma 2 | Section 3, Eq. (9)–(15), Lemma 2 | [`Erdos1059/Supports.lean`](Erdos1059/Supports.lean), [`Erdos1059/GramBound.lean`](Erdos1059/GramBound.lean), [`Erdos1059/ProductGram.lean`](Erdos1059/ProductGram.lean), [`Erdos1059/PrincipalMoment.lean`](Erdos1059/PrincipalMoment.lean), [`Erdos1059/ResidualMoment.lean`](Erdos1059/ResidualMoment.lean) |
| Character Fourier bounds & Lemma 3 | Section 4, Eq. (16)–(20), Lemma 3 | [`Erdos1059/LemmaThree.lean`](Erdos1059/LemmaThree.lean), [`Erdos1059/SieveFourier.lean`](Erdos1059/SieveFourier.lean) |
| Vaughan mean value & prime averaging | Section 4, Eq. (21)–(23), Lemma 4 | [`Erdos1059/Analytic/PrimeAverages.lean`](Erdos1059/Analytic/PrimeAverages.lean), [`Erdos1059/FourierTransfer.lean`](Erdos1059/FourierTransfer.lean), [`Erdos1059/SievePrimeTransfer.lean`](Erdos1059/SievePrimeTransfer.lean) |
| Moment comparison & final assembly | Section 5 | [`Erdos1059/PrimeMomentComparison.lean`](Erdos1059/PrimeMomentComparison.lean), [`Erdos1059/SparseShiftAssembly.lean`](Erdos1059/SparseShiftAssembly.lean), [`Erdos1059/FinalProof.lean`](Erdos1059/FinalProof.lean) |
| Build-time axiom verification | — | [`Erdos1059/BuildAudit.lean`](Erdos1059/BuildAudit.lean), [`Erdos1059/AxiomCheck.lean`](Erdos1059/AxiomCheck.lean), [`Audit.lean`](Audit.lean) |

## Layout

- `erdos_1059_full_proof.pdf`: The manuscript accompanying this formalization.
- `Erdos1059/`: Lean source code for the formalization; `FinalProof.lean` holds the terminal theorems.
- `Erdos1059/Analytic/`: Analytic number theory foundations, including vendored libraries and prime transfer.
- `Audit.lean`: List of 1146 declarations audited by the test pipeline.
- `scripts/`: Verification scripts (`check.sh` and `check_axioms.py`).
- `third_party/`: Upstream notices, licenses, and correspondence manifests for vendored components.
- `docs/`: Verification records (`docs/verification/`), detailed correspondence mapping ([`docs/PAPER_CORRESPONDENCE.md`](docs/PAPER_CORRESPONDENCE.md)), and verification summary ([`docs/VERIFICATION.md`](docs/VERIFICATION.md)). Working documents [`FORMALIZATION.md`](FORMALIZATION.md) and [`ANALYTIC_AUDIT.md`](ANALYTIC_AUDIT.md) document current status alongside historical development checkpoints, while [`EXPERT_REVIEW.md`](EXPERT_REVIEW.md) and planning logs record earlier historical iterations.
- `lakefile.toml`, `lake-manifest.json`, `lean-toolchain`: Project configuration pinning Lean `v4.34.0-rc2` and Mathlib `85e3a25e`.

## Authorship and use of AI

**Paper Author:** Johan Land, 5 September 2026.

**AI Provenance in Manuscript:** The paper acknowledges the use of three large language models: GPT-6-Astra (OpenAI), Claude Fable 5.1 (Anthropic), and Gemini 3.8 (Google).
