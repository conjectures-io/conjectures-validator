example : True := by
  trivial
