# Synthetic example package

Shows the shape of a chat-log package. Never eligible.
